#pragma once
#include <cstdint>
#include <BWAPI/Client/GameData.h>

namespace PlutoSCR {
constexpr std::uint32_t Magic = 0x52534350; // PCSR
constexpr std::uint32_t Version = 4;
constexpr wchar_t ControlMapping[] = L"Local\\PlutoSCR_Control_v4";
constexpr wchar_t GameDataMapping[] = L"Local\\PlutoSCR_GameData_v4";

enum class State : std::uint32_t { Empty, RuntimeReady, HostReady, InGame, Stopping, Fault };

#pragma pack(push, 8)
struct Control {
  std::uint32_t magic;
  std::uint32_t version;
  volatile LONG state;

  // Seqlock: odd while x64 runtime writes state; even when stable.
  volatile LONG stateSequence;
  volatile LONG publishedFrame;
  volatile LONG consumedFrame;

  // x86 host increments after Pluto returns from callbacks.
  volatile LONG commandSequence;
  volatile LONG drainedCommandSequence;

  volatile LONG lastCommandCount;
  volatile LONG lastUnitCommandCount;
  volatile LONG rejectedCommands;
  volatile LONG lastError;
};
#pragma pack(pop)

static_assert(sizeof(BWAPIC::Command) == 12, "BWAPIClient Command ABI drift");
static_assert(sizeof(BWAPIC::UnitCommand) == 24, "BWAPIClient UnitCommand ABI drift");
}
