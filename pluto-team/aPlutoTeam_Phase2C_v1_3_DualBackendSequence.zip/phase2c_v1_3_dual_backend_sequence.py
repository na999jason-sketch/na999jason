from __future__ import annotations
import argparse, hashlib, json, struct, subprocess, threading
from pathlib import Path
import numpy as np
import torch
from pluto_trunk import PlutoFirstStep, linear

RESP=struct.Struct('<qqqqff'); REQ_HDR=struct.Struct('<iiiIqqqq')

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c: raise EOFError(f'expected {n}, got {len(b)}')
        b+=c
    return bytes(b)

def parse_resp(raw):
    a,arg,pos,unit,win,lp=RESP.unpack(raw)
    return {'action':int(a),'arg':int(arg),'pos':int(pos),'unit':int(unit),'win':float(win),'logprob':float(lp),'hex':raw.hex()}

def req_size(n): return 0x30+n*48+n*436+n+n+20+233+292*4+128*128*2+128*128+32

def parse_req(raw):
    n,w,h,flags,f0,f1,f2,f3=REQ_HDR.unpack_from(raw,0)
    if (w,h)!=(128,128) or len(raw)!=req_size(n): raise ValueError('bad request')
    off=0x30
    cat=np.frombuffer(raw,dtype='<i8',count=n*6,offset=off).copy().reshape(n,6);off+=n*48
    cont=np.frombuffer(raw,dtype='<f4',count=n*109,offset=off).copy().reshape(n,109);off+=n*436
    actor=np.frombuffer(raw,dtype=np.uint8,count=n,offset=off).copy();off+=n
    target=np.frombuffer(raw,dtype=np.uint8,count=n,offset=off).copy();off+=n
    action_mask=np.frombuffer(raw,dtype=np.uint8,count=20,offset=off).copy();off+=20
    arg_mask=np.frombuffer(raw,dtype=np.uint8,count=233,offset=off).copy();off+=233
    glob=np.frombuffer(raw,dtype='<f4',count=292,offset=off).copy();off+=292*4
    bits=np.frombuffer(raw,dtype='<u2',count=128*128,offset=off).copy().reshape(128,128);off+=128*128*2
    static=np.frombuffer(raw,dtype=np.uint8,count=128*128,offset=off).copy().reshape(128,128);off+=128*128
    hist=np.frombuffer(raw,dtype='<i8',count=4,offset=off).copy();off+=32
    return {'n':n,'cat':torch.from_numpy(cat).long(),'cont':torch.from_numpy(cont).float(),
            'global':torch.from_numpy(glob).float(),'bits':torch.from_numpy(bits.astype(np.int64,copy=False)).long(),
            'static':torch.from_numpy(static.astype(np.int64,copy=False)).long(),'hist':torch.from_numpy(hist).long(),
            'action_mask':action_mask,'actor_mask':actor,'target_mask':target,'arg_mask':arg_mask,'forced':[f0,f1,f2,f3]}

def run_engine_sequence(exe,weights,backend,threads,requests,stderr_path,timeout_s=300):
    cmd=[str(exe),'--blob',str(weights),'--backend',backend,'--threads',str(threads),'--seed','123456789','--argmax']
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=flags,bufsize=0)
    err=[]
    def drain():
        while True:
            c=p.stderr.read(65536)
            if not c: break
            err.append(c)
    th=threading.Thread(target=drain,daemon=True); th.start()
    try:
        hs=read_exact(p.stdout,0x88)
        magic,ver,fps,maxu,step,label,build=struct.unpack('<4sIiiq48s64s',hs)
        if magic.rstrip(b'\0')!=b'PLO1' or ver!=3: raise RuntimeError('bad handshake')
        print(f'ENGINE_HANDSHAKE backend={backend} label={label.rstrip(chr(0).encode()).decode(errors="replace")} build={build.rstrip(chr(0).encode()).decode(errors="replace")}',flush=True)
        out=[]
        for i,r in enumerate(requests,1):
            p.stdin.write(r); p.stdin.flush(); out.append(read_exact(p.stdout,0x28))
            if i<=4 or i%16==0: print(f'ENGINE_STEP backend={backend} {i}/{len(requests)} action={parse_resp(out[-1])["action"]}',flush=True)
        p.stdin.close()
        try: rc=p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired: p.kill(); rc=p.wait(timeout=10)
        th.join(timeout=10); stderr_path.write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
        if rc!=0: raise RuntimeError(f'engine {backend} exit {rc}')
        return out
    finally:
        if p.poll() is None: p.kill(); p.wait(timeout=10)

def prepare_feature(m,req):
    u0=m.encode_units(req['cat'],req['cont']); planes=m.assemble_planes(u0,req['cont'],req['bits'],req['static'])
    _,s32,s8=m.spatial_encoder(planes); u1=m.inject_spatial(u0,s32,req['cont']); U=m.encoder(u1); xt=m.global_hist(req['global'],req['hist'])
    return {'s8':s8,'U':U,'xt':xt,'mask':torch.from_numpy(req['action_mask'].astype(bool,copy=False))}

def run_torch_no_slow(m,features):
    h=m.w['gru.h0'].clone(); cache=m.slow_init(); acts=[]; raw=[]
    for f in features:
        h=m.gru_step(f['xt'],h,f['s8'],f['U'],cache[3]); logits=linear(h,m.w['action_head.weight']).float(); raw.append(int(torch.argmax(logits)))
        z=logits.clone(); z[~f['mask']]=-1e30; acts.append(int(torch.argmax(z)))
    return acts,raw

def first_bad(a,b): return next((i+1 for i,(x,y) in enumerate(zip(a,b)) if x!=y),None)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--exe',required=True); ap.add_argument('--int8-weights',required=True); ap.add_argument('--fp32-weights',required=True)
    ap.add_argument('--sequence',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    seq=Path(a.sequence); out=Path(a.out); out.mkdir(parents=True,exist_ok=True); man=json.loads((seq/'manifest.json').read_text(encoding='utf-8'))
    raws=[]; metas=[]
    for x in man['items']:
        r=(seq/x['request_file']).read_bytes()
        if hashlib.sha256(r).hexdigest()!=x['request_sha256']: raise SystemExit('request SHA mismatch')
        raws.append(r); metas.append(x)
    print(f'SEQUENCE_REQUESTS={len(raws)} frames={metas[0]["frame"]}..{metas[-1]["frame"]}')
    i8raw=run_engine_sequence(Path(a.exe),Path(a.int8_weights),'int8mv',1,raws,out/'official_int8.stderr.txt')
    f32raw=run_engine_sequence(Path(a.exe),Path(a.fp32_weights),'pk',4,raws,out/'official_fp32.stderr.txt',timeout_s=600)
    i8=[parse_resp(x) for x in i8raw]; f32=[parse_resp(x) for x in f32raw]
    i8a=[x['action'] for x in i8]; f32a=[x['action'] for x in f32]
    same=sum(x==y for x,y in zip(i8a,f32a)); fb_if=first_bad(i8a,f32a)
    print(f'OFFICIAL_INT8_VS_FP32_ACTION={same}/{len(raws)} first_bad={fb_if}')
    m=PlutoFirstStep(Path(a.int8_weights),'center01'); reqs=[parse_req(r) for r in raws]
    with torch.inference_mode():
        features=[]
        for i,r in enumerate(reqs,1):
            features.append(prepare_feature(m,r))
            if i<=4 or i%16==0: print(f'FEATURE_READY {i}/{len(reqs)}',flush=True)
        ta,traw=run_torch_no_slow(m,features)
    ti=sum(x==y for x,y in zip(ta,i8a)); tf=sum(x==y for x,y in zip(ta,f32a)); all3=sum(x==y==z for x,y,z in zip(ta,i8a,f32a))
    fb_ti=first_bad(ta,i8a); fb_tf=first_bad(ta,f32a)
    print(f'PYTORCH_VS_OFFICIAL_INT8={ti}/{len(raws)} first_bad={fb_ti}')
    print(f'PYTORCH_VS_OFFICIAL_FP32={tf}/{len(raws)} first_bad={fb_tf}')
    print(f'ALL_THREE_ACTION_MATCH={all3}/{len(raws)}')
    if same==len(raws) and tf<len(raws): cls='STRUCTURAL_OR_RECURRENT_ORDER_MISMATCH_CONFIRMED'
    elif same<len(raws) and tf>ti: cls='NUMERIC_BACKEND_DRIFT_CONTRIBUTES'
    elif same<len(raws): cls='MIXED_NUMERIC_AND_STRUCTURE'
    else: cls='FULL_PARITY'
    # divergence detail around every pair's first bad
    piv=sorted({x for x in [fb_if,fb_ti,fb_tf] if x is not None})
    windows=[]
    for p in piv:
        for j in range(max(1,p-2),min(len(raws),p+2)+1):
            windows.append({'step':j,'frame':metas[j-1]['frame'],'int8':i8a[j-1],'fp32':f32a[j-1],'torch':ta[j-1]})
    # unique by step
    windows=list({x['step']:x for x in windows}.values()); windows.sort(key=lambda x:x['step'])
    report={'format':'pluto-team-phase2c-v1.3-dual-backend-sequence','steps':len(raws),'frames':[metas[0]['frame'],metas[-1]['frame']],
            'official_int8_vs_fp32_action_match':same,'official_int8_vs_fp32_first_bad':fb_if,
            'pytorch_vs_int8_action_match':ti,'pytorch_vs_int8_first_bad':fb_ti,
            'pytorch_vs_fp32_action_match':tf,'pytorch_vs_fp32_first_bad':fb_tf,'all_three_match':all3,
            'classification':cls,'divergence_windows':windows,'int8_actions':i8a,'fp32_actions':f32a,'pytorch_actions':ta}
    (out/'phase2c_v1_3_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    txt=['aPlutoTeam Phase2C v1.3 Official INT8 vs FP32 Persistent Sequence',f'steps={len(raws)}',
         f'official_int8_vs_fp32_action={same}/{len(raws)} first_bad={fb_if}',
         f'pytorch_vs_official_int8={ti}/{len(raws)} first_bad={fb_ti}',f'pytorch_vs_official_fp32={tf}/{len(raws)} first_bad={fb_tf}',
         f'all_three_match={all3}/{len(raws)}',f'result_class={cls}','PHASE2C_V1_3_DUAL_BACKEND_SEQUENCE=PASS']
    (out/'phase2c_v1_3_summary.txt').write_text('\n'.join(txt)+'\n',encoding='utf-8'); print('\n'.join(txt))
if __name__=='__main__': main()
