# aPlutoTeam Phase2C v1.3 — Official INT8 vs FP32 Persistent Sequence

Purpose: isolate the remaining sequential divergence found by Phase2C v1.2.

Facts entering this phase:
- v104 real trajectory owner matching is clean.
- seeded official 4-way engine preserves the old 3-way policy exactly on real requests.
- Phase2C v1.1 found a first-step recurrent configuration with 8/8 official action matches.
- Phase2C v1.2 fresh-official vs PyTorch matches the first 13 sequential actions, then diverges.
- the live recorder begins at request 2, so official-persistent-vs-live is not a valid h0 comparison.
- old Phase2B v1.3 already proved quantisation is not the *only* discrepancy on a synthetic probe.

This phase runs the same 64 real requests persistently through:
1. official patched 4-way INT8MV backend,
2. official patched 4-way all-FP32 PK backend,
3. PyTorch dequantized reconstruction (no slow tick, best current sequential baseline).

Interpretation:
- official INT8 == official FP32 for all 64 but PyTorch differs => structural/recurrent ordering remains.
- official INT8 and FP32 diverge and PyTorch follows FP32 better => numeric backend drift contributes.
- both happen => mixed.

No training occurs here.
