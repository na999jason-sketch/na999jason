from __future__ import annotations
import argparse, copy, hashlib, json, struct
from pathlib import Path
import numpy as np
from plwb import PLWB

def align64(n:int)->int: return (n+63)&~63

def file_sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        while True:
            b=f.read(8*1024*1024)
            if not b: break
            h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--output',required=True); ap.add_argument('--manifest',required=True)
    a=ap.parse_args(); src=PLWB(a.input); hdr=copy.deepcopy(src.header)
    hdr['dtype']='float32'; hdr['label']=str(hdr.get('label','pluto'))+'_fp32_recon'
    entries=[]; cursor=0
    for t in src.tensors:
        cursor=align64(cursor); nbytes=t.numel*4
        entries.append({'name':t.name,'shape':list(t.shape),'offset':cursor,'nbytes':nbytes,'dtype':'float32'})
        cursor+=nbytes
    total=align64(cursor); hdr['tensors']=entries; hdr['total_bytes']=total
    hb=json.dumps(hdr,separators=(',',':'),ensure_ascii=False).encode('utf-8'); base=align64(16+len(hb))
    out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('wb') as f:
        f.write(b'PLWB'); f.write(struct.pack('<I',1)); f.write(struct.pack('<Q',len(hb))); f.write(hb); f.write(b'\0'*(base-f.tell()))
        for i,(t,e) in enumerate(zip(src.tensors,entries),1):
            arr=np.asarray(src.dequantized(t.name),dtype='<f4')
            if tuple(arr.shape)!=tuple(t.shape): raise RuntimeError((t.name,arr.shape,t.shape))
            f.seek(base+e['offset']); f.write(arr.tobytes(order='C'))
            if i%40==0 or i==len(entries): print(f'FP32_EXPORT {i}/{len(entries)} {t.name} {t.shape}',flush=True)
        f.truncate(base+total)
    check=PLWB(out)
    if len(check.tensors)!=len(src.tensors): raise SystemExit('tensor count mismatch')
    src_params=sum(t.numel for t in src.tensors); out_params=sum(t.numel for t in check.tensors)
    if out_params!=src_params: raise SystemExit(f'parameter count mismatch {out_params} != {src_params}')
    if any(t.dtype!='float32' for t in check.tensors): raise SystemExit('non-fp32 output tensor')
    man={'format':'pluto-team-phase2c-v1.3-team4-fp32','source':str(a.input),'output':str(out),'output_bytes':out.stat().st_size,
         'output_sha256':file_sha256(out),'base':check.base,'total_bytes':check.total_bytes,
         'tensor_count':len(check.tensors),'parameter_count':out_params,'label':check.header.get('label')}
    Path(a.manifest).write_text(json.dumps(man,indent=2),encoding='utf-8'); print(json.dumps(man,indent=2)); print('TEAM4_FP32_PLWB_EXPORT=PASS')
if __name__=='__main__': main()
