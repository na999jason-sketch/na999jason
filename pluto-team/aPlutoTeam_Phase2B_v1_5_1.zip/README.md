# aPlutoTeam Phase2B v1.5.1 — I8 Dump Semantics Discovery

v1.5 failed only because `BWRL_I8_DUMP=1` produced no dump files.
The official inference itself was healthy and reproduced action=12 / arg=43 / pos=54.

This diagnostic stops assuming the env-var semantics. It:
- extracts ASCII strings and nearby format strings from the exact official `pluto_infer.exe`,
- tries `BWRL_I8_DUMP` as `1`, `0`, `all`, an absolute directory, and an absolute file prefix,
- scans the output tree and TEMP for newly-created dump-like files,
- records all attempts and candidates,
- does not fail merely because one encoding produces no files.

No training or model mutation occurs.
