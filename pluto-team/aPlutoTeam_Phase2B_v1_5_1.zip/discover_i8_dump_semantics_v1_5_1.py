from __future__ import annotations
import argparse, hashlib, json, os, re, struct, subprocess, threading, time
from pathlib import Path

HANDSHAKE_SIZE=0x88
RESPONSE_SIZE=0x28

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c: raise EOFError(f"wanted {n}, got {len(b)}")
        b.extend(c)
    return bytes(b)

def pack_request():
    n=2; W=H=128; flags=0
    parts=[struct.pack("<iiiIqqqq",n,W,H,flags,0,0,0,0)]
    cats=[[0,0,0,0,0,0],[0,1,23,0,228,0]]
    cont=[[0.0]*109 for _ in range(n)]
    cont[1][0]=0.5; cont[1][1]=0.5; cont[1][2]=1.0; cont[1][22]=1.0
    for r in cats: parts.append(struct.pack("<"+"q"*6,*r))
    for r in cont: parts.append(struct.pack("<"+"f"*109,*r))
    parts += [bytes([1,1]),bytes([1,1]),bytes([1]*20),bytes([1]*233)]
    parts += [struct.pack("<"+"f"*292,*([0.0]*292))]
    parts += [bytes(128*128*2),bytes(128*128),struct.pack("<qqqq",0,0,0,0)]
    return b"".join(parts)

def parse_hs(raw):
    magic,ver,fps,mu,step,label,build=struct.unpack("<4sIiiq48s64s",raw)
    z=lambda b:b.split(b"\0",1)[0].decode(errors="replace")
    return {"magic":magic.decode(errors="replace"),"version":ver,"frames_per_step":fps,
            "max_units":mu,"model_step":step,"label":z(label),"build":z(build)}

def parse_resp(raw):
    a,arg,pos,u,win,lp=struct.unpack("<qqqqff",raw)
    return {"action":a,"arg":arg,"pos":pos,"unit":u,"win":float(win),
            "logprob":float(lp),"hex":raw.hex()}

def sha256(path:Path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for c in iter(lambda:f.read(1<<20),b""): h.update(c)
    return h.hexdigest()

def extract_strings(exe:Path,out:Path):
    data=exe.read_bytes()
    ascii_hits=[]
    for m in re.finditer(rb"[\x20-\x7e]{4,}",data):
        s=m.group().decode("ascii","replace")
        if any(k in s for k in ["BWRL_I8_DUMP","BWRL_DUMP_RESID","c%04","_M_","dump","DUMP",".bin","fopen","CreateFile"]):
            ascii_hits.append({"offset":m.start(),"text":s})
    # Keep nearby printable strings around the exact env-var and format-string offsets.
    anchors=[h["offset"] for h in ascii_hits if "BWRL_I8_DUMP" in h["text"] or "c%04" in h["text"]]
    nearby=[]
    for m in re.finditer(rb"[\x20-\x7e]{4,}",data):
        if anchors and any(abs(m.start()-a)<=32768 for a in anchors):
            nearby.append({"offset":m.start(),"text":m.group().decode("ascii","replace")})
    rep={"exe":str(exe),"exe_bytes":len(data),"hits":ascii_hits,"nearby":nearby[:1200]}
    out.write_text(json.dumps(rep,indent=2),encoding="utf-8")
    return rep

def snapshot_files(roots):
    d={}
    for root in roots:
        root=Path(root)
        if not root.exists(): continue
        try:
            for p in root.rglob("*"):
                if p.is_file():
                    try:d[str(p.resolve())]=(p.stat().st_size,p.stat().st_mtime_ns)
                    except:pass
        except:pass
    return d

def run_attempt(exe,blob,work,env_value,resid=False,timeout_s=60):
    work.mkdir(parents=True,exist_ok=True)
    stderr=work/"stderr.log"
    env=os.environ.copy()
    env["BWRL_I8_DUMP"]=env_value
    if resid: env["BWRL_DUMP_RESID"]="1"
    else: env.pop("BWRL_DUMP_RESID",None)
    cmd=[str(exe),"--blob",str(blob),"--backend","int8mv","--threads","1",
         "--seed","123456789","--argmax","--verbose"]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                       cwd=work,env=env,bufsize=0)
    def drain():
        with stderr.open("wb") as f:
            while True:
                c=p.stderr.read(65536)
                if not c:break
                f.write(c);f.flush()
    th=threading.Thread(target=drain,daemon=True);th.start()
    timed=threading.Event()
    def kill():
        timed.set()
        try:p.kill()
        except:pass
    tm=threading.Timer(timeout_s,kill);tm.daemon=True;tm.start()
    hs=resp=err=None
    t0=time.monotonic()
    try:
        hs=parse_hs(read_exact(p.stdout,HANDSHAKE_SIZE))
        p.stdin.write(pack_request());p.stdin.flush()
        resp=parse_resp(read_exact(p.stdout,RESPONSE_SIZE))
        try:p.stdin.close()
        except:pass
        p.wait(timeout=15)
    except Exception as e:
        err=f"{type(e).__name__}: {e}"
        try:p.kill();p.wait(timeout=10)
        except:pass
    finally:
        tm.cancel();th.join(timeout=10)
    return {"env_value":env_value,"cwd":str(work),"elapsed_s":time.monotonic()-t0,
            "timeout":timed.is_set(),"error":err,"handshake":hs,"response":resp,
            "stderr_bytes":stderr.stat().st_size if stderr.exists() else 0}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe",required=True)
    ap.add_argument("--blob",required=True)
    ap.add_argument("--out",required=True)
    args=ap.parse_args()
    exe=Path(args.exe).resolve(); blob=Path(args.blob).resolve(); out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    string_rep=extract_strings(exe,out/"exe_dump_string_context.json")
    (out/"request_other_center.bin").write_bytes(pack_request())

    attempts=[]
    variants=[
        ("value_1","1"),
        ("value_0","0"),
        ("value_all","all"),
        ("abs_directory",str((out/"abs_dump_dir").resolve())),
        ("abs_prefix",str((out/"abs_prefix"/"capture").resolve())),
    ]
    (out/"abs_dump_dir").mkdir(parents=True,exist_ok=True)
    (out/"abs_prefix").mkdir(parents=True,exist_ok=True)

    global_roots=[out,Path.cwd(),Path(os.environ.get("TEMP",out))]
    before=snapshot_files(global_roots)

    for name,val in variants:
        work=out/name
        r=run_attempt(exe,blob,work,val,resid=False)
        r["name"]=name
        attempts.append(r)
        print(f"ATTEMPT {name} env={val!r} response={r['response']} error={r['error']}",flush=True)

    after=snapshot_files(global_roots)
    new=[]
    for path,meta in after.items():
        if path not in before:
            p=Path(path)
            # Exclude our own known diagnostics; preserve likely engine dump candidates separately.
            if p.name not in {"stderr.log","request_other_center.bin","exe_dump_string_context.json"}:
                new.append({"path":path,"bytes":meta[0],"sha256":sha256(p) if meta[0] <= 32*1024*1024 else None})

    # Find dump-looking files even if overwritten/created inside attempt cwd.
    candidates=[]
    seen=set()
    patterns=[re.compile(r"c\d+.*(?:_a|_q|_s|_zp).*\.bin$",re.I),
              re.compile(r".*(?:dump|quant|zp).*\.bin$",re.I)]
    for root in global_roots:
        root=Path(root)
        if not root.exists():continue
        for p in root.rglob("*"):
            if p.is_file() and any(rx.match(p.name) for rx in patterns):
                rp=str(p.resolve())
                if rp not in seen:
                    seen.add(rp)
                    candidates.append({"path":rp,"bytes":p.stat().st_size,
                                       "sha256":sha256(p) if p.stat().st_size<=32*1024*1024 else None})

    rep={
        "format":"pluto-team-phase2b-v1.5.1-i8-dump-path-discovery",
        "attempts":attempts,
        "new_files":new[:500],
        "dump_candidates":candidates[:500],
        "string_hit_count":len(string_rep["hits"]),
        "string_anchor_hits":[h for h in string_rep["hits"] if "BWRL_I8_DUMP" in h["text"] or "c%04" in h["text"]],
    }
    (out/"v1_5_1_discovery.json").write_text(json.dumps(rep,indent=2),encoding="utf-8")

    with (out/"v1_5_1_summary.txt").open("w",encoding="utf-8") as f:
        f.write("Pluto-Team Phase2B v1.5.1 I8 dump path discovery\n")
        for r in attempts:
            f.write(f"{r['name']} env={r['env_value']!r} action={None if not r['response'] else r['response']['action']} "
                    f"elapsed_s={r['elapsed_s']:.3f} stderr_bytes={r['stderr_bytes']} error={r['error']}\n")
        f.write(f"string_hit_count={len(string_rep['hits'])}\n")
        f.write(f"dump_candidates={len(candidates)} new_files={len(new)}\n")
        f.write("PHASE2B_V1_5_1_DUMP_DISCOVERY=PASS\n")
    print((out/"v1_5_1_summary.txt").read_text(encoding="utf-8"))

    # We only fail on inference regression, not on absent dump files: this phase is discovery.
    good=[r for r in attempts if r["response"] and r["response"]["action"]==12 and r["response"]["arg"]==43 and r["response"]["pos"]==54]
    if not good:
        raise SystemExit("official inference regression")

if __name__=="__main__":
    main()
