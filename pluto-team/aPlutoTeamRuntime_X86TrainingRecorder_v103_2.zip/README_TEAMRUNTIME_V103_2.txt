aPlutoTeamRuntime v103.2 x86 — Quit-Aware Event Guard
====================================================

WHY
---
The v103.1 live log proved:
- original Pluto onFrame began normally;
- the first intercepted request-event SetEvent had req_seq=0 and resp_seq=0;
- v103.1 classified that as a non-request and skipped the model-boundary rewrite;
- StarCraft then terminated before onFrame returned; pluto_infer exited after 0 steps.

v103.2 removes that unverified req_seq==resp_seq assumption.

EVENT CLASSIFICATION
--------------------
1) shm.quit != 0:
   Official EngineClient shutdown wake. Never rewrite. Log fatal/client state.

2) quit == 0, valid request header N / 128 / 128, sequence not already rewritten:
   Rewrite owner column exactly once and forward SetEvent.

3) same sequence already rewritten:
   Pass through; never rewrite the same payload twice.

4) header not ready:
   Pass through as a non-request wake.

The last-rewritten sentinel starts at UINT32_MAX, so a real first request with
sequence 0 is allowed.

NO STRATEGY CHANGE
------------------
No target replacement, no ally-defense rule, no fabricated observation.
Original Pluto still owns inference, judgment and command generation.
