# aPlutoTeam Phase3B v1.1 — Owner-Vocab Gate Isolation

Phase3B v1 proved the 4-row PLWB was rejected before handshake with:

`owner_emb.weight dim0 = 4, engine expects 3 (owner vocab)`

That is useful: the official inference executable contains an explicit owner-vocabulary
compatibility gate.

v1.1 does not guess a permanent patch. It:

1. reproduces the exact rejection,
2. finds the diagnostic strings in the exact official `pluto_infer.exe`,
3. resolves `.text` xrefs to those strings,
4. locates nearby `cmp ..., 3` instructions,
5. patches each candidate only in an isolated temporary EXE copy (`3 -> 4`),
6. tries the 4-way model against each candidate,
7. if exactly one candidate reaches handshake, runs full self/ally/enemy/neutral seed-parity probes.

The official executable is never overwritten and no patched executable is uploaded as a deliverable.
This is still model/engine compatibility diagnosis, not team-strategy code and not training.
