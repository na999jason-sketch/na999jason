from __future__ import annotations
import argparse, json, os, re, shutil, struct, subprocess, threading, time
from pathlib import Path

import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from capstone.x86 import X86_OP_IMM, X86_OP_MEM, X86_REG_RIP

HS=0x88
RESP=0x28

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c:
            raise EOFError(f"wanted {n}, got {len(b)}")
        b.extend(c)
    return bytes(b)

def req(owner):
    n=2; W=H=128; flags=0
    parts=[struct.pack("<iiiIqqqq",n,W,H,flags,0,0,0,0)]
    cats=[[0,0,0,0,0,0],[0,owner,23,0,228,0]]
    cont=[[0.0]*109 for _ in range(n)]
    cont[1][0]=0.5; cont[1][1]=0.5; cont[1][2]=1.0; cont[1][22]=1.0
    for r in cats: parts.append(struct.pack("<"+"q"*6,*r))
    for r in cont: parts.append(struct.pack("<"+"f"*109,*r))
    parts += [bytes([1,1]),bytes([1,1]),bytes([1]*20),bytes([1]*233)]
    parts += [struct.pack("<"+"f"*292,*([0.0]*292))]
    parts += [bytes(128*128*2),bytes(128*128),struct.pack("<qqqq",0,0,0,0)]
    return b"".join(parts)

def parse_hs(raw):
    magic,ver,fps,mu,step,label,build=struct.unpack("<4sIiiq48s64s",raw)
    z=lambda b:b.split(b"\0",1)[0].decode(errors="replace")
    return {"magic":z(magic),"version":ver,"fps":fps,"max_units":mu,
            "step":step,"label":z(label),"build":z(build)}

def parse_resp(raw):
    a,arg,pos,u,f0,f1=struct.unpack("<qqqqff",raw)
    return {"action":a,"arg":arg,"pos":pos,"unit":u,
            "float0":float(f0),"float1":float(f1),"hex":raw.hex()}

def run_engine(exe,blob,owner,out,tag,timeout=45):
    out.mkdir(parents=True,exist_ok=True)
    errp=out/f"{tag}.stderr.log"
    cmd=[str(exe),"--blob",str(blob),"--backend","int8mv","--threads","1",
         "--seed","123456789","--argmax","--verbose"]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
    def drain():
        with errp.open("wb") as f:
            while True:
                c=p.stderr.read(65536)
                if not c:break
                f.write(c);f.flush()
    th=threading.Thread(target=drain,daemon=True);th.start()
    t0=time.monotonic(); hs=resp=err=None
    try:
        hs=parse_hs(read_exact(p.stdout,HS))
        p.stdin.write(req(owner));p.stdin.flush()
        resp=parse_resp(read_exact(p.stdout,RESP))
        try:p.stdin.close()
        except:pass
        p.wait(timeout=15)
    except Exception as e:
        err=f"{type(e).__name__}: {e}"
        try:p.kill();p.wait(timeout=10)
        except:pass
    th.join(timeout=10)
    stderr=errp.read_text(errors="replace") if errp.exists() else ""
    return {"tag":tag,"owner":owner,"exe":str(exe),"elapsed_s":time.monotonic()-t0,
            "returncode":p.returncode,"handshake":hs,"response":resp,"error":err,"stderr":stderr}

def find_strings(data, needles):
    out=[]
    # Return complete surrounding printable string for every hit.
    for needle in needles:
        for m in re.finditer(re.escape(needle.encode()),data):
            a=m.start()
            s=a
            while s>0 and 0x20 <= data[s-1] <= 0x7e: s-=1
            e=m.end()
            while e<len(data) and 0x20 <= data[e] <= 0x7e: e+=1
            out.append((s,e,data[s:e].decode("ascii","replace")))
    uniq={}
    for a,e,s in out: uniq[(a,e)]=s
    return [(a,e,s) for (a,e),s in sorted(uniq.items())]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe",required=True)
    ap.add_argument("--official",required=True)
    ap.add_argument("--team4",required=True)
    ap.add_argument("--out",required=True)
    args=ap.parse_args()
    exe=Path(args.exe).resolve(); official=Path(args.official).resolve()
    team4=Path(args.team4).resolve(); out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    # Baseline proves the observed v1 failure first.
    baseline=run_engine(exe,team4,1,out,"baseline_team4_ally")
    print("BASELINE",baseline["error"],baseline["stderr"].strip(),flush=True)

    data=exe.read_bytes()
    pe=pefile.PE(str(exe),fast_load=False)
    base=pe.OPTIONAL_HEADER.ImageBase
    textsec=next((s for s in pe.sections if s.Name.rstrip(b"\0")==b".text"),None)
    if textsec is None: raise SystemExit(".text missing")
    text=textsec.get_data()
    text_va=base+textsec.VirtualAddress

    string_hits=find_strings(data,["owner vocab","owner_emb.weight","engine expects","blob incompatible"])
    str_ranges=[]
    for fo,fe,s in string_hits:
        try:rva=pe.get_rva_from_offset(fo)
        except:continue
        str_ranges.append({"file_offset":fo,"file_end":fe,"va":base+rva,"text":s})
    print("STRING_HITS",json.dumps(str_ranges,indent=2),flush=True)

    md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
    ins=list(md.disasm(text,text_va))
    xrefs=[]
    for idx,i in enumerate(ins):
        for op in i.operands:
            target=None
            if op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP:
                target=i.address+i.size+op.mem.disp
            elif op.type==X86_OP_IMM:
                target=int(op.imm)
            if target is None: continue
            for s in str_ranges:
                # Most compilers point to string start, but tolerate inside the same string.
                span=s["file_end"]-s["file_offset"]
                if s["va"] <= target < s["va"]+span:
                    xrefs.append({"idx":idx,"address":i.address,"mnemonic":i.mnemonic,
                                  "op_str":i.op_str,"string":s["text"],"target":target})
                    break

    # Candidate gate: a CMP with immediate 3 close to a diagnostic xref.
    candidates=[]
    seen=set()
    for xr in xrefs:
        idx=xr["idx"]
        lo=max(0,idx-100); hi=min(len(ins),idx+30)
        for j in range(lo,hi):
            i=ins[j]
            if i.mnemonic!="cmp": continue
            immops=[op for op in i.operands if op.type==X86_OP_IMM and int(op.imm)==3]
            if not immops: continue
            try:
                enc=i.encoding
                imm_off=int(enc.imm_offset); imm_size=int(enc.imm_size)
            except Exception:
                continue
            if imm_off<=0 or imm_size not in (1,2,4,8): continue
            file_off=pe.get_offset_from_rva((i.address-base))+imm_off
            key=(i.address,file_off,imm_size)
            if key in seen: continue
            seen.add(key)
            # Verify encoded immediate really is 3 before offering a patch.
            raw=data[file_off:file_off+imm_size]
            if int.from_bytes(raw,"little",signed=False)!=3: continue
            candidates.append({"address":i.address,"file_offset":file_off,"imm_size":imm_size,
                               "mnemonic":i.mnemonic,"op_str":i.op_str,
                               "distance_to_xref":xr["address"]-i.address,
                               "xref_address":xr["address"],"xref_string":xr["string"]})

    # Dump readable windows.
    lines=[]
    for xr in xrefs:
        idx=xr["idx"];lo=max(0,idx-70);hi=min(len(ins),idx+80)
        lines.append("="*100)
        lines.append(f"XREF 0x{xr['address']:x} {xr['mnemonic']} {xr['op_str']} -> {xr['string']!r}")
        for j in range(lo,hi):
            i=ins[j]
            mark=">>" if j==idx else "  "
            lines.append(f"{mark} {i.address:016x}: {i.mnemonic:8s} {i.op_str}")
    (out/"owner_vocab_xrefs.txt").write_text("\n".join(lines),encoding="utf-8")

    attempts=[]
    # Do NOT permanently modify the official binary. Each candidate is isolated in its own copy.
    for n,c in enumerate(candidates):
        patched=out/f"pluto_infer_gate_candidate_{n}.exe"
        b=bytearray(data)
        b[c["file_offset"]:c["file_offset"]+c["imm_size"]]=(4).to_bytes(c["imm_size"],"little")
        patched.write_bytes(b)
        r=run_engine(patched,team4,1,out,f"candidate_{n}_ally")
        r["candidate"]=c
        attempts.append(r)
        print("PATCH_ATTEMPT",n,c,"HS",r["handshake"],"RESP",r["response"],
              "ERR",r["error"],"STDERR",r["stderr"].strip(),flush=True)

    accepted=[r for r in attempts if r["handshake"] is not None]
    full=None
    if len(accepted)==1:
        chosen=Path(accepted[0]["exe"])
        cases={}
        # Fresh process per category, matching Phase2/3 probe discipline.
        for owner,name in [(0,"self"),(1,"ally"),(2,"enemy"),(3,"neutral")]:
            cases[name]=run_engine(chosen,team4,owner,out,f"chosen_{name}")
        # Official references.
        refs={}
        for owner,name in [(0,"self"),(1,"other"),(2,"neutral")]:
            refs[name]=run_engine(exe,official,owner,out,f"official_{name}")
        eq=lambda a,b: bool(a["response"] and b["response"] and a["response"]["hex"]==b["response"]["hex"])
        checks={
            "patched_engine_accepts_4way":all(cases[k]["response"] for k in cases),
            "self_preserved":eq(cases["self"],refs["self"]),
            "ally_seed_preserved":eq(cases["ally"],refs["other"]),
            "enemy_seed_preserved":eq(cases["enemy"],refs["other"]),
            "neutral_preserved":eq(cases["neutral"],refs["neutral"]),
            "ally_enemy_identical":eq(cases["ally"],cases["enemy"]),
        }
        full={"chosen_candidate":accepted[0]["candidate"],"cases":cases,"refs":refs,
              "checks":checks,"pass":all(checks.values())}

    report={"format":"pluto-team-phase3b-v1.1-owner-vocab-gate-isolation",
            "baseline":baseline,"strings":str_ranges,
            "xrefs":[{k:v for k,v in x.items() if k!="idx"} for x in xrefs],
            "candidates":candidates,"attempts":attempts,"accepted_count":len(accepted),
            "full_probe":full}
    (out/"phase3b_v1_1_gate_isolation.json").write_text(json.dumps(report,indent=2),encoding="utf-8")

    with (out/"phase3b_v1_1_summary.txt").open("w",encoding="utf-8") as f:
        f.write(f"baseline_owner_vocab_reject={'owner vocab' in baseline['stderr']}\n")
        f.write(f"string_hits={len(str_ranges)} xrefs={len(xrefs)} cmp3_candidates={len(candidates)}\n")
        f.write(f"patched_candidates_accepting_handshake={len(accepted)}\n")
        if full:
            for k,v in full["checks"].items(): f.write(f"{k}={v}\n")
            f.write(f"PHASE3B_V1_1_GATE_ISOLATION={'PASS' if full['pass'] else 'PARTIAL'}\n")
        else:
            f.write("PHASE3B_V1_1_GATE_ISOLATION=DIAGNOSTIC_ONLY\n")
    print((out/"phase3b_v1_1_summary.txt").read_text(),flush=True)

    # This is a diagnostic/isolation run. Failure to find the correct gate must still preserve artifact.
    # Exit success as long as the known rejection was reproduced and static analysis completed.
    if "owner vocab" not in baseline["stderr"]:
        raise SystemExit("known owner-vocab rejection not reproduced")

if __name__=="__main__":
    main()
