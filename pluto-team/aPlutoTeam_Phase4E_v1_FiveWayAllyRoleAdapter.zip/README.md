# Phase4E v1 — Five-Way Ally Role Adapter

Owner vocabulary:
- 0 SELF
- 1 ALLY_UNIT (friendly, non-controllable mobile/combat ally)
- 2 ALLY_ASSET (friendly, non-controllable worker/building)
- 3 ENEMY
- 4 NEUTRAL

Why: Phase4D proved a single ALLY relation channel can be isolated, but one signal could not encode
both ordinary allied presence and protected allied assets. Phase4E splits those semantics before
Pluto's strategy network. ALLY_UNIT starts neutral-like for safety; ALLY_ASSET gets an isolated
relation marker and low-rank adapter trained with the official Pluto engine.

No bridge combat policy is added. Pluto still chooses all actions.
