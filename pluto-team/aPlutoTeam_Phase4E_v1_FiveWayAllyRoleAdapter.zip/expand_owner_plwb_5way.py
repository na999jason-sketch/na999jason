from __future__ import annotations
import json, math, struct, sys
from pathlib import Path
import numpy as np

def main():
    if len(sys.argv)!=3:
        raise SystemExit("usage: expand_owner_plwb_5way.py IN OUT")
    src=Path(sys.argv[1]); dst=Path(sys.argv[2]); raw=src.read_bytes()
    if raw[:4]!=b'PLWB': raise SystemExit('not PLWB')
    hlen=struct.unpack_from('<Q',raw,8)[0]
    hdr=json.loads(raw[16:16+hlen].decode('utf-8'))
    old_base=len(raw)-int(hdr['total_bytes'])
    tensors=hdr['tensors']
    own=next(t for t in tensors if t['name']=='owner_emb.weight')
    if list(own['shape'])!=[3,256]: raise SystemExit(f"unexpected owner shape {own['shape']}")
    if own.get('dtype','float32')!='float32': raise SystemExit('owner embedding must be float32')
    off=old_base+int(own['offset'])
    old=np.frombuffer(raw,dtype='<f4',count=3*256,offset=off).copy().reshape(3,256)

    # SELF0, ALLY_UNIT1, ALLY_ASSET2, ENEMY3, NEUTRAL4
    new=np.empty((5,256),dtype='<f4')
    new[0]=old[0]
    new[1]=old[2]  # safe non-hostile starting point
    new[2]=old[2]  # relation marker/training will separate this row
    new[3]=old[1]
    new[4]=old[2]

    # Rebuild data section while preserving all tensor payloads except owner.
    old_data=memoryview(raw)[old_base:]
    chunks=[]
    cursor=0
    new_tensors=[]
    for t in tensors:
        nt=dict(t)
        name=t['name']
        start=int(t['offset']); nbytes=int(t['nbytes'])
        if start<cursor: raise SystemExit('non-monotonic tensor offsets')
        if start>cursor:
            chunks.append(bytes(old_data[cursor:start]))
        nt['offset']=sum(len(x) for x in chunks)
        if name=='owner_emb.weight':
            payload=new.tobytes()
            nt['shape']=[5,256]
            nt['nbytes']=len(payload)
            chunks.append(payload)
        else:
            payload=bytes(old_data[start:start+nbytes])
            chunks.append(payload)
            # scale payload, if present, is separate later in data and offsets must shift.
        cursor=start+nbytes
        new_tensors.append(nt)
    if cursor<len(old_data): chunks.append(bytes(old_data[cursor:]))
    new_data=b''.join(chunks)

    # Generic offset reconstruction: compute delta after owner insertion for every stored offset.
    delta=len(new_data)-len(old_data)
    owner_old_end=int(own['offset'])+int(own['nbytes'])
    owner_delta=(5-3)*256*4
    for nt,t in zip(new_tensors,tensors):
        if t['name']!='owner_emb.weight' and int(t['offset'])>=owner_old_end:
            nt['offset']=int(t['offset'])+owner_delta
        if 'scale_offset' in t and t['scale_offset'] is not None:
            so=int(t['scale_offset'])
            nt['scale_offset']=so+owner_delta if so>=owner_old_end else so

    hdr['tensors']=new_tensors
    hdr['total_bytes']=int(hdr['total_bytes'])+owner_delta
    hdr['label']=str(hdr.get('label',''))+'-team5roles'
    h=json.dumps(hdr,separators=(',',':')).encode('utf-8')
    out=b'PLWB'+struct.pack('<I',1)+struct.pack('<Q',len(h))+h+new_data
    dst.write_bytes(out)
    print(json.dumps({
        'owner_old_shape':[3,256],
        'owner_new_shape':[5,256],
        'owner_mapping':{
            '0':'SELF <- old SELF',
            '1':'ALLY_UNIT <- old NEUTRAL seed',
            '2':'ALLY_ASSET <- old NEUTRAL seed',
            '3':'ENEMY <- old OTHER',
            '4':'NEUTRAL <- old NEUTRAL'
        },
        'owner_bytes_delta':owner_delta,
        'output_bytes':len(out)
    },indent=2))
    print('FIVEWAY_OWNER_PLWB_BUILD=PASS')

if __name__=='__main__':
    main()
