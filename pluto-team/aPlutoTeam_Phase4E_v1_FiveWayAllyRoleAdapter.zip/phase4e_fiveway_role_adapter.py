from __future__ import annotations
import argparse, json, math, shutil, struct, subprocess, threading, hashlib
from pathlib import Path
import numpy as np

RESP=struct.Struct('<qqqqff')
REQ_HDR=struct.Struct('<iiiIqqqq')
EMB_NAMES=["unit_type_emb.weight","owner_emb.weight","order_emb.weight","last_action_emb.weight","train_type_emb.weight","research_type_emb.weight"]
WORKER_TYPES={7,41,64}
BUILDING_MIN=106; BUILDING_MAX=201; LN_EPS=1e-5

def read_exact(p,n):
    b=bytearray()
    while len(b)<n:
        c=p.read(n-len(b))
        if not c: raise EOFError
        b+=c
    return bytes(b)

def parse_resp(b):
    a,arg,pos,unit,win,lp=RESP.unpack(b)
    return dict(action=int(a),arg=int(arg),pos=int(pos),unit=int(unit),win=float(win),logprob=float(lp))

def run(exe,w,backend,threads,reqs,errfile):
    cmd=[str(exe),'--blob',str(w),'--backend',backend,'--threads',str(threads),'--seed','123456789','--argmax']
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                       creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),bufsize=0)
    err=[]
    th=threading.Thread(target=lambda:[err.append(c) for c in iter(lambda:p.stderr.read(65536),b'')],daemon=True); th.start()
    hs=read_exact(p.stdout,0x88)
    magic,ver,*_=struct.unpack('<4sIiiq48s64s',hs)
    if magic.rstrip(b'\0')!=b'PLO1' or ver!=3: raise RuntimeError('bad handshake')
    out=[]
    for r in reqs:
        p.stdin.write(r); p.stdin.flush(); out.append(parse_resp(read_exact(p.stdout,0x28)))
    p.stdin.close(); rc=p.wait(timeout=900); th.join(timeout=5)
    Path(errfile).write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
    if rc!=0: raise RuntimeError(rc)
    return out

def hdr(path):
    raw=Path(path).read_bytes()
    hlen=struct.unpack_from('<Q',raw,8)[0]
    h=json.loads(raw[16:16+hlen].decode())
    return raw,h,len(raw)-int(h['total_bytes']),{t['name']:t for t in h['tensors']}

def tensor(path,name):
    raw,h,base,by=hdr(path); t=by[name]
    if t.get('dtype','float32')!='float32': raise ValueError(name)
    n=math.prod(t['shape']); off=base+int(t['offset'])
    return np.frombuffer(raw,dtype='<f4',count=n,offset=off).copy().reshape(t['shape'])

def write_owner(path,idx,row):
    raw=bytearray(Path(path).read_bytes()); hlen=struct.unpack_from('<Q',raw,8)[0]
    h=json.loads(raw[16:16+hlen].decode()); base=len(raw)-int(h['total_bytes'])
    t=next(x for x in h['tensors'] if x['name']=='owner_emb.weight')
    off=base+int(t['offset'])+idx*256*4
    raw[off:off+1024]=np.asarray(row,dtype='<f4').reshape(256).tobytes()
    Path(path).write_bytes(raw)

def row_slice(path,tname,row,c0,c1):
    raw,h,base,by=hdr(path); t=by[tname]; cols=int(t['shape'][1]); off=base+int(t['offset'])+(row*cols+c0)*4
    return np.frombuffer(raw,dtype='<f4',count=c1-c0,offset=off).copy()

def write_slice(path,tname,row,c0,val):
    raw=bytearray(Path(path).read_bytes()); hlen=struct.unpack_from('<Q',raw,8)[0]
    h=json.loads(raw[16:16+hlen].decode()); base=len(raw)-int(h['total_bytes']); t=next(x for x in h['tensors'] if x['name']==tname)
    cols=int(t['shape'][1]); off=base+int(t['offset'])+(row*cols+c0)*4
    v=np.asarray(val,dtype='<f4'); raw[off:off+4*len(v)]=v.tobytes(); Path(path).write_bytes(raw)

def is_asset(t): return int(t) in WORKER_TYPES or BUILDING_MIN<=int(t)<=BUILDING_MAX

def convert5(raw,teacher=False,cat=None):
    out=bytearray(raw); n=REQ_HDR.unpack_from(raw,0)[0]
    for i in range(n):
        p=0x30+i*48; typ=struct.unpack_from('<q',out,p)[0]; own=struct.unpack_from('<q',out,p+8)[0]
        if own==0: new=0
        elif own==1:
            asset=is_asset(typ)
            if teacher:
                new=0 if (cat=='ally_threat' and asset) else 4
            else:
                new=2 if asset else 1
        elif own==2: new=3
        elif own==3: new=4
        else: raise ValueError(own)
        struct.pack_into('<q',out,p+8,new)
    return bytes(out)

def score(got,tgt,items):
    s=0.; mx=0.; am=0; exact=0
    for g,t,m in zip(got,tgt,items):
        w=float(m.get('weight',1.0))
        if m['category']=='peace_block': w*=3
        elif m['category']=='ally_threat': w*=4
        p=0.
        if g['action']==t['action']: p+=8; am+=1
        if g['arg']==t['arg']: p+=2
        if g['unit']==t['unit']: p+=2
        if g['pos']==t['pos']: p+=1
        p+=.5*max(0,1-min(1,abs(g['win']-t['win'])/.25))
        if (g['action'],g['arg'],g['pos'],g['unit'])==(t['action'],t['arg'],t['pos'],t['unit']): exact+=1
        s+=w*p; mx+=w*13.5
    return dict(score=s,normalized=s/mx,action_match=am,exact_int4=exact)

def cats(g,t,items):
    o={}
    for c in sorted(set(x['category'] for x in items)):
        ids=[i for i,x in enumerate(items) if x['category']==c]
        o[c]=score([g[i] for i in ids],[t[i] for i in ids],[items[i] for i in ids])
    return o

def reward(r,n):
    x=r['overall']['normalized']; c=r['category']; b=n['category']
    for k in ('peace_dense','peace_block','enemy_preserve'):
        x-=.06*max(0,b[k]['action_match']-c[k]['action_match'])
    x+=.06*(c['ally_threat']['action_match']-b['ally_threat']['action_match'])
    x+=.30*(c['ally_threat']['normalized']-b['ally_threat']['normalized'])
    return float(x)

def rms(x): return float(np.sqrt(np.mean(np.asarray(x,dtype=np.float64)**2)))

def marker(owner,gamma,beta):
    C=np.stack([gamma*owner[0],gamma*owner[3],gamma*owner[4],gamma,beta],axis=0).astype(np.float64)
    q=np.random.default_rng(20261005).standard_normal(256)
    q-=C.T@(np.linalg.pinv(C@C.T,rcond=1e-12)@(C@q))
    q/=max(rms(q),1e-12)
    return q.astype(np.float32),float(np.max(np.abs(C@q)))

def asset_activation(fp32,raws,row,q,owner_start):
    em={n:tensor(fp32,n) for n in EMB_NAMES}; ga=tensor(fp32,'cat_norm.weight').reshape(-1); be=tensor(fp32,'cat_norm.bias').reshape(-1)
    vals=[]
    for raw in raws:
        n=REQ_HDR.unpack_from(raw,0)[0]
        cat=np.frombuffer(raw,dtype='<i8',count=n*6,offset=0x30).reshape(n,6)
        for rr in cat:
            if int(rr[1])!=2: continue
            z=np.concatenate([row if i==1 else em[nm][int(rr[i])] for i,nm in enumerate(EMB_NAMES)]).astype(np.float64)
            y=(z-z.mean())/math.sqrt(((z-z.mean())**2).mean()+LN_EPS)*ga+be
            vals.append(float(q@y[owner_start:owner_start+256]))
    if not vals: raise ValueError('no asset rows')
    return float(np.median(vals)),dict(count=len(vals),median=float(np.median(vals)),std=float(np.std(vals)))

def patch_fp32(path,asset_row,q,act,hids,coeffs,owner_start,base):
    write_owner(path,1,tensor(path,'owner_emb.weight')[4]) # ALLY_UNIT == NEUTRAL
    write_owner(path,2,asset_row)
    rows=tensor(path,'input_proj.0.gate_up.weight').shape[0]; mid=rows//2
    sv=q.astype(np.float64)/act; cc=np.asarray(coeffs).reshape(len(hids),2)
    for i,j in enumerate(hids):
        a,b=cc[i]; write_slice(path,'input_proj.0.gate_up.weight',j,owner_start,base[(j,'g')]+(a+b)*sv)
        write_slice(path,'input_proj.0.gate_up.weight',mid+j,owner_start,base[(j,'v')]+(a-b)*sv)

def quant_patch(src,dst,asset_row,q,act,hids,coeffs,owner_start):
    shutil.copy2(src,dst); write_owner(dst,1,tensor(dst,'owner_emb.weight')[4]); write_owner(dst,2,asset_row)
    raw,h,base0,by=hdr(dst); t=by['input_proj.0.gate_up.weight']; shape=tuple(t['shape']); rows,cols=shape
    if t.get('dtype')!='int8': raise ValueError('gate not int8')
    data=np.frombuffer(raw,dtype=np.int8,count=int(t['nbytes']),offset=base0+int(t['offset'])).copy().reshape(shape)
    scales=np.frombuffer(raw,dtype='<f4',count=int(t['scale_len']),offset=base0+int(t['scale_offset'])).copy()
    if len(scales)==rows: arr=data.astype(np.float32)*scales[:,None]; axis=0
    elif len(scales)==cols: arr=data.astype(np.float32)*scales[None,:]; axis=1
    else: raise ValueError('scale shape')
    mid=rows//2; sv=q.astype(np.float64)/act; cc=np.asarray(coeffs).reshape(len(hids),2)
    for i,j in enumerate(hids):
        a,b=cc[i]; arr[j,owner_start:owner_start+256]+=(a+b)*sv; arr[mid+j,owner_start:owner_start+256]+=(a-b)*sv
    if axis==0:
        ns=np.maximum(np.max(np.abs(arr),axis=1)/127,1e-12).astype('<f4'); nq=np.clip(np.rint(arr/ns[:,None]),-127,127).astype(np.int8)
    else:
        ns=np.maximum(np.max(np.abs(arr),axis=0)/127,1e-12).astype('<f4'); nq=np.clip(np.rint(arr/ns[None,:]),-127,127).astype(np.int8)
    rb=bytearray(Path(dst).read_bytes()); hlen=struct.unpack_from('<Q',rb,8)[0]; hh=json.loads(rb[16:16+hlen].decode()); bb=len(rb)-int(hh['total_bytes']); tt=next(x for x in hh['tensors'] if x['name']=='input_proj.0.gate_up.weight')
    rb[bb+int(tt['offset']):bb+int(tt['offset'])+len(nq.tobytes())]=nq.tobytes()
    rb[bb+int(tt['scale_offset']):bb+int(tt['scale_offset'])+len(ns.tobytes())]=ns.tobytes()
    Path(dst).write_bytes(rb)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--exe',required=True); ap.add_argument('--int8',required=True); ap.add_argument('--fp32',required=True); ap.add_argument('--samples',required=True); ap.add_argument('--out',required=True)
    a=ap.parse_args(); exe=Path(a.exe); i8=Path(a.int8); fp=Path(a.fp32); samples=Path(a.samples); out=Path(a.out); out.mkdir(exist_ok=True); logs=out/'logs'; logs.mkdir(exist_ok=True)

    man=json.loads((samples/'manifest.json').read_text()); items=man['samples']; raw=[]
    for m in items:
        b=(samples/m['file']).read_bytes(); assert hashlib.sha256(b).hexdigest()==m['sha256']; raw.append(b)
    req=[convert5(b,False,m['category']) for b,m in zip(raw,items)]
    teach=[convert5(b,True,m['category']) for b,m in zip(raw,items)]
    rev=list(range(47,-1,-1))
    keep=[]
    for c in ('peace_dense','enemy_preserve','peace_block','ally_threat'):
        ids=[i for i,m in enumerate(items) if m['category']==c]; keep+=ids[::2][:6]
    keep=sorted(keep); sreq=[req[i] for i in keep]; steach=[teach[i] for i in keep]; sitems=[items[i] for i in keep]

    tt_s=run(exe,fp,'pk',4,steach,logs/'teacher_search.stderr.txt')
    tt_f=run(exe,fp,'pk',4,teach,logs/'teacher_fwd.stderr.txt')
    tt_r=run(exe,fp,'pk',4,[teach[i] for i in rev],logs/'teacher_rev.stderr.txt')

    own=tensor(fp,'owner_emb.weight'); ga=tensor(fp,'cat_norm.weight').reshape(-1); be=tensor(fp,'cat_norm.bias').reshape(-1)
    owner_start=tensor(fp,'unit_type_emb.weight').shape[1]; gamma=ga[owner_start:owner_start+256]; beta=be[owner_start:owner_start+256]
    q,res=marker(own,gamma,beta); scale=float(np.median([rms(own[0]-own[4]),rms(own[3]-own[4])]))
    asset_row=(own[4].astype(np.float64)+0.005*scale*q).astype(np.float32)

    gate=tensor(fp,'input_proj.0.gate_up.weight'); down=tensor(fp,'input_proj.0.down.weight'); mid=gate.shape[0]//2
    norms=np.linalg.norm(down.astype(np.float64),axis=0); hids=[int(x) for x in np.argsort(norms)[::-1][:6]]
    base={}
    for j in hids:
        base[(j,'g')]=row_slice(fp,'input_proj.0.gate_up.weight',j,owner_start,owner_start+256)
        base[(j,'v')]=row_slice(fp,'input_proj.0.gate_up.weight',mid+j,owner_start,owner_start+256)
    # temporarily mark asset row to measure isolated activation
    write_owner(fp,1,own[4]); write_owner(fp,2,asset_row)
    act,ast=asset_activation(fp,sreq,asset_row,q,owner_start)
    print(f'PHASE4E_MARKER residual={res:.3e} act={act:.6g} hids={hids}',flush=True)

    def ev(c,tag,mode):
        patch_fp32(fp,asset_row,q,act,hids,c,owner_start,base)
        if mode=='s': rr,ii,tt=sreq,sitems,tt_s
        elif mode=='f': rr,ii,tt=req,items,tt_f
        else: rr,ii,tt=[req[i] for i in rev],[items[i] for i in rev],tt_r
        g=run(exe,fp,'pk',4,rr,logs/f'{tag}_{mode}.stderr.txt')
        return dict(overall=score(g,tt,ii),category=cats(g,tt,ii))

    zero=np.zeros(len(hids)*2)
    neutral=ev(zero,'zero','s')
    coeff=zero.copy(); cur=neutral; cr=reward(cur,neutral); seen=[(cr,coeff.copy(),cur)]
    for pi,step in enumerate([16.,8.,4.,2.,1.],1):
        for k in range(len(coeff)):
            opts=[]
            for sg in (-1.,1.):
                c=coeff.copy(); c[k]+=sg*step; r=ev(c,f'p{pi}_k{k}_{int(sg)}','s'); rw=reward(r,neutral); opts.append((rw,c,r)); seen.append((rw,c.copy(),r))
                print(f'ROLE_ADAPT p={pi} k={k} sg={sg:+.0f} step={step:g} rw={rw:.6f} peace={r["category"]["peace_block"]["action_match"]}/6 threat={r["category"]["ally_threat"]["action_match"]}/6',flush=True)
            w=max(opts,key=lambda x:x[0])
            if w[0]>cr+1e-8: cr,coeff,cur=w
        print(f'ROLE_PASS_DONE p={pi} reward={cr:.6f}',flush=True)

    uniq=[]; keys=set()
    for rw,c,r in sorted(seen,key=lambda x:x[0],reverse=True):
        k=tuple(np.round(c,6))
        if k in keys: continue
        keys.add(k); uniq.append((rw,c,r))
        if len(uniq)>=4: break
    vals=[]
    # neutral full baselines
    nf=ev(zero,'neutral','f'); nr=ev(zero,'neutral','r')
    for i,(rw,c,sr) in enumerate(uniq,1):
        vals.append(dict(reward=rw,coeffs=c.tolist(),search=sr,fwd=ev(c,f'v{i}','f'),rev=ev(c,f'v{i}','r')))

    def metric(v):
        cf=v['fwd']['category']; cr=v['rev']['category']; bf=nf['category']; br=nr['category']
        preserve=all(cf[k]['action_match']>=bf[k]['action_match']-1 and cr[k]['action_match']>=br[k]['action_match']-1 for k in ('peace_dense','peace_block','enemy_preserve'))
        tf,tf0=cf['ally_threat'],bf['ally_threat']; tr,tr0=cr['ally_threat'],br['ally_threat']
        noregr=tf['action_match']>=tf0['action_match'] and tr['action_match']>=tr0['action_match']
        improve=(tf['action_match']>tf0['action_match'] or tr['action_match']>tr0['action_match'] or tf['normalized']+tr['normalized']>=tf0['normalized']+tr0['normalized']+.03)
        return dict(preserve_ok=preserve,no_threat_regression=noregr,threat_improved=improve,deployable=bool(preserve and noregr and improve),
                    threat_fwd=[tf['action_match'],tf0['action_match'],tf['normalized'],tf0['normalized']],threat_rev=[tr['action_match'],tr0['action_match'],tr['normalized'],tr0['normalized']])
    for v in vals: v['metrics']=metric(v)
    ok=[v for v in vals if v['metrics']['deployable']]
    deploy=False; int8rep=None
    if ok:
        best=max(ok,key=lambda v:(v['fwd']['category']['ally_threat']['action_match']+v['rev']['category']['ally_threat']['action_match'],
                                  v['fwd']['category']['ally_threat']['normalized']+v['rev']['category']['ally_threat']['normalized']))
        cand=out/'pluto_weights_team5_role_adapter_int8.bin'; quant_patch(i8,cand,asset_row,q,act,hids,best['coeffs'],owner_start)
        # final int8 teacher/baselines
        ti_f=run(exe,i8,'int8mv',1,teach,logs/'i8_teacher_f.stderr.txt'); ti_r=run(exe,i8,'int8mv',1,[teach[i] for i in rev],logs/'i8_teacher_r.stderr.txt')
        basei=out/'neutral5.bin'; shutil.copy2(i8,basei); write_owner(basei,1,own[4]); write_owner(basei,2,own[4])
        bi_f=run(exe,basei,'int8mv',1,req,logs/'i8_base_f.stderr.txt'); bi_r=run(exe,basei,'int8mv',1,[req[i] for i in rev],logs/'i8_base_r.stderr.txt')
        ca_f=run(exe,cand,'int8mv',1,req,logs/'i8_cand_f.stderr.txt'); ca_r=run(exe,cand,'int8mv',1,[req[i] for i in rev],logs/'i8_cand_r.stderr.txt')
        Bf=dict(overall=score(bi_f,ti_f,items),category=cats(bi_f,ti_f,items)); Br=dict(overall=score(bi_r,ti_r,[items[i] for i in rev]),category=cats(bi_r,ti_r,[items[i] for i in rev]))
        Cv=dict(fwd=dict(overall=score(ca_f,ti_f,items),category=cats(ca_f,ti_f,items)),rev=dict(overall=score(ca_r,ti_r,[items[i] for i in rev]),category=cats(ca_r,ti_r,[items[i] for i in rev])))
        ofn,orn=nf,nr; nf,nr=Bf,Br; im=metric(Cv); nf,nr=ofn,orn
        int8rep=dict(metrics=im,candidate=Cv,baseline_fwd=Bf,baseline_rev=Br)
        deploy=im['deployable']
        if not deploy: cand.unlink(missing_ok=True)
        basei.unlink(missing_ok=True)

    report=dict(format='phase4e-v1-fiveway-ally-role-adapter',owner_vocab='SELF0 ALLY_UNIT1 ALLY_ASSET2 ENEMY3 NEUTRAL4',
                marker=dict(residual=res,activation=act,stats=ast,hidden_ids=hids),neutral_fwd=nf,neutral_rev=nr,
                validations=vals,int8_validation=int8rep,deployable=deploy,
                classification='TEAM5_ROLE_ADAPTER_INT8_FOUND' if deploy else 'NO_DEPLOYABLE_TEAM5_ROLE_ADAPTER')
    (out/'phase4e_v1_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (out/'phase4e_v1_summary.txt').write_text(
        f"aPlutoTeam Phase4E v1 Five-Way Ally Role Adapter\nowner_vocab=SELF0 ALLY_UNIT1 ALLY_ASSET2 ENEMY3 NEUTRAL4\nfp32_candidates={len(ok)}\nint8_deployable={deploy}\nresult_class={report['classification']}\nPHASE4E_V1_FIVEWAY_ROLE_ADAPTER=PASS\n",encoding='utf-8')
    print((out/'phase4e_v1_summary.txt').read_text(),flush=True)
    if not deploy:
        (out/'NO_RUNTIME_WEIGHTS.txt').write_text('No runtime weights emitted; validation did not pass.\n')

if __name__=='__main__':
    main()
