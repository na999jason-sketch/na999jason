# aPlutoTeam Phase2B v1.1 — FP32 isolation test

Phase2B v1 structurally ran, but the official int8mv engine and our dequantized FP32 PyTorch
forward did not agree (`official action 12` vs `PyTorch action 16`). That alone does not tell us
whether the problem is architecture/order or the shipped engine's dynamic u8 activation
quantization.

v1.1 isolates those causes.

1. Download the exact official `cog2026-2578600` release and verify SHA-256.
2. Convert the shipped PLWB into a new **all-float32 PLWB** while preserving all 269 tensor
   names/shapes and model configuration.
3. Launch the **official `pluto_infer.exe` itself** on:
   - original int8 blob with `int8mv`
   - reconstructed float32 blob with official `pk` backend
4. Send the exact same deterministic `other_center` request to both.
5. Re-run our PyTorch FP32 reconstruction.
6. Compare:
   - official int8mv vs official FP32
   - official FP32 vs PyTorch FP32

Interpretation:
- Official FP32 ≈ PyTorch FP32 => trunk/order is likely right; implement engine quantization next.
- Official FP32 != PyTorch FP32 => there is still a structural/order/initial-state bug to locate.

`BWRL_DUMP_RESID=1` is also enabled for both official runs and the stderr logs are preserved in
the artifact for activation-tag diagnostics.

The temporary ~1.26 GB float32 blob is deleted before artifact upload.
