from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--weights",required=True)
    ap.add_argument("--official-json",required=True)
    ap.add_argument("--out",required=True)
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)

    # Re-run exactly the same PyTorch v1 reconstruction.
    subprocess.run([
        sys.executable,"run_phase2b_v1.py",
        "--weights",args.weights,
        "--out",str(out/"pytorch"),
        "--coord-mode","center01",
    ],check=True)

    py=json.load(open(out/"pytorch"/"phase2b_v1_report.json"))
    off=json.load(open(args.official_json))
    i8=off["int8"]["response"]
    fp=off["fp32"]["response"]
    pa=py["pytorch"]["action"]
    pw=py["pytorch"]["win"]

    report={
        "format":"pluto-team-phase2b-v1.1-fp32-isolation",
        "official_int8":i8,
        "official_fp32":fp,
        "pytorch_fp32_reconstruction":{"action":pa,"win":pw},
        "comparison":{
            "official_int8_vs_fp32_action_same": i8["action"]==fp["action"],
            "official_int8_vs_fp32_win_abs_error": abs(i8["win"]-fp["win"]),
            "official_fp32_vs_pytorch_action_same": fp["action"]==pa,
            "official_fp32_vs_pytorch_win_abs_error": abs(fp["win"]-pw),
        },
        "interpretation":{
            "if_official_fp32_matches_pytorch":
                "Current architecture/order is strongly supported; shipped int8mv quantization explains most remaining divergence.",
            "if_official_fp32_differs_from_pytorch":
                "There is still an architecture/order/initial-state discrepancy independent of shipped int8mv quantization.",
        }
    }
    (out/"phase2b_v1_1_comparison.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    with (out/"phase2b_v1_1_summary.txt").open("w",encoding="utf-8") as f:
        f.write("Pluto-Team Phase2B v1.1 FP32 isolation\n")
        f.write(f"official_int8 action={i8['action']} win={i8['win']:.12g}\n")
        f.write(f"official_fp32 action={fp['action']} win={fp['win']:.12g}\n")
        f.write(f"pytorch_fp32 action={pa} win={pw:.12g}\n")
        for k,v in report["comparison"].items(): f.write(f"{k}={v}\n")
        f.write("PHASE2B_FP32_ISOLATION=PASS\n")
    print((out/"phase2b_v1_1_summary.txt").read_text())

if __name__=="__main__":
    main()
