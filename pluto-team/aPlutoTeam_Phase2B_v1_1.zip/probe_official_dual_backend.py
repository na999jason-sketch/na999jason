from __future__ import annotations
import argparse, hashlib, json, os, struct, subprocess
from pathlib import Path

HANDSHAKE_SIZE=0x88
RESPONSE_SIZE=0x28

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c: raise EOFError(f"wanted {n}, got {len(b)}")
        b.extend(c)
    return bytes(b)

def pack_request():
    n=2; W=H=128; flags=0
    parts=[struct.pack("<iiiIqqqq",n,W,H,flags,0,0,0,0)]
    cats=[[0,0,0,0,0,0],[0,1,23,0,228,0]]
    cont=[[0.0]*109 for _ in range(n)]
    cont[1][0]=0.5;cont[1][1]=0.5;cont[1][2]=1.0;cont[1][22]=1.0
    for r in cats: parts.append(struct.pack("<"+"q"*6,*r))
    for r in cont: parts.append(struct.pack("<"+"f"*109,*r))
    parts += [bytes([1,1]), bytes([1,1]), bytes([1]*20), bytes([1]*233)]
    parts += [struct.pack("<"+"f"*292,*([0.0]*292))]
    parts += [bytes(128*128*2), bytes(128*128), struct.pack("<qqqq",0,0,0,0)]
    return b"".join(parts)

def parse_hs(raw):
    magic,ver,fps,mu,step,label,build=struct.unpack("<4sIiiq48s64s",raw)
    z=lambda b:b.split(b"\0",1)[0].decode(errors="replace")
    return {"magic":magic.decode(errors="replace"),"version":ver,"frames_per_step":fps,
            "max_units":mu,"model_step":step,"label":z(label),"build":z(build)}

def parse_resp(raw):
    a,arg,pos,u,win,lp=struct.unpack("<qqqqff",raw)
    return {"action":a,"arg":arg,"pos":pos,"unit":u,"win":float(win),"logprob":float(lp),
            "hex":raw.hex()}

def run(exe,blob,backend,out_log):
    env=os.environ.copy()
    env["BWRL_DUMP_RESID"]="1"
    cmd=[str(exe),"--blob",str(blob),"--backend",backend,"--threads","1",
         "--seed","123456789","--argmax","--verbose"]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
    hs=parse_hs(read_exact(p.stdout,HANDSHAKE_SIZE))
    p.stdin.write(pack_request());p.stdin.flush()
    rr=parse_resp(read_exact(p.stdout,RESPONSE_SIZE))
    p.stdin.close()
    rc=p.wait(timeout=120)
    err=p.stderr.read().decode("utf-8",errors="replace")
    Path(out_log).write_text(err,encoding="utf-8")
    if rc!=0: raise SystemExit(f"engine rc={rc}\n{err}")
    return {"command":cmd,"handshake":hs,"response":rr,"stderr_log":str(out_log)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe",required=True)
    ap.add_argument("--int8",required=True)
    ap.add_argument("--fp32",required=True)
    ap.add_argument("--out",required=True)
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    i8=run(Path(args.exe),Path(args.int8),"int8mv",out/"official_int8_resid.log")
    fp=run(Path(args.exe),Path(args.fp32),"pk",out/"official_fp32_resid.log")
    rep={"format":"pluto-team-phase2b-v1.1-official-dual-backend",
         "int8":i8,"fp32":fp,
         "known_phase2a_int8_action":12,
         "known_phase2a_int8_win":0.08457028865814209}
    (out/"official_dual_backend.json").write_text(json.dumps(rep,indent=2),encoding="utf-8")
    print("OFFICIAL_INT8",i8["response"])
    print("OFFICIAL_FP32",fp["response"])
    print("OFFICIAL_DUAL_BACKEND=PASS")

if __name__=="__main__":
    main()
