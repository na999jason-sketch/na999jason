from __future__ import annotations
import argparse, json, re, struct, subprocess, threading, time
from pathlib import Path

import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from capstone.x86 import X86_OP_IMM

HS=0x88
RESP=0x28
TARGETS=[
    "owner_emb.weight",
    "unit_type_emb.weight",
    "order_emb.weight",
    "last_action_emb.weight",
    "train_type_emb.weight",
    "research_type_emb.weight",
    "owner vocab",
]

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c: raise EOFError(f"wanted {n}, got {len(b)}")
        b.extend(c)
    return bytes(b)

def request(owner:int):
    n=2;W=H=128;flags=0
    parts=[struct.pack("<iiiIqqqq",n,W,H,flags,0,0,0,0)]
    cats=[[0,0,0,0,0,0],[0,owner,23,0,228,0]]
    cont=[[0.0]*109 for _ in range(n)]
    cont[1][0]=0.5;cont[1][1]=0.5;cont[1][2]=1.0;cont[1][22]=1.0
    for r in cats:parts.append(struct.pack("<"+"q"*6,*r))
    for r in cont:parts.append(struct.pack("<"+"f"*109,*r))
    parts += [bytes([1,1]),bytes([1,1]),bytes([1]*20),bytes([1]*233)]
    parts += [struct.pack("<"+"f"*292,*([0.0]*292))]
    parts += [bytes(128*128*2),bytes(128*128),struct.pack("<qqqq",0,0,0,0)]
    return b"".join(parts)

def parse_hs(raw):
    magic,ver,fps,mu,step,label,build=struct.unpack("<4sIiiq48s64s",raw)
    z=lambda b:b.split(b"\0",1)[0].decode(errors="replace")
    return {"magic":z(magic),"version":ver,"fps":fps,"max_units":mu,"step":step,
            "label":z(label),"build":z(build)}

def parse_resp(raw):
    a,arg,pos,u,f0,f1=struct.unpack("<qqqqff",raw)
    return {"action":a,"arg":arg,"pos":pos,"unit":u,
            "float0":float(f0),"float1":float(f1),"hex":raw.hex()}

def run_engine(exe,blob,owner,out,tag):
    errp=out/f"{tag}.stderr.log"
    cmd=[str(exe),"--blob",str(blob),"--backend","int8mv","--threads","1",
         "--seed","123456789","--argmax","--verbose"]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
    def drain():
        with errp.open("wb") as f:
            while True:
                c=p.stderr.read(65536)
                if not c:break
                f.write(c);f.flush()
    th=threading.Thread(target=drain,daemon=True);th.start()
    hs=resp=err=None;t0=time.monotonic()
    try:
        hs=parse_hs(read_exact(p.stdout,HS))
        p.stdin.write(request(owner));p.stdin.flush()
        resp=parse_resp(read_exact(p.stdout,RESP))
        try:p.stdin.close()
        except:pass
        p.wait(timeout=15)
    except Exception as e:
        err=f"{type(e).__name__}: {e}"
        try:p.kill();p.wait(timeout=10)
        except:pass
    th.join(timeout=10)
    stderr=errp.read_text(errors="replace") if errp.exists() else ""
    return {"tag":tag,"owner":owner,"handshake":hs,"response":resp,"error":err,
            "returncode":p.returncode,"stderr":stderr,"elapsed_s":time.monotonic()-t0}

def section_for(pe,off):
    for s in pe.sections:
        a=int(s.PointerToRawData);b=a+int(s.SizeOfRawData)
        if a<=off<b:return s.Name.rstrip(b"\0").decode(errors="replace")
    return None

def scan_rip_refs(data, pe, target_va, text_sec):
    """
    Raw byte scan for common x86-64 RIP-relative LEA/MOV forms.
    This intentionally does not depend on linear-sweep disassembly staying synchronized.
    """
    refs=[]
    raw=text_sec.get_data()
    sec_file=int(text_sec.PointerToRawData)
    sec_va=int(pe.OPTIONAL_HEADER.ImageBase)+int(text_sec.VirtualAddress)

    for i in range(len(raw)-7):
        # REX + LEA/MOV r64,[rip+disp32]
        if 0x40 <= raw[i] <= 0x4f and raw[i+1] in (0x8d,0x8b):
            modrm=raw[i+2]
            if (modrm & 0xC7)==0x05:
                disp=struct.unpack_from("<i",raw,i+3)[0]
                next_va=sec_va+i+7
                dst=next_va+disp
                if dst==target_va:
                    refs.append({"file_offset":sec_file+i,"va":sec_va+i,
                                 "len":7,"bytes":raw[i:i+7].hex(),
                                 "kind":"rex_rip_lea_mov"})
        # LEA/MOV r32,[rip+disp32] (rare for strings, but cheap to include)
        if raw[i] in (0x8d,0x8b):
            modrm=raw[i+1]
            if (modrm & 0xC7)==0x05:
                disp=struct.unpack_from("<i",raw,i+2)[0]
                next_va=sec_va+i+6
                dst=next_va+disp
                if dst==target_va:
                    refs.append({"file_offset":sec_file+i,"va":sec_va+i,
                                 "len":6,"bytes":raw[i:i+6].hex(),
                                 "kind":"rip_lea_mov"})
    return refs

def disasm_window(data, pe, center_file, radius=320):
    text=next(s for s in pe.sections if s.Name.rstrip(b"\0")==b".text")
    start=max(int(text.PointerToRawData), center_file-radius)
    end=min(int(text.PointerToRawData)+int(text.SizeOfRawData), center_file+radius)
    code=data[start:end]
    va=int(pe.OPTIONAL_HEADER.ImageBase)+int(text.VirtualAddress)+(start-int(text.PointerToRawData))
    md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
    rows=[]
    for ins in md.disasm(code,va):
        fo=start+(ins.address-va)
        imms=[int(op.imm) for op in ins.operands if op.type==X86_OP_IMM]
        rows.append({"file_offset":fo,"va":ins.address,"size":ins.size,
                     "mnemonic":ins.mnemonic,"op_str":ins.op_str,
                     "immediates":imms,"bytes":bytes(ins.bytes).hex()})
    return rows

def candidate_immediates(rows, center_file, pe):
    """
    Patch candidates close to an owner string xref.
    Include comparisons and assignments of literal 3, because the gate may use either.
    """
    out=[];seen=set()
    interesting={"cmp","mov","movabs","push"}
    for r in rows:
        if r["mnemonic"] not in interesting or 3 not in r["immediates"]:
            continue
        # Locate immediate byte encoding by checking suffixes for 03 / 03000000.
        b=bytes.fromhex(r["bytes"])
        for pat,size in [(b"\x03\x00\x00\x00",4),(b"\x03",1)]:
            # Prefer a suffix occurrence; immediate generally trails instruction.
            idx=b.rfind(pat)
            if idx<0:continue
            fo=r["file_offset"]+idx
            key=(fo,size)
            if key in seen:continue
            seen.add(key)
            out.append({"file_offset":fo,"size":size,
                        "instruction_file_offset":r["file_offset"],
                        "instruction_va":r["va"],"mnemonic":r["mnemonic"],
                        "op_str":r["op_str"],"distance_to_owner_xref":abs(r["file_offset"]-center_file)})
            break
    out.sort(key=lambda x:(x["distance_to_owner_xref"],x["file_offset"]))
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe",required=True)
    ap.add_argument("--official",required=True)
    ap.add_argument("--team4",required=True)
    ap.add_argument("--out",required=True)
    args=ap.parse_args()
    exe=Path(args.exe).resolve();official=Path(args.official).resolve()
    team4=Path(args.team4).resolve();out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    baseline=run_engine(exe,team4,1,out,"baseline_team4_ally")
    print("BASELINE",baseline["stderr"].strip(),flush=True)

    data=exe.read_bytes();pe=pefile.PE(str(exe),fast_load=False)
    base=int(pe.OPTIONAL_HEADER.ImageBase)
    text=next(s for s in pe.sections if s.Name.rstrip(b"\0")==b".text")

    strings={}
    allrefs={}
    for name in TARGETS:
        pos=data.find(name.encode())
        if pos<0:
            strings[name]=None;allrefs[name]=[];continue
        rva=int(pe.get_rva_from_offset(pos));va=base+rva
        strings[name]={"file_offset":pos,"rva":rva,"va":va,"section":section_for(pe,pos)}
        allrefs[name]=scan_rip_refs(data,pe,va,text)
        print("RIPREF",name,allrefs[name],flush=True)

    owner_refs=allrefs.get("owner_emb.weight",[])
    vocab_refs=allrefs.get("owner vocab",[])
    windows=[]
    candidates=[]
    seen=set()

    # Prefer owner_emb refs; also inspect owner-vocab diagnostic refs.
    for ref in owner_refs+vocab_refs:
        rows=disasm_window(data,pe,ref["file_offset"],radius=640)
        windows.append({"ref":ref,"rows":rows})
        for c in candidate_immediates(rows,ref["file_offset"],pe):
            k=(c["file_offset"],c["size"])
            if k not in seen:
                seen.add(k);candidates.append(c)
    candidates.sort(key=lambda x:(x["distance_to_owner_xref"],x["file_offset"]))
    candidates=candidates[:64]

    print("CANDIDATES",json.dumps(candidates,indent=2),flush=True)

    attempts=[]
    for i,c in enumerate(candidates):
        patched=out/f"candidate_{i:02d}.exe"
        b=bytearray(data)
        old=int.from_bytes(b[c["file_offset"]:c["file_offset"]+c["size"]],"little")
        if old!=3:continue
        b[c["file_offset"]:c["file_offset"]+c["size"]]=(4).to_bytes(c["size"],"little")
        patched.write_bytes(b)
        r=run_engine(patched,team4,1,out,f"candidate_{i:02d}_ally")
        r["candidate_index"]=i;r["candidate"]=c
        attempts.append(r)
        print("TRY",i,c,"HS",bool(r["handshake"]),"RESP",r["response"],
              "STDERR",r["stderr"].strip(),flush=True)

    accepted=[r for r in attempts if r["handshake"] is not None]
    parity=[]
    for r in accepted:
        i=r["candidate_index"];patched=out/f"candidate_{i:02d}.exe"
        cases={name:run_engine(patched,team4,o,out,f"parity_c{i:02d}_{name}")
               for o,name in [(0,"self"),(1,"ally"),(2,"enemy"),(3,"neutral")]}
        refs={name:run_engine(exe,official,o,out,f"official_c{i:02d}_{name}")
              for o,name in [(0,"self"),(1,"other"),(2,"neutral")]}
        eq=lambda a,b:bool(a["response"] and b["response"] and a["response"]["hex"]==b["response"]["hex"])
        checks={
          "all_4way_run":all(v["response"] is not None for v in cases.values()),
          "self_preserved":eq(cases["self"],refs["self"]),
          "ally_seed_preserved":eq(cases["ally"],refs["other"]),
          "enemy_seed_preserved":eq(cases["enemy"],refs["other"]),
          "neutral_preserved":eq(cases["neutral"],refs["neutral"]),
          "ally_enemy_identical":eq(cases["ally"],cases["enemy"]),
        }
        parity.append({"candidate_index":i,"candidate":r["candidate"],
                       "checks":checks,"cases":cases,"official_refs":refs,
                       "pass":all(checks.values())})
        print("PARITY",i,checks,flush=True)

    winners=[x for x in parity if x["pass"]]

    # Human-readable disassembly windows.
    with (out/"raw_rip_xref_windows.txt").open("w",encoding="utf-8") as f:
        for w in windows:
            f.write("="*100+"\n")
            f.write("REF "+json.dumps(w["ref"])+"\n")
            for r in w["rows"]:
                f.write(f"{r['file_offset']:08x} {r['va']:016x} {r['mnemonic']:8s} {r['op_str']}\n")

    report={"format":"pluto-team-phase3b-v1.3-raw-rip-owner-gate-trace",
            "baseline":baseline,"strings":strings,"rip_refs":allrefs,
            "candidates":candidates,"attempts":attempts,
            "accepting_handshake_count":len(accepted),
            "parity":parity,"winner_count":len(winners),
            "winner":winners[0] if len(winners)==1 else None}
    (out/"phase3b_v1_3_raw_rip_trace.json").write_text(json.dumps(report,indent=2),encoding="utf-8")

    with (out/"phase3b_v1_3_summary.txt").open("w",encoding="utf-8") as f:
        f.write(f"known_rejection_reproduced={'owner vocab' in baseline['stderr']}\n")
        f.write(f"owner_emb_raw_rip_refs={len(owner_refs)}\n")
        f.write(f"owner_vocab_raw_rip_refs={len(vocab_refs)}\n")
        f.write(f"candidate_immediates={len(candidates)}\n")
        f.write(f"accepting_handshake_candidates={len(accepted)}\n")
        f.write(f"full_parity_winners={len(winners)}\n")
        if len(winners)==1:
            f.write("winner="+json.dumps(winners[0]["candidate"])+"\n")
            for k,v in winners[0]["checks"].items():f.write(f"{k}={v}\n")
            f.write("PHASE3B_V1_3_RAW_RIP_OWNER_GATE_TRACE=PASS\n")
        else:
            f.write("PHASE3B_V1_3_RAW_RIP_OWNER_GATE_TRACE=DIAGNOSTIC_ONLY\n")
    print((out/"phase3b_v1_3_summary.txt").read_text(),flush=True)

    if "owner vocab" not in baseline["stderr"]:
        raise SystemExit("known owner-vocab rejection was not reproduced")

if __name__=="__main__":
    main()
