# aPlutoTeam Phase3B v1.3 — Raw RIP Owner Gate Trace

v1.2 still found zero descriptor references because searching for literal VA/RVA
pointers does not catch normal x86-64 RIP-relative references.

v1.3 fixes that directly:

- raw-scans `.text` for RIP-relative LEA/MOV instructions whose destination is
  `owner_emb.weight` or `owner vocab`;
- disassembles a wide window around the exact raw xrefs;
- searches that function window for literal `3` used by `cmp`/`mov`/`push`;
- changes each candidate to `4` only in a temporary EXE copy;
- tests the four-row model;
- any candidate that reaches handshake must pass full byte-identical seed parity.

No patched executable is uploaded. This remains compatibility diagnosis only.
