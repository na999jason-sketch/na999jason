@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v111-launch.log"
>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V111_LAUNCHER=START

echo === aPlutoTeamRuntime v111 - v110 Ally Context + v109 Preference + Lurker-Only Burrow + Win Value ===

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV111.dll" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing %%~F
  pause
  exit /b 1
)
if not exist "%ROOT%\pluto\pluto_infer.exe" (
  echo [FAIL] missing pluto\pluto_infer.exe
  pause
  exit /b 2
)
if not exist "%ROOT%\pluto\pluto_weights.bin" (
  echo [FAIL] missing pluto\pluto_weights.bin
  pause
  exit /b 3
)

taskkill /IM pluto_infer.exe /F >nul 2>nul

REM Keep exactly the same official stock Pluto model contract as v110.
if exist "%ROOT%\pluto\pluto_infer.official.exe" if exist "%ROOT%\pluto\pluto_weights.official.bin" (
  copy /Y "%ROOT%\pluto\pluto_infer.official.exe" "%ROOT%\pluto\pluto_infer.exe" >nul
  copy /Y "%ROOT%\pluto\pluto_weights.official.bin" "%ROOT%\pluto\pluto_weights.bin" >nul
  echo V111_STOCK_RESTORE=OFFICIAL_BACKUPS_APPLIED>>"%LAUNCHLOG%"
) else (
  echo V111_STOCK_RESTORE=NO_BACKUPS_USING_ACTIVE_FILES_RUNTIME_WILL_VERIFY_STOCK3>>"%LAUNCHLOG%"
)

del /q "%ROOT%\plutoteam-x86-v111.log" 2>nul

echo.
echo [v111] v109 early-army preference is preserved unchanged.
echo [v111] Allied army is non-owned by default and contributes SELF combat context only near visible enemies.
echo [v111] Burrowing research/non-Lurker burrow are blocked; Lurker burrow remains allowed.
echo [v111] Pluto win/value is logged from the official infer response.
echo [v111] Press a key only after the game is loaded.
pause >nul
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV111.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
  echo [FAIL] injection failed
  pause
  exit /b %RC%
)
echo [PASS] v111 injected. Check plutoteam-x86-v111.log after the game.
pause
