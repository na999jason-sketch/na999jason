aPlutoTeamRuntime v111 - v110 BASELINE + LURKER_ONLY BURROW + OFFICIAL WIN/VALUE LOG

PURPOSE
- Preserve v110 ally observation policy unchanged.
- Preserve v109 early-army preference unchanged.
- Prevent wasteful Zerg Burrowing research and non-Lurker burrow/unburrow behavior.
- Keep Lurker Burrow/Unburrow fully available.
- Log Pluto's own real-time win/value directly from the official inference response.
- NO model training, NO weight patch, NO inference EXE patch, NO replacement strategy.

UNCHANGED BASELINE
- Official stock Pluto: SELF=0, OTHER=1, NEUTRAL=2.
- v110 ally observation: all allies non-owned by default; allied combat/support becomes temporary SELF context only within 512 px of a visible enemy.
- Ally actor/target mask=0 plus ally-target DROP safety.
- v109 early-army preference parameters and implementation remain unchanged.

V111 BURROW POLICY = LURKER_ONLY
1) Legacy research command 0x30 with tech id 11 (Burrowing) is dropped before SCR submission.
   - Result: no minerals/gas are spent on Burrowing.
2) Legacy Burrow/Unburrow commands 0x2c/0x2d are allowed only when the explicit current selection is known and consists entirely of Zerg Lurkers.
3) Drone/Zergling/Hydralisk/Defiler/etc. Burrow/Unburrow is dropped.
4) No replacement command is invented. Pluto continues making all other decisions itself.

V111 REAL-TIME PLUTO WIN/VALUE
- Official infer response is 0x28 bytes: int64 action,arg,pos,unit + float win + float logprob.
- v111 reads the existing float at SHM response offset 0x85F60.
- Reconstructed official semantics: win = P(win) - P(loss), range approximately [-1,+1].
- Therefore pwin_percent = (win + 1) * 50.
- This is Pluto's own model evaluation, not a separately trained estimator.
- Logging is read-only and does not feed back into Pluto decisions.
- Logs periodically and also on >=0.10 value movement.

EXPECTED LOG MARKERS
PLUTOTEAMRUNTIME_V111_RESIDENT=LOADED
V111_STOCK_ENGINE=OFFICIAL_3WAY_GATE_VERIFIED offset=59203 value=3
V111_STOCK_WEIGHTS=OWNER_EMB_3X256_VERIFIED
V111_BURROW_POLICY=LURKER_ONLY_RESEARCH_DROP_NONLURKER_BURROW_DROP_LURKER_ALLOW
V111_BURROW_BLOCK kind=RESEARCH_BURROWING ...
V111_BURROW_BLOCK kind=BURROW_NON_LURKER ...
V111_LURKER_BURROW_ALLOW ...
V111_BURROW_SUMMARY research_blocked=... command_blocked=... lurker_allowed=...
V111_PLUTO_WIN_VALUE frame=... value=... pwin_percent=... action=... logprob=...
V111_PLUTO_WIN_SUMMARY frame=... last=... min=... max=... won=...
V110_SHM_OWNER_REWRITE=PASS ... (v110 observation marker intentionally preserved)
V109_PREF_SUMMARY ...
TEAM_TRAINING_RECORDER=CONFIRMED_DISABLED_V111

TEST
- Zerg: confirm Burrowing never completes and non-Lurkers stop burrow/unburrow cycling.
- If Lurkers are produced, confirm their normal burrow combat still works and V111_LURKER_BURROW_ALLOW appears.
- Compare V111_PLUTO_WIN_VALUE movement with visible game state.
- Confirm v110 macro/team behavior remains otherwise unchanged.

After the game, send plutoteam-x86-v111.log. PTRJ is not recorded.
