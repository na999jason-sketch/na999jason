# aPlutoTeam Phase2B v1.3 — streaming residual isolation

v1.2 did not prove that either inference backend was slow.

The diagnostic artifact showed a classic pipe deadlock:
- official int8 stderr log: 4142 bytes, stops mid residual-dump line
- official FP32 stderr log: 4142 bytes, stops at essentially the same place
- neither process reached the stdout handshake

`BWRL_DUMP_RESID=1` writes several KB to stderr before the handshake.
v1.2 connected stderr to a PIPE but only read it after the process exited.
On Windows the pipe filled, so pluto_infer blocked before it could emit the handshake.

v1.3 drains stderr continuously in a dedicated thread while simultaneously
reading the binary stdout protocol.

This preserves residual diagnostics and removes the false timeout/deadlock.

No Pluto weights are trained or modified by this phase.
