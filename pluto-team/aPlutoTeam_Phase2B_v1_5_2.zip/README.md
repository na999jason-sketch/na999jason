# aPlutoTeam Phase2B v1.5.2 — I8 Dump Xref Disassembly

v1.5.1 proved:
- every tested `BWRL_I8_DUMP` value still preserves the correct official result (12/43/54),
- none of those values created files,
- the official EXE definitely contains:
  - `BWRL_I8_DUMP`
  - `%s/c%04d_M%lld_K%lld_N%lld`
  - `_a.bin`, `_q.bin`, `_s.bin`, `_zp.bin`.

So v1.5.2 stops guessing environment-variable values and statically traces the exact code path.

It installs `pefile` + `capstone`, finds RIP-relative xrefs from `.text` to those strings,
annotates imported calls (`getenv`, file I/O, mkdir/CreateDirectory, snprintf, etc.), and
emits large disassembly windows around every xref.

This should reveal the extra gating condition and/or exact meaning of the `%s` path argument.

Diagnostic only; no training and no model mutation.
