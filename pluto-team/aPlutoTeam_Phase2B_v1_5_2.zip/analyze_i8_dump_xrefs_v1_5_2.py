from __future__ import annotations
import argparse, json, re
from pathlib import Path

import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from capstone.x86 import X86_OP_MEM, X86_OP_IMM, X86_REG_RIP

TARGET_STRINGS = [
    b"BWRL_I8_DUMP\x00",
    b"%s/c%04d_M%lld_K%lld_N%lld\x00",
    b"_a.bin\x00",
    b"_q.bin\x00",
    b"_s.bin\x00",
    b"_zp.bin\x00",
    b"BWRL_I8_NOSHARE\x00",
    b"BWRL_I8_NOFUSE\x00",
]

def printable_name(b):
    return b.rstrip(b"\x00").decode("ascii", "replace")

def find_all(data: bytes, needle: bytes):
    pos=0
    out=[]
    while True:
        i=data.find(needle,pos)
        if i<0: break
        out.append(i)
        pos=i+1
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe", required=True)
    ap.add_argument("--out", required=True)
    args=ap.parse_args()

    exe=Path(args.exe).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    data=exe.read_bytes()
    pe=pefile.PE(str(exe), fast_load=False)
    image_base=pe.OPTIONAL_HEADER.ImageBase

    iat={}
    imports=[]
    if hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
        for desc in pe.DIRECTORY_ENTRY_IMPORT:
            dll=desc.dll.decode(errors="replace")
            for imp in desc.imports:
                name=(imp.name.decode(errors="replace") if imp.name else f"ord_{imp.ordinal}")
                iat[int(imp.address)] = f"{dll}!{name}"
                imports.append({"dll":dll,"name":name,"iat_va":int(imp.address)})

    text_sec=None
    for s in pe.sections:
        name=s.Name.rstrip(b"\x00")
        if name==b".text":
            text_sec=s
            break
    if text_sec is None:
        raise SystemExit(".text missing")

    text=text_sec.get_data()
    text_va=image_base + text_sec.VirtualAddress

    md=Cs(CS_ARCH_X86, CS_MODE_64)
    md.detail=True
    ins=list(md.disasm(text, text_va))
    addr_to_idx={x.address:i for i,x in enumerate(ins)}

    string_records=[]
    target_va_to_label={}
    for needle in TARGET_STRINGS:
        label=printable_name(needle)
        offs=find_all(data,needle)
        for off in offs:
            try:
                rva=pe.get_rva_from_offset(off)
            except Exception:
                continue
            va=image_base+rva
            target_va_to_label[va]=label
            string_records.append({"label":label,"file_offset":off,"rva":rva,"va":va})

    def rip_target(i,op):
        return i.address+i.size+op.mem.disp

    xrefs=[]
    for idx,i in enumerate(ins):
        refs=[]
        for op in i.operands:
            if op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP:
                t=rip_target(i,op)
                if t in target_va_to_label:
                    refs.append({"target_va":t,"label":target_va_to_label[t],"kind":"rip_mem"})
            elif op.type==X86_OP_IMM and int(op.imm) in target_va_to_label:
                t=int(op.imm)
                refs.append({"target_va":t,"label":target_va_to_label[t],"kind":"imm"})
        if refs:
            xrefs.append({"idx":idx,"address":i.address,"mnemonic":i.mnemonic,"op_str":i.op_str,"refs":refs})

    # Annotate imports and referenced strings for context.
    def annotation(i):
        ann=[]
        for op in i.operands:
            if op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP:
                t=rip_target(i,op)
                if t in iat:
                    ann.append("IAT="+iat[t])
                if t in target_va_to_label:
                    ann.append("STR="+repr(target_va_to_label[t]))
            elif op.type==X86_OP_IMM:
                t=int(op.imm)
                if t in target_va_to_label:
                    ann.append("STR="+repr(target_va_to_label[t]))
        return " ; " + " | ".join(ann) if ann else ""

    windows=[]
    for x in xrefs:
        idx=x["idx"]
        lo=max(0,idx-90)
        hi=min(len(ins),idx+140)
        lines=[]
        for j in range(lo,hi):
            i=ins[j]
            marker=">>" if j==idx else "  "
            lines.append(f"{marker} {i.address:016x}: {i.mnemonic:8s} {i.op_str}{annotation(i)}")
        windows.append({
            "xref":{k:v for k,v in x.items() if k!="idx"},
            "window_start":ins[lo].address if lo<len(ins) else None,
            "window_end":ins[hi-1].address if hi else None,
            "disassembly":"\n".join(lines),
        })

    interesting_imports=[]
    rx=re.compile(r"(getenv|fopen|fwrite|fclose|mkdir|CreateDirectory|CreateFile|WriteFile|snprintf|sprintf|open|write|stat|access|filesystem|remove)",re.I)
    for r in imports:
        if rx.search(r["name"]):
            interesting_imports.append(r)

    report={
        "format":"pluto-team-phase2b-v1.5.2-i8-dump-xref-disassembly",
        "exe":str(exe),
        "image_base":image_base,
        "text_va":text_va,
        "text_size":len(text),
        "strings":string_records,
        "xrefs":[{k:v for k,v in x.items() if k!="idx"} for x in xrefs],
        "interesting_imports":interesting_imports,
        "windows":windows,
    }
    (out/"i8_dump_xrefs.json").write_text(json.dumps(report,indent=2),encoding="utf-8")

    with (out/"i8_dump_xrefs.txt").open("w",encoding="utf-8") as f:
        f.write("Pluto-Team Phase2B v1.5.2 I8 dump xref disassembly\n\n")
        f.write("TARGET STRINGS\n")
        for r in string_records:
            f.write(f"{r['label']!r} file=0x{r['file_offset']:x} rva=0x{r['rva']:x} va=0x{r['va']:x}\n")
        f.write("\nINTERESTING IMPORTS\n")
        for r in interesting_imports:
            f.write(f"0x{r['iat_va']:x} {r['dll']}!{r['name']}\n")
        f.write("\nXREF WINDOWS\n")
        for w in windows:
            f.write("\n"+"="*100+"\n")
            f.write(json.dumps(w["xref"])+"\n")
            f.write(w["disassembly"]+"\n")
        f.write("\nPHASE2B_V1_5_2_XREF_DISASSEMBLY=PASS\n")

    print(f"string_records={len(string_records)} xrefs={len(xrefs)} interesting_imports={len(interesting_imports)}")
    for x in xrefs:
        print(f"XREF 0x{x['address']:x} {x['mnemonic']} {x['op_str']} -> {[r['label'] for r in x['refs']]}")
    print("PHASE2B_V1_5_2_XREF_DISASSEMBLY=PASS")

    if not any(r["label"]=="BWRL_I8_DUMP" for r in string_records):
        raise SystemExit("BWRL_I8_DUMP string not found")
    if not any(any(r["label"]=="BWRL_I8_DUMP" for r in x["refs"]) for x in xrefs):
        raise SystemExit("BWRL_I8_DUMP xref not found")

if __name__=="__main__":
    main()
