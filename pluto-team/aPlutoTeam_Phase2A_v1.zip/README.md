# aPlutoTeam Phase2A v1 — official infer black-box parity probes

This phase does not alter or train Pluto.

It launches the official `pluto_infer.exe` directly through its documented pipe transport,
reads the PLO1 v3 handshake, sends deterministic synthetic model-boundary requests, and records
the exact 40-byte responses.

Why this matters:
- Phase1 proved that all 269 public inference tensors can be recovered into a trainable checkpoint.
- Phase2A gives us stable official-engine reference outputs.
- Phase2B can implement the PyTorch forward and compare against these references.

Probes:
- null_only
- self_center
- other_center
- neutral_center
- other_nw
- other_se
- repeat of other_center in a fresh engine process

The workflow uses `--argmax --seed 123456789 --threads 1` and requires the repeated fresh-process
response to be byte-identical.

No StarCraft process is needed. This is an offline inference-engine probe.
