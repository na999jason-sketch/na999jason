#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

HANDSHAKE_SIZE = 0x88
RESPONSE_SIZE = 0x28

def read_exact(pipe, n: int) -> bytes:
    out = bytearray()
    while len(out) < n:
        chunk = pipe.read(n - len(out))
        if not chunk:
            raise EOFError(f"expected {n} bytes, got {len(out)}")
        out.extend(chunk)
    return bytes(out)

def pack_request(owner: int | None, x: float = 0.5, y: float = 0.5) -> bytes:
    # Row 0 is Pluto's reserved null unit. When owner is None, send only row 0.
    n = 1 if owner is None else 2
    W = H = 128
    flags = 0
    forced = (0, 0, 0, 0)

    parts = [struct.pack("<iiiIqqqq", n, W, H, flags, *forced)]

    cats = [[0, 0, 0, 0, 0, 0] for _ in range(n)]
    cont = [[0.0] * 109 for _ in range(n)]

    if owner is not None:
        # A conservative synthetic Marine-like row. The black-box probe is not intended
        # to represent a legal full game state; it is a stable model-boundary stimulus.
        cats[1] = [
            0,      # unit_type: Terran Marine
            owner,  # owner vocabulary: 0 self, 1 other, 2 neutral
            23,     # order: Nothing
            0,      # last action
            228,    # no train type sentinel
            0,      # no research/upgrade
        ]
        cont[1][0] = float(x)
        cont[1][1] = float(y)
        cont[1][2] = 1.0    # hp fraction
        cont[1][22] = 1.0   # completed

    for row in cats:
        parts.append(struct.pack("<" + "q"*6, *row))
    for row in cont:
        parts.append(struct.pack("<" + "f"*109, *row))

    # Keep null and synthetic row targetable to avoid an empty pointer mask.
    parts.append(bytes([1] * n))      # unit_mask_a
    parts.append(bytes([1] * n))      # unit_mask_b

    # Enable every high-level action / argument at the request boundary. The engine
    # still applies its own static per-action arg restrictions.
    parts.append(bytes([1] * 20))
    parts.append(bytes([1] * 233))

    parts.append(struct.pack("<" + "f"*292, *([0.0] * 292)))  # globals
    parts.append(bytes(128 * 128 * 2))                       # map bits u16
    parts.append(bytes(128 * 128))                           # static map u8
    parts.append(struct.pack("<qqqq", 0, 0, 0, 0))           # action history

    req = b"".join(parts)
    expected = 0x30 + n*0x30 + n*0x1b4 + n + n + 20 + 233 + 292*4 + 0x8000 + 0x4000 + 0x20
    if len(req) != expected:
        raise AssertionError((len(req), expected))
    return req

def parse_handshake(raw: bytes) -> dict:
    if len(raw) != HANDSHAKE_SIZE:
        raise ValueError("bad handshake length")
    magic, version, frames_per_step, max_units, model_step, label, build = struct.unpack(
        "<4sIiiq48s64s", raw
    )
    def zstr(b):
        return b.split(b"\0", 1)[0].decode("utf-8", errors="replace")
    return {
        "magic": magic.decode("ascii", errors="replace"),
        "version": version,
        "frames_per_step": frames_per_step,
        "max_units": max_units,
        "model_step": model_step,
        "label": zstr(label),
        "build": zstr(build),
    }

def parse_response(raw: bytes) -> dict:
    if len(raw) != RESPONSE_SIZE:
        raise ValueError("bad response length")
    a, arg, pos, unit, win, lp = struct.unpack("<qqqqff", raw)
    return {
        "action": a,
        "arg": arg,
        "pos": pos,
        "unit": unit,
        "win": float(win),
        "logprob": float(lp),
        "response_hex": raw.hex(),
    }

def run_once(exe: Path, weights: Path, request: bytes, seed: int, threads: int) -> dict:
    cmd = [
        str(exe),
        "--blob", str(weights),
        "--threads", str(threads),
        "--seed", str(seed),
        "--argmax",
        "--verbose",
    ]
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    p = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=creationflags,
    )

    try:
        hs_raw = read_exact(p.stdout, HANDSHAKE_SIZE)
        hs = parse_handshake(hs_raw)
        if hs["magic"] != "PLO1" or hs["version"] != 3:
            raise RuntimeError(f"unexpected handshake: {hs}")

        p.stdin.write(request)
        p.stdin.flush()
        resp_raw = read_exact(p.stdout, RESPONSE_SIZE)
        resp = parse_response(resp_raw)

        # EOF on pipe transport asks the engine to shut down cleanly.
        p.stdin.close()
        try:
            rc = p.wait(timeout=30)
        except subprocess.TimeoutExpired:
            p.kill()
            rc = p.wait(timeout=10)

        stderr = p.stderr.read().decode("utf-8", errors="replace")
        return {
            "command": cmd,
            "returncode": rc,
            "handshake": hs,
            "response": resp,
            "stderr": stderr,
        }
    finally:
        if p.poll() is None:
            p.kill()
            p.wait(timeout=10)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exe", required=True)
    ap.add_argument("--weights", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=123456789)
    ap.add_argument("--threads", type=int, default=1)
    args = ap.parse_args()

    exe = Path(args.exe).resolve()
    weights = Path(args.weights).resolve()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    probes = [
        ("null_only", None, 0.5, 0.5),
        ("self_center", 0, 0.5, 0.5),
        ("other_center", 1, 0.5, 0.5),
        ("neutral_center", 2, 0.5, 0.5),
        ("other_nw", 1, 0.20, 0.20),
        ("other_se", 1, 0.80, 0.80),
    ]

    results = []
    for name, owner, x, y in probes:
        req = pack_request(owner, x, y)
        run = run_once(exe, weights, req, args.seed, args.threads)
        if run["returncode"] != 0:
            print(run["stderr"], file=sys.stderr)
            raise SystemExit(f"{name}: engine return code {run['returncode']}")
        item = {
            "name": name,
            "owner": owner,
            "x": x,
            "y": y,
            "request_sha256": hashlib.sha256(req).hexdigest(),
            **run,
        }
        results.append(item)
        print(name, run["response"])

    # Repeat one probe from a fresh engine. --argmax + reset recurrent state should
    # produce exactly the same response bytes.
    req = pack_request(1, 0.5, 0.5)
    repeat = run_once(exe, weights, req, args.seed, args.threads)
    original = next(x for x in results if x["name"] == "other_center")
    deterministic = repeat["response"]["response_hex"] == original["response"]["response_hex"]

    report = {
        "format": "pluto-team-phase2a-blackbox-v1",
        "engine": str(exe),
        "weights": str(weights),
        "weights_sha256": hashlib.sha256(weights.read_bytes()).hexdigest(),
        "seed": args.seed,
        "threads": args.threads,
        "argmax": True,
        "deterministic_repeat_other_center": deterministic,
        "repeat_other_center": repeat,
        "probes": results,
    }

    (out / "phase2a_blackbox_probes.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    with (out / "phase2a_blackbox_summary.txt").open("w", encoding="utf-8") as f:
        f.write("Pluto-Team Phase2A v1 official infer black-box probe\n")
        f.write(f"weights_sha256={report['weights_sha256']}\n")
        f.write(f"deterministic_repeat_other_center={deterministic}\n")
        for item in results:
            r = item["response"]
            f.write(
                f"{item['name']}: action={r['action']} arg={r['arg']} "
                f"pos={r['pos']} unit={r['unit']} win={r['win']:.9g} "
                f"logprob={r['logprob']:.9g} hex={r['response_hex']}\n"
            )

    # Save stderr per probe for later reverse-engineering/parity work.
    logs = out / "engine_logs"
    logs.mkdir(exist_ok=True)
    for item in results:
        (logs / f"{item['name']}.log").write_text(item["stderr"], encoding="utf-8")
    (logs / "repeat_other_center.log").write_text(repeat["stderr"], encoding="utf-8")

    if not deterministic:
        raise SystemExit("FAIL: fresh-process argmax repeat was not byte-identical")

    hs = results[0]["handshake"]
    if hs["frames_per_step"] != 6 or hs["max_units"] != 768:
        raise SystemExit(f"FAIL unexpected handshake config: {hs}")

    print("PHASE2A_OFFICIAL_INFER_BLACKBOX=PASS")
    print("HANDSHAKE", hs)

if __name__ == "__main__":
    main()
