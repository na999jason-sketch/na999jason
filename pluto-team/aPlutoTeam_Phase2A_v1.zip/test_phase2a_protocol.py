from probe_pluto_infer_pipe import pack_request, parse_handshake, parse_response
import struct

def test_request_lengths():
    a = pack_request(None)
    assert len(a) == 0x30 + 1*0x30 + 1*0x1b4 + 1 + 1 + 20 + 233 + 292*4 + 0x8000 + 0x4000 + 0x20
    b = pack_request(1)
    assert len(b) == 0x30 + 2*0x30 + 2*0x1b4 + 2 + 2 + 20 + 233 + 292*4 + 0x8000 + 0x4000 + 0x20

def test_parse_protocol():
    hs = struct.pack("<4sIiiq48s64s", b"PLO1", 3, 6, 768, 2578600, b"x\0", b"y\0")
    d = parse_handshake(hs)
    assert d["magic"] == "PLO1"
    assert d["version"] == 3
    assert d["frames_per_step"] == 6
    assert d["max_units"] == 768

    rr = struct.pack("<qqqqff", 1,2,3,4,0.25,-1.5)
    r = parse_response(rr)
    assert r["action"] == 1 and r["arg"] == 2 and r["pos"] == 3 and r["unit"] == 4
