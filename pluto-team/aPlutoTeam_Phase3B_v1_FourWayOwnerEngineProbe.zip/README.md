# aPlutoTeam Phase3B v1 — Four-Way Owner Engine Probe

v101 in-game logging proved that SC:R allies are identified correctly from the real
`Game::alliances` matrix and CUnit owner field, including allied buildings.

The remaining model-level problem is that the official Pluto model currently uses:

- 0 self
- 1 other player
- 2 neutral

This phase tests the shortest safe upgrade path before touching the live DLL:

1. Download the exact official `pluto_weights.bin`.
2. Rebuild only `owner_emb.weight` from `[3,256]` to `[4,256]`.
3. Preserve policy at the seed point:
   - new[0] = old[0] self
   - new[1] = old[1] ally seed
   - new[2] = old[1] enemy seed
   - new[3] = old[2] neutral
4. Launch the unmodified official `pluto_infer.exe`.
5. Send fresh-process probes for owner categories 0/1/2/3.
6. Require byte-identical responses versus the corresponding official 3-way rows.

If this passes, the official engine is already capable of loading the four-row owner
embedding. Then the next runtime step is to rewrite only the request's owner column
immediately before the Pluto request event is signaled, using the alliance relation
already proven by v101.

No training occurs in this phase.
