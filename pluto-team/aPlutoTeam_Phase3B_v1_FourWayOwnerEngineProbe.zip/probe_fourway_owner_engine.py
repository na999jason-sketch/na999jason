from __future__ import annotations
import argparse, json, os, struct, subprocess, threading, time
from pathlib import Path

HS=0x88
RESP=0x28

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c:
            raise EOFError(f"wanted {n}, got {len(b)}")
        b.extend(c)
    return bytes(b)

def request(owner:int):
    n=2; W=H=128; flags=0
    parts=[struct.pack("<iiiIqqqq",n,W,H,flags,0,0,0,0)]
    cats=[[0,0,0,0,0,0],[0,owner,23,0,228,0]]
    cont=[[0.0]*109 for _ in range(n)]
    cont[1][0]=0.5; cont[1][1]=0.5; cont[1][2]=1.0; cont[1][22]=1.0
    for r in cats: parts.append(struct.pack("<"+"q"*6,*r))
    for r in cont: parts.append(struct.pack("<"+"f"*109,*r))
    parts += [bytes([1,1]),bytes([1,1]),bytes([1]*20),bytes([1]*233)]
    parts += [struct.pack("<"+"f"*292,*([0.0]*292))]
    parts += [bytes(128*128*2),bytes(128*128),struct.pack("<qqqq",0,0,0,0)]
    return b"".join(parts)

def parse_hs(raw):
    magic,ver,fps,mu,step,label,build=struct.unpack("<4sIiiq48s64s",raw)
    z=lambda b:b.split(b"\0",1)[0].decode(errors="replace")
    return {"magic":magic.decode(errors="replace"),"version":ver,"fps":fps,
            "max_units":mu,"step":step,"label":z(label),"build":z(build)}

def parse_resp(raw):
    a,arg,pos,u,f0,f1=struct.unpack("<qqqqff",raw)
    # Keep float names neutral; Phase2 protocol semantic order remains under exact verification.
    return {"action":a,"arg":arg,"pos":pos,"unit":u,
            "float0":float(f0),"float1":float(f1),"hex":raw.hex()}

def one(exe:Path, blob:Path, owner:int, tag:str, out:Path, timeout=60):
    log=out/f"{tag}.stderr.log"
    cmd=[str(exe),"--blob",str(blob),"--backend","int8mv","--threads","1",
         "--seed","123456789","--argmax","--verbose"]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)

    def drain():
        with log.open("wb") as f:
            while True:
                c=p.stderr.read(65536)
                if not c: break
                f.write(c); f.flush()
    th=threading.Thread(target=drain,daemon=True); th.start()

    t0=time.monotonic()
    hs=resp=err=None
    try:
        hs=parse_hs(read_exact(p.stdout,HS))
        p.stdin.write(request(owner)); p.stdin.flush()
        raw=read_exact(p.stdout,RESP)
        resp=parse_resp(raw)
        try:p.stdin.close()
        except:pass
        p.wait(timeout=20)
    except Exception as e:
        err=f"{type(e).__name__}: {e}"
        try:p.kill();p.wait(timeout=10)
        except:pass
    th.join(timeout=10)
    return {"tag":tag,"owner":owner,"blob":str(blob),"elapsed_s":time.monotonic()-t0,
            "returncode":p.returncode,"handshake":hs,"response":resp,"error":err,
            "stderr_bytes":log.stat().st_size if log.exists() else 0}

def eq(a,b):
    return bool(a and b and a["response"] and b["response"] and
                a["response"]["hex"]==b["response"]["hex"])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe",required=True)
    ap.add_argument("--official",required=True)
    ap.add_argument("--team4",required=True)
    ap.add_argument("--out",required=True)
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    exe=Path(args.exe); official=Path(args.official); team4=Path(args.team4)

    cases={}
    for owner,name in [(0,"self"),(1,"other"),(2,"neutral")]:
        r=one(exe,official,owner,f"official_{name}",out)
        cases[r["tag"]]=r
        print("CASE",r["tag"],r["handshake"],r["response"],r["error"],flush=True)

    for owner,name in [(0,"self"),(1,"ally"),(2,"enemy"),(3,"neutral")]:
        r=one(exe,team4,owner,f"team4_{name}",out)
        cases[r["tag"]]=r
        print("CASE",r["tag"],r["handshake"],r["response"],r["error"],flush=True)

    checks={
        "engine_accepts_4way_owner_blob":
            all(cases[k]["response"] is not None and cases[k]["error"] is None
                for k in ["team4_self","team4_ally","team4_enemy","team4_neutral"]),
        "self_preserved":eq(cases["official_self"],cases["team4_self"]),
        "ally_seed_preserved":eq(cases["official_other"],cases["team4_ally"]),
        "enemy_seed_preserved":eq(cases["official_other"],cases["team4_enemy"]),
        "neutral_preserved":eq(cases["official_neutral"],cases["team4_neutral"]),
        "ally_enemy_identical_at_seed":eq(cases["team4_ally"],cases["team4_enemy"]),
    }
    passed=all(checks.values())
    rep={"format":"pluto-team-phase3b-v1-fourway-owner-engine-probe",
         "cases":cases,"checks":checks,"pass":passed}
    (out/"phase3b_v1_fourway_owner_probe.json").write_text(json.dumps(rep,indent=2),encoding="utf-8")
    with (out/"phase3b_v1_summary.txt").open("w",encoding="utf-8") as f:
        for k,v in checks.items(): f.write(f"{k}={v}\n")
        f.write(f"PHASE3B_V1_FOURWAY_OWNER_ENGINE_PROBE={'PASS' if passed else 'FAIL'}\n")
    print((out/"phase3b_v1_summary.txt").read_text(),flush=True)
    if not passed:
        raise SystemExit(2)

if __name__=="__main__":
    main()
