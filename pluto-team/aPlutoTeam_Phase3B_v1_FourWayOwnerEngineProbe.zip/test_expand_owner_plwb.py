import json, struct, subprocess, sys, tempfile
from pathlib import Path

def make_synth(path):
    # Minimal legal PLWB for testing the rebuilder. owner is followed by a second tensor.
    owner = b"".join(struct.pack("<f", float(i)) for i in range(3*256))
    other = b"ABCD"*8
    tensors=[
      {"name":"owner_emb.weight","shape":[3,256],"offset":0,"nbytes":len(owner),"dtype":"float32"},
      {"name":"dummy","shape":[8],"offset":len(owner),"nbytes":len(other),"dtype":"float32"},
    ]
    hdr={"label":"synthetic","total_bytes":len(owner)+len(other),"tensors":tensors}
    hb=json.dumps(hdr,separators=(",",":")).encode()
    base=(16+len(hb)+63)&~63
    raw=b"PLWB"+struct.pack("<I",1)+struct.pack("<Q",len(hb))+hb+b"\0"*(base-16-len(hb))+owner+other
    path.write_bytes(raw)

def read(path):
    raw=path.read_bytes(); hlen=struct.unpack_from("<Q",raw,8)[0]
    hdr=json.loads(raw[16:16+hlen]);base=len(raw)-hdr["total_bytes"]
    return raw,hdr,base

with tempfile.TemporaryDirectory() as td:
    td=Path(td); a=td/"a.bin"; b=td/"b.bin"
    make_synth(a)
    subprocess.check_call([sys.executable,str(Path(__file__).with_name("expand_owner_plwb_4way.py")),str(a),str(b)])
    raw,h,base=read(b)
    owner=next(t for t in h["tensors"] if t["name"]=="owner_emb.weight")
    dummy=next(t for t in h["tensors"] if t["name"]=="dummy")
    assert owner["shape"]==[4,256]
    assert owner["nbytes"]==4096
    assert dummy["offset"]==4096
    data=raw[base:]
    row=1024
    assert data[row:2*row]==data[2*row:3*row]
    assert data[3*row:4*row] != data[2*row:3*row]
    assert data[4096:4096+32]==b"ABCD"*8
print("SYNTHETIC_PLWB_REBUILD_TEST=PASS")
