import argparse, torch, math

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("checkpoint")
    args = ap.parse_args()
    ckpt = torch.load(args.checkpoint, map_location="cpu")
    state = ckpt["state_dict"]
    total = sum(v.numel() for v in state.values())
    print("format:", ckpt.get("format"))
    print("tensors:", len(state))
    print("params:", total)
    w = state["owner_emb.weight"]
    print("owner_emb.weight:", tuple(w.shape), w.dtype)
    if tuple(w.shape) != (4,256):
        raise SystemExit("FAIL owner vocab not expanded")
    if not torch.equal(w[1], w[2]):
        raise SystemExit("FAIL seed policy expected ally==enemy")
    bad = []
    for name, t in state.items():
        if t.is_floating_point() and not torch.isfinite(t.float()).all():
            bad.append(name)
    if bad:
        raise SystemExit("FAIL non-finite tensors: " + ", ".join(bad[:20]))
    print("PASS")

if __name__ == "__main__":
    main()
