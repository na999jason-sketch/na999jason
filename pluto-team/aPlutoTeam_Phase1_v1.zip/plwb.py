from __future__ import annotations
import json, math, struct
from dataclasses import dataclass
from pathlib import Path
import numpy as np

DTYPE_BYTES = {"float32": 4, "float16": 2, "bfloat16": 2, "int8": 1}

@dataclass(frozen=True)
class TensorInfo:
    name: str
    shape: tuple[int, ...]
    offset: int
    nbytes: int
    dtype: str
    scale_offset: int | None = None
    scale_len: int | None = None

    @property
    def numel(self) -> int:
        return math.prod(self.shape)

    @property
    def scale_axis(self) -> int | None:
        if self.scale_len is None:
            return None
        if self.scale_len == self.shape[0]:
            return 0
        if len(self.shape) > 1 and self.scale_len == self.shape[1]:
            return 1
        raise ValueError(f"{self.name}: unsupported scale axis")

class PLWB:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.raw = self.path.read_bytes()
        if self.raw[:4] != b"PLWB":
            raise ValueError("not a Pluto PLWB weights container")
        self.version = struct.unpack_from("<I", self.raw, 4)[0]
        if self.version != 1:
            raise ValueError(f"unsupported PLWB version: {self.version}")
        self.header_len = struct.unpack_from("<Q", self.raw, 8)[0]
        h0, h1 = 16, 16 + self.header_len
        if h1 > len(self.raw):
            raise ValueError("truncated PLWB header")
        self.header = json.loads(self.raw[h0:h1].decode("utf-8"))
        self.total_bytes = int(self.header["total_bytes"])
        self.base = len(self.raw) - self.total_bytes
        if self.base < h1 or self.base % 64:
            raise ValueError("invalid PLWB data base")
        self.tensors = []
        for d in self.header["tensors"]:
            self.tensors.append(TensorInfo(
                name=d["name"],
                shape=tuple(int(x) for x in d["shape"]),
                offset=int(d["offset"]),
                nbytes=int(d["nbytes"]),
                dtype=d.get("dtype", "float32"),
                scale_offset=None if d.get("scale_offset") is None else int(d["scale_offset"]),
                scale_len=None if d.get("scale_len") is None else int(d["scale_len"]),
            ))
        self.by_name = {t.name: t for t in self.tensors}
        if len(self.by_name) != len(self.tensors):
            raise ValueError("duplicate tensor name")
        self.validate()

    def _slice(self, offset: int, nbytes: int) -> memoryview:
        a = self.base + offset
        b = a + nbytes
        if a < self.base or b > len(self.raw):
            raise ValueError("tensor span outside PLWB data")
        return memoryview(self.raw)[a:b]

    def validate(self) -> None:
        spans = []
        for t in self.tensors:
            if t.dtype not in DTYPE_BYTES:
                raise ValueError(f"{t.name}: unsupported dtype {t.dtype}")
            expected = t.numel * DTYPE_BYTES[t.dtype]
            if t.nbytes != expected:
                raise ValueError(f"{t.name}: nbytes {t.nbytes} != expected {expected}")
            spans.append((t.offset, t.offset + t.nbytes, t.name))
            if t.scale_len is not None:
                _ = t.scale_axis
                spans.append((t.scale_offset, t.scale_offset + 4*t.scale_len, t.name+"#scale"))
        spans.sort()
        prev = 0
        for a, b, name in spans:
            if a < prev:
                raise ValueError(f"overlap around {name}")
            if b > self.total_bytes:
                raise ValueError(f"{name}: span exceeds total_bytes")
            prev = b
        if prev != self.total_bytes:
            raise ValueError(f"PLWB tail mismatch: {prev} != {self.total_bytes}")

    def raw_array(self, name: str) -> np.ndarray:
        t = self.by_name[name]
        buf = self._slice(t.offset, t.nbytes)
        if t.dtype == "float32":
            return np.frombuffer(buf, dtype="<f4").reshape(t.shape)
        if t.dtype == "float16":
            return np.frombuffer(buf, dtype="<f2").reshape(t.shape)
        if t.dtype == "bfloat16":
            u = np.frombuffer(buf, dtype="<u2").astype(np.uint32) << 16
            return u.view("<f4").reshape(t.shape)
        if t.dtype == "int8":
            return np.frombuffer(buf, dtype=np.int8).reshape(t.shape)
        raise AssertionError(t.dtype)

    def scales(self, name: str) -> np.ndarray | None:
        t = self.by_name[name]
        if t.scale_len is None:
            return None
        return np.frombuffer(self._slice(t.scale_offset, 4*t.scale_len), dtype="<f4")

    def dequantized(self, name: str) -> np.ndarray:
        t = self.by_name[name]
        a = self.raw_array(name)
        if t.dtype != "int8":
            return a.astype(np.float32, copy=False)
        s = self.scales(name)
        shape = [1] * len(t.shape)
        shape[t.scale_axis] = t.scale_len
        return a.astype(np.float32) * s.reshape(shape)

    def summary(self) -> dict:
        return {
            "version": self.version,
            "label": self.header.get("label"),
            "source_checkpoint": self.header.get("source_checkpoint"),
            "source_step": self.header.get("source_step"),
            "frames_per_step": self.header.get("frames_per_step"),
            "tensor_count": len(self.tensors),
            "parameter_count": sum(t.numel for t in self.tensors),
            "base": self.base,
            "total_bytes": self.total_bytes,
        }
