from pathlib import Path
import argparse, json
import numpy as np
import torch
from plwb import PLWB

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("weights")
    ap.add_argument("output")
    ap.add_argument("--dtype", choices=["float32","bfloat16"], default="bfloat16")
    args = ap.parse_args()

    blob = PLWB(args.weights)
    target_dtype = torch.float32 if args.dtype == "float32" else torch.bfloat16
    state = {}
    for i, t in enumerate(blob.tensors, 1):
        arr = np.array(blob.dequantized(t.name), dtype=np.float32, copy=True)
        ten = torch.from_numpy(arr)
        if ten.is_floating_point():
            ten = ten.to(target_dtype)
        state[t.name] = ten
        if i % 20 == 0 or i == len(blob.tensors):
            print(f"[{i}/{len(blob.tensors)}] {t.name} {tuple(t.shape)}")

    payload = {
        "format": "pluto-team-trainable-v1",
        "source_summary": blob.summary(),
        "source_header": blob.header,
        "state_dict": state,
    }
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, out)
    print("WROTE", out)
    print(json.dumps(blob.summary(), indent=2))

if __name__ == "__main__":
    main()
