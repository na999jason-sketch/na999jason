import json, struct
from pathlib import Path
import numpy as np
from plwb import PLWB

def make_tiny(path: Path):
    # fp32 [2] then int8 [2,2] + scales [2]
    fp = np.array([1.25, -2.5], dtype="<f4").tobytes()
    q = np.array([[127, -127], [64, -64]], dtype=np.int8).tobytes()
    scales = np.array([0.1, 0.2], dtype="<f4").tobytes()
    t0_off = 0
    t1_off = len(fp)
    s_off = t1_off + len(q)
    total = len(fp)+len(q)+len(scales)
    header = {
        "total_bytes": total,
        "label": "tiny",
        "frames_per_step": 6,
        "model_config": {},
        "tensors": [
            {"name":"a","shape":[2],"offset":t0_off,"nbytes":len(fp),"dtype":"float32"},
            {"name":"b","shape":[2,2],"offset":t1_off,"nbytes":len(q),"dtype":"int8",
             "scale_offset":s_off,"scale_len":2},
        ],
    }
    while True:
        hb = json.dumps(header, separators=(",",":")).encode()
        base = ((16+len(hb)+63)//64)*64
        # header length changes only if we changed header; here stable
        break
    raw = bytearray(base+total)
    raw[:4] = b"PLWB"
    struct.pack_into("<I", raw, 4, 1)
    struct.pack_into("<Q", raw, 8, len(hb))
    raw[16:16+len(hb)] = hb
    raw[base+t0_off:base+t0_off+len(fp)] = fp
    raw[base+t1_off:base+t1_off+len(q)] = q
    raw[base+s_off:base+s_off+len(scales)] = scales
    path.write_bytes(raw)

def test_parser_and_dequant(tmp_path):
    p = tmp_path/"tiny.bin"
    make_tiny(p)
    b = PLWB(p)
    assert b.summary()["tensor_count"] == 2
    np.testing.assert_allclose(b.dequantized("a"), [1.25,-2.5])
    out = b.dequantized("b")
    np.testing.assert_allclose(out, [[12.7,-12.7],[12.8,-12.8]], rtol=1e-5, atol=1e-5)
