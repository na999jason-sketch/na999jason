# aPlutoTeam Phase 1 v1

Goal: recover the public Pluto CoG 2026 inference weights into a trainable PyTorch-side state
without changing the current PlutoSCR runtime.

This phase deliberately does NOT train yet. It establishes:
1. PLWB parser / dequantization
2. trainable checkpoint export
3. team owner-vocabulary migration: 3 classes -> 4 classes
4. deterministic preservation rule for the existing policy

## Original owner vocabulary

The public Pluto model uses:
- 0 = self
- 1 = other player
- 2 = neutral

For Pluto-Team v1 we reserve:
- 0 = self
- 1 = ally
- 2 = enemy
- 3 = neutral

To preserve the old 1v1 policy before training:
- team[0] <- original[0]
- team[1] <- original[1]
- team[2] <- original[1]
- team[3] <- original[2]

So ally and enemy initially behave identically to the original "other player" representation.
Only fine-tuning will separate them.

## Files

- `plwb.py`
  - Reads the PLWB container.
  - Validates tensor bounds/layout.
  - Dequantizes int8 tensors with per-channel scales.

- `export_trainable_checkpoint.py`
  - Converts every public inference tensor to a PyTorch state dictionary.
  - Supports `--dtype float32` or `--dtype bfloat16`.
  - Writes the original header/config beside the tensors.

- `make_team_checkpoint.py`
  - Loads the exported checkpoint.
  - Expands `owner_emb.weight` from [3, 256] to [4, 256].
  - Uses the policy-preserving mapping above.
  - Adds Pluto-Team metadata.

- `inspect_checkpoint.py`
  - Verifies counts, owner embedding shape, NaN/Inf, and metadata.

- `tests/test_plwb.py`
  - Uses a tiny synthetic PLWB file so CI can validate the parser without the 320 MB Pluto weights.

## Local usage

Place the official file here (do not commit it):

    weights/pluto_weights.bin

Then:

    python -m pip install -r requirements.txt
    python export_trainable_checkpoint.py weights/pluto_weights.bin out/pluto_cog2026_trainable.pt --dtype bfloat16
    python make_team_checkpoint.py out/pluto_cog2026_trainable.pt out/pluto_team_seed_v1.pt
    python inspect_checkpoint.py out/pluto_team_seed_v1.pt

Expected team checkpoint property:

    owner_emb.weight shape == (4, 256)

and initially:

    ally row == enemy row == original "other player" row

## What this DOES NOT prove yet

A successful export does not prove our PyTorch forward is numerically equivalent to
`pluto_infer.exe`. That is Phase 2.

Phase 2 will implement the forward graph and a parity harness that feeds the same model-boundary
observation to both engines and compares logits / sampled outputs with forced-action probes.

## Training policy later

Do NOT immediately unfreeze all 315M parameters.

First training pass:
- freeze the spatial encoder
- freeze the unit transformer
- freeze most existing embeddings
- train the new ally/owner relation pathway
- train selected GRU/head parameters
- add a new team-value critic
- keep a 1v1 replay/evaluation set to detect catastrophic forgetting

Human 2v2/3v3 games can be recorded as trajectories. Weight updates should happen between games,
not in the middle of a live match.

## Source basis

This scaffold is an independent implementation based on the publicly documented PLWB layout,
tensor names/shapes, quantization rule, and model architecture reverse-engineering notes for
Pluto CoG 2026. It does not include Pluto binaries or weights.
