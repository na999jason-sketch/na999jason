from pathlib import Path
import argparse
import torch

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()

    ckpt = torch.load(args.input, map_location="cpu")
    state = ckpt["state_dict"]
    key = "owner_emb.weight"
    if key not in state:
        raise KeyError(key)
    old = state[key]
    if tuple(old.shape) != (3, 256):
        raise ValueError(f"expected owner_emb.weight [3,256], got {tuple(old.shape)}")

    new = torch.empty((4, 256), dtype=old.dtype)
    new[0] = old[0]  # self
    new[1] = old[1]  # ally starts identical to old "other"
    new[2] = old[1]  # enemy starts identical to old "other"
    new[3] = old[2]  # neutral
    state[key] = new

    ckpt["format"] = "pluto-team-seed-v1"
    ckpt["team_owner_vocab"] = {
        "0": "self",
        "1": "ally",
        "2": "enemy",
        "3": "neutral",
    }
    ckpt["migration"] = {
        "owner_emb.weight": {
            "old_shape": [3, 256],
            "new_shape": [4, 256],
            "mapping": {
                "new[0]": "old[0] self",
                "new[1]": "old[1] other -> ally seed",
                "new[2]": "old[1] other -> enemy seed",
                "new[3]": "old[2] neutral",
            },
            "policy_preserving_before_team_finetune": True,
        }
    }

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(ckpt, out)
    print("WROTE", out)
    print("owner_emb.weight", tuple(state[key].shape))
    print("ally==enemy", torch.equal(state[key][1], state[key][2]))

if __name__ == "__main__":
    main()
