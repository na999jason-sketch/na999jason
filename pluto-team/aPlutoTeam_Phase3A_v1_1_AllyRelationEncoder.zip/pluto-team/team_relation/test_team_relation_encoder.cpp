#include "TeamRelationEncoder.h"

#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

using pluto_team::OwnerCategory;
using pluto_team::RelationSnapshot;

static std::vector<std::uint8_t> make_game() {
  std::vector<std::uint8_t> game(pluto_team::kScrGameAlliancesOffset + 144, 0);
  game[pluto_team::kScrGameAlliancesOffset + 1 * 12 + 1] = 1;
  game[pluto_team::kScrGameAlliancesOffset + 1 * 12 + 2] = 1;  // local -> ally
  game[pluto_team::kScrGameAlliancesOffset + 2 * 12 + 1] = 0;  // reverse differs on purpose
  game[pluto_team::kScrGameAlliancesOffset + 1 * 12 + 3] = 0;  // enemy
  return game;
}

static std::array<std::uint8_t, pluto_team::kScrCUnitSize> make_cunit(std::uint8_t owner) {
  std::array<std::uint8_t, pluto_team::kScrCUnitSize> raw{};
  raw[pluto_team::kScrCUnitOwnerOffset] = owner;
  return raw;
}

int main() {
  auto game = make_game();
  std::array<std::uint8_t, 12> active{};
  active[1] = active[2] = active[3] = 1;

  RelationSnapshot s;
  assert(RelationSnapshot::FromScrGame(game.data(), game.size(), 1, active, s));

  OwnerCategory c{};
  assert(s.EncodeOwner(1, c) && c == OwnerCategory::Self);
  assert(s.EncodeOwner(2, c) && c == OwnerCategory::Ally);
  assert(s.EncodeOwner(3, c) && c == OwnerCategory::Enemy);
  assert(s.EncodeOwner(11, c) && c == OwnerCategory::Neutral);

  // The same owner rule applies to mobile units and buildings. No type heuristic.
  auto allyUnit = make_cunit(2);
  auto allyBuilding = make_cunit(2);
  assert(s.EncodeCUnit(allyUnit.data(), allyUnit.size(), c) && c == OwnerCategory::Ally);
  assert(s.EncodeCUnit(allyBuilding.data(), allyBuilding.size(), c) && c == OwnerCategory::Ally);

  auto enemyBuilding = make_cunit(3);
  assert(s.EncodeCUnit(enemyBuilding.data(), enemyBuilding.size(), c) && c == OwnerCategory::Enemy);

  // Transition safety: inactive owner slot is neutral rather than guessed enemy.
  active[2] = 0;
  RelationSnapshot afterLeave;
  assert(RelationSnapshot::FromScrGame(game.data(), game.size(), 1, active, afterLeave));
  assert(afterLeave.EncodeOwner(2, c) && c == OwnerCategory::Neutral);

  std::cout << "TEAM_RELATION_CPP_SELFTEST=PASS\n";
  std::cout << "owner_vocab=self:0 ally:1 enemy:2 neutral:3\n";
  std::cout << "ally_units_and_buildings=ALLY\n";
  return 0;
}
