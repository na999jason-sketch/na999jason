from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, MutableSequence, Sequence

SCR_PLAYER_COUNT = 12
SCR_ACTIVE_PLAYER_LIMIT = 8
SCR_GAME_ALLIANCES_OFFSET = 58692
SCR_CUNIT_SIZE = 336
SCR_CUNIT_OWNER_OFFSET = 0x4C

OWNER_SELF = 0
OWNER_ALLY = 1
OWNER_ENEMY = 2
OWNER_NEUTRAL = 3

OWNER_NAMES = {
    OWNER_SELF: "self",
    OWNER_ALLY: "ally",
    OWNER_ENEMY: "enemy",
    OWNER_NEUTRAL: "neutral",
}


class RelationUnavailable(RuntimeError):
    """Raised when a frame cannot be classified without inventing relations."""


@dataclass(frozen=True)
class TeamRelationSnapshot:
    """Authoritative relation view for one observation frame.

    `alliances` is SCR Game::alliances[12][12] in row-major order.  The local
    player's row is authoritative; symmetry is deliberately not assumed.
    """

    self_player: int
    participating: tuple[bool, ...]
    alliances: bytes

    def __post_init__(self) -> None:
        if not (0 <= self.self_player < SCR_ACTIVE_PLAYER_LIMIT):
            raise RelationUnavailable(f"invalid self player {self.self_player}")
        if len(self.participating) != SCR_PLAYER_COUNT:
            raise RelationUnavailable("participating must have 12 entries")
        if len(self.alliances) != SCR_PLAYER_COUNT * SCR_PLAYER_COUNT:
            raise RelationUnavailable("alliances must have 144 bytes")
        if not self.participating[self.self_player]:
            raise RelationUnavailable("self player is not participating")

    @classmethod
    def from_scr_game(
        cls,
        game_blob: bytes | bytearray | memoryview,
        self_player: int,
        participating: Sequence[bool],
    ) -> "TeamRelationSnapshot":
        end = SCR_GAME_ALLIANCES_OFFSET + SCR_PLAYER_COUNT * SCR_PLAYER_COUNT
        if len(game_blob) < end:
            raise RelationUnavailable(
                f"SCR Game blob too small for alliances: {len(game_blob)} < {end}"
            )
        matrix = bytes(game_blob[SCR_GAME_ALLIANCES_OFFSET:end])
        return cls(self_player, tuple(bool(x) for x in participating), matrix)

    def alliance_value(self, owner: int) -> int:
        if not (0 <= owner < SCR_PLAYER_COUNT):
            raise RelationUnavailable(f"invalid owner {owner}")
        return self.alliances[self.self_player * SCR_PLAYER_COUNT + owner]

    def encode_owner(self, owner: int) -> int:
        """Map raw SCR player owner -> Pluto-Team owner vocabulary.

        0=self, 1=ally, 2=enemy, 3=neutral.

        Units owned by inactive player slots are treated as neutral rather than
        guessed ally/enemy.  In normal SCR lifecycle abandoned units are moved
        to neutral ownership; this rule also keeps stale transition frames from
        inventing hostility.
        """
        if not (0 <= owner < SCR_PLAYER_COUNT):
            raise RelationUnavailable(f"invalid owner {owner}")
        if owner == self.self_player:
            return OWNER_SELF
        if owner >= SCR_ACTIVE_PLAYER_LIMIT:
            return OWNER_NEUTRAL
        if not self.participating[owner]:
            return OWNER_NEUTRAL
        return OWNER_ALLY if self.alliance_value(owner) != 0 else OWNER_ENEMY

    def encode_cunit(self, raw_cunit: bytes | bytearray | memoryview) -> int:
        """Classify any CUnit, including buildings, by its owner byte.

        StarCraft buildings and mobile units share the CUnit owner field at
        +0x4C, so no unit-type heuristic is used.
        """
        if len(raw_cunit) <= SCR_CUNIT_OWNER_OFFSET:
            raise RelationUnavailable("CUnit record too small for owner field")
        return self.encode_owner(int(raw_cunit[SCR_CUNIT_OWNER_OFFSET]))

    def encode_batch(self, raw_owner_ids: Iterable[int]) -> list[int]:
        return [self.encode_owner(int(owner)) for owner in raw_owner_ids]

    def rewrite_cat_owner_column(
        self,
        cat_rows: MutableSequence[MutableSequence[int]],
        raw_owner_ids: Sequence[int],
    ) -> None:
        """Write the four-way owner category into model cat[:,1] in place.

        This function must be called before the old three-way `other-player`
        collapse.  It intentionally changes no other categorical feature.
        """
        if len(cat_rows) != len(raw_owner_ids):
            raise RelationUnavailable("cat/raw-owner length mismatch")
        for row, owner in zip(cat_rows, raw_owner_ids):
            if len(row) < 2:
                raise RelationUnavailable("categorical row has no owner column")
            row[1] = self.encode_owner(int(owner))


def make_synthetic_cunit(owner: int, unit_type: int = 0) -> bytearray:
    """Test helper matching the verified SCR CUnit size/offsets."""
    if not (0 <= owner < 256):
        raise ValueError(owner)
    raw = bytearray(SCR_CUNIT_SIZE)
    raw[SCR_CUNIT_OWNER_OFFSET] = owner
    raw[0x64:0x66] = int(unit_type).to_bytes(2, "little", signed=False)
    return raw
