from pathlib import Path

from team_relation_encoder import (
    OWNER_NAMES,
    SCR_GAME_ALLIANCES_OFFSET,
    TeamRelationSnapshot,
    make_synthetic_cunit,
)


def main():
    game = bytearray(SCR_GAME_ALLIANCES_OFFSET + 144)
    active = [False] * 12
    for p in (1, 2, 3):
        active[p] = True
    game[SCR_GAME_ALLIANCES_OFFSET + 1 * 12 + 1] = 1
    game[SCR_GAME_ALLIANCES_OFFSET + 1 * 12 + 2] = 1
    game[SCR_GAME_ALLIANCES_OFFSET + 1 * 12 + 3] = 0
    s = TeamRelationSnapshot.from_scr_game(game, 1, active)

    cases = [
        ("self_unit", make_synthetic_cunit(1, 7)),
        ("ally_unit", make_synthetic_cunit(2, 65)),
        ("ally_building", make_synthetic_cunit(2, 154)),
        ("enemy_unit", make_synthetic_cunit(3, 66)),
        ("enemy_building", make_synthetic_cunit(3, 106)),
        ("neutral_unit", make_synthetic_cunit(11, 176)),
    ]
    lines = [
        "Pluto-Team Phase3A v1 relation encoder",
        "source=SCR Game::alliances[12][12] offset 58692 + CUnit.owner offset 0x4c",
        "owner_vocab=0:self,1:ally,2:enemy,3:neutral",
    ]
    for name, raw in cases:
        cat = s.encode_cunit(raw)
        lines.append(f"{name}={cat}:{OWNER_NAMES[cat]}")
    lines.append("ALLY_UNIT_BUILDING_RECOGNITION=PASS")
    Path("team_relation_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
