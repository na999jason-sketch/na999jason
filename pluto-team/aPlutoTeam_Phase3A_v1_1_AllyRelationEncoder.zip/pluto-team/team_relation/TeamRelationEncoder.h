#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace pluto_team {

constexpr std::size_t kScrPlayerCount = 12;
constexpr std::size_t kScrActivePlayerLimit = 8;
constexpr std::size_t kScrGameAlliancesOffset = 58692;
constexpr std::size_t kScrCUnitSize = 336;
constexpr std::size_t kScrCUnitOwnerOffset = 0x4c;

enum class OwnerCategory : std::uint8_t {
  Self = 0,
  Ally = 1,
  Enemy = 2,
  Neutral = 3,
};

struct RelationSnapshot {
  std::uint8_t selfPlayer = 0xff;
  std::array<std::uint8_t, kScrPlayerCount> participating{};
  std::array<std::uint8_t, kScrPlayerCount * kScrPlayerCount> alliances{};
  bool valid = false;

  static bool FromScrGame(const std::uint8_t* game,
                          std::size_t gameSize,
                          std::uint8_t self,
                          const std::array<std::uint8_t, kScrPlayerCount>& active,
                          RelationSnapshot& out) noexcept {
    const std::size_t end = kScrGameAlliancesOffset + alliances_size();
    if (!game || gameSize < end || self >= kScrActivePlayerLimit || !active[self]) {
      out = {};
      return false;
    }
    RelationSnapshot tmp;
    tmp.selfPlayer = self;
    tmp.participating = active;
    std::memcpy(tmp.alliances.data(), game + kScrGameAlliancesOffset, tmp.alliances.size());
    tmp.valid = true;
    out = tmp;
    return true;
  }

  static constexpr std::size_t alliances_size() noexcept {
    return kScrPlayerCount * kScrPlayerCount;
  }

  bool EncodeOwner(std::uint8_t owner, OwnerCategory& out) const noexcept {
    if (!valid || selfPlayer >= kScrActivePlayerLimit || owner >= kScrPlayerCount) {
      return false;
    }
    if (owner == selfPlayer) {
      out = OwnerCategory::Self;
      return true;
    }
    if (owner >= kScrActivePlayerLimit || !participating[owner]) {
      out = OwnerCategory::Neutral;
      return true;
    }
    const auto rel = alliances[static_cast<std::size_t>(selfPlayer) * kScrPlayerCount + owner];
    out = rel ? OwnerCategory::Ally : OwnerCategory::Enemy;
    return true;
  }

  bool EncodeCUnit(const std::uint8_t* raw,
                   std::size_t rawSize,
                   OwnerCategory& out) const noexcept {
    if (!raw || rawSize <= kScrCUnitOwnerOffset) {
      return false;
    }
    return EncodeOwner(raw[kScrCUnitOwnerOffset], out);
  }
};

}  // namespace pluto_team
