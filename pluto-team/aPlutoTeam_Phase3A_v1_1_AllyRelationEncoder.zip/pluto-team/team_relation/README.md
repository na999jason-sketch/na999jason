# Pluto-Team Phase3A v1 — Ally Relation Encoder

This is the first concrete Pluto-Team observation-boundary change.

It does **not** add strategy to the SCR compatibility bridge and it does **not** hide allies.
Instead, before the model's categorical owner feature is collapsed, it classifies every raw SCR
`CUnit` by the real player relationship:

- `0 = self`
- `1 = ally`
- `2 = enemy`
- `3 = neutral`

## Source of truth

The encoder uses the verified SC:R state already used by PlutoSCR v97+:

- `CUnit.owner` at `+0x4C` (76)
- `Game::alliances[12][12]` at SCR Game offset `58692`
- local player's alliance row is authoritative; symmetry is not assumed
- owners `>= 8` are neutral
- inactive player slots are treated as neutral during lifecycle transitions rather than guessed

Buildings are also `CUnit`s and use the same owner field, so an allied Nexus/Barracks/Hatchery is
classified exactly the same way as an allied mobile unit. No unit-type heuristic is used.

## Where it belongs

The important placement is **before** the original three-way owner collapse. The future
Pluto-Team request builder should preserve each unit's raw player owner ID long enough to call
`rewrite_cat_owner_column()` and then feed the four-way category to the expanded
`owner_emb.weight[4,256]` created in Phase1.

The public original `pluto_infer.exe` still only understands the original three-way model. This
Phase3A work therefore establishes the correct team observation semantics and tests them; it does
not claim that the unmodified official binary can consume the new category yet.

## 1v1 preservation

Phase1 seeded the four-row owner embedding as:

- team[0] <- old self
- team[1] <- old other (ally seed)
- team[2] <- old other (enemy seed)
- team[3] <- old neutral

Therefore a 1v1 observation maps enemy to row 2, whose initial vector is byte-for-byte the old
`other` vector. The tests verify this preservation rule.

## Fail-closed rule

If the alliance snapshot itself is invalid, classification fails rather than inventing an ally or
enemy relation. This keeps the current project's no-fabricated-observation rule.
