import unittest

from team_relation_encoder import (
    OWNER_ALLY,
    OWNER_ENEMY,
    OWNER_NEUTRAL,
    OWNER_SELF,
    RelationUnavailable,
    SCR_GAME_ALLIANCES_OFFSET,
    TeamRelationSnapshot,
    make_synthetic_cunit,
)


def snapshot(*, ally=True, enemy=True):
    game = bytearray(SCR_GAME_ALLIANCES_OFFSET + 144)
    participating = [False] * 12
    participating[1] = True  # self
    participating[2] = ally
    participating[3] = enemy
    game[SCR_GAME_ALLIANCES_OFFSET + 1 * 12 + 1] = 1
    if ally:
        game[SCR_GAME_ALLIANCES_OFFSET + 1 * 12 + 2] = 1
    if enemy:
        game[SCR_GAME_ALLIANCES_OFFSET + 1 * 12 + 3] = 0
    # Deliberately make reverse relation different: local-row authority matters.
    game[SCR_GAME_ALLIANCES_OFFSET + 2 * 12 + 1] = 0
    return TeamRelationSnapshot.from_scr_game(game, 1, participating)


class TeamRelationEncoderTests(unittest.TestCase):
    def test_self_ally_enemy_neutral(self):
        s = snapshot()
        self.assertEqual(s.encode_owner(1), OWNER_SELF)
        self.assertEqual(s.encode_owner(2), OWNER_ALLY)
        self.assertEqual(s.encode_owner(3), OWNER_ENEMY)
        self.assertEqual(s.encode_owner(11), OWNER_NEUTRAL)

    def test_ally_unit_and_ally_building_are_both_ally(self):
        s = snapshot()
        marine_like = make_synthetic_cunit(2, unit_type=0)
        nexus_like = make_synthetic_cunit(2, unit_type=154)
        self.assertEqual(s.encode_cunit(marine_like), OWNER_ALLY)
        self.assertEqual(s.encode_cunit(nexus_like), OWNER_ALLY)

    def test_enemy_unit_and_building_are_both_enemy(self):
        s = snapshot()
        unit = make_synthetic_cunit(3, unit_type=65)
        building = make_synthetic_cunit(3, unit_type=106)
        self.assertEqual(s.encode_cunit(unit), OWNER_ENEMY)
        self.assertEqual(s.encode_cunit(building), OWNER_ENEMY)

    def test_inactive_player_slot_fails_safe_to_neutral(self):
        s = snapshot(ally=False)
        self.assertEqual(s.encode_owner(2), OWNER_NEUTRAL)

    def test_local_alliance_row_is_authoritative(self):
        s = snapshot()
        self.assertEqual(s.alliance_value(2), 1)
        self.assertEqual(s.encode_owner(2), OWNER_ALLY)

    def test_rewrite_only_owner_column(self):
        s = snapshot()
        cat = [[9, 99, 8, 7, 6, 5] for _ in range(4)]
        before = [row[:] for row in cat]
        s.rewrite_cat_owner_column(cat, [1, 2, 3, 11])
        self.assertEqual([row[1] for row in cat], [0, 1, 2, 3])
        for i, row in enumerate(cat):
            self.assertEqual(row[0], before[i][0])
            self.assertEqual(row[2:], before[i][2:])

    def test_one_vs_one_embedding_preservation_rule(self):
        # Phase1 migration: team[0]=old self, team[1]=old other,
        # team[2]=old other, team[3]=old neutral.
        old = ["SELF_VEC", "OTHER_VEC", "NEUTRAL_VEC"]
        team = [old[0], old[1], old[1], old[2]]
        s = snapshot(ally=False, enemy=True)
        self.assertEqual(team[s.encode_owner(1)], old[0])
        self.assertEqual(team[s.encode_owner(3)], old[1])
        self.assertEqual(team[s.encode_owner(11)], old[2])

    def test_invalid_snapshot_is_fail_closed(self):
        game = bytearray(SCR_GAME_ALLIANCES_OFFSET + 144)
        participating = [False] * 12
        with self.assertRaises(RelationUnavailable):
            TeamRelationSnapshot.from_scr_game(game, 1, participating)


if __name__ == "__main__":
    unittest.main(verbosity=2)
