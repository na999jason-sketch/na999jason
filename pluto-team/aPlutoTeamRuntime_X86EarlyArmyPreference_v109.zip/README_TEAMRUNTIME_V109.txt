aPlutoTeamRuntime v109 - STOCK3 / NO TRAINING / v108 Ally Role Split + Soft Early-Army Preference

PURPOSE
- Continue v108 in-game validation, but make Pluto prefer early unit production a little more often.
- NO training, NO owner embedding expansion, NO inference EXE patch, NO fixed build order.
- Official Pluto remains the policy/reasoner. v109 only gives a temporary choice nudge when a safe alternative is known.

UNCHANGED FROM v108
- Official stock Pluto model: SELF=0, OTHER=1, NEUTRAL=2.
- Allied combat/support -> SELF context with actor=0,target=0.
- Allied economy/production -> NEUTRAL context with actor=0,target=0.
- Enemy -> OTHER. Map neutral -> NEUTRAL.
- Exact legacy-shadow relation matching and SC:R command translation stay unchanged.

EARLY-ARMY PREFERENCE
v109 does NOT hardcode action numbers such as "action 10 = worker".
It learns the meaning of Pluto's own action IDs from commands Pluto actually emits in the current match:
- Train/Morph a BWAPI worker -> WORKER_PRODUCTION evidence for that action ID.
- Train/Morph a combat/support unit, or fighter production -> ARMY_PRODUCTION evidence.

A preference nudge is permitted only when ALL of these are true:
1) Current game frame <= 7200 (opening only).
2) Pluto has at least 10 own workers.
3) A pure WORKER action ID and a different pure ARMY action ID have both been observed in this match.
4) BOTH action IDs are valid in the CURRENT Pluto action_mask.
5) Cooldown has expired and max nudge count has not been reached.

When eligible, 1 of every 3 eligible requests temporarily masks ONLY the learned worker-production action for ONE inference request.
The army action and every other legal action remain available, so Pluto chooses its own next-best action.
Immediately after inference the original action-mask byte is restored.

WHY THIS IS NOT A FIXED RUSH BUILD
- No unit type is ordered by the bridge.
- No barracks/gateway/pool timing is scripted.
- No attack timing is scripted.
- Tech, expansion, defense, movement, research, upgrades, and other actions are never masked by this preference.
- If army production is not currently valid, no bias is applied.
- If Pluto's action IDs are shared/mixed between worker and army production, the runtime refuses to bias that ID.
- Cooldown and a hard nudge cap prevent permanent worker suppression.

TUNING FOR THIS TEST
- end frame: 7200
- minimum own workers: 10
- cadence: 1 of 3 eligible requests
- cooldown: 96 frames
- max nudges per match: 18

EXPECTED LOG MARKERS
PLUTOTEAMRUNTIME_V109_RESIDENT=LOADED
TEAM_RUNTIME_PLUTO_MODEL=OFFICIAL_UNMODIFIED_NO_TRAINING
V109_STOCK_ENGINE=OFFICIAL_3WAY_GATE_VERIFIED offset=59203 value=3
V109_STOCK_WEIGHTS=OWNER_EMB_3X256_VERIFIED
V109_PREF_LEARN ... evidence=WORKER_PRODUCTION or ARMY_PRODUCTION
V109_EARLY_ARMY_BIAS=APPLIED ... worker_action=... army_action=...
V109_PREF_SUMMARY ... nudges=... map=...
V109_SHM_OWNER_REWRITE=PASS ...
TEAM_TRAINING_RECORDER=CONFIRMED_DISABLED_V109

WHAT TO WATCH IN GAME
1) Does the opening field units a little earlier/more often than v108?
2) Does worker/economy growth remain sane rather than collapsing?
3) When army production is unavailable or Pluto wants tech/expand/defense, does it still switch naturally?
4) Does v108's ally combat behavior remain intact?

After the game, send plutoteam-x86-v109.log. PTRJ is not recorded.
