$ErrorActionPreference='Stop'

$vw="${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if(!(Test-Path $vw)){throw 'vswhere missing'}
$vs=& $vw -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if(!$vs){throw 'Visual Studio x86 tools not found'}
$vc=Join-Path $vs 'VC\Auxiliary\Build\vcvars32.bat'
if(!(Test-Path $vc)){throw 'vcvars32.bat missing'}

$libs=Get-ChildItem 'src' -Recurse -File -Filter '*.lib'
$client=$libs | Where-Object {$_.Name -ieq 'BWAPIClient.lib'} | Select-Object -First 1
$bwapi=$libs | Where-Object {$_.Name -ieq 'BWAPILIB.lib'} | Select-Object -First 1
if(!$client -or !$bwapi){throw 'BWAPI static libraries missing'}

New-Item -ItemType Directory 'build_v109' -Force | Out-Null
$bat=(Resolve-Path 'build_v109').Path + '\build-v109.cmd'
$lines=@(
'@echo off',
'setlocal EnableExtensions',
('call "{0}"' -f $vc),
'if errorlevel 1 exit /b 11',
('set "BWAPILIB={0}"' -f $bwapi.FullName),
('set "BWAPICLIENT={0}"' -f $client.FullName),
'echo === COMPILE V109 STOCK3 ROLE-SPLIT + EARLY ARMY PREFERENCE ===',
'cl /nologo /c /EHsc /O2 /std:c++17 /MD /DWIN32 /DNDEBUG /D_WINDOWS /I"src\bwapi\include" /I"minhook\include" "src\plutoscr_x86\PlutoSCRX86TeamRuntimeV104.cpp" /Fo"build_v109\PlutoSCRX86TeamRuntimeV109.obj"',
'if errorlevel 1 exit /b 21',
'echo === COMPILE MINHOOK X86 ===',
'cl /nologo /c /O2 /MD /DWIN32 /DNDEBUG /I"minhook\include" /I"minhook\src" "minhook\src\buffer.c" /Fo"build_v109\mh_buffer.obj"',
'if errorlevel 1 exit /b 22',
'cl /nologo /c /O2 /MD /DWIN32 /DNDEBUG /I"minhook\include" /I"minhook\src" "minhook\src\hook.c" /Fo"build_v109\mh_hook.obj"',
'if errorlevel 1 exit /b 23',
'cl /nologo /c /O2 /MD /DWIN32 /DNDEBUG /I"minhook\include" /I"minhook\src" "minhook\src\trampoline.c" /Fo"build_v109\mh_trampoline.obj"',
'if errorlevel 1 exit /b 24',
'cl /nologo /c /O2 /MD /DWIN32 /DNDEBUG /I"minhook\include" /I"minhook\src" /I"minhook\src\hde" "minhook\src\hde\hde32.c" /Fo"build_v109\mh_hde32.obj"',
'if errorlevel 1 exit /b 25',
'echo === LINK V109 RESIDENT ===',
'link /nologo /DLL /MACHINE:X86 /OUT:"build_v109\PlutoSCRX86TeamRuntimeV109.dll" "build_v109\PlutoSCRX86TeamRuntimeV109.obj" "build_v109\mh_buffer.obj" "build_v109\mh_hook.obj" "build_v109\mh_trampoline.obj" "build_v109\mh_hde32.obj" "%BWAPICLIENT%" "%BWAPILIB%" kernel32.lib user32.lib advapi32.lib',
'if errorlevel 1 exit /b 31',
'echo === COMPILE INJECTOR ===',
'cl /nologo /EHsc /O2 /MD /DWIN32 /D_WINDOWS "src\PlutoSCRX86Inject.cpp" /Fe:"build_v109\PlutoSCRX86Inject.exe" /link /MACHINE:X86 kernel32.lib',
'if errorlevel 1 exit /b 41',
'echo PLUTOTEAMRUNTIME_V109_DIRECT_LINK=PASS',
'exit /b 0'
)
Set-Content $bat $lines -Encoding ASCII
& $env:ComSpec /D /C $bat
if($LASTEXITCODE -ne 0){throw "v109 direct build failed: $LASTEXITCODE"}

foreach($f in @('build_v109\PlutoSCRX86TeamRuntimeV109.dll','build_v109\PlutoSCRX86Inject.exe')){
  if(!(Test-Path $f)){throw "missing output: $f"}
  $b=[IO.File]::ReadAllBytes((Resolve-Path $f))
  $pe=[BitConverter]::ToInt32($b,0x3c)
  $m=[BitConverter]::ToUInt16($b,$pe+4)
  Write-Host ("PE_MACHINE {0} 0x{1:X4}" -f $f,$m)
  if($m -ne 0x014c){throw "non-x86 output: $f"}
}
Write-Host 'PLUTOTEAMRUNTIME_V109_BUILD_VERIFIED=PASS'
