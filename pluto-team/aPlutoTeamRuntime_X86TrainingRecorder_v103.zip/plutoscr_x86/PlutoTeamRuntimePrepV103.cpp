#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <stdexcept>

static const char* kInferSha="ad880d8be52a6ef03893fa20644b6627e04fcd55e030178c6d52486b82340f2b";
static const char* kWeightsSha="00b400eace6e4782202ebdcb3c30db76054aaa6a08c6a7dcb59575abc2d0a26e";

static std::wstring joinp(const std::wstring&a,const std::wstring&b){
  if(a.empty())return b;wchar_t c=a.back();return (c==L'\\'||c==L'/')?a+b:a+L"\\"+b;
}
static bool exists(const std::wstring&p){DWORD a=GetFileAttributesW(p.c_str());return a!=INVALID_FILE_ATTRIBUTES&&!(a&FILE_ATTRIBUTE_DIRECTORY);}
static uint64_t fsize(const std::wstring&p){WIN32_FILE_ATTRIBUTE_DATA d{};if(!GetFileAttributesExW(p.c_str(),GetFileExInfoStandard,&d))return 0;ULARGE_INTEGER u{};u.HighPart=d.nFileSizeHigh;u.LowPart=d.nFileSizeLow;return u.QuadPart;}
static std::string hex(const std::vector<unsigned char>&v){static const char*h="0123456789abcdef";std::string s;s.resize(v.size()*2);for(size_t i=0;i<v.size();++i){s[i*2]=h[v[i]>>4];s[i*2+1]=h[v[i]&15];}return s;}
static bool sha256(const std::wstring&p,std::string&out){
  BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hh=nullptr;DWORD obj=0,hashlen=0,cb=0;
  if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)!=0)return false;
  bool ok=false;
  std::vector<unsigned char> ob,hv,buf;
  do{
    if(BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,(PUCHAR)&obj,sizeof(obj),&cb,0)!=0)break;
    if(BCryptGetProperty(alg,BCRYPT_HASH_LENGTH,(PUCHAR)&hashlen,sizeof(hashlen),&cb,0)!=0)break;
    ob.resize(obj);hv.resize(hashlen);buf.resize(1<<20);
    if(BCryptCreateHash(alg,&hh,ob.data(),obj,nullptr,0,0)!=0)break;
    std::ifstream f(p,std::ios::binary);if(!f)break;
    bool hashOk=true;
    while(f){
      f.read((char*)buf.data(),(std::streamsize)buf.size());
      std::streamsize n=f.gcount();
      if(n>0&&BCryptHashData(hh,buf.data(),(ULONG)n,0)!=0){hashOk=false;break;}
    }
    if(!hashOk)break;
    if(BCryptFinishHash(hh,hv.data(),hashlen,0)!=0)break;
    out=hex(hv);ok=true;
  }while(false);
  if(hh)BCryptDestroyHash(hh);
  if(alg)BCryptCloseAlgorithmProvider(alg,0);
  return ok;
}
static bool copyReplace(const std::wstring&src,const std::wstring&dst){
  return CopyFileW(src.c_str(),dst.c_str(),FALSE)!=0;
}
static bool moveReplace(const std::wstring&src,const std::wstring&dst){
  return MoveFileExW(src.c_str(),dst.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
}
static uint64_t parseNum(const std::string&s,size_t keyPos,size_t*beg=nullptr,size_t*end=nullptr){
  size_t c=s.find(':',keyPos);if(c==std::string::npos)throw std::runtime_error("colon missing");
  size_t a=c+1;while(a<s.size()&&(s[a]==' '||s[a]=='\t'||s[a]=='\r'||s[a]=='\n'))++a;
  size_t b=a;while(b<s.size()&&s[b]>='0'&&s[b]<='9')++b;if(b==a)throw std::runtime_error("number missing");
  if(beg)*beg=a;if(end)*end=b;return std::stoull(s.substr(a,b-a));
}
static void replaceNum(std::string&s,const std::string&key,uint64_t value,size_t start=0){
  size_t k=s.find(key,start);if(k==std::string::npos)throw std::runtime_error("key missing "+key);
  size_t a=0,b=0;(void)parseNum(s,k,&a,&b);s.replace(a,b-a,std::to_string(value));
}
static uint64_t align64(uint64_t x){return (x+63ull)&~63ull;}

static bool patchInfer(const std::wstring&official,const std::wstring&active){
  std::wstring tmp=active+L".v103.tmp";
  DeleteFileW(tmp.c_str());if(!CopyFileW(official.c_str(),tmp.c_str(),FALSE))return false;
  std::fstream f(tmp,std::ios::binary|std::ios::in|std::ios::out);if(!f)return false;
  unsigned char b[6]{};f.seekg(59201);f.read((char*)b,6);
  const unsigned char exp[6]={0x41,0xB9,0x03,0x00,0x00,0x00};
  if(f.gcount()!=6||std::memcmp(b,exp,6)!=0){std::cerr<<"TEAM4_PREP_ENGINE_SIGNATURE=FAIL\n";return false;}
  uint32_t four=4;f.seekp(59203);f.write((const char*)&four,4);f.flush();f.close();
  if(!moveReplace(tmp,active))return false;
  std::cout<<"TEAM4_PREP_ENGINE_PATCH=PASS offset=59203 3_to_4\n";return true;
}
static bool buildWeights(const std::wstring&official,const std::wstring&active){
  std::ifstream in(official,std::ios::binary);if(!in)return false;
  unsigned char h[16]{};in.read((char*)h,16);if(in.gcount()!=16||std::memcmp(h,"PLWB",4)!=0)return false;
  uint32_t ver=0;uint64_t hlen=0;std::memcpy(&ver,h+4,4);std::memcpy(&hlen,h+8,8);
  if(ver!=1||hlen<1024||hlen>1024*1024)return false;
  std::string hdr((size_t)hlen,'\0');in.read(hdr.data(),(std::streamsize)hlen);if((uint64_t)in.gcount()!=hlen)return false;
  size_t totalKey=hdr.find("\"total_bytes\"");if(totalKey==std::string::npos)return false;
  uint64_t oldTotal=parseNum(hdr,totalKey);
  uint64_t fileBytes=fsize(official);if(fileBytes<=oldTotal)return false;
  uint64_t oldBase=fileBytes-oldTotal;
  if(oldBase<16+hlen)return false;
  size_t owner=hdr.find("owner_emb.weight");if(owner==std::string::npos)return false;
  size_t shapeK=hdr.find("\"shape\"",owner);size_t lb=hdr.find('[',shapeK),rb=hdr.find(']',lb);
  if(shapeK==std::string::npos||lb==std::string::npos||rb==std::string::npos)return false;
  std::string sh=hdr.substr(lb+1,rb-lb-1);sh.erase(std::remove_if(sh.begin(),sh.end(),[](char c){return c==' '||c=='\t'||c=='\r'||c=='\n';}),sh.end());
  if(sh!="3,256")return false;
  size_t offK=hdr.find("\"offset\"",owner),nbK=hdr.find("\"nbytes\"",owner);
  if(offK==std::string::npos||nbK==std::string::npos)return false;
  uint64_t oldOff=parseNum(hdr,offK),oldN=parseNum(hdr,nbK);if(oldN!=3072)return false;
  uint64_t appendOff=align64(oldTotal),newTotal=appendOff+4096;
  hdr.replace(lb+1,rb-lb-1,"4,256");
  owner=hdr.find("owner_emb.weight");offK=hdr.find("\"offset\"",owner);nbK=hdr.find("\"nbytes\"",owner);
  {size_t a=0,b=0;(void)parseNum(hdr,offK,&a,&b);hdr.replace(a,b-a,std::to_string(appendOff));}
  owner=hdr.find("owner_emb.weight");nbK=hdr.find("\"nbytes\"",owner);
  {size_t a=0,b=0;(void)parseNum(hdr,nbK,&a,&b);hdr.replace(a,b-a,"4096");}
  replaceNum(hdr,"\"total_bytes\"",newTotal,0);
  uint64_t newBase=align64(16ull+(uint64_t)hdr.size());

  std::vector<unsigned char> owner3(3072);in.clear();in.seekg((std::streamoff)(oldBase+oldOff));in.read((char*)owner3.data(),3072);if(in.gcount()!=3072)return false;
  std::vector<unsigned char> owner4(4096);
  std::memcpy(owner4.data()+0,owner3.data()+0,1024);
  std::memcpy(owner4.data()+1024,owner3.data()+1024,1024);
  std::memcpy(owner4.data()+2048,owner3.data()+1024,1024);
  std::memcpy(owner4.data()+3072,owner3.data()+2048,1024);

  std::wstring tmp=active+L".v103.tmp";DeleteFileW(tmp.c_str());
  std::ofstream out(tmp,std::ios::binary|std::ios::trunc);if(!out)return false;
  out.write("PLWB",4);out.write((const char*)&ver,4);uint64_t nh=(uint64_t)hdr.size();out.write((const char*)&nh,8);out.write(hdr.data(),(std::streamsize)hdr.size());
  std::vector<char> zeros(1<<20,0);
  uint64_t pos=16ull+hdr.size();
  while(pos<newBase){uint64_t n=std::min<uint64_t>(zeros.size(),newBase-pos);out.write(zeros.data(),(std::streamsize)n);pos+=n;}

  in.clear();in.seekg((std::streamoff)oldBase);std::vector<char> buf(1<<20);uint64_t rem=oldTotal;
  while(rem){size_t want=(size_t)std::min<uint64_t>(buf.size(),rem);in.read(buf.data(),(std::streamsize)want);if((size_t)in.gcount()!=want)return false;out.write(buf.data(),(std::streamsize)want);rem-=want;}
  uint64_t pad=appendOff-oldTotal;while(pad){uint64_t n=std::min<uint64_t>(zeros.size(),pad);out.write(zeros.data(),(std::streamsize)n);pad-=n;}
  out.write((const char*)owner4.data(),4096);out.flush();out.close();
  if(fsize(tmp)!=newBase+newTotal)return false;
  if(!moveReplace(tmp,active))return false;
  std::cout<<"TEAM4_PREP_WEIGHTS=PASS owner_emb=[4,256] self=old0 ally=old1 enemy=old1 neutral=old2\n";
  return true;
}
int wmain(int argc,wchar_t**argv){
  std::wstring root;
  if(argc>=2)root=argv[1];else{wchar_t b[32768]{};DWORD n=GetCurrentDirectoryW((DWORD)(sizeof(b)/sizeof(b[0])),b);root.assign(b,n);}
  std::wstring sub=joinp(root,L"pluto");
  std::wstring infer=joinp(sub,L"pluto_infer.exe"),weights=joinp(sub,L"pluto_weights.bin");
  std::wstring bi=joinp(sub,L"pluto_infer.official.exe"),bw=joinp(sub,L"pluto_weights.official.bin");
  if(!exists(infer)||!exists(weights)){std::cerr<<"TEAM4_PREP=FAIL missing pluto runtime\n";return 2;}
  std::string hi,hw;
  if(exists(bi)&&exists(bw)){
    if(!sha256(bi,hi)||hi!=kInferSha||!sha256(bw,hw)||hw!=kWeightsSha){std::cerr<<"TEAM4_PREP=FAIL official backups hash mismatch\n";return 3;}
  }else{
    if(!sha256(infer,hi)||hi!=kInferSha){std::cerr<<"TEAM4_PREP=FAIL pluto_infer.exe is not exact official build\n";return 4;}
    if(!sha256(weights,hw)||hw!=kWeightsSha){std::cerr<<"TEAM4_PREP=FAIL pluto_weights.bin is not exact official build\n";return 5;}
    if(!CopyFileW(infer.c_str(),bi.c_str(),TRUE)){std::cerr<<"TEAM4_PREP=FAIL backup infer\n";return 6;}
    if(!CopyFileW(weights.c_str(),bw.c_str(),TRUE)){std::cerr<<"TEAM4_PREP=FAIL backup weights\n";return 7;}
  }
  std::cout<<"TEAM4_PREP_OFFICIAL_BACKUPS=PASS\n";
  if(!patchInfer(bi,infer)){std::cerr<<"TEAM4_PREP=FAIL engine patch\n";return 8;}
  if(!buildWeights(bw,weights)){std::cerr<<"TEAM4_PREP=FAIL weights build\n";return 9;}
  std::cout<<"TEAM4_PREP=PASS\n";return 0;
}
