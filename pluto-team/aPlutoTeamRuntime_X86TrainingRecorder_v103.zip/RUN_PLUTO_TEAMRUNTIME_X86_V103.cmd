@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v103-launch.log"

>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V103_LAUNCHER=START
>>"%LAUNCHLOG%" echo ROOT=%ROOT%
echo === aPlutoTeamRuntime v103 x86 Training Recorder ===
echo [NOTE] Original Pluto still performs observation, inference, decisions and commands.
echo [NOTE] v103 records exact 4-way requests/responses for offline team learning.

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV103.dll" "%ROOT%\PlutoTeamRuntimePrepV103.exe" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing: %%~F
  >>"%LAUNCHLOG%" echo FAIL missing: %%~F
  pause
  exit /b 1
)

if exist "%ROOT%\pluto\pluto_infer.exe" if exist "%ROOT%\pluto\pluto_weights.bin" goto runtime_ready
if exist "%ROOT%\pluto_infer.exe" if exist "%ROOT%\pluto_weights.bin" (
  if not exist "%ROOT%\pluto" mkdir "%ROOT%\pluto"
  copy /Y "%ROOT%\pluto_infer.exe" "%ROOT%\pluto\pluto_infer.exe" >nul || goto runtime_fail
  copy /Y "%ROOT%\pluto_weights.bin" "%ROOT%\pluto\pluto_weights.bin" >nul || goto runtime_fail
  goto runtime_ready
)
echo [FAIL] Exact official Pluto inference files are missing.
pause
exit /b 2

:runtime_fail
echo [FAIL] Could not create Pluto runtime layout.
pause
exit /b 3

:runtime_ready
tasklist /FI "IMAGENAME eq pluto_infer.exe" 2^>nul | find /I "pluto_infer.exe" ^>nul
if not errorlevel 1 (
  echo [FAIL] stale pluto_infer.exe is already running.
  echo Run: taskkill /IM pluto_infer.exe /F
  pause
  exit /b 5
)

echo [INFO] Preparing exact official Pluto runtime for 4-way owner input...
"%ROOT%\PlutoTeamRuntimePrepV103.exe" "%ROOT%" >>"%LAUNCHLOG%" 2>&1
if errorlevel 1 (
  echo [FAIL] Four-way runtime preparation failed.
  type "%LAUNCHLOG%"
  pause
  exit /b 6
)
echo [PASS] Four-way inference runtime prepared.

del /q "%ROOT%\plutoteam-x86-v103.log" 2>nul
del /q "%ROOT%\plutoteam-x86-v103-inject.log" 2>nul

echo.
echo RECOMMENDED TRAINING GAME:
echo - 3v3 or 2v2.
echo - Let allies be safe for a while.
echo - Also create situations where allies are attacked while your army can respond.
echo - Continue until enemies are visible and combat occurs.
echo.
echo Start SC:R 32-bit and enter the FIRST game.
echo Press any key ONCE to inject v103.
pause >nul

"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV103.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  type "%LAUNCHLOG%"
  echo [FAIL] injection stage failed.
  pause
  exit /b %RC%
)

timeout /t 2 /nobreak >nul
if exist "%ROOT%\plutoteam-x86-v103.log" (
  echo [PASS] v103 runtime started.
  echo After games, run PACK_PLUTO_TEAM_TRAINING_DATA_V103.cmd.
) else (
  echo [FAIL] runtime log missing.
)
pause
