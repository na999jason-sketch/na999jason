aPlutoTeamRuntime v103 x86 — Team Training Recorder
====================================================

PURPOSE
-------
v102 proved that live SC:R observations reach the official Pluto inference engine as:
  0 SELF / 1 ALLY / 2 ENEMY / 3 NEUTRAL

v103 keeps that exact runtime path and adds two training prerequisites:

1) SHADOW-EXACT OWNER MATCHING
   Owner relation for model rows is matched against the legacy CUnit shadow that
   original Pluto itself observed, rather than against a later moving raw CUnit.
   This removes timing drift without fabricating state.

2) EXACT TRAJECTORY RECORDING
   Every paired inference step records:
   - exact rewritten request header
   - cat[N,6], cont[N,109]
   - actor/target masks
   - action and argument masks
   - global features
   - spatial bits/static planes
   - history
   - exact 40-byte engine response
   - frame/sequence, owner counts, match metadata
   The match terminal record includes win/loss.

NO NEW STRATEGY
---------------
v103 does not decide whether to defend allies.
It does not replace targets or create commands.
Original Pluto still performs observation processing, inference, decisions and commands.
The direct ally-target drop-only safety from v101/v102 remains.

WHY THIS DATA
-------------
The goal is NOT "never go toward allies".

Offline learning will distinguish:
- normal ally context,
- enemy near ally,
- ally normalized HP/shield drops,
- enemy combat,
- terminal team win/loss.

That lets the next training stage learn that an ally is not an attack target, while
still allowing movement/support toward an ally when enemy threat is present.

FILES CREATED IN GAME
---------------------
plutoteam-x86-v103.log
plutoteam-v103-trajectory-g1.ptrj
plutoteam-v103-trajectory-g2.ptrj
...

Run PACK_PLUTO_TEAM_TRAINING_DATA_V103.cmd after the games.
It creates:
  plutoteam-v103-training-data.zip

RECOMMENDED FIRST DATA SET
--------------------------
Collect 3-5 team games if convenient:
A. ordinary early game / allies safe
B. ally base being attacked while Pluto has combat units
C. normal attack on enemy positions
D. at least one full match ending, so win/loss is recorded

Do not force a fixed scripted response from Pluto. We want the original policy's
actual behavior plus the true team context.

EXPECTED LOG MARKERS
--------------------
TEAM4_OWNER_MATCH_SOURCE=LEGACY_SHADOW_EXACT_OBSERVATION
TEAM_TRAINING_RECORDER=START
TEAM4_SHM_OWNER_REWRITE=PASS ... unmatched=...
TEAM_TRAINING_RECORDER=STEP_PASS ...
TEAM_TRAINING_RECORDER=END ... won=... steps=...

IMPORTANT
---------
The recorder produces training data. It does not by itself change the current
ally==enemy seed behavior. The next stage consumes these trajectories and trains
the ally-specific parameters while keeping the original enemy policy protected.
