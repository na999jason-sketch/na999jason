@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "OUT=plutoteam-v103-training-data.zip"
if exist "%OUT%" del /q "%OUT%"
echo Packing v103 trajectories and runtime log...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$f=@(Get-ChildItem -File 'plutoteam-v103-trajectory-g*.ptrj' -ErrorAction SilentlyContinue)+@(Get-Item 'plutoteam-x86-v103.log' -ErrorAction SilentlyContinue); if(!$f){throw 'No v103 training files found'}; Compress-Archive -Path ($f.FullName) -DestinationPath '%OUT%' -CompressionLevel Optimal -Force"
if errorlevel 1 (
  echo [FAIL] pack failed.
  pause
  exit /b 1
)
echo [PASS] %OUT%
for %%F in ("%OUT%") do echo Size: %%~zF bytes
pause
