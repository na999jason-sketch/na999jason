@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v107-launch.log"
>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V107_LAUNCHER=START

echo === aPlutoTeamRuntime v107 - Friendly Context / No Control / No Ally Target ===

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV107.dll" "%ROOT%\PlutoTeamRuntimePrepV104.exe" "%ROOT%\PATCH_ALLY_FRIENDLY_V107.ps1" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing %%~F
  pause
  exit /b 1
)
if not exist "%ROOT%\pluto\pluto_infer.exe" exit /b 2
if not exist "%ROOT%\pluto\pluto_weights.bin" exit /b 3

taskkill /IM pluto_infer.exe /F >nul 2>nul

REM 1) Build the proven 4-way runtime first.
"%ROOT%\PlutoTeamRuntimePrepV104.exe" "%ROOT%" >>"%LAUNCHLOG%" 2>&1
if errorlevel 1 (
  type "%LAUNCHLOG%"
  echo [FAIL] team4 prep failed
  pause
  exit /b 4
)

REM 2) IMPORTANT: this line is intentionally AFTER the real prep invocation.
REM    v105 accidentally inserted this inside the file-check block and therefore
REM    did not reliably apply the SELF semantic row.
powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%\PATCH_ALLY_FRIENDLY_V107.ps1" -Weights "%ROOT%\pluto\pluto_weights.bin" >>"%LAUNCHLOG%" 2>&1
if errorlevel 1 (
  type "%LAUNCHLOG%"
  echo [FAIL] ally-friendly weight patch failed
  pause
  exit /b 5
)

echo TEAM4_V107_ALLY_FRIENDLY_PATCH=PASS>>"%LAUNCHLOG%"
del /q "%ROOT%\plutoteam-x86-v107.log" 2>nul

echo Enter the SC:R 32-bit team game, then press a key once.
pause >nul
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV107.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
  echo [FAIL] injection failed
  pause
  exit /b %RC%
)
pause
