﻿param([Parameter(Mandatory=$true)][string]$Weights)
$ErrorActionPreference='Stop'
$p=(Resolve-Path $Weights).Path
[byte[]]$raw=[IO.File]::ReadAllBytes($p)
if([Text.Encoding]::ASCII.GetString($raw,0,4) -ne 'PLWB'){throw 'not PLWB'}
[UInt64]$hlen=[BitConverter]::ToUInt64($raw,8)
$hdr=([Text.Encoding]::UTF8.GetString($raw,16,[int]$hlen) | ConvertFrom-Json)
[Int64]$base=$raw.LongLength-[Int64]$hdr.total_bytes
$t=$hdr.tensors | Where-Object {$_.name -eq 'owner_emb.weight'} | Select-Object -First 1
if($null -eq $t){throw 'owner_emb.weight missing'}
if([int]$t.shape[0] -ne 4 -or [int]$t.shape[1] -ne 256){throw "owner shape is not [4,256]"}
if([int]$t.nbytes -ne 4096){throw "owner nbytes is not 4096"}
[Int64]$off=$base+[Int64]$t.offset
[int]$row=1024

[byte[]]$enemyBefore=New-Object byte[] $row
[byte[]]$neutralBefore=New-Object byte[] $row
[Array]::Copy($raw,$off+2*$row,$enemyBefore,0,$row)
[Array]::Copy($raw,$off+3*$row,$neutralBefore,0,$row)

# Critical v107 mapping: ALLY gets SELF semantic embedding, but remains owner id 1.
[Array]::Copy($raw,$off,$raw,$off+$row,$row)
[IO.File]::WriteAllBytes($p,$raw)

[byte[]]$check=[IO.File]::ReadAllBytes($p)
for($i=0;$i -lt $row;$i++){
  if($check[$off+$i] -ne $check[$off+$row+$i]){throw "ALLY!=SELF at byte $i"}
  if($check[$off+2*$row+$i] -ne $enemyBefore[$i]){throw "ENEMY row changed at byte $i"}
  if($check[$off+3*$row+$i] -ne $neutralBefore[$i]){throw "NEUTRAL row changed at byte $i"}
}
Write-Host 'TEAM4_V107_OWNER_MAPPING=SELF0_ALLY1_ENEMY2_NEUTRAL3'
Write-Host 'TEAM4_V107_ALLY_CONTEXT=SELF_SEMANTIC_OWNER_ID_STAYS_1'
Write-Host 'TEAM4_V107_ALLY_FRIENDLY_PATCH=PASS'
