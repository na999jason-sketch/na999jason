aPlutoTeamRuntime v107 — Friendly Context / No Control / No Ally Target
=========================================================================

This replaces the discarded five-way v106 proposal.

Critical correction
-------------------
The intended v105 ALLY=SELF experiment was not reliable: its launcher inserted
PATCH_ALLY_FRIENDLY_V105.ps1 at the first textual occurrence of
PlutoTeamRuntimePrepV104.exe, which was inside the file-existence FOR block.
With a complete package that block does not execute, so the actual runtime could
remain ALLY=old OTHER while the DLL log claimed the v105 seed.

v107 fixes the experiment and also fixes the missing control/target separation.

Model semantics
---------------
owner vocabulary:
  0 SELF
  1 ALLY
  2 ENEMY
  3 NEUTRAL

embedding:
  SELF    = original SELF
  ALLY    = original SELF  (friendly power/context)
  ENEMY   = original OTHER
  NEUTRAL = original NEUTRAL

mask semantics for every matched ALLY row:
  actor_mask  = 0  (not owned / not commandable)
  target_mask = 0  (not a direct unit-target candidate)

Therefore allied combat units remain present in unit encoding, spatial encoding,
attention, and strategic context as friendly forces, but Pluto cannot directly
select or unit-target them.

The bridge-level ally-target DROP remains enabled only as a second safety layer.
A healthy v107 game should drive ally-target blocked counts close to zero.

No handcrafted defend/follow/attack strategy is added. Original Pluto still
chooses every strategic action and command.
