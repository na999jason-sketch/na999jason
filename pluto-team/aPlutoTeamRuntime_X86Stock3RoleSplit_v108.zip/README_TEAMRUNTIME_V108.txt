aPlutoTeamRuntime v108 - STOCK3 NO-TRAINING Ally Role Split Test

PURPOSE
- In-game test only. No Pluto training. No owner embedding expansion. No inference EXE patch.
- Original Pluto remains the observer/reasoner/strategy/command generator.
- Real SCR alliance relations are read exactly as in proven v104.

MODEL
- Requires official stock Pluto 3-owner model: SELF=0, OTHER=1, NEUTRAL=2.
- If official backups from v104/v107 exist, launcher restores them before injection.
- Runtime fails closed if the inference owner gate is not 3 or owner_emb is not [3,256].

ALLY OBSERVATION PROJECTION (NO HANDCRAFTED STRATEGY)
- Allied combat/support units -> SELF semantic context, actor_mask=0, target_mask=0.
- Allied static combat structures -> SELF semantic context, actor_mask=0, target_mask=0.
- Allied workers, production/tech/economy buildings, Larva/Egg/Cocoon/Lurker Egg/Overlord, spell pseudo-units -> NEUTRAL semantic context, actor_mask=0, target_mask=0.
- Actual enemies -> stock OTHER semantic.
- Map neutrals -> stock NEUTRAL semantic.

Friendly-force classification uses only static BWAPI UnitType metadata:
canAttack / isSpellcaster / isDetector / transport space, plus Terran Bunker.
It never uses enemy proximity, HP, threatened-base rules, or custom tactical actions.

WHY THIS TEST EXISTS
v107 proved ALLY=SELF globally damages normal macro/tech because allied economy and buildings look owned.
v108 tests whether separating allied military context from non-owned economy context recovers normal Pluto macro while still allowing allied army strength to influence Pluto's own decisions.

LIMITATION
This is NOT a learned/native fourth ALLY concept. It is a pragmatic no-training compatibility projection into stock Pluto's three known semantics. Allied economic/base assets intentionally do not look like owned friendly assets in this test, so natural ally-base defense is not fully represented.

EXPECTED LOG MARKERS
PLUTOTEAMRUNTIME_V108_RESIDENT=LOADED
TEAM_RUNTIME_PLUTO_MODEL=OFFICIAL_UNMODIFIED_NO_TRAINING
V108_STOCK_ENGINE=OFFICIAL_3WAY_GATE_VERIFIED offset=59203 value=3
V108_STOCK_WEIGHTS=OWNER_EMB_3X256_VERIFIED
V108_ALLY_ROLE_SAMPLE ... role=FRIENDLY_FORCE or NONOWNED_CONTEXT
V108_SHM_OWNER_REWRITE=PASS ... ally_friendly_force=... ally_nonowned_context=...
TEAM_TRAINING_RECORDER=CONFIRMED_DISABLED_V108

IN-GAME CHECK
1) Early build/tech should look much closer to normal Pluto than v107.
2) Allied workers/buildings must not be controlled or treated as owned economy.
3) Allied combat/support units must never be controlled or directly selected as targets.
4) With allied army nearby in a real fight, compare Pluto's engage/retreat behavior to normal.
5) No PTRJ is recorded in v108.
