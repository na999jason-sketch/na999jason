# aPlutoTeam Phase2C v1.1 — Recurrent Layout Grid

Phase2C v1 proved on eight clean v104 real-game requests that the official 3-way -> seeded 4-way owner migration is byte-exact policy preserving (8/8), while the current PyTorch first-step reconstruction mismatches all eight actions.

This diagnostic does not train or mutate Pluto strategy. It keeps the already-validated 4-way seed and uses the official patched 4-way engine as the black-box reference on the same eight requests.

It scans high-value recurrent-layout uncertainties that Phase2B v1.4 did not exhaust:
- global/history concatenation order
- first-step slow-cache mode (none/input/post-attention/post-FF)
- GRU r/z/n packed gate permutations
- GRU reset placement
- GRU update convention
- hidden query chunk assignment to spatial/unit/slow attention
- legal action mask effect
- presence/absence of action_head.bias in the official PLWB

The grid is two-stage so common trunk tensors are computed once per probe and the large combinatorial search stays fast.

Interpretation:
- FULL_ACTION_MATCH: adopt that recurrent layout and rerun exact parity.
- STRONG_CANDIDATE: patch candidate and isolate remaining head/trunk difference.
- COMMON_TRUNK_STILL_SUSPECT: move next to encoder/spatial layout grid (QKV packing, null-row scatter, etc.).
