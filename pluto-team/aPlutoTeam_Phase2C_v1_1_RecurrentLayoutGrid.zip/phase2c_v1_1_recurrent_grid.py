from __future__ import annotations

import argparse
import itertools
import json
import math
import struct
import subprocess
import threading
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from pluto_trunk import PlutoFirstStep, linear, ln, rms, swiglu

RESP = struct.Struct('<qqqqff')
REQ_HDR = struct.Struct('<iiiIqqqq')


def read_exact(pipe, n: int) -> bytes:
    out = bytearray()
    while len(out) < n:
        c = pipe.read(n - len(out))
        if not c:
            raise EOFError(f'expected {n} bytes, got {len(out)}')
        out += c
    return bytes(out)


def parse_response(raw: bytes) -> dict:
    a, arg, pos, unit, win, logprob = RESP.unpack(raw)
    return {'action': int(a), 'arg': int(arg), 'pos': int(pos), 'unit': int(unit),
            'win': float(win), 'logprob': float(logprob), 'hex': raw.hex()}


def request_expected_size(n: int) -> int:
    return 0x30 + n*6*8 + n*109*4 + n + n + 20 + 233 + 292*4 + 128*128*2 + 128*128 + 4*8


def parse_request(raw: bytes) -> dict:
    n, w, h, flags, f0, f1, f2, f3 = REQ_HDR.unpack_from(raw, 0)
    expected = request_expected_size(n)
    if len(raw) != expected:
        raise ValueError(f'bad request size {len(raw)} expected {expected}')
    off = 0x30
    cat = np.frombuffer(raw, dtype='<i8', count=n*6, offset=off).copy().reshape(n,6); off += n*6*8
    cont = np.frombuffer(raw, dtype='<f4', count=n*109, offset=off).copy().reshape(n,109); off += n*109*4
    actor = np.frombuffer(raw, dtype=np.uint8, count=n, offset=off).copy(); off += n
    target = np.frombuffer(raw, dtype=np.uint8, count=n, offset=off).copy(); off += n
    action_mask = np.frombuffer(raw, dtype=np.uint8, count=20, offset=off).copy(); off += 20
    arg_mask = np.frombuffer(raw, dtype=np.uint8, count=233, offset=off).copy(); off += 233
    glob = np.frombuffer(raw, dtype='<f4', count=292, offset=off).copy(); off += 292*4
    bits = np.frombuffer(raw, dtype='<u2', count=128*128, offset=off).copy().reshape(128,128); off += 128*128*2
    static = np.frombuffer(raw, dtype=np.uint8, count=128*128, offset=off).copy().reshape(128,128); off += 128*128
    hist = np.frombuffer(raw, dtype='<i8', count=4, offset=off).copy(); off += 4*8
    assert off == len(raw)
    return {
        'n':n,'width':w,'height':h,'flags':flags,'forced':[int(f0),int(f1),int(f2),int(f3)],
        'cat':torch.from_numpy(cat).long(), 'cont':torch.from_numpy(cont).float(),
        'global':torch.from_numpy(glob).float(),
        'bits':torch.from_numpy(bits.astype(np.int64,copy=False)).long(),
        'static':torch.from_numpy(static.astype(np.int64,copy=False)).long(),
        'hist':torch.from_numpy(hist).long(),
        'actor_mask':actor,'target_mask':target,'action_mask':action_mask,'arg_mask':arg_mask,
    }


def run_engine(exe: Path, weights: Path, request: bytes, stderr_path: Path, timeout_s: int = 45) -> dict:
    cmd = [str(exe), '--blob', str(weights), '--backend', 'int8mv', '--threads', '1',
           '--seed', '123456789', '--argmax', '--verbose']
    creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         creationflags=creationflags, bufsize=0)
    err=[]
    def drain():
        while True:
            c=p.stderr.read(65536)
            if not c: break
            err.append(c)
    th=threading.Thread(target=drain,daemon=True); th.start()
    t0=time.time()
    try:
        hs_raw=read_exact(p.stdout,0x88)
        magic,ver,fps,max_units,model_step,label,build=struct.unpack('<4sIiiq48s64s',hs_raw)
        if magic.rstrip(b'\0') != b'PLO1' or ver != 3:
            raise RuntimeError('bad handshake')
        p.stdin.write(request); p.stdin.flush()
        rr=read_exact(p.stdout,0x28)
        p.stdin.close()
        try: rc=p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            p.kill(); rc=p.wait(timeout=10)
        th.join(timeout=10)
        stderr_path.write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
        return {'returncode':int(rc),'response':parse_response(rr),'elapsed_s':time.time()-t0}
    finally:
        if p.poll() is None:
            p.kill(); p.wait(timeout=10)


def slow_tick_variant(m: PlutoFirstStep, h, cache, mode: str):
    if mode == 'none':
        return cache
    w=m.w
    x=rms(h,w['gru.slow_enc.in_norm.weight'])
    x=linear(x,w['gru.slow_enc.in_proj.weight'])
    new=[]
    for i in range(4):
        a=rms(x,w[f'gru.slow_enc.layers.{i}.norm_input.weight'])
        old=cache[i]
        cn=rms(old[1:],w[f'gru.slow_enc.layers.{i}.norm_cache.weight'])
        kv_old=linear(cn,w[f'gru.slow_enc.layers.{i}.kv_cache.weight'])
        kv_new=linear(a,w[f'gru.slow_enc.layers.{i}.kv_input.weight']).unsqueeze(0)
        K,V=torch.cat([kv_old,kv_new],dim=0).chunk(2,dim=-1)
        q=linear(a,w[f'gru.slow_enc.layers.{i}.q_proj.weight'])
        att=m.mha(q,K,V,8)
        x_att=x+linear(att,w[f'gru.slow_enc.layers.{i}.out_proj.weight'])
        ff_in=rms(x_att,w[f'gru.slow_enc.layers.{i}.ff_norm.weight'])
        x_ff=x_att+swiglu(ff_in,w[f'gru.slow_enc.layers.{i}.ff.gate_up.weight'],w[f'gru.slow_enc.layers.{i}.ff.down.weight'])
        if mode == 'input': appended=x
        elif mode == 'attn': appended=x_att
        elif mode == 'ff': appended=x_ff
        else: raise ValueError(mode)
        new.append(torch.cat([old[1:],appended.unsqueeze(0)],dim=0))
        x=x_ff
    return torch.stack(new,dim=0)


def global_hist_parts(m: PlutoFirstStep, req: dict):
    w=m.w
    g=linear(req['global'],w['global_proj.0.weight'],w['global_proj.0.bias'])
    g=ln(g,w['global_proj.1.weight'],w['global_proj.1.bias'])
    e=w['action_hist_emb.weight'][req['hist']].reshape(-1)
    ah=linear(e,w['action_hist_proj.0.weight'],w['action_hist_proj.0.bias'])
    ah=ln(ah,w['action_hist_proj.1.weight'],w['action_hist_proj.1.bias'])
    return g,ah


def prepare_common(m: PlutoFirstStep, req: dict):
    u0=m.encode_units(req['cat'],req['cont'])
    planes=m.assemble_planes(u0,req['cont'],req['bits'],req['static'])
    _,s32,s8=m.spatial_encoder(planes)
    u1=m.inject_spatial(u0,s32,req['cont'])
    U=m.encoder(u1)
    g,ah=global_hist_parts(m,req)
    h0=m.w['gru.h0'].clone()
    c0=m.slow_init()
    return {'s8':s8,'U':U,'g':g,'ah':ah,'h0':h0,'c0':c0}


def action_logits(m: PlutoFirstStep, h):
    w=m.w
    b=w['action_head.bias'] if 'action_head.bias' in m.blob.by_name else None
    return linear(h,w['action_head.weight'],b)


def build_attention_reads(m: PlutoFirstStep, h0, s8, U, M):
    w=m.w; d=4096
    hq=h0 @ w['gru.W_hq']
    hchunks=list(hq[:3*d].chunk(3))
    qchunks=list(hq[3*d:].chunk(3))
    srcs=[
        (s8[0].permute(1,2,0).reshape(-1,384),'gru.spatial_kv_proj.weight','gru.w_out_s'),
        (U,'gru.unit_kv_proj.weight','gru.w_out_u'),
        (M,'gru.slow_kv_proj.weight','gru.w_out_slow'),
    ]
    reads={}
    for si,(src,pn,wn) in enumerate(srcs):
        K,V=linear(src,w[pn]).chunk(2,dim=-1)
        for qi,q in enumerate(qchunks):
            reads[(qi,si)]=m.mha(q,K,V,8) @ w[wn]
    return hchunks,qchunks,reads


def evaluate_cfg(m, req, common, pre, cfg):
    w=m.w; h0=common['h0']
    xt=torch.cat([common['g'],common['ah']],dim=-1) if cfg['xt']=='g_ah' else torch.cat([common['ah'],common['g']],dim=-1)
    xi=linear(xt,w['gru.W_i.weight'],w['gru.W_i.bias'])
    xchunks=list(xi.chunk(3))
    hchunks,_,reads=pre[cfg['slow']]
    qp=cfg['qperm']
    att=sum((reads[(qp[si],si)] for si in range(3)), torch.zeros(3*4096))
    achunks=list(att.chunk(3))
    gp=cfg['gateperm']
    hr,hz,hn=[hchunks[gp[i]] for i in range(3)]
    xr,xz,xn=[xchunks[gp[i]] for i in range(3)]
    ar,az,an=[achunks[gp[i]] for i in range(3)]
    r=torch.sigmoid(xr+hr+ar)
    z=torch.sigmoid(xz+hz+az)
    if cfg['reset']=='current':
        n=torch.tanh(xn + r*hn + an)
    elif cfg['reset']=='reset_hidden_att':
        n=torch.tanh(xn + r*(hn+an))
    elif cfg['reset']=='reset_att':
        n=torch.tanh(xn + hn + r*an)
    else:
        raise ValueError(cfg['reset'])
    if cfg['update']=='z_keeps_h':
        h1=(1-z)*n + z*h0
    elif cfg['update']=='z_takes_n':
        h1=z*n + (1-z)*h0
    else:
        raise ValueError(cfg['update'])
    logits=action_logits(m,h1).float()
    raw_action=int(torch.argmax(logits).item())
    mask=torch.from_numpy(req['action_mask'].astype(bool,copy=False))
    masked=logits.clone(); masked[~mask]=-1e30
    masked_action=int(torch.argmax(masked).item())
    return logits,raw_action,masked_action


def cfg_key(c):
    return (c['xt'],c['slow'],tuple(c['gateperm']),tuple(c['qperm']),c['reset'],c['update'])


def cfg_dict(k):
    return {'xt':k[0],'slow':k[1],'gateperm':list(k[2]),'qperm':list(k[3]),'reset':k[4],'update':k[5]}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--team4-exe',required=True)
    ap.add_argument('--team4-weights',required=True)
    ap.add_argument('--probes',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    exe=Path(args.team4_exe).resolve(); weights=Path(args.team4_weights).resolve()
    pdir=Path(args.probes).resolve(); out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    logs=out/'engine_logs'; logs.mkdir(exist_ok=True)
    manifest=json.loads((pdir/'manifest.json').read_text(encoding='utf-8'))
    model=PlutoFirstStep(weights,'center01')
    torch.set_grad_enabled(False)

    suspicious={n:list(info.shape) for n,info in model.blob.by_name.items() if n.startswith('action_head') or n.startswith('gru.W_') or n.startswith('global_proj') or n.startswith('action_hist_proj')}
    print('ACTION_HEAD_TENSORS',json.dumps({k:v for k,v in suspicious.items() if k.startswith('action_head')},sort_keys=True))
    print('ACTION_HEAD_BIAS_PRESENT', 'action_head.bias' in model.blob.by_name)

    probes=[]
    for p in manifest['probes']:
        raw=(pdir/p['request_file']).read_bytes(); req=parse_request(raw)
        off=run_engine(exe,weights,raw,logs/f"{p['name']}.stderr.log")
        if off['returncode']!=0: raise SystemExit(f"official engine failed {p['name']}")
        oa=off['response']['action']
        legal=bool(req['action_mask'][oa]) if 0 <= oa < 20 else False
        if not legal: raise SystemExit(f"official action {oa} is masked out for {p['name']}; mask convention assumption wrong")
        common=prepare_common(model,req)
        caches={sm:slow_tick_variant(model,common['h0'],common['c0'],sm) for sm in ['none','input','attn','ff']}
        pre={sm:build_attention_reads(model,common['h0'],common['s8'],common['U'],caches[sm][3]) for sm in caches}
        probes.append({'meta':p,'req':req,'official':off,'common':common,'pre':pre})
        print(f"OFFICIAL {p['name']} frame={p['frame']} action={oa} legal={legal}")

    # Stage A: current query-chunk assignment, broad recurrent-layout scan.
    stage1_cfgs=[]
    ident=(0,1,2)
    for xt,slow,gp,reset,update in itertools.product(
        ['g_ah','ah_g'], ['none','input','attn','ff'], itertools.permutations(range(3)),
        ['current','reset_hidden_att','reset_att'], ['z_keeps_h','z_takes_n']):
        stage1_cfgs.append({'xt':xt,'slow':slow,'gateperm':tuple(gp),'qperm':ident,'reset':reset,'update':update})

    def score_configs(cfgs):
        score={cfg_key(c):{'raw_match':0,'masked_match':0,'raw_rank_sum':0,'masked_rank_sum':0,'rows':[]} for c in cfgs}
        for pi,p in enumerate(probes):
            target=int(p['official']['response']['action']); req=p['req']
            mask=torch.from_numpy(req['action_mask'].astype(bool,copy=False))
            allowed_ids=torch.nonzero(mask,as_tuple=False).flatten().tolist()
            for c in cfgs:
                logits,ra,ma=evaluate_cfg(model,req,p['common'],p['pre'],c)
                raw_order=torch.argsort(logits,descending=True).tolist()
                rr=raw_order.index(target)+1
                masked_order=sorted(allowed_ids,key=lambda i:float(logits[i]),reverse=True)
                mr=masked_order.index(target)+1
                s=score[cfg_key(c)]
                s['raw_match']+=int(ra==target); s['masked_match']+=int(ma==target)
                s['raw_rank_sum']+=rr; s['masked_rank_sum']+=mr
                s['rows'].append({'probe':p['meta']['name'],'official':target,'raw':ra,'masked':ma,'raw_rank':rr,'masked_rank':mr})
        rows=[]
        for k,s in score.items():
            rows.append({'config':cfg_dict(k),**s,'mean_raw_rank':s['raw_rank_sum']/len(probes),'mean_masked_rank':s['masked_rank_sum']/len(probes)})
        rows.sort(key=lambda r:(-r['masked_match'],-r['raw_match'],r['mean_masked_rank'],r['mean_raw_rank']))
        return rows

    t0=time.time()
    stage1=score_configs(stage1_cfgs)
    print('STAGE1_TOP')
    for i,r in enumerate(stage1[:12],1):
        print(i,json.dumps({k:r[k] for k in ['config','masked_match','raw_match','mean_masked_rank','mean_raw_rank']},sort_keys=True))

    # Stage B: only the top Stage-A recurrent layouts, now permute q chunk -> source assignment.
    stage2_cfgs=[]; seen=set()
    for base in stage1[:12]:
        bc=base['config']
        for qp in itertools.permutations(range(3)):
            c={'xt':bc['xt'],'slow':bc['slow'],'gateperm':tuple(bc['gateperm']),'qperm':tuple(qp),'reset':bc['reset'],'update':bc['update']}
            k=cfg_key(c)
            if k not in seen:
                seen.add(k); stage2_cfgs.append(c)
    stage2=score_configs(stage2_cfgs)
    print('STAGE2_TOP')
    for i,r in enumerate(stage2[:20],1):
        print(i,json.dumps({k:r[k] for k in ['config','masked_match','raw_match','mean_masked_rank','mean_raw_rank']},sort_keys=True))

    report={
        'format':'pluto-team-phase2c-v1.1-recurrent-layout-grid',
        'probe_count':len(probes),
        'action_head_bias_present':'action_head.bias' in model.blob.by_name,
        'suspicious_tensor_shapes':suspicious,
        'official':[{'name':p['meta']['name'],'frame':p['meta']['frame'],'response':p['official']['response'],'action_mask':p['req']['action_mask'].tolist()} for p in probes],
        'stage1_top':stage1[:30],
        'stage2_top':stage2[:30],
        'elapsed_s':time.time()-t0,
    }
    best=stage2[0]
    report['best']=best
    (out/'phase2c_v1_1_recurrent_grid.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    with (out/'phase2c_v1_1_summary.txt').open('w',encoding='utf-8') as f:
        f.write('aPlutoTeam Phase2C v1.1 Recurrent Layout Grid\n')
        f.write(f"probes={len(probes)}\n")
        f.write(f"action_head_bias_present={report['action_head_bias_present']}\n")
        f.write(f"best_masked_match={best['masked_match']}/{len(probes)}\n")
        f.write(f"best_raw_match={best['raw_match']}/{len(probes)}\n")
        f.write(f"best_mean_masked_rank={best['mean_masked_rank']:.6f}\n")
        f.write('best_config='+json.dumps(best['config'],sort_keys=True)+'\n')
        if best['masked_match']==len(probes):
            f.write('PHASE2C_V1_1_RECURRENT_LAYOUT=FULL_ACTION_MATCH\n')
        elif best['masked_match']>=6:
            f.write('PHASE2C_V1_1_RECURRENT_LAYOUT=STRONG_CANDIDATE\n')
        else:
            f.write('PHASE2C_V1_1_RECURRENT_LAYOUT=COMMON_TRUNK_STILL_SUSPECT\n')
        f.write('PHASE2C_V1_1_DIAGNOSTIC_COMPLETE=PASS\n')
    print((out/'phase2c_v1_1_summary.txt').read_text(encoding='utf-8'))

if __name__=='__main__':
    main()
