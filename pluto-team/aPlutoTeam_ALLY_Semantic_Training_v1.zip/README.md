# aPlutoTeam ALLY Semantic Training v1

This package replaces the discarded SELF/ENEMY/NEUTRAL-copy experiments.

## Semantic target

Runtime vocabulary remains:

- `0 SELF` = friendly **and owned/controllable**
- `1 ALLY` = friendly **but not owned/not controllable**
- `2 ENEMY` = hostile
- `3 NEUTRAL` = neutral

`owner_emb[ALLY]` is a new independent 256-float parameter vector. It is **not** copied from SELF, ENEMY, or NEUTRAL, and all 256 values are free during search. All original Pluto weights are frozen.

## Real data used

Only compact request windows are packaged; the original giant PTRJ files are not needed by GitHub Actions.

- `macro_train`, `macro_val`: real v107 g2 state windows. There are allies and **no visible enemies**. These isolate ownership/economy semantics.
- `combat_train`, `combat_val`: real clean g1 state windows from separated ally/enemy contact periods. These teach friendly-force semantics.

The recorded Pluto responses from g1/g2 are **not used as labels**, because those games used known-wrong ALLY semantics.

## Teacher construction

Teachers are generated fresh by the official Pluto inference engine from the same real observations.

### Macro / not-owned objective

Positive reference: remove ALLY unit rows from the observation. Their workers, buildings and tech must not be counted as Pluto-owned economy.

Negative reference: rewrite ALLY rows as SELF. This is explicitly the bad collapse observed in v107.

A learned ALLY candidate must be closer to the positive than to the SELF-collapse negative on held-out macro windows.

### Combat / friendly-force objective

Positive reference: keep allied mobile/combat rows but give them SELF combat semantics while keeping them non-controllable and non-targetable; allied workers/buildings are removed from this reference so their economy is not taught as owned.

Negative references: the same allied combat rows are rewritten as NEUTRAL and as ENEMY.

A learned ALLY candidate must be closer to the positive than to **both** negative references on held-out combat windows, with special emphasis on Pluto's continuous `win` estimate.

## Recurrent-state rule

Every chronological macro/combat window starts a fresh `pluto_infer.exe` process. Unrelated snapshots never share hidden state. Within a window, real chronological recurrence is preserved.

## Deployment gate

No embedding file is emitted unless held-out validation simultaneously passes:

1. macro / not-owned separation,
2. combat / friendly-force semantics,
3. ALLY remains numerically distinct from SELF, ENEMY, and NEUTRAL.

If any gate fails, the workflow emits only the report and `NO_DEPLOYABLE_ALLY_SEMANTIC_EMBEDDING`.
