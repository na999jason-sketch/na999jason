from __future__ import annotations
import argparse, hashlib, json, shutil, struct
from pathlib import Path

FILE_HDR=struct.Struct('<8s6I')
STEP_HDR=struct.Struct('<4s15I')
END_HDR=struct.Struct('<4s5IQ')
REQ_HDR=struct.Struct('<iiiIqqqq')

WORKER_TYPES={7,41,64}
BUILDING_MIN=106
BUILDING_MAX=201

def request_sizes(n:int):
    return {
        'request_header':0x30,
        'cat':n*6*8,
        'cont':n*109*4,
        'actor':n,
        'target':n,
        'action_mask':20,
        'arg_mask':233,
        'global':292*4,
        'bits':128*128*2,
        'static':128*128,
        'hist':4*8,
    }

def iter_steps(path:Path):
    with path.open('rb') as f:
        h=f.read(FILE_HDR.size)
        if len(h)!=FILE_HDR.size: raise ValueError('short header')
        magic,ver,gen,self_id,ally_mask,hbytes,res=FILE_HDR.unpack(h)
        if not magic.startswith(b'PTRJ103') or ver!=1 or hbytes!=32:
            raise ValueError('bad PTRJ103 header')
        idx=0
        while True:
            tag=f.read(4)
            if not tag: return
            f.seek(-4,1)
            if tag==b'STEP':
                vals=STEP_HDR.unpack(f.read(STEP_HDR.size))
                _,hb,pb,rb,req,resp,frame,n,sc,ac,ec,nc,fb,un,amb,blocked=vals
                payload=f.read(pb); response=f.read(rb)
                if len(payload)!=pb or len(response)!=rb: raise ValueError('truncated')
                yield idx, {'req_seq':req,'frame':frame,'n':n,'counts':{'self':sc,'ally':ac,'enemy':ec,'neutral':nc},'payload':payload,'response':response}
                idx+=1
            elif tag==b'END!':
                f.read(END_HDR.size); return
            else:
                raise ValueError(f'bad tag {tag!r}')

def split_req(raw:bytes):
    n=REQ_HDR.unpack_from(raw,0)[0]
    sizes=request_sizes(n)
    if sum(sizes.values())!=len(raw):
        raise ValueError(f'request size mismatch n={n} expected={sum(sizes.values())} got={len(raw)}')
    off=0; out={}
    for k,z in sizes.items():
        out[k]=raw[off:off+z]; off+=z
    return n,out

def row_stats(raw:bytes):
    n,p=split_req(raw)
    out={'self':0,'ally':0,'enemy':0,'neutral':0,'self_combat':0,'ally_combat':0,'enemy_combat':0}
    cat=p['cat']
    for r in range(n):
        typ,owner,*_=struct.unpack_from('<6q',cat,r*48)
        if owner==0: key='self'
        elif owner==1:key='ally'
        elif owner==2:key='enemy'
        elif owner==3:key='neutral'
        else: continue
        out[key]+=1
        combat=(typ not in WORKER_TYPES and not (BUILDING_MIN<=typ<=BUILDING_MAX))
        if combat and key in ('self','ally','enemy'): out[key+'_combat']+=1
    return out

def sha(path:Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()

def extract_block(steps,start,length,dst,source_name,kind):
    dst.mkdir(parents=True,exist_ok=True)
    items=[]
    for j in range(length):
        idx,obj=steps[start+j]
        raw=obj['payload']
        name=f'{j:03d}_s{idx:04d}_f{obj["frame"]}.req'
        p=dst/name; p.write_bytes(raw)
        st=row_stats(raw)
        items.append({'file':name,'source_step':idx,'frame':obj['frame'],'n':obj['n'],**st,'sha256':hashlib.sha256(raw).hexdigest()})
    return {'name':dst.name,'kind':kind,'source':source_name,'start_step':start,'length':length,'items':items}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--g1',required=True)
    ap.add_argument('--g2',required=True)
    ap.add_argument('--out',required=True)
    a=ap.parse_args()
    g1=Path(a.g1); g2=Path(a.g2); out=Path(a.out)
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True)
    s1=list(iter_steps(g1)); s2=list(iter_steps(g2))
    if len(s1)<1328 or len(s2)<256: raise SystemExit('trajectory shorter than expected')
    # g2: no enemy throughout; early macro train and later held-out macro validation.
    # g1: two physically/time-separated real ally/enemy contact windows.
    specs=[
        ('macro_train','macro',s2,16,32,g2.name),
        ('macro_val','macro',s2,224,32,g2.name),
        ('combat_train','combat',s1,463,32,g1.name),
        ('combat_val','combat',s1,1296,32,g1.name),
    ]
    blocks=[]
    for name,kind,steps,start,length,src in specs:
        b=extract_block(steps,start,length,out/name,src,kind)
        blocks.append(b)
    manifest={
        'format':'pluto-team-ally-semantic-dataset-v1',
        'principle':'ALLY is learned as friendly but not owned; no SELF/ENEMY/NEUTRAL row is used as runtime ALLY definition',
        'sources':{
            'g1':{'file':g1.name,'sha256':sha(g1),'steps':len(s1),'role':'combat/friendly-force'},
            'g2':{'file':g2.name,'sha256':sha(g2),'steps':len(s2),'role':'macro/non-owned separation'},
        },
        'blocks':blocks,
    }
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    # Guards: macro windows must contain allies and zero enemies. Combat windows must contain both.
    for b in blocks:
        for m in b['items']:
            if m['ally']<=0: raise SystemExit(f'no ally in {b["name"]}/{m["file"]}')
            if b['kind']=='macro' and m['enemy']!=0: raise SystemExit(f'enemy leaked into macro {m}')
            if b['kind']=='combat' and (m['enemy']<=0 or m['ally_combat']<=0): raise SystemExit(f'bad combat sample {m}')
    print(json.dumps({'blocks':[(b['name'],b['start_step'],b['length'],b['items'][0]['frame'],b['items'][-1]['frame']) for b in blocks]},indent=2))
    print('ALLY_SEMANTIC_DATASET_BUILD=PASS')

if __name__=='__main__': main()
