from pathlib import Path
import hashlib, importlib.util, json, struct

root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('trainer',root/'ally_semantic_train.py')
t=importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
man=json.loads((root/'dataset/manifest.json').read_text(encoding='utf-8'))
by={b['name']:b for b in man['blocks']}
assert set(by)=={'macro_train','macro_val','combat_train','combat_val'}

def owners_masks(raw):
    n,p=t.parse_req(raw); cat=p[1]; actor=p[3]; target=p[4]
    out=[]
    for i in range(n):
        typ,owner,*_=struct.unpack_from('<6q',cat,i*48)
        out.append((int(typ),int(owner),actor[i],target[i]))
    return out

for name,b in by.items():
    for m in b['items']:
        raw=(root/'dataset'/name/m['file']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==m['sha256']
        cand=t.normalize_candidate(raw)
        cm=owners_masks(cand)
        assert any(o==1 for _,o,_,_ in cm)
        assert all(a==0 and z==0 for _,o,a,z in cm if o==1)
        if name.startswith('macro'):
            pos=t.macro_drop_allies(raw); neg=t.macro_allies_as_self(raw)
            assert all(o!=1 for _,o,_,_ in owners_masks(pos))
            assert all(o!=1 for _,o,_,_ in owners_masks(neg))
            assert any(o==0 for _,o,_,_ in owners_masks(neg))
        else:
            ps=t.combat_variant(raw,0); nn=t.combat_variant(raw,3); ne=t.combat_variant(raw,2)
            assert all(o!=1 for _,o,_,_ in owners_masks(ps))
            assert all(o!=1 for _,o,_,_ in owners_masks(nn))
            assert all(o!=1 for _,o,_,_ in owners_masks(ne))
            assert any(o==0 for _,o,_,_ in owners_masks(ps))
            assert any(o==3 for _,o,_,_ in owners_masks(nn))
            assert any(o==2 for _,o,_,_ in owners_masks(ne))
print('ALLY_SEMANTIC_STATIC_VALIDATION=PASS')
