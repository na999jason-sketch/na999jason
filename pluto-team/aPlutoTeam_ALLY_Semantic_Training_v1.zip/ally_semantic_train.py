from __future__ import annotations
import argparse, hashlib, json, math, os, shutil, struct, subprocess, threading
from pathlib import Path
import numpy as np

RESP=struct.Struct('<qqqqff')
REQ_HDR=struct.Struct('<iiiIqqqq')
WORKER_TYPES={7,41,64}
BUILDING_MIN=106
BUILDING_MAX=201

# Request layout recovered from the real PTRJ103 recorder.
def sizes(n:int):
    return [0x30,n*48,n*436,n,n,20,233,292*4,128*128*2,128*128,32]

def parse_req(raw:bytes):
    n=REQ_HDR.unpack_from(raw,0)[0]
    zs=sizes(n)
    if sum(zs)!=len(raw): raise ValueError(f'bad request bytes n={n} expected={sum(zs)} got={len(raw)}')
    off=0; parts=[]
    for z in zs:
        parts.append(raw[off:off+z]); off+=z
    return n,parts

def rebuild(raw:bytes, keep:list[int], owner_override:dict[int,int]|None=None, force_ally_masks_zero=True):
    n,p=parse_req(raw)
    hdr=bytearray(p[0]); cat=p[1]; cont=p[2]; actor=p[3]; target=p[4]; tail=b''.join(p[5:])
    out_cat=bytearray(); out_cont=bytearray(); out_actor=bytearray(); out_target=bytearray()
    owner_override=owner_override or {}
    for old_i in keep:
        row=bytearray(cat[old_i*48:(old_i+1)*48])
        typ,owner,*_=struct.unpack_from('<6q',row,0)
        if old_i in owner_override:
            struct.pack_into('<q',row,8,int(owner_override[old_i]))
            new_owner=int(owner_override[old_i])
        else:
            new_owner=int(owner)
        out_cat += row
        out_cont += cont[old_i*436:(old_i+1)*436]
        a=actor[old_i]; t=target[old_i]
        # ALLY is never controllable and never a direct unit-target candidate in the semantic trainer.
        # This isolates relation learning from command-ownership mechanics.
        if force_ally_masks_zero and (int(owner)==1 or new_owner==1):
            a=0; t=0
        out_actor.append(a); out_target.append(t)
    struct.pack_into('<i',hdr,0,len(keep))
    out=bytes(hdr)+bytes(out_cat)+bytes(out_cont)+bytes(out_actor)+bytes(out_target)+tail
    if len(out)!=sum(sizes(len(keep))): raise AssertionError('rebuild size mismatch')
    return out

def normalize_candidate(raw:bytes):
    n,p=parse_req(raw); cat=p[1]
    keep=list(range(n))
    # retain real ALLY rows with owner id 1, but guarantee no control/target leakage
    return rebuild(raw,keep,{})

def classify_rows(raw:bytes):
    n,p=parse_req(raw); cat=p[1]
    rows=[]
    for i in range(n):
        typ,owner,*_=struct.unpack_from('<6q',cat,i*48)
        combat=(int(typ) not in WORKER_TYPES and not (BUILDING_MIN<=int(typ)<=BUILDING_MAX))
        rows.append((i,int(typ),int(owner),combat))
    return rows

def macro_drop_allies(raw:bytes):
    rs=classify_rows(raw)
    keep=[i for i,t,o,c in rs if o!=1]
    return rebuild(raw,keep,{})

def macro_allies_as_self(raw:bytes):
    rs=classify_rows(raw); keep=[i for i,_,_,_ in rs]
    ov={i:0 for i,t,o,c in rs if o==1}
    return rebuild(raw,keep,ov)

def combat_variant(raw:bytes, ally_owner:int):
    # Keep allied mobile/combat context; drop allied workers/buildings so the teacher cannot
    # accidentally teach "their economy is mine". actor/target remain zero.
    rs=classify_rows(raw)
    keep=[]; ov={}
    for i,t,o,combat in rs:
        if o!=1:
            keep.append(i)
        elif combat:
            keep.append(i); ov[i]=ally_owner
    return rebuild(raw,keep,ov)

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c: raise EOFError(f'expected {n}, got {len(b)}')
        b+=c
    return bytes(b)

def parse_resp(raw:bytes):
    action,arg,pos,unit,win,logprob=RESP.unpack(raw)
    return {'action':int(action),'arg':int(arg),'pos':int(pos),'unit':int(unit),'win':float(win),'logprob':float(logprob)}

def run_engine(exe:Path,weights:Path,requests:list[bytes],stderr_path:Path,timeout_s=900):
    cmd=[str(exe),'--blob',str(weights),'--backend','int8mv','--threads','1','--seed','123456789','--argmax']
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=flags,bufsize=0)
    err=[]
    def drain():
        while True:
            c=p.stderr.read(65536)
            if not c: break
            err.append(c)
    th=threading.Thread(target=drain,daemon=True); th.start()
    try:
        hs=read_exact(p.stdout,0x88)
        magic,ver,*_=struct.unpack('<4sIiiq48s64s',hs)
        if magic.rstrip(b'\0')!=b'PLO1' or ver!=3: raise RuntimeError('bad Pluto handshake')
        out=[]
        for r in requests:
            p.stdin.write(r); p.stdin.flush(); out.append(parse_resp(read_exact(p.stdout,40)))
        p.stdin.close()
        try: rc=p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            p.kill(); rc=p.wait(timeout=10)
        th.join(timeout=10)
        stderr_path.write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
        if rc!=0: raise RuntimeError(f'pluto_infer exit {rc}')
        return out
    finally:
        if p.poll() is None:
            p.kill(); p.wait(timeout=10)

def load_owner_info(path:Path):
    raw=path.read_bytes()
    if raw[:4]!=b'PLWB': raise ValueError('not PLWB')
    hlen=struct.unpack_from('<Q',raw,8)[0]
    hdr=json.loads(raw[16:16+hlen].decode('utf-8'))
    base=len(raw)-int(hdr['total_bytes'])
    t=next(x for x in hdr['tensors'] if x['name']=='owner_emb.weight')
    if list(t['shape'])!=[4,256] or int(t['nbytes'])!=4096: raise ValueError(f'expected [4,256], got {t}')
    abs_off=base+int(t['offset'])
    a=np.frombuffer(raw,dtype='<f4',count=1024,offset=abs_off).copy().reshape(4,256)
    return abs_off,a

def patch_ally_row(path:Path,abs_off:int,row:np.ndarray):
    b=np.asarray(row,dtype='<f4').reshape(256).tobytes()
    with path.open('r+b',buffering=0) as f:
        f.seek(abs_off+1024); f.write(b); f.flush(); os.fsync(f.fileno())

def rms(x): return float(np.sqrt(np.mean(np.asarray(x,dtype=np.float64)**2)))

def resp_distance(a,b,kind):
    # Unit/arg/pos are deliberately excluded: counterfactual row removal changes row indexing.
    # Macro supervision is action-heavy; combat supervision is win-estimate-heavy.
    ad=1.0 if a['action']!=b['action'] else 0.0
    wd=abs(a['win']-b['win'])
    if kind=='macro': return 2.0*ad + 1.0*wd
    return 0.75*ad + 5.0*wd

def seq_metrics(cand,pos,negatives,kind):
    dpos=[resp_distance(a,b,kind) for a,b in zip(cand,pos)]
    negds=[]
    for neg in negatives:
        negds.append([resp_distance(a,b,kind) for a,b in zip(cand,neg)])
    dneg=[min(x) for x in zip(*negds)]
    pos_action=sum(a['action']==b['action'] for a,b in zip(cand,pos))
    neg_action=max(sum(a['action']==b['action'] for a,b in zip(cand,neg)) for neg in negatives)
    pos_win=float(np.mean([abs(a['win']-b['win']) for a,b in zip(cand,pos)]))
    neg_win=min(float(np.mean([abs(a['win']-b['win']) for a,b in zip(cand,neg)])) for neg in negatives)
    return {
        'steps':len(cand),
        'positive_distance':float(np.mean(dpos)),
        'nearest_negative_distance':float(np.mean(dneg)),
        'margin':float(np.mean(dneg)-np.mean(dpos)),
        'positive_action_match':int(pos_action),
        'best_negative_action_match':int(neg_action),
        'positive_win_mae':pos_win,
        'best_negative_win_mae':neg_win,
    }

def independent_seed(anchors,rng,scale):
    selfr,enemyr,neutralr=anchors[0],anchors[2],anchors[3]
    centroid=(selfr+enemyr+neutralr)/3.0
    basis=[]
    for v in (selfr-centroid,enemyr-centroid,neutralr-centroid):
        q=v.astype(np.float64).copy()
        for b in basis:q-=np.dot(q,b)*b
        n=np.linalg.norm(q)
        if n>1e-10:basis.append(q/n)
    d=rng.standard_normal(256).astype(np.float64)
    for b in basis:d-=np.dot(d,b)*b
    d/=max(rms(d),1e-12)
    return (centroid + 0.85*scale*d).astype(np.float32)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--exe',required=True)
    ap.add_argument('--weights',required=True)
    ap.add_argument('--dataset',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--generations',type=int,default=6)
    ap.add_argument('--directions',type=int,default=4)
    ap.add_argument('--seeds',type=int,default=6)
    a=ap.parse_args()
    exe=Path(a.exe); base=Path(a.weights); ds=Path(a.dataset); out=Path(a.out)
    out.mkdir(parents=True,exist_ok=True); logs=out/'logs'; logs.mkdir(exist_ok=True)
    man=json.loads((ds/'manifest.json').read_text(encoding='utf-8'))
    byname={b['name']:b for b in man['blocks']}
    needed=['macro_train','macro_val','combat_train','combat_val']
    if any(x not in byname for x in needed): raise SystemExit('dataset blocks missing')
    blocks={}
    for name in needed:
        b=byname[name]; raws=[]
        for m in b['items']:
            r=(ds/name/m['file']).read_bytes()
            if hashlib.sha256(r).hexdigest()!=m['sha256']: raise SystemExit(f'SHA mismatch {name}/{m["file"]}')
            raws.append(r)
        blocks[name]=raws

    # All candidate inputs use the real relation id 1 and no actor/target leakage.
    cand_req={k:[normalize_candidate(r) for r in v] for k,v in blocks.items()}
    teacher_req={
        'macro_train_pos':[macro_drop_allies(r) for r in blocks['macro_train']],
        'macro_train_neg_self':[macro_allies_as_self(r) for r in blocks['macro_train']],
        'macro_val_pos':[macro_drop_allies(r) for r in blocks['macro_val']],
        'macro_val_neg_self':[macro_allies_as_self(r) for r in blocks['macro_val']],
        'combat_train_pos':[combat_variant(r,0) for r in blocks['combat_train']],
        'combat_train_neg_neutral':[combat_variant(r,3) for r in blocks['combat_train']],
        'combat_train_neg_enemy':[combat_variant(r,2) for r in blocks['combat_train']],
        'combat_val_pos':[combat_variant(r,0) for r in blocks['combat_val']],
        'combat_val_neg_neutral':[combat_variant(r,3) for r in blocks['combat_val']],
        'combat_val_neg_enemy':[combat_variant(r,2) for r in blocks['combat_val']],
    }

    # Each sequence gets a fresh inference process: no hidden-state contamination across unrelated windows.
    teacher={}
    for k,rr in teacher_req.items():
        teacher[k]=run_engine(exe,base,rr,logs/f'teacher_{k}.stderr.txt')
        print(f'TEACHER {k}=PASS steps={len(rr)}',flush=True)

    abs_off,anchors=load_owner_info(base)
    selfr,enemyr,neutralr=anchors[0].copy(),anchors[2].copy(),anchors[3].copy()
    scale=float(np.median([rms(selfr-enemyr),rms(selfr-neutralr),rms(enemyr-neutralr)]))
    if not math.isfinite(scale) or scale<1e-8: raise SystemExit('bad owner embedding scale')
    centroid=(selfr+enemyr+neutralr)/3.0
    candidate_file=out/'candidate_weights.bin'; shutil.copy2(base,candidate_file)
    eval_id=0

    def evaluate(row,split):
        nonlocal eval_id
        eval_id+=1; patch_ally_row(candidate_file,abs_off,row)
        if split=='train': mn='macro_train'; cn='combat_train'
        elif split=='val': mn='macro_val'; cn='combat_val'
        else: raise ValueError(split)
        # Critical: macro and combat each start from fresh h0.
        m=run_engine(exe,candidate_file,cand_req[mn],logs/f'e{eval_id:04d}_{split}_macro.stderr.txt')
        c=run_engine(exe,candidate_file,cand_req[cn],logs/f'e{eval_id:04d}_{split}_combat.stderr.txt')
        mm=seq_metrics(m,teacher[mn+'_pos'],[teacher[mn+'_neg_self']],'macro')
        cm=seq_metrics(c,teacher[cn+'_pos'],[teacher[cn+'_neg_neutral'],teacher[cn+'_neg_enemy']],'combat')
        dists={
            'self':rms(row-selfr)/scale,
            'enemy':rms(row-enemyr)/scale,
            'neutral':rms(row-neutralr)/scale,
            'centroid':rms(row-centroid)/scale,
        }
        # Both meanings are mandatory. Positive margin means candidate is closer to desired semantics than negatives.
        score=2.0*mm['margin'] + 2.5*cm['margin'] - 0.20*mm['positive_distance'] - 0.20*cm['positive_distance']
        mind=min(dists['self'],dists['enemy'],dists['neutral'])
        if mind<0.10: score-=6.0*(0.10-mind)
        if dists['centroid']>2.25: score-=1.5*(dists['centroid']-2.25)
        return {'split':split,'score':float(score),'macro':mm,'combat':cm,'distances':dists,'row':np.asarray(row,dtype=np.float32).copy()}

    def public(r):
        return {'split':r['split'],'score':r['score'],'macro':r['macro'],'combat':r['combat'],'distances':r['distances']}

    rng=np.random.default_rng(20261005)
    pool=[]
    for i in range(a.seeds):
        row=independent_seed(anchors,rng,scale)
        rec=evaluate(row,'train'); pool.append(rec)
        print(f'SEED {i+1}/{a.seeds} score={rec["score"]:.6f} macroMargin={rec["macro"]["margin"]:.6f} combatMargin={rec["combat"]["margin"]:.6f}',flush=True)
    center_rec=max(pool,key=lambda r:r['score'])
    center=center_rec['row'].copy()
    best=center_rec
    trace=[]

    for gen in range(a.generations):
        sigma=(0.32*(0.80**gen))*scale
        step=(0.22*(0.86**gen))*scale
        g=np.zeros(256,dtype=np.float64); genrecs=[]
        for j in range(a.directions):
            d=rng.standard_normal(256).astype(np.float64); d/=max(rms(d),1e-12)
            rp=evaluate(center+sigma*d,'train'); rm=evaluate(center-sigma*d,'train')
            genrecs += [rp,rm]; pool += [rp,rm]
            g += (rp['score']-rm['score'])*d
            print(f'ES g={gen+1} d={j+1} plus={rp["score"]:.6f} minus={rm["score"]:.6f}',flush=True)
        gr=rms(g)
        proposed=center.copy() if gr<1e-12 else center + step*(g/gr)
        # Broad safety bound only; no pull toward any existing owner class.
        dc=proposed-centroid; dr=rms(dc)
        if dr>2.25*scale: proposed=centroid+dc*((2.25*scale)/dr)
        rc=evaluate(proposed,'train'); pool.append(rc); genrecs.append(rc)
        winner=max(genrecs,key=lambda r:r['score'])
        if winner['score']>best['score']: best=winner
        if winner['score']>=center_rec['score']:
            center=winner['row'].copy(); center_rec=winner
        trace.append({'generation':gen+1,'sigma':sigma,'step':step,'gradient_rms':gr,'winner':public(winner)})
        print(f'GEN {gen+1} winner={winner["score"]:.6f} macroMargin={winner["macro"]["margin"]:.6f} combatMargin={winner["combat"]["margin"]:.6f}',flush=True)

    # Held-out validation of unique top candidates.
    ranked=sorted(pool,key=lambda r:r['score'],reverse=True)
    unique=[]; seen=set()
    for r in ranked:
        h=hashlib.sha256(np.asarray(r['row'],dtype='<f4').tobytes()).hexdigest()
        if h in seen: continue
        seen.add(h); unique.append(r)
        if len(unique)>=5: break
    vals=[]
    for i,r in enumerate(unique,1):
        v=evaluate(r['row'],'val')
        # Hard semantic gates. BOTH must pass.
        macro_ok=(v['macro']['margin']>0.03 and
                  v['macro']['positive_distance']<v['macro']['nearest_negative_distance'] and
                  v['macro']['positive_action_match']>=v['macro']['best_negative_action_match'])
        combat_ok=(v['combat']['margin']>0.03 and
                   v['combat']['positive_distance']<v['combat']['nearest_negative_distance'] and
                   v['combat']['positive_win_mae']<v['combat']['best_negative_win_mae'])
        distinct_ok=min(v['distances']['self'],v['distances']['enemy'],v['distances']['neutral'])>=0.10
        deploy=bool(macro_ok and combat_ok and distinct_ok)
        vals.append({'rank':i,'train':public(r),'val':public(v),'macro_ok':macro_ok,'combat_ok':combat_ok,'distinct_ok':distinct_ok,'deployable':deploy,'row':r['row']})
        print(f'VALIDATE rank={i} deploy={deploy} macro={macro_ok} combat={combat_ok} distinct={distinct_ok}',flush=True)

    ok=[v for v in vals if v['deployable']]
    if ok:
        chosen=max(ok,key=lambda v:v['val']['score'])
        row=np.asarray(chosen['row'],dtype='<f4')
        row.tofile(out/'ally_semantic_embedding_f32.bin')
        (out/'ally_semantic_embedding.json').write_text(json.dumps({'vector':[float(x) for x in row],'validation':{k:v for k,v in chosen.items() if k!='row'}},indent=2),encoding='utf-8')
        result='ALLY_SEMANTIC_EMBEDDING_FOUND'; deployable=True
    else:
        chosen=None; result='NO_DEPLOYABLE_ALLY_SEMANTIC_EMBEDDING'; deployable=False

    report={
        'format':'pluto-team-ally-semantic-training-v1',
        'definition':'ALLY is independently learned as FRIENDLY + NOT_OWNED; it is never defined by copying SELF/ENEMY/NEUTRAL',
        'runtime_owner_vocab':'0 SELF, 1 ALLY, 2 ENEMY, 3 NEUTRAL',
        'macro_supervision':{'positive':'remove ALLY rows (their economy/tech is not owned)','negative':'rewrite ALLY rows to SELF'},
        'combat_supervision':{'positive':'keep allied mobile/combat rows as non-controllable SELF semantic reference; remove allied worker/building rows','negatives':['combat ALLY->NEUTRAL','combat ALLY->ENEMY']},
        'mask_rule':'ALLY actor_mask=0 and target_mask=0 in every candidate/reference request',
        'recurrent_rule':'fresh pluto_infer process for every macro/combat chronological window and every candidate',
        'search':{'seeds':a.seeds,'generations':a.generations,'directions':a.directions,'all_256_ally_values_trainable':True,'existing_owner_weights_frozen':True},
        'anchor_scale':scale,'trace':trace,
        'validations':[{k:v for k,v in x.items() if k!='row'} for x in vals],
        'deployable':deployable,'classification':result,
    }
    (out/'ally_semantic_training_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    summary='\n'.join([
        'aPlutoTeam ALLY Semantic Training v1',
        'ALLY definition: FRIENDLY + NOT_OWNED (independent learned 256D row)',
        f'train macro={len(blocks["macro_train"])} combat={len(blocks["combat_train"])}; heldout macro={len(blocks["macro_val"])} combat={len(blocks["combat_val"])}',
        f'seeds={a.seeds} generations={a.generations} directions={a.directions}',
        f'deployable={deployable} result_class={result}',
        'ALLY_SEMANTIC_TRAINING_V1=PASS',
    ])+'\n'
    (out/'ally_semantic_training_summary.txt').write_text(summary,encoding='utf-8')
    print(summary,flush=True)
    candidate_file.unlink(missing_ok=True)

if __name__=='__main__': main()
