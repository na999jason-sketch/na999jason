aPlutoTeamRuntime v110 - STOCK3 / NO TRAINING / Combat-Local Ally Context + v109 Early-Army Preference

PURPOSE
- Preserve v109 early-army preference EXACTLY.
- Stop allied ground/air force from looking like permanently owned army during normal production/composition reasoning.
- Still let original Pluto see allied combat/support force as friendly combat context during a real visible engagement.
- NO model training, NO weight patch, NO inference EXE patch, NO scripted combat/economy strategy.

UNCHANGED FROM v109
- Official stock Pluto model: SELF=0, OTHER=1, NEUTRAL=2.
- Exact SCR alliance matrix relation matching.
- Ally actor mask = 0 and target mask = 0, plus ally-target DROP safety.
- Original Pluto inference/model/weights/strategy remain untouched.
- v109 early-army preference is unchanged:
  * end frame 7200
  * minimum own workers 10
  * 1 of every 3 eligible requests
  * 96 frame cooldown
  * max 18 nudges
  * same self-calibrating worker/army action evidence and one-request worker-action mask.

V110 ALLY OBSERVATION POLICY
Problem in v108/v109:
- Allied combat/support rows were always rewritten to stock SELF.
- Even though actor/target masks prevented control, the model could still read allied ground army as part of friendly/owned composition and then over-complement with air or under-build gateways/ground production.

v110 changes ONLY the observation projection:
1) Actual own units -> SELF.
2) Actual enemies -> OTHER/enemy.
3) Map neutrals -> NEUTRAL.
4) Every actual ally -> NEUTRAL/non-owned by default.
5) If an allied combat/support row is within 512 pixels of ANY currently visible enemy row in the SAME observation, only that ally row is temporarily exposed as SELF context for that inference.
6) Ally actor and target masks remain zero in all cases.

WHY THIS SEPARATES MACRO FROM COMBAT BETTER
- An allied army sitting at home / moving around / massing is not permanently counted as owned composition.
- Gateway/ground-vs-air composition reasoning therefore sees primarily Pluto's own army outside combat.
- During a visible local engagement, nearby allied combat force is exposed as friendly context so Pluto can take that force into account for the immediate fight.
- The bridge still does not decide attack/defend/retreat. Original Pluto decides all actions.

IMPORTANT LIMITATION
- Official Pluto has only three learned owner semantics. This is not a true fourth native ALLY representation.
- During an active engagement, exposed ally rows still use SELF semantic for that inference, so some temporary macro leakage is possible while fighting.
- v110 intentionally minimizes that exposure window instead of training or modifying the model.

EXPECTED LOG MARKERS
PLUTOTEAMRUNTIME_V110_RESIDENT=LOADED
V110_STOCK_ENGINE=OFFICIAL_3WAY_GATE_VERIFIED offset=59203 value=3
V110_STOCK_WEIGHTS=OWNER_EMB_3X256_VERIFIED
TEAM_RUNTIME_ALLY_ROLE_POLICY=ALL_ALLY_NONOWNED_BY_DEFAULT_COMBAT_FORCE_TO_SELF_ONLY_NEAR_VISIBLE_ENEMY
V110_ALLY_CONTEXT_SAMPLE ... combat_capable=... near_visible_enemy=... model_owner=...
V110_SHM_OWNER_REWRITE=PASS ... enemy_anchors=... ally_combat_exposed=... ally_combat_neutral=... ally_noncombat_neutral=...
V109_PREF_LEARN ...
V109_EARLY_ARMY_BIAS=APPLIED ...
V109_PREF_SUMMARY ...
TEAM_TRAINING_RECORDER=CONFIRMED_DISABLED_V110

WHAT TO WATCH IN GAME
1) Before contact: allied ground army should NOT push Pluto toward excessive air composition merely by existing.
2) Macro: resources should be spent more normally; gateway/production scaling should resemble Pluto's own needs more closely.
3) During combat: V110 log should show ally_combat_exposed > 0 when allies are near visible enemies.
4) Outside combat: ally_combat_exposed should return to 0 while ally_combat_neutral remains > 0.
5) v109 early-army preference markers should still appear exactly as before when it self-calibrates.

After the game, send plutoteam-x86-v110.log. PTRJ is not recorded.
