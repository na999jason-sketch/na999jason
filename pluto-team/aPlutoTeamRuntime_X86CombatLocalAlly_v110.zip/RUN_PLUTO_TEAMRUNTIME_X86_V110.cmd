@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v110-launch.log"
>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V110_LAUNCHER=START

echo === aPlutoTeamRuntime v110 - Combat-Local Ally Context + v109 Early Army Preference ===

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV110.dll" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing %%~F
  pause
  exit /b 1
)
if not exist "%ROOT%\pluto\pluto_infer.exe" (
  echo [FAIL] missing pluto\pluto_infer.exe
  pause
  exit /b 2
)
if not exist "%ROOT%\pluto\pluto_weights.bin" (
  echo [FAIL] missing pluto\pluto_weights.bin
  pause
  exit /b 3
)

taskkill /IM pluto_infer.exe /F >nul 2>nul

REM Keep exactly the same official stock Pluto model contract as v108.
if exist "%ROOT%\pluto\pluto_infer.official.exe" if exist "%ROOT%\pluto\pluto_weights.official.bin" (
  copy /Y "%ROOT%\pluto\pluto_infer.official.exe" "%ROOT%\pluto\pluto_infer.exe" >nul
  copy /Y "%ROOT%\pluto\pluto_weights.official.bin" "%ROOT%\pluto\pluto_weights.bin" >nul
  echo V110_STOCK_RESTORE=OFFICIAL_BACKUPS_APPLIED>>"%LAUNCHLOG%"
) else (
  echo V110_STOCK_RESTORE=NO_BACKUPS_USING_ACTIVE_FILES_RUNTIME_WILL_VERIFY_STOCK3>>"%LAUNCHLOG%"
)

del /q "%ROOT%\plutoteam-x86-v110.log" 2>nul

echo.
echo [v110] v109 early-army preference is preserved unchanged.
echo [v110] Allied army is non-owned by default and contributes SELF combat context only near visible enemies.
echo [v110] Press a key only after the game is loaded.
pause >nul
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV110.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
  echo [FAIL] injection failed
  pause
  exit /b %RC%
)
echo [PASS] v110 injected. Check plutoteam-x86-v110.log after the game.
pause
