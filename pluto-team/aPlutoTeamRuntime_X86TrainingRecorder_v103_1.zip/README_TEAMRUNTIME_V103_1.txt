aPlutoTeamRuntime v103.1 x86 — Request-Sequence Guard Fix
=========================================================

WHY v103.1
----------
The first v103 live run loaded correctly, verified the 4-way engine/weights,
started the recorder, and reached the first original Pluto onFrame. It then
logged TEAM4_SHM_OWNER_REWRITE=FAIL_CLOSED before any rewritten request.

v103.1 adds protocol-aware SetEvent handling:
- reads SHM req_seq (+0x40) and resp_seq (+0x80);
- rewrites only a NEW request sequence;
- ignores wake-only SetEvent when req_seq == resp_seq;
- ignores duplicate SetEvent for a request already rewritten;
- never rewrites the same payload twice (important because neutral 2 -> 3);
- logs every rewrite precondition failure with the exact reason;
- wraps the rewrite in SEH so an access fault is recorded fail-closed.

No strategy or replacement action is added. Original Pluto still observes,
infers, decides and emits commands.

EXPECTED EARLY LOG
------------------
TEAM4_REQSEQ_GUARD=WAKE_NO_NEW_REQUEST ...   (allowed)
or
TEAM4_REQSEQ_GUARD=NEW_REQUEST_REWRITTEN ...
TEAM4_SHM_OWNER_REWRITE=PASS ...
TEAM_TRAINING_RECORDER=STEP_PASS ...

If a real new request cannot be rewritten, the log now identifies exactly:
NO_VIEW / RELATIONS_NOT_READY / SELF_INVALID / BAD_MAGIC / BAD_N /
PAYLOAD_NOT_READABLE / INVALID_OLD_OWNER / SEH code.

Trajectory format remains PTRJ103 and is compatible with trajectory_v103.py.
