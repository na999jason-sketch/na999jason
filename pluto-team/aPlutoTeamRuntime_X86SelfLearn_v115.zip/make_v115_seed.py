from pathlib import Path
import argparse, math, struct, sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent/'v114src'))
try:
    from trajectory_v114 import iter_file, RESP
except Exception:
    # packaged beside trajectory_v114.py
    from trajectory_v114 import iter_file, RESP
F=16; A=20
FMT='<8sIIIIIQQQ' + 'I'*A + 'f'*(A*F)
SIZE=struct.calcsize(FMT)
def clamp(x,a,b): return a if x<a else b if x>b else x
def dot(w,x): return sum(a*b for a,b in zip(w,x))
def features(step,prev):
    sc,ac,ec,nc=step['counts']; fl=step['flags']; n=max(1,sc+ac+ec+nc)
    anchor=sum(1 for q in fl if q&(1<<6)); asset=sum(1 for q in fl if q&(1<<3)); support=sum(1 for q in fl if q&(1<<4))
    ally_self=sum(1 for q in fl if (q&1) and (q&(1<<5))); ally_combat=sum(1 for q in fl if (q&1) and (q&(1<<1)))
    return [1.0,clamp(step['frame']/20000.0,0,2),sc/100.0,ac/100.0,ec/100.0,nc/200.0,
            clamp(ec/(sc+1.0),0,3)/3.0,clamp(ac/(sc+1.0),0,3)/3.0,clamp(anchor/12.0,0,1),clamp(asset/6.0,0,1),clamp(support/16.0,0,1),
            clamp(ally_self/20.0,0,1),clamp(ally_combat/30.0,0,1),clamp(ac/n,0,1),clamp(prev,-1,1),clamp((prev+1)/2,0,1)]
def action_mask(step):
    n=step['n']; off=0x30+n*48+n*436+n+n
    return step['payload'][off:off+20]
def train_one(path):
    rows=[]; end=None; prev=0.0
    for kind,meta,o in iter_file(Path(path)):
        if kind=='end': end=o; continue
        a,arg,pos,unit,win,lp=RESP.unpack(o['response'])
        x=features(o,prev); prev=float(win)
        fl=o['flags']; distress=any((q&(1<<6)) or (q&(1<<3)) or (q&(1<<4)) for q in fl)
        rows.append((x,bytes(action_mask(o)),int(a),float(win),distress))
    if end is None: raise SystemExit('missing END')
    weights=[[0.0]*F for _ in range(A)]; seen=[0]*A
    lr=0.0008; R=1.0 if end['won'] else -1.0; ds=0; used=0; advsum=0.0
    for x,allowed,a,pv,distress in rows:
        if not distress or not (0<=a<A): continue
        ds+=1; adv=clamp(R-pv,-2,2); advsum+=adv
        ids=[k for k in range(A) if allowed[k]]
        if len(ids)<2 or not allowed[a]: continue
        scores=[dot(weights[k],x) for k in range(A)]
        mx=max(scores[k] for k in ids); ex={k:math.exp(clamp(scores[k]-mx,-30,0)) for k in ids}; den=sum(ex.values()); pi={k:ex[k]/den for k in ids}
        seen[a]+=1
        for k in ids:
            grad=adv*((1.0 if k==a else 0.0)-pi[k])
            for j in range(F):
                weights[k][j]=clamp(weights[k][j]+lr*(grad*x[j]-0.00001*weights[k][j]),-1.5,1.5)
        used+=1
    vals=[b'PLR115\0\0',1,SIZE,1,1 if end['won'] else 0,0 if end['won'] else 1,len(rows),ds,0,*seen,*[weights[a][j] for a in range(A) for j in range(F)]]
    return struct.pack(FMT,*vals),dict(games=1,wins=int(end['won']),losses=int(not end['won']),steps=len(rows),distress=ds,used=used,mean_adv=advsum/max(1,ds),seen=seen,maxabs=max(abs(w) for r in weights for w in r))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('ptrj');ap.add_argument('out');a=ap.parse_args();raw,s=train_one(a.ptrj);Path(a.out).write_bytes(raw);print('V115_SEED_CREATED',s,'size',len(raw))
if __name__=='__main__':main()
