@echo off
cd /d "%~dp0"
if exist "pluto-v115-residual.bin" (
  python inspect_v115_residual.py "pluto-v115-residual.bin"
) else (
  echo No persisted model yet. Showing packaged seed.
  python inspect_v115_residual.py "pluto-v115-seed.bin"
)
pause
