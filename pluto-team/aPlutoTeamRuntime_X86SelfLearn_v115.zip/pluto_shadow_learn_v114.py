from __future__ import annotations
import argparse, glob, json, math, os, random, struct, hashlib
from pathlib import Path
from trajectory_v114 import iter_file, RESP
F=16; A=20

def clamp(x,a,b): return a if x<a else b if x>b else x
def sig(x):
    x=clamp(x,-30.0,30.0); return 1.0/(1.0+math.exp(-x))
def dot(w,x): return sum(a*b for a,b in zip(w,x))
def softmax(z):
    m=max(z); e=[math.exp(clamp(v-m,-50,0)) for v in z]; s=sum(e); return [q/s for q in e]
def features(step, win_value):
    sc,ac,ec,nc=step['counts']; fl=step['flags']; n=max(1,step['n'])
    anchor=sum(1 for q in fl if q&(1<<6)); asset=sum(1 for q in fl if q&(1<<3)); support=sum(1 for q in fl if q&(1<<4));
    ally_self=sum(1 for q in fl if (q&1) and (q&(1<<5))); ally_combat=sum(1 for q in fl if (q&1) and (q&(1<<1)))
    return [1.0, clamp(step['frame']/20000.0,0,2), sc/100.0, ac/100.0, ec/100.0, nc/200.0,
            clamp(ec/(sc+1.0),0,3)/3.0, clamp(ac/(sc+1.0),0,3)/3.0,
            clamp(anchor/12.0,0,1), clamp(asset/6.0,0,1), clamp(support/16.0,0,1),
            clamp(ally_self/20.0,0,1), clamp(ally_combat/30.0,0,1), clamp(ac/n,0,1),
            clamp(win_value,-1,1), clamp((win_value+1.0)/2.0,0,1)]
def load_game(path):
    rows=[]; terminal=None
    for kind,meta,o in iter_file(Path(path)):
        if kind=='end': terminal=o; continue
        a,arg,pos,unit,win,lp=RESP.unpack(o['response'])
        if 0<=a<A: rows.append({'x':features(o,float(win)),'a':int(a),'pluto_v':float(win),'lp':float(lp),'distress':any(q&(1<<6) for q in o['flags']),'frame':o['frame']})
    if terminal is None: raise ValueError(f'{path}: missing END')
    return {'path':str(path),'won':1 if terminal['won'] else 0,'rows':rows,'final_frame':terminal['final_frame']}
def metrics(games,vw,pw):
    nv=0; brier=0.0; pluto_brier=0.0; n=0; pol_ll=0.0; distress_n=0; distress_adv=0.0
    for g in games:
        y=g['won']
        for r in g['rows']:
            p=sig(dot(vw,r['x'])); brier+=(p-y)**2; pluto=((r['pluto_v']+1)/2); pluto_brier+=(pluto-y)**2; nv+=1
            pi=softmax([dot(w,r['x']) for w in pw]); pol_ll += -math.log(max(pi[r['a']],1e-12)); n+=1
            if r['distress']:
                distress_n+=1; distress_adv += (1 if y else -1)-r['pluto_v']
    d=max(1,nv)
    return {'samples':nv,'value_brier':brier/d,'pluto_value_brier':pluto_brier/d,'policy_nll':pol_ll/max(1,n),'distress_samples':distress_n,'distress_mean_mc_advantage':distress_adv/max(1,distress_n)}
def train(games,epochs=24,vlr=0.08,plr=0.025,l2=1e-4,seed=114):
    vw=[0.0]*F; pw=[[0.0]*F for _ in range(A)]; rnd=random.Random(seed)
    flat=[(g,r) for g in games for r in g['rows']]
    history=[]
    for ep in range(epochs):
        rnd.shuffle(flat)
        for g,r in flat:
            x=r['x']; y=float(g['won']); pv=sig(dot(vw,x)); err=y-pv
            for j in range(F): vw[j]+=vlr*(err*x[j]-l2*vw[j])
            z=[dot(w,x) for w in pw]; pi=softmax(z); R=1.0 if g['won'] else -1.0; adv=clamp(R-r['pluto_v'],-2,2)
            # Conservative shadow REINFORCE: only learns a residual preference; it is not applied live in v114.
            for k in range(A):
                grad=adv*((1.0 if k==r['a'] else 0.0)-pi[k])
                for j in range(F): pw[k][j]+=plr*(grad*x[j]-l2*pw[k][j])
        m=metrics(games,vw,pw); m['epoch']=ep+1; history.append(m)
    return vw,pw,history
def heldout(games):
    if len(games)<4:return None
    trainset=games[:-1]; test=[games[-1]]; vw,pw,h=train(trainset,epochs=24); return {'train_games':len(trainset),'test_file':test[0]['path'],'train_final':h[-1],'test':metrics(test,vw,pw)}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('files',nargs='*'); ap.add_argument('--glob'); ap.add_argument('--out',default='pluto-v114-learning'); ap.add_argument('--epochs',type=int,default=24); a=ap.parse_args()
    fs=list(a.files)
    if a.glob: fs+=glob.glob(a.glob)
    fs=sorted(set(fs))
    if not fs: raise SystemExit('no PTRJ114 files')
    games=[load_game(x) for x in fs]; out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    vw,pw,h=train(games,epochs=a.epochs); m=metrics(games,vw,pw); ho=heldout(games)
    dist=[g for g in games if any(r['distress'] for r in g['rows'])]
    report={'format':'pluto-v114-shadow-selflearn-v1','mode':'SHADOW_ONLY_NOT_APPLIED_TO_LIVE_PLUTO','games':len(games),'wins':sum(g['won'] for g in games),'losses':len(games)-sum(g['won'] for g in games),'samples':sum(len(g['rows']) for g in games),'distress_games':len(dist),'final_metrics':m,'heldout_latest_game':ho,
            'feature_names':['bias','frame','self_count','ally_count','enemy_count','neutral_count','enemy_self_ratio','ally_self_ratio','distress_anchor','distress_asset','distress_support','ally_model_self','ally_combat_count','true_ally_fraction','pluto_win_value','pluto_pwin'],
            'value_weights':vw,'policy_weights':pw,'history':h,
            'note':'This learner updates from actual terminal win/loss and recorded Pluto actions. v114 does not feed it back into live action selection; promotion requires held-out/live A-B evidence.'}
    (out/'learning_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    # Compact human-readable progress.
    lines=[f'V114_SELFLEARN games={report["games"]} wins={report["wins"]} losses={report["losses"]} samples={report["samples"]}',
           f'VALUE_BRIER shadow={m["value_brier"]:.6f} original_pluto={m["pluto_value_brier"]:.6f}',
           f'POLICY_NLL shadow={m["policy_nll"]:.6f}',f'DISTRESS games={report["distress_games"]} samples={m["distress_samples"]} mean_mc_advantage={m["distress_mean_mc_advantage"]:.6f}']
    if ho: lines.append(f'HELDOUT latest value_brier={ho["test"]["value_brier"]:.6f} original_pluto={ho["test"]["pluto_value_brier"]:.6f} policy_nll={ho["test"]["policy_nll"]:.6f}')
    lines.append('V114_SHADOW_LEARNING=PASS_LIVE_POLICY_UNCHANGED')
    (out/'learning_summary.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8'); print('\n'.join(lines))
if __name__=='__main__': main()
