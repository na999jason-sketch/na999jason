from pathlib import Path
import argparse, math, struct
F=16;A=20
FMT='<8sIIIIIQQQ'+'I'*A+'f'*(A*F); SIZE=struct.calcsize(FMT)
def load(p):
    b=Path(p).read_bytes()
    if len(b)!=SIZE: raise SystemExit(f'bad size {len(b)} expected {SIZE}')
    v=struct.unpack(FMT,b); magic,ver,hb,g,w,l,ts,ds,ap=v[:9]; seen=list(v[9:9+A]); flat=v[9+A:]
    if not magic.startswith(b'PLR115') or ver!=1 or hb!=SIZE: raise SystemExit('bad header')
    weights=[list(flat[a*F:(a+1)*F]) for a in range(A)]
    l2=math.sqrt(sum(x*x for r in weights for x in r)); mx=max(abs(x) for r in weights for x in r)
    return dict(games=g,wins=w,losses=l,total_steps=ts,distress_steps=ds,applied_total=ap,seen=seen,l2=l2,maxabs=mx)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('file',nargs='?',default='pluto-v115-residual.bin');a=ap.parse_args();m=load(a.file)
    gate=m['games']>=2 and m['wins']>0 and m['losses']>0 and m['distress_steps']>=512
    print(f"V115_MODEL games={m['games']} wins={m['wins']} losses={m['losses']} total_steps={m['total_steps']} distress_steps={m['distress_steps']} applied_total={m['applied_total']}")
    print(f"V115_GATE={'READY' if gate else 'WAITING'} weight_l2={m['l2']:.6f} max_abs={m['maxabs']:.6f}")
    print('V115_ACTION_SEEN '+','.join(f'{i}:{n}' for i,n in enumerate(m['seen'])))
if __name__=='__main__':main()
