@echo off
cd /d "%~dp0"
del /q "pluto-v115-residual.bin" 2>nul
del /q "pluto-v115-learning-state.txt" 2>nul
echo Reset complete. Next launch will load pluto-v115-seed.bin (the v114 g1 loss seed).
pause
