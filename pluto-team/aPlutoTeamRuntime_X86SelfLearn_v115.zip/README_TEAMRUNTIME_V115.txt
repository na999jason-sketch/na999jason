aPlutoTeamRuntime v115 - Embedded Persistent Self-Learning Residual

What changed from v114
- v114 PTRJ114 recording remains enabled.
- Learning is now embedded in the resident DLL. You do NOT need to run RUN_SHADOW_SELFLEARN_V114.cmd for v115 to learn.
- At match end the DLL updates a small persistent policy residual from the real terminal result (win=+1, loss=-1) and saves it to pluto-v115-residual.bin.
- The next match loads/uses that learned residual automatically.

Important: what is and is not learning
- Official pluto_weights.bin is still the base model and is NOT overwritten.
- v115 learns a 20-action x 16-context residual specialized to ALLY DISTRESS states.
- It uses REINFORCE-style terminal advantage R - PlutoValue.
- It can affect live play by temporarily suppressing ONE learned-poor top-level action, allowing Pluto to choose another valid action.
- This is real cross-game feedback, but it is not yet full 315M-parameter Pluto weight fine-tuning.

Safety / promotion gate
- The supplied pluto-v115-seed.bin contains the user's v114 g1 loss: 1 game, 0 wins, 1 loss, 867 distress samples.
- A loss-only model is NEVER allowed to change live actions.
- Live residual requires: games >= 2, wins >= 1, losses >= 1, distress samples >= 512.
- Even when ready, it only acts in distress states BEFORE frame 7500, on 1/4 eligible requests, max 48 times per match.
- Frame >= 7500: both v112 opening bias and v115 learned residual are OFF; original Pluto strategy is 100% (v113 observation compatibility remains).
- It masks at most one sufficiently-seen, clearly negative residual action when score spread is large enough.
- Actor/target ally masks remain blocked exactly as before. v113 ally observation is unchanged.

Files written automatically
- plutoteam-x86-v115.log                     detailed runtime/learning log
- plutoteam-v115-selflearn-g*.ptrj           full PTRJ114 trajectories
- pluto-v115-residual.bin                    persistent learned residual
- pluto-v115-learning-state.txt              compact human-readable learning state

Useful log markers
- V115_SELFLEARN_MODEL=LOADED
- V115_LIVE_LEARNING_GATE=
- V115_SELFLEARN_TRAIN
- V115_RESIDUAL_APPLIED
- V115_RESIDUAL_SUMMARY

Interpretation
- First v115 game: learns automatically at the end. If it is a win, the model now has one seeded loss + one win and the live gate becomes READY for the following game.
- If it is another loss, learning updates, but live behavior stays unchanged until at least one win exists.
- Therefore improvement is learned from contrast, not from blindly copying one bad game.

Reset
- Delete pluto-v115-residual.bin to return to the supplied g1 seed on next launch.
- Delete both pluto-v115-residual.bin and pluto-v115-seed.bin to start completely fresh.
