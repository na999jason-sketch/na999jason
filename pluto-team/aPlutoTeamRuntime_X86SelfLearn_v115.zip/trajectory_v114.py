from __future__ import annotations
import argparse, json, math, struct
from pathlib import Path
FILE_HDR=struct.Struct("<8s6I")
STEP_HDR=struct.Struct("<4s17I")
END_HDR=struct.Struct("<4s5IQ")
RESP=struct.Struct("<qqqqff")
REQ_HDR=struct.Struct("<iiiIqqqq")

def request_size(n:int)->int:
    return 0x30+n*48+n*436+n+n+20+233+292*4+128*128*2+128*128+32

def iter_file(path:Path):
    with path.open('rb') as f:
        raw=f.read(FILE_HDR.size)
        if len(raw)!=FILE_HDR.size: raise ValueError('short header')
        magic,ver,gen,self_id,ally_mask,hbytes,res=FILE_HDR.unpack(raw)
        if not magic.startswith(b'PTRJ114') or ver!=1 or hbytes!=32: raise ValueError(f'bad header {magic} v{ver} h={hbytes}')
        meta={'file':path.name,'generation':gen,'self':self_id,'ally_mask':ally_mask}
        while True:
            tag=f.read(4)
            if not tag: return
            f.seek(-4,1)
            if tag==b'STEP':
                h=f.read(STEP_HDR.size); vals=STEP_HDR.unpack(h)
                (_,hb,pb,rb,relb,flagb,req,resp,frame,n,sc,ac,ec,nc,fb,un,amb,blocked)=vals
                if hb!=72 or rb!=40 or relb!=n or flagb!=n or pb!=request_size(n): raise ValueError('bad step sizes')
                payload=f.read(pb); response=f.read(rb); rel=f.read(relb); flags=f.read(flagb)
                if min(len(payload),len(response),len(rel),len(flags))==0: raise ValueError('truncated step')
                yield 'step',meta,{'req_seq':req,'resp_seq':resp,'frame':frame,'n':n,'counts':(sc,ac,ec,nc),'fallback':fb,'unmatched':un,'ambiguous':amb,'blocked':blocked,'payload':payload,'response':response,'relation':rel,'flags':flags}
            elif tag==b'END!':
                raw=f.read(END_HDR.size); _,hb,gen,won,frame,steps,bytes_written=END_HDR.unpack(raw)
                yield 'end',meta,{'generation':gen,'won':bool(won),'final_frame':frame,'steps':steps,'bytes':bytes_written}; return
            else: raise ValueError(f'unknown tag {tag!r}')

def summarize(path:Path):
    steps=distress=distress_support=distress_assets=0; terminal=None; actions={}; minv=1e9;maxv=-1e9
    for kind,meta,o in iter_file(path):
        if kind=='end': terminal=o; continue
        steps+=1; a,arg,pos,unit,win,lp=RESP.unpack(o['response']); actions[str(a)]=actions.get(str(a),0)+1; minv=min(minv,win);maxv=max(maxv,win)
        fl=o['flags']; da=sum(1 for x in fl if x&(1<<6)); ds=sum(1 for x in fl if x&(1<<4)); dax=sum(1 for x in fl if x&(1<<3))
        if da: distress+=1
        distress_support+=ds; distress_assets+=dax
    return {'format':'PTRJ114','file':path.name,'steps':steps,'distress_steps':distress,'distress_support_rows':distress_support,'distress_asset_rows':distress_assets,'win_value_min':None if steps==0 else minv,'win_value_max':None if steps==0 else maxv,'actions':actions,'terminal':terminal}

def synth(path:Path):
    n=3; p=bytearray(request_size(n)); struct.pack_into('<iiiIqqqq',p,0,n,128,128,0,0,0,0,0)
    rel=bytes([0,1,2]); flags=bytes([1<<5,1|(1<<6)|(1<<3),0]); resp=RESP.pack(3,0,0,-1,0.2,-1.0)
    fh=FILE_HDR.pack(b'PTRJ114\0',1,1,2,0x12,32,0)
    sh=STEP_HDR.pack(b'STEP',72,len(p),40,n,n,1,1,100,n,1,1,1,0,0,0,0,0)
    eh=END_HDR.pack(b'END!',32,1,1,200,1,len(fh)+len(sh)+len(p)+40+2*n)
    path.write_bytes(fh+sh+p+resp+rel+flags+eh)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('files',nargs='*'); ap.add_argument('--selftest',action='store_true'); ap.add_argument('--json-out'); a=ap.parse_args()
    if a.selftest:
        p=Path('ptrj114-selftest.ptrj'); synth(p); r=summarize(p); p.unlink(); assert r['steps']==1 and r['distress_steps']==1 and r['terminal']['won']; print('PTRJ114_PARSER_SELFTEST=PASS'); return
    if not a.files: raise SystemExit('give .ptrj files')
    r=[summarize(Path(x)) for x in a.files]; txt=json.dumps(r,indent=2); print(txt)
    if a.json_out: Path(a.json_out).write_text(txt,encoding='utf-8')
if __name__=='__main__': main()
