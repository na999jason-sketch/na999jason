@echo off
setlocal EnableExtensions
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$files=@(); $files += Get-ChildItem -File 'plutoteam-v115-selflearn-g*.ptrj' -ErrorAction SilentlyContinue; if(Test-Path 'plutoteam-x86-v115.log'){$files += Get-Item 'plutoteam-x86-v115.log'}; if(!$files){Write-Host '[FAIL] no v115 self-learning data'; exit 1}; Compress-Archive -Force -Path ($files.FullName) -DestinationPath 'plutoteam-v115-selflearn-data.zip'"
if errorlevel 1 (pause & exit /b 1)
echo [PASS] plutoteam-v115-selflearn-data.zip created.
pause
