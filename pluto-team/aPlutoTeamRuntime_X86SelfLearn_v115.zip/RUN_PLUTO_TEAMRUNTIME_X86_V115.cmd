@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v115-launch.log"
>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V115_LAUNCHER=START

echo === aPlutoTeamRuntime v115 - Embedded Persistent Self-Learning Residual ===

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV115.dll" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing %%~F
  pause
  exit /b 1
)
if not exist "%ROOT%\pluto\pluto_infer.exe" (
  echo [FAIL] missing pluto\pluto_infer.exe
  pause
  exit /b 2
)
if not exist "%ROOT%\pluto\pluto_weights.bin" (
  echo [FAIL] missing pluto\pluto_weights.bin
  pause
  exit /b 3
)

taskkill /IM pluto_infer.exe /F >nul 2>nul
if exist "%ROOT%\pluto\pluto_infer.official.exe" if exist "%ROOT%\pluto\pluto_weights.official.bin" (
  copy /Y "%ROOT%\pluto\pluto_infer.official.exe" "%ROOT%\pluto\pluto_infer.exe" >nul
  copy /Y "%ROOT%\pluto\pluto_weights.official.bin" "%ROOT%\pluto\pluto_weights.bin" >nul
  echo V115_STOCK_RESTORE=OFFICIAL_BACKUPS_APPLIED>>"%LAUNCHLOG%"
) else (
  echo V115_STOCK_RESTORE=NO_BACKUPS_USING_ACTIVE_FILES_RUNTIME_WILL_VERIFY_STOCK3>>"%LAUNCHLOG%"
)

del /q "%ROOT%\plutoteam-x86-v115.log" 2>nul

echo.
echo [v115] Official Pluto remains the base policy. PTRJ114 recording remains enabled.
echo [v115] Every finished game updates pluto-v115-residual.bin automatically.
echo [v115] The supplied g1 loss is already seeded, but ONE LOSS ALONE cannot alter live actions.
echo [v115] Live residual starts only after at least one WIN + one LOSS exist and 512 distress samples are learned.
echo [v115] Residual is DISTRESS-ONLY, cadence 1/4, max 48 interventions per match, one top-level action masked at most per intervention.
echo [v115] Frame 7500+ disables BOTH opening pressure and learned residual: original Pluto strategy 100%%.
echo [v115] Press a key only after the game is loaded.
pause >nul
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV115.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
  echo [FAIL] injection failed
  pause
  exit /b %RC%
)
echo [PASS] v115 injected. After each game check plutoteam-x86-v115.log and pluto-v115-learning-state.txt.
pause
