from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", required=True)
    ap.add_argument("--official-json", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    off = json.load(open(args.official_json, encoding="utf-8"))
    i8 = off["int8"]
    fp = off["fp32"]

    report = {
        "format": "pluto-team-phase2b-v1.3-fp32-isolation",
        "official_int8": i8,
        "official_fp32": fp,
        "pytorch_fp32_reconstruction": None,
        "comparison": {},
        "result_class": None,
    }

    if i8["status"] == "ok" and i8.get("response"):
        report["comparison"]["phase2a_int8_action_match"] = (
            i8["response"]["action"] == off["known_phase2a_int8_action"]
        )
        report["comparison"]["phase2a_int8_win_abs_error"] = abs(
            i8["response"]["win"] - off["known_phase2a_int8_win"]
        )

    if fp["status"] == "ok" and fp.get("response"):
        # Only pay the cost of a PyTorch forward if official FP32 actually finished.
        subprocess.run([
            sys.executable, "run_phase2b_v1.py",
            "--weights", args.weights,
            "--out", str(out / "pytorch"),
            "--coord-mode", "center01",
        ], check=True)

        py = json.load(open(out / "pytorch" / "phase2b_v1_report.json", encoding="utf-8"))
        pa = py["pytorch"]["action"]
        pw = py["pytorch"]["win"]
        report["pytorch_fp32_reconstruction"] = {"action": pa, "win": pw}

        if i8["status"] == "ok" and i8.get("response"):
            report["comparison"]["official_int8_vs_fp32_action_same"] = (
                i8["response"]["action"] == fp["response"]["action"]
            )
            report["comparison"]["official_int8_vs_fp32_win_abs_error"] = abs(
                i8["response"]["win"] - fp["response"]["win"]
            )

        report["comparison"]["official_fp32_vs_pytorch_action_same"] = (
            fp["response"]["action"] == pa
        )
        report["comparison"]["official_fp32_vs_pytorch_win_abs_error"] = abs(
            fp["response"]["win"] - pw
        )

        if (
            report["comparison"]["official_fp32_vs_pytorch_action_same"]
            and report["comparison"]["official_fp32_vs_pytorch_win_abs_error"] < 1e-3
        ):
            report["result_class"] = "FP32_PARITY_CLOSE_QUANTIZATION_NEXT"
        else:
            report["result_class"] = "FP32_PARITY_MISMATCH_STRUCTURE_ORDER_NEXT"
    elif fp["status"] == "timeout":
        report["result_class"] = "OFFICIAL_FP32_TIMEOUT_BOUNDED"
    else:
        report["result_class"] = "OFFICIAL_FP32_ERROR_BOUNDED"

    (out / "phase2b_v1_3_comparison.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    with (out / "phase2b_v1_3_summary.txt").open("w", encoding="utf-8") as f:
        f.write("Pluto-Team Phase2B v1.3 bounded FP32 isolation\n")
        f.write(f"int8_status={i8['status']} elapsed_s={i8['elapsed_s']:.3f}\n")
        f.write(f"fp32_status={fp['status']} elapsed_s={fp['elapsed_s']:.3f}\n")
        if i8.get("response"):
            f.write(f"official_int8={i8['response']}\n")
        if fp.get("response"):
            f.write(f"official_fp32={fp['response']}\n")
        if report["pytorch_fp32_reconstruction"]:
            f.write(f"pytorch_fp32={report['pytorch_fp32_reconstruction']}\n")
        for k,v in report["comparison"].items():
            f.write(f"{k}={v}\n")
        f.write(f"result_class={report['result_class']}\n")
        f.write("PHASE2B_V1_2_BOUNDED_ISOLATION=PASS\n")

    print((out / "phase2b_v1_3_summary.txt").read_text(encoding="utf-8"))

if __name__ == "__main__":
    main()
