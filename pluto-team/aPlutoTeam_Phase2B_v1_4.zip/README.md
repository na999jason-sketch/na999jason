# aPlutoTeam Phase2B v1.4 — Structural Isolation Grid

v1.3 established:
- official int8mv is healthy and reproduces Phase2A exactly.
- official all-FP32 `pk` is healthy.
- official FP32 keeps action=12, while our PyTorch FP32 gives action=16.
- therefore quantisation is not the only discrepancy; a structural/order/input convention mismatch remains.

v1.4 isolates two high-value uncertainties without touching training:
1. spatial coordinate plane convention: center01 / edge01 / center_m11 / edge_m11
2. first-step slow-cache state:
   - none (no first tick)
   - append layer input
   - append post-attention
   - append post-FF (current implementation)

This makes a 4 x 4 = 16 variant grid and ranks each variant against
the official FP32 action (12) and win value (-0.0043392688967).

If none matches action 12, the next diagnostic is activation-input dumping
(`BWRL_I8_DUMP`) to localize the first common-trunk/GRU divergence.

No model training occurs in this phase.
