from __future__ import annotations
import argparse, json, math, time
from pathlib import Path
import torch
from pluto_trunk import PlutoFirstStep, linear, rms, swiglu

OFFICIAL_FP32_ACTION = 12
OFFICIAL_FP32_WIN = -0.004339268896728754

def make_other_center():
    n=2
    cat=torch.zeros((n,6),dtype=torch.long)
    cont=torch.zeros((n,109),dtype=torch.float32)
    cat[1]=torch.tensor([0,1,23,0,228,0])
    cont[1,0]=0.5
    cont[1,1]=0.5
    cont[1,2]=1.0
    cont[1,22]=1.0
    return {
        "cat":cat,
        "cont":cont,
        "global":torch.zeros(292,dtype=torch.float32),
        "bits":torch.zeros((128,128),dtype=torch.int64),
        "static":torch.zeros((128,128),dtype=torch.int64),
        "hist":torch.zeros(4,dtype=torch.long),
    }

def slow_tick_variant(m, h, cache, append_mode):
    w=m.w
    x=rms(h,w["gru.slow_enc.in_norm.weight"])
    x=linear(x,w["gru.slow_enc.in_proj.weight"])
    new=[]
    for i in range(4):
        a=rms(x,w[f"gru.slow_enc.layers.{i}.norm_input.weight"])
        old=cache[i]
        cn=rms(old[1:],w[f"gru.slow_enc.layers.{i}.norm_cache.weight"])
        kv_old=linear(cn,w[f"gru.slow_enc.layers.{i}.kv_cache.weight"])
        kv_new=linear(a,w[f"gru.slow_enc.layers.{i}.kv_input.weight"]).unsqueeze(0)
        K,V=torch.cat([kv_old,kv_new],dim=0).chunk(2,dim=-1)
        q=linear(a,w[f"gru.slow_enc.layers.{i}.q_proj.weight"])
        att=m.mha(q,K,V,8)
        x_att=x+linear(att,w[f"gru.slow_enc.layers.{i}.out_proj.weight"])
        ff_in=rms(x_att,w[f"gru.slow_enc.layers.{i}.ff_norm.weight"])
        x_ff=x_att+swiglu(
            ff_in,
            w[f"gru.slow_enc.layers.{i}.ff.gate_up.weight"],
            w[f"gru.slow_enc.layers.{i}.ff.down.weight"],
        )
        if append_mode=="input":
            appended=x
        elif append_mode=="attn":
            appended=x_att
        elif append_mode=="ff":
            appended=x_ff
        else:
            raise ValueError(append_mode)
        new.append(torch.cat([old[1:],appended.unsqueeze(0)],dim=0))
        x=x_ff
    return torch.stack(new,dim=0)

def one_variant(weights, coord_mode, cache_mode):
    m=PlutoFirstStep(weights,coord_mode)
    req=make_other_center()
    u0=m.encode_units(req["cat"],req["cont"])
    planes=m.assemble_planes(u0,req["cont"],req["bits"],req["static"])
    s64,s32,s8=m.spatial_encoder(planes)
    u1=m.inject_spatial(u0,s32,req["cont"])
    U=m.encoder(u1)
    xt=m.global_hist(req["global"],req["hist"])
    h0=m.w["gru.h0"].clone()
    c0=m.slow_init()

    if cache_mode=="none":
        cuse=c0
    else:
        cuse=slow_tick_variant(m,h0,c0,cache_mode)

    h1=m.gru_step(xt,h0,s8,U,cuse[3])
    logits=linear(h1,m.w["action_head.weight"])
    action=int(torch.argmax(logits).item())
    order=torch.argsort(logits,descending=True)
    rank12=int((order==OFFICIAL_FP32_ACTION).nonzero(as_tuple=False)[0,0].item())+1
    top5=[{"id":int(i),"logit":float(logits[i])} for i in order[:5]]
    win,_=m.win_value(cuse[3,-1])
    return {
        "coord_mode":coord_mode,
        "cache_mode":cache_mode,
        "action":action,
        "action_match":action==OFFICIAL_FP32_ACTION,
        "action12_rank":rank12,
        "action12_logit":float(logits[OFFICIAL_FP32_ACTION]),
        "top5":top5,
        "win":win,
        "win_abs_error":abs(win-OFFICIAL_FP32_WIN),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--weights",required=True)
    ap.add_argument("--out",required=True)
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    torch.set_grad_enabled(False)

    coords=["center01","edge01","center_m11","edge_m11"]
    caches=["none","input","attn","ff"]
    rows=[]
    t0=time.time()
    for c in coords:
        for cm in caches:
            r=one_variant(args.weights,c,cm)
            rows.append(r)
            print(
                f"VARIANT coord={c} cache={cm} action={r['action']} "
                f"rank12={r['action12_rank']} win={r['win']:.9f} "
                f"win_err={r['win_abs_error']:.9f}",
                flush=True
            )

    # Rank action-matching variants first, then official-action rank, then win error.
    ranked=sorted(rows,key=lambda r:(not r["action_match"],r["action12_rank"],r["win_abs_error"]))
    report={
        "format":"pluto-team-phase2b-v1.4-structural-grid",
        "official_fp32":{"action":OFFICIAL_FP32_ACTION,"win":OFFICIAL_FP32_WIN},
        "variants":rows,
        "ranked":ranked,
        "elapsed_s":time.time()-t0,
        "interpretation":{
            "coord_changes_action":"If coordinate variants materially change action/rank, pin coordinate table next.",
            "cache_changes_action":"If cache append variants materially change action/rank, resolve slow-cache append semantics next.",
            "no_variant_matches":"If none reaches action 12, mismatch is earlier/common trunk or GRU math; use activation-input dump next."
        }
    }
    (out/"phase2b_v1_4_structural_grid.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    with (out/"phase2b_v1_4_summary.txt").open("w",encoding="utf-8") as f:
        f.write("Pluto-Team Phase2B v1.4 structural isolation grid\n")
        f.write(f"official_fp32_action={OFFICIAL_FP32_ACTION} official_fp32_win={OFFICIAL_FP32_WIN:.12g}\n")
        for i,r in enumerate(ranked[:8],1):
            f.write(
                f"rank{i} coord={r['coord_mode']} cache={r['cache_mode']} "
                f"action={r['action']} match={r['action_match']} "
                f"action12_rank={r['action12_rank']} "
                f"win={r['win']:.12g} win_err={r['win_abs_error']:.12g}\n"
            )
        f.write("PHASE2B_V1_4_STRUCTURAL_GRID=PASS\n")
    print((out/"phase2b_v1_4_summary.txt").read_text())

if __name__=="__main__":
    main()
