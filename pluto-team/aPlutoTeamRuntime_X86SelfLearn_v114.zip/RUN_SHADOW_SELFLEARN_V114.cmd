@echo off
setlocal EnableExtensions
cd /d "%~dp0"
py -3 trajectory_v114.py --selftest || (echo [FAIL] Python 3 required & pause & exit /b 1)
py -3 pluto_shadow_learn_v114.py --glob "plutoteam-v114-selflearn-g*.ptrj" --out "pluto-v114-learning"
if errorlevel 1 (pause & exit /b 1)
type "pluto-v114-learning\learning_summary.txt"
echo.
echo Shadow learner updated. Live Pluto weights are NOT auto-promoted in v114.
pause
