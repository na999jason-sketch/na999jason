aPlutoTeamRuntime v114 - Self-Learning Phase 1 (PTRJ114 + Shadow Learner)

Live game policy
- EXACT v113 live policy: v112 opening pressure + v113 ally distress observation.
- No v114 learning output is applied to live actions yet.
- Frame >= 7500 opening bias remains OFF exactly as v113.
- Official Pluto model/weights remain active during collection.

What v114 adds
- PTRJ114 trajectory recorder after the first successful Pluto frame.
- Every recorded step stores the exact post-v113 model request Pluto saw, the official response (action/arg/pos/unit/win/logprob), terminal win/loss, and a sidecar with TRUE SCR relation plus context flags.
- True relation sidecar: 0=self, 1=ally, 2=enemy, 3=neutral.
- Context flag bits: b0 true ally; b1 combat-capable; b2 local-combat context; b3 distress strategic building; b4 distress support; b5 represented as SELF to Pluto; b6 distress anchor; b7 worker.

Shadow learning
- pluto_shadow_learn_v114.py learns from actual final win/loss using a value learner plus conservative contextual policy-gradient probe.
- It outputs learning_report.json and learning_summary.txt so we can watch whether distress/ally situations acquire useful reward signal.
- It is intentionally SHADOW ONLY. It does not replace Pluto or send commands.
- Promotion to a live learned Pluto will happen only after held-out/live A-B evidence shows improvement.

Workflow
1. Run games normally with v114. PTRJ files accumulate beside the runtime.
2. Run PACK_PLUTO_SELFLEARN_DATA_V114.cmd and upload the zip for analysis/training, or run RUN_SHADOW_SELFLEARN_V114.cmd if Python 3 is installed.
3. We compare learning curves, especially distress states, before changing ally observation or promoting learned parameters.
