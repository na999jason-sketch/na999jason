from __future__ import annotations

import argparse
import hashlib
import json
import os
import struct
import subprocess
import threading
import time
from pathlib import Path

import numpy as np
import torch

from pluto_trunk import PlutoFirstStep

RESP = struct.Struct('<qqqqff')
REQ_HDR = struct.Struct('<iiiIqqqq')


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def read_exact(pipe, n: int) -> bytes:
    out = bytearray()
    while len(out) < n:
        c = pipe.read(n - len(out))
        if not c:
            raise EOFError(f'expected {n} bytes, got {len(out)}')
        out += c
    return bytes(out)


def parse_response(raw: bytes) -> dict:
    a, arg, pos, unit, win, logprob = RESP.unpack(raw)
    return {
        'action': int(a), 'arg': int(arg), 'pos': int(pos), 'unit': int(unit),
        'win': float(win), 'logprob': float(logprob), 'hex': raw.hex(),
    }


def request_expected_size(n: int) -> int:
    return 0x30 + n*6*8 + n*109*4 + n + n + 20 + 233 + 292*4 + 128*128*2 + 128*128 + 4*8


def parse_request(raw: bytes) -> dict:
    if len(raw) < REQ_HDR.size:
        raise ValueError('short request')
    n, w, h, flags, f0, f1, f2, f3 = REQ_HDR.unpack_from(raw, 0)
    if not (1 <= n <= 1024):
        raise ValueError(f'bad N={n}')
    if (w, h) != (128, 128):
        raise ValueError(f'bad map size {(w,h)}')
    expected = request_expected_size(n)
    if len(raw) != expected:
        raise ValueError(f'bad request size {len(raw)} expected {expected}')

    off = 0x30
    cat = np.frombuffer(raw, dtype='<i8', count=n*6, offset=off).copy().reshape(n, 6)
    off += n*6*8
    cont = np.frombuffer(raw, dtype='<f4', count=n*109, offset=off).copy().reshape(n, 109)
    off += n*109*4
    actor = np.frombuffer(raw, dtype=np.uint8, count=n, offset=off).copy(); off += n
    target = np.frombuffer(raw, dtype=np.uint8, count=n, offset=off).copy(); off += n
    action_mask = np.frombuffer(raw, dtype=np.uint8, count=20, offset=off).copy(); off += 20
    arg_mask = np.frombuffer(raw, dtype=np.uint8, count=233, offset=off).copy(); off += 233
    glob = np.frombuffer(raw, dtype='<f4', count=292, offset=off).copy(); off += 292*4
    bits = np.frombuffer(raw, dtype='<u2', count=128*128, offset=off).copy().reshape(128,128); off += 128*128*2
    static = np.frombuffer(raw, dtype=np.uint8, count=128*128, offset=off).copy().reshape(128,128); off += 128*128
    hist = np.frombuffer(raw, dtype='<i8', count=4, offset=off).copy(); off += 4*8
    assert off == len(raw)

    owners = cat[:,1].astype(np.int64)
    if np.any((owners < 0) | (owners > 3)):
        bad = sorted(set(int(x) for x in owners if x < 0 or x > 3))
        raise ValueError(f'bad four-way owners: {bad}')

    return {
        'n': n, 'width': w, 'height': h, 'flags': flags, 'forced': [f0,f1,f2,f3],
        'cat_np': cat, 'cont_np': cont,
        'cat': torch.from_numpy(cat).long(),
        'cont': torch.from_numpy(cont).float(),
        'global': torch.from_numpy(glob).float(),
        'bits': torch.from_numpy(bits.astype(np.int64, copy=False)).long(),
        'static': torch.from_numpy(static.astype(np.int64, copy=False)).long(),
        'hist': torch.from_numpy(hist).long(),
        'actor_mask': actor, 'target_mask': target,
        'action_mask': action_mask, 'arg_mask': arg_mask,
        'owner_counts': {str(i): int((owners == i).sum()) for i in range(4)},
    }


def collapse_team4_request_to_official3(raw: bytes) -> bytes:
    req = parse_request(raw)
    out = bytearray(raw)
    n = req['n']
    cat_off = 0x30
    mapping = {0:0, 1:1, 2:1, 3:2}
    for r in range(n):
        owner_off = cat_off + r*6*8 + 8
        old = struct.unpack_from('<q', out, owner_off)[0]
        if old not in mapping:
            raise ValueError(f'row {r}: invalid owner {old}')
        struct.pack_into('<q', out, owner_off, mapping[old])
    return bytes(out)


def run_engine(exe: Path, weights: Path, request: bytes, stderr_path: Path, timeout_s: int = 45) -> dict:
    cmd = [str(exe), '--blob', str(weights), '--backend', 'int8mv', '--threads', '1', '--seed', '123456789', '--argmax', '--verbose']
    creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         creationflags=creationflags, bufsize=0)
    stderr_chunks = []

    def drain():
        while True:
            c = p.stderr.read(65536)
            if not c:
                break
            stderr_chunks.append(c)

    th = threading.Thread(target=drain, daemon=True)
    th.start()
    t0 = time.time()
    try:
        hs_raw = read_exact(p.stdout, 0x88)
        magic, ver, fps, max_units, model_step, label, build = struct.unpack('<4sIiiq48s64s', hs_raw)
        hs = {
            'magic': magic.rstrip(b'\0').decode(errors='replace'), 'version': int(ver),
            'frames_per_step': int(fps), 'max_units': int(max_units), 'model_step': int(model_step),
            'label': label.split(b'\0',1)[0].decode(errors='replace'),
            'build': build.split(b'\0',1)[0].decode(errors='replace'),
        }
        if hs['magic'] != 'PLO1' or hs['version'] != 3:
            raise RuntimeError(f'bad handshake {hs}')
        p.stdin.write(request); p.stdin.flush()
        raw_resp = read_exact(p.stdout, 0x28)
        p.stdin.close()
        try:
            rc = p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            p.kill(); rc = p.wait(timeout=10)
        th.join(timeout=10)
        stderr = b''.join(stderr_chunks).decode(errors='replace')
        stderr_path.write_text(stderr, encoding='utf-8')
        return {
            'command': cmd, 'returncode': int(rc), 'handshake': hs,
            'response': parse_response(raw_resp), 'elapsed_s': time.time()-t0,
        }
    finally:
        if p.poll() is None:
            p.kill(); p.wait(timeout=10)


def pytorch_forward(model: PlutoFirstStep, request: bytes) -> dict:
    req = parse_request(request)
    with torch.inference_mode():
        r = model.forward_first(req)
    logits = r['action_logits'].detach().float().cpu()
    order = torch.argsort(logits, descending=True)
    return {
        'action': int(r['action']), 'win': float(r['win']), 'win_no_tick': float(r['win_no_tick']),
        'top10': [{'id': int(i), 'logit': float(logits[i])} for i in order[:10]],
        'action_logits': logits,
        'stages': r['stages'],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--official-exe', required=True)
    ap.add_argument('--official-weights', required=True)
    ap.add_argument('--team4-exe', required=True)
    ap.add_argument('--team4-weights', required=True)
    ap.add_argument('--probes', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--coord-mode', default='center01', choices=['center01','edge01','center_m11','edge_m11'])
    args = ap.parse_args()

    official_exe = Path(args.official_exe).resolve()
    official_weights = Path(args.official_weights).resolve()
    team4_exe = Path(args.team4_exe).resolve()
    team4_weights = Path(args.team4_weights).resolve()
    probes = Path(args.probes).resolve()
    out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    logs = out / 'engine_logs'; logs.mkdir(exist_ok=True)

    manifest = json.loads((probes/'manifest.json').read_text(encoding='utf-8'))
    model = PlutoFirstStep(team4_weights, args.coord_mode)

    report = {
        'format':'pluto-team-phase2c-v1-real-request-parity',
        'official_exe_sha256': sha256_file(official_exe),
        'official_weights_sha256': sha256_file(official_weights),
        'team4_exe_sha256': sha256_file(team4_exe),
        'team4_weights_sha256': sha256_file(team4_weights),
        'coord_mode': args.coord_mode,
        'probes': [],
    }

    exact_4way_seed_parity = 0
    pytorch_action_match = 0

    for p in manifest['probes']:
        name = p['name']
        raw4 = (probes / p['request_file']).read_bytes()
        req = parse_request(raw4)
        raw3 = collapse_team4_request_to_official3(raw4)

        off3 = run_engine(official_exe, official_weights, raw3, logs/f'{name}_official3.stderr.log')
        off4 = run_engine(team4_exe, team4_weights, raw4, logs/f'{name}_team4.stderr.log')
        if off3['returncode'] != 0 or off4['returncode'] != 0:
            raise SystemExit(f'{name}: engine return code official3={off3["returncode"]} team4={off4["returncode"]}')

        seed_equal = off3['response']['hex'] == off4['response']['hex']
        exact_4way_seed_parity += int(seed_equal)

        pt = pytorch_forward(model, raw4)
        official_action = int(off4['response']['action'])
        order = [x['id'] for x in pt['top10']]
        if official_action in order:
            rank = order.index(official_action)+1
        else:
            logits = pt.pop('action_logits')
            full_order = torch.argsort(logits, descending=True).tolist()
            rank = full_order.index(official_action)+1
        # remove tensor if still present
        pt.pop('action_logits', None)
        action_match = pt['action'] == official_action
        pytorch_action_match += int(action_match)

        row = {
            'probe': p,
            'request_owner_counts': req['owner_counts'],
            'official3_collapsed': off3,
            'official4_seeded': off4,
            'seeded_4way_exact_response_parity': seed_equal,
            'pytorch4': pt,
            'pytorch_action_match': action_match,
            'official_action_rank_in_pytorch': int(rank),
            'pytorch_win_abs_error_vs_official4': abs(float(pt['win']) - float(off4['response']['win'])),
        }
        report['probes'].append(row)
        print(
            f"PROBE {name} frame={p['frame']} N={p['n']} "
            f"seed4eq3={seed_equal} official4_action={official_action} "
            f"pytorch_action={pt['action']} rank={rank} "
            f"official4_win={off4['response']['win']:.9f} pytorch_win={pt['win']:.9f}",
            flush=True,
        )

    report['summary'] = {
        'probe_count': len(report['probes']),
        'seeded_4way_exact_response_parity_count': exact_4way_seed_parity,
        'seeded_4way_exact_response_parity_all': exact_4way_seed_parity == len(report['probes']),
        'pytorch_action_match_count': pytorch_action_match,
        'pytorch_action_match_all': pytorch_action_match == len(report['probes']),
    }

    (out/'phase2c_v1_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    with (out/'phase2c_v1_summary.txt').open('w', encoding='utf-8') as f:
        f.write('aPlutoTeam Phase2C v1 Real-Trajectory Parity\n')
        f.write(f"probes={report['summary']['probe_count']}\n")
        f.write(f"seeded_4way_exact_response_parity={exact_4way_seed_parity}/{len(report['probes'])}\n")
        f.write(f"pytorch_action_match={pytorch_action_match}/{len(report['probes'])}\n")
        if report['summary']['seeded_4way_exact_response_parity_all']:
            f.write('OFFICIAL_4WAY_SEED_PRESERVATION=PASS\n')
        else:
            f.write('OFFICIAL_4WAY_SEED_PRESERVATION=FAIL\n')
        if report['summary']['pytorch_action_match_all']:
            f.write('PYTORCH_REAL_REQUEST_ACTION_PARITY=PASS\n')
        else:
            f.write('PYTORCH_REAL_REQUEST_ACTION_PARITY=NOT_YET\n')
        f.write('PHASE2C_V1_DIAGNOSTIC_COMPLETE=PASS\n')
    print((out/'phase2c_v1_summary.txt').read_text(encoding='utf-8'))

    # Hard gate only the already-proven policy-preserving 3->4 owner migration.
    # PyTorch parity remains diagnostic; do not train until it reaches PASS.
    if not report['summary']['seeded_4way_exact_response_parity_all']:
        raise SystemExit('FAIL: 4-way owner seed did not preserve official responses')

if __name__ == '__main__':
    main()
