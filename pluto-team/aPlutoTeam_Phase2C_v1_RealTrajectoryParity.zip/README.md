# aPlutoTeam Phase2C v1 — Real-Trajectory Parity

This is a **diagnostic gate before ally-embedding training**. It does not train or modify Pluto policy weights.

## Why this phase exists

The v104 SC:R runtime produced the first clean team trajectory: 2,174 recorded requests with four-way owner semantics and no owner-match fallback/unmatched/ambiguous events. However, the current team seed intentionally initializes `ALLY` from the old `OTHER/ENEMY` embedding, so the live responses in that trajectory are **not training labels** and are **not a parity oracle** for a fresh recurrent state.

Before changing `owner_emb[1]`, we need two independent checks on real v104 requests:

1. **Official policy-preservation check** — collapse the four-way owner vocabulary back to the original three-way vocabulary (`SELF->SELF`, `ALLY->OTHER`, `ENEMY->OTHER`, `NEUTRAL->NEUTRAL`) and compare a fresh official 3-way inference engine against a fresh patched 4-way engine using the seeded 4-way PLWB. Responses must be byte-identical.
2. **PyTorch trunk parity diagnostic** — run the reconstructed `PlutoFirstStep` on the same four-way request and compare action/win output with the fresh patched official 4-way engine. This remains diagnostic; training must not start until the PyTorch action parity issue is resolved.

## Included real probes

Eight exact request byte streams were extracted from `plutoteam-v103.3-trajectory-g1.ptrj` (the filename is historical; the data came from v104 runtime generation 1):

- first recorded request (frame 469)
- first visible enemy (frame 3158)
- first allied Hydralisk (frame 7543)
- maximum visible enemy count (frame 15807)
- closest allied Hydralisk to a Pluto unit (frame 16587, about 19 px)
- largest ally-target-block burst (frame 16699, +36 blocked direct ally-target commands)
- maximum visible ally count (frame 16870)
- final recorded request (frame 16892)

Each `.req` is the exact shared-memory request captured by v104. The paired `.resp` is retained only as historical live-run metadata. Because Pluto is recurrent and those live responses occurred after thousands of prior steps, a fresh engine is not expected to reproduce them directly.

## Success markers

`OFFICIAL_4WAY_SEED_PRESERVATION=PASS`
: Required. All eight fresh official 3-way collapsed-request responses exactly equal the corresponding fresh official patched 4-way seeded responses.

`PYTORCH_REAL_REQUEST_ACTION_PARITY=PASS`
: Desired before training. If this is `NOT_YET`, use the per-probe official action rank and stage diagnostics to isolate the remaining PyTorch structural/input mismatch.

`PHASE2C_V1_DIAGNOSTIC_COMPLETE=PASS`
: The diagnostic completed and report files were produced.

## Important safety invariant for the project

Do not behavior-clone the recorded v104 actions. They were generated while the ally embedding was intentionally identical to the enemy/other embedding. When training begins, freeze the original Pluto trunk and all owner rows except `owner_emb[1]` (ALLY), and use objectives that penalize ally-hostile behavior while preserving official enemy behavior.
