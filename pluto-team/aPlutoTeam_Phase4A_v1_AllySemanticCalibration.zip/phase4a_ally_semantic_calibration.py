from __future__ import annotations
import argparse, hashlib, json, math, os, shutil, struct, subprocess, threading, time
from pathlib import Path
import numpy as np

RESP=struct.Struct('<qqqqff')
REQ_HDR=struct.Struct('<iiiIqqqq')


def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c: raise EOFError(f'expected {n}, got {len(b)}')
        b+=c
    return bytes(b)

def parse_resp(raw):
    a,arg,pos,unit,win,lp=RESP.unpack(raw)
    return {'action':int(a),'arg':int(arg),'pos':int(pos),'unit':int(unit),'win':float(win),'logprob':float(lp),'hex':raw.hex()}

def req_n(raw): return REQ_HDR.unpack_from(raw,0)[0]

def rewrite_ally_owner(raw:bytes, new_owner:int)->bytes:
    out=bytearray(raw); n=req_n(raw); off=0x30
    for r in range(n):
        p=off+r*48+8
        o=struct.unpack_from('<q',out,p)[0]
        if o==1: struct.pack_into('<q',out,p,int(new_owner))
    return bytes(out)

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for c in iter(lambda:f.read(1<<20),b''): h.update(c)
    return h.hexdigest()

def load_plwb_owner(path:Path):
    raw=bytearray(path.read_bytes())
    if raw[:4]!=b'PLWB': raise ValueError('not PLWB')
    hlen=struct.unpack_from('<Q',raw,8)[0]
    hdr=json.loads(raw[16:16+hlen].decode('utf-8'))
    base=len(raw)-int(hdr['total_bytes'])
    t=next(x for x in hdr['tensors'] if x['name']=='owner_emb.weight')
    if list(t['shape'])!=[4,256] or int(t['nbytes'])!=4096: raise ValueError(f'bad owner tensor {t}')
    off=base+int(t['offset'])
    arr=np.frombuffer(raw,dtype='<f4',count=4*256,offset=off).copy().reshape(4,256)
    return raw,off,arr

def patch_owner_row(path:Path, coeff):
    raw,off,a=load_plwb_owner(path)
    s,e,n=coeff
    row=(s*a[0]+e*a[2]+n*a[3]).astype('<f4')
    raw[off+1024:off+2048]=row.tobytes()
    path.write_bytes(raw)
    return row

def run_engine_sequence(exe:Path,weights:Path,requests:list[bytes],stderr_path:Path,timeout_s=600):
    cmd=[str(exe),'--blob',str(weights),'--backend','int8mv','--threads','1','--seed','123456789','--argmax']
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=flags,bufsize=0)
    err=[]
    def drain():
        while True:
            c=p.stderr.read(65536)
            if not c: break
            err.append(c)
    th=threading.Thread(target=drain,daemon=True); th.start()
    try:
        hs=read_exact(p.stdout,0x88)
        magic,ver,*_=struct.unpack('<4sIiiq48s64s',hs)
        if magic.rstrip(b'\0')!=b'PLO1' or ver!=3: raise RuntimeError('bad handshake')
        out=[]
        for r in requests:
            p.stdin.write(r); p.stdin.flush(); out.append(parse_resp(read_exact(p.stdout,0x28)))
        p.stdin.close()
        try: rc=p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired: p.kill(); rc=p.wait(timeout=10)
        th.join(timeout=10); stderr_path.write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
        if rc!=0: raise RuntimeError(f'engine exit {rc}')
        return out
    finally:
        if p.poll() is None: p.kill(); p.wait(timeout=10)

def simplex_coarse():
    vals=[0.0,0.25,0.5,0.75,1.0]; out=[]
    for s in vals:
      for e in vals:
        n=1.0-s-e
        if n>=-1e-9 and n<=1.0+1e-9:
          out.append((round(s,6),round(e,6),round(max(0,n),6)))
    return sorted(set(out))

def refine(best):
    s0,e0,n0=best; out=set()
    # local simplex around best, 0.05 increments within +/-0.15 on s/e
    for ds in np.arange(-0.15,0.151,0.05):
      for de in np.arange(-0.15,0.151,0.05):
        s=s0+float(ds); e=e0+float(de); n=1.0-s-e
        if s>=-1e-9 and e>=-1e-9 and n>=-1e-9 and s<=1+1e-9 and e<=1+1e-9 and n<=1+1e-9:
          out.add((round(max(0,s),6),round(max(0,e),6),round(max(0,n),6)))
    out.discard(tuple(best)); return sorted(out)

def score_responses(got,target,items):
    score=0.0; maxscore=0.0; am=0; exact4=0
    for g,t,m in zip(got,target,items):
        w=float(m['weight']); pts=0.0
        if g['action']==t['action']: pts+=8; am+=1
        if g['arg']==t['arg']: pts+=2
        if g['unit']==t['unit']: pts+=2
        if g['pos']==t['pos']: pts+=1
        # small continuous tie-breaker only
        pts+=0.5*max(0.0,1.0-min(1.0,abs(g['win']-t['win'])/0.25))
        if (g['action'],g['arg'],g['pos'],g['unit'])==(t['action'],t['arg'],t['pos'],t['unit']): exact4+=1
        score+=w*pts; maxscore+=w*13.5
    return {'score':score,'normalized':score/maxscore if maxscore else 0,'action_match':am,'exact_int4':exact4}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--exe',required=True); ap.add_argument('--weights',required=True); ap.add_argument('--samples',required=True); ap.add_argument('--out',required=True)
    a=ap.parse_args(); exe=Path(a.exe); base=Path(a.weights); samples=Path(a.samples); out=Path(a.out); out.mkdir(parents=True,exist_ok=True); logs=out/'logs'; logs.mkdir(exist_ok=True)
    man=json.loads((samples/'manifest.json').read_text(encoding='utf-8')); items=man['samples']; raws=[]
    for m in items:
        r=(samples/m['file']).read_bytes()
        if hashlib.sha256(r).hexdigest()!=m['sha256']: raise SystemExit(f'SHA mismatch {m["file"]}')
        raws.append(r)
    print(f'PHASE4A_SAMPLES={len(raws)}',flush=True)

    # Teacher sequence: peace/non-threat allies -> neutral; threat allies -> self.
    teacher_raw=[]
    for r,m in zip(raws,items): teacher_raw.append(rewrite_ally_owner(r,0 if m['teacher']=='self' else 3))
    teacher=run_engine_sequence(exe,base,teacher_raw,logs/'teacher.stderr.txt')

    work=out/'candidate_weights.bin'; shutil.copy2(base,work)
    results=[]
    def evaluate(coeff,stage):
        shutil.copy2(base,work); row=patch_owner_row(work,coeff)
        got=run_engine_sequence(exe,work,raws,logs/f'{stage}_{coeff[0]:.2f}_{coeff[1]:.2f}_{coeff[2]:.2f}.stderr.txt')
        sc=score_responses(got,teacher,items)
        rec={'stage':stage,'coeff':{'self':coeff[0],'enemy':coeff[1],'neutral':coeff[2]},**sc,'responses':got}
        results.append(rec)
        print(f'CAND {stage} S={coeff[0]:.2f} E={coeff[1]:.2f} N={coeff[2]:.2f} score={sc["normalized"]:.6f} action={sc["action_match"]}/{len(raws)}',flush=True)
        return rec,row

    best=None; bestrow=None
    for c in simplex_coarse():
        r,row=evaluate(c,'coarse')
        if best is None or r['score']>best['score']: best,bestrow=r,row.copy()
    coarse_best=(best['coeff']['self'],best['coeff']['enemy'],best['coeff']['neutral'])
    for c in refine(coarse_best):
        r,row=evaluate(c,'refine')
        if r['score']>best['score']: best,bestrow=r,row.copy()

    # Per-category scores for best candidate
    best_coeff=(best['coeff']['self'],best['coeff']['enemy'],best['coeff']['neutral'])
    shutil.copy2(base,work); bestrow=patch_owner_row(work,best_coeff); bestgot=run_engine_sequence(exe,work,raws,logs/'best.stderr.txt')
    cats={}
    for cat in sorted(set(m['category'] for m in items)):
        idx=[i for i,m in enumerate(items) if m['category']==cat]
        sc=score_responses([bestgot[i] for i in idx],[teacher[i] for i in idx],[items[i] for i in idx])
        cats[cat]=sc
    np.asarray(bestrow,dtype='<f4').tofile(out/'ally_embedding_v1_f32.bin')
    (out/'ally_embedding_v1.json').write_text(json.dumps({'coeff':best['coeff'],'vector':[float(x) for x in bestrow]},indent=2),encoding='utf-8')
    maxc=max(best_coeff)
    cls='DISTINCT_ALLY_EMBEDDING_FOUND' if maxc<0.95 else 'ANCHOR_COLLAPSE_MORE_TEAM_DATA_NEEDED'
    report={'format':'pluto-team-phase4a-v1-ally-semantic-calibration','sample_count':len(items),'source_manifest':man,
            'teacher_rule':'ALLY->NEUTRAL when no enemy within 384px; ALLY->SELF with original actor masks when enemy is within 384px of ally',
            'best':{k:v for k,v in best.items() if k!='responses'},'best_by_category':cats,'classification':cls,'all_candidates':[{k:v for k,v in r.items() if k!='responses'} for r in results]}
    (out/'phase4a_v1_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    summary='\n'.join([
      'aPlutoTeam Phase4A v1 Ally Semantic Calibration',f'samples={len(items)}',
      f'best_coeff SELF={best_coeff[0]:.6f} ENEMY={best_coeff[1]:.6f} NEUTRAL={best_coeff[2]:.6f}',
      f'best_score={best["normalized"]:.6f} action_match={best["action_match"]}/{len(items)} exact_int4={best["exact_int4"]}/{len(items)}',
      f'result_class={cls}','PHASE4A_V1_ALLY_SEMANTIC_CALIBRATION=PASS'])+'\n'
    (out/'phase4a_v1_summary.txt').write_text(summary,encoding='utf-8'); print(summary,flush=True)
    work.unlink(missing_ok=True)
if __name__=='__main__': main()
