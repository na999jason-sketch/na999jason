# aPlutoTeam Phase4A v1 — Ally Semantic Calibration

This is the first offline behavioral calibration of the dedicated ALLY owner embedding.
It does not change Pluto strategy code, command code, or any original model parameter other than owner_emb[1].

Evidence motivating this phase:
- v104 ALLY=ENEMY made allies hostile-like.
- v105 ALLY=SELF still produced persistent ally-focused behavior. In the second reported game the runtime log reached 3,904 blocked ally targets while the user observed repeated Stim near the allied 6 o'clock Zerg natural.

Training/calibration data:
- 48 exact clean v104 real SC:R requests selected from the 2,174-step clean trajectory.
- 12 peace/block frames, 12 dense peace frames, 12 enemy-preservation frames, 12 enemy-near-ally threat frames.

Teacher rule:
- Peace / enemy not near ally: rewrite ALLY -> NEUTRAL for the teacher request, so allied presence must not provoke hostile/self-ownership behavior.
- Enemy within 384 px of an ally: rewrite ALLY -> SELF for the teacher request while keeping the original actor masks, so the policy sees a friendly asset under threat but still cannot command the allied unit.

Search:
- Only owner_emb[1] changes.
- Candidate row is a learned mixture of the frozen SELF, ENEMY and NEUTRAL semantic anchors.
- Coarse simplex search followed by local refinement, evaluated by the exact official patched Pluto inference engine.
- No PyTorch parity approximation is used for the behavioral score.

Outputs:
- ally_embedding_v1_f32.bin (256 float32 values)
- ally_embedding_v1.json
- phase4a_v1_report.json
- phase4a_v1_summary.txt
