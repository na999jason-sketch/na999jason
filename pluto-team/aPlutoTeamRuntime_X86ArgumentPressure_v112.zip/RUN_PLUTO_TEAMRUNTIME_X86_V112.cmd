@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v112-launch.log"
>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V112_LAUNCHER=START

echo === aPlutoTeamRuntime v112 - Argument-Level Early Pressure / Original Pluto after frame 7500 ===

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV112.dll" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing %%~F
  pause
  exit /b 1
)
if not exist "%ROOT%\pluto\pluto_infer.exe" (
  echo [FAIL] missing pluto\pluto_infer.exe
  pause
  exit /b 2
)
if not exist "%ROOT%\pluto\pluto_weights.bin" (
  echo [FAIL] missing pluto\pluto_weights.bin
  pause
  exit /b 3
)

taskkill /IM pluto_infer.exe /F >nul 2>nul
if exist "%ROOT%\pluto\pluto_infer.official.exe" if exist "%ROOT%\pluto\pluto_weights.official.bin" (
  copy /Y "%ROOT%\pluto\pluto_infer.official.exe" "%ROOT%\pluto\pluto_infer.exe" >nul
  copy /Y "%ROOT%\pluto\pluto_weights.official.bin" "%ROOT%\pluto\pluto_weights.bin" >nul
  echo V112_STOCK_RESTORE=OFFICIAL_BACKUPS_APPLIED>>"%LAUNCHLOG%"
) else (
  echo V112_STOCK_RESTORE=NO_BACKUPS_USING_ACTIVE_FILES_RUNTIME_WILL_VERIFY_STOCK3>>"%LAUNCHLOG%"
)

del /q "%ROOT%\plutoteam-x86-v112.log" 2>nul

echo.
echo [v112] 0-3999 strong, 4000-5999 medium, 6000-7499 light argument-level army preference.
echo [v112] Frame 7500+ has NO opening-bias mask: original Pluto strategy 100%%.
echo [v112] No fixed build order or unit is forced. Official model and v110 ally context are retained.
echo [v112] Lurker-only burrow policy, win/value logging, and stale-handle recovery are retained.
echo [v112] Press a key only after the game is loaded.
pause >nul
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV112.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
  echo [FAIL] injection failed
  pause
  exit /b %RC%
)
echo [PASS] v112 injected. Check plutoteam-x86-v112.log after the game.
pause
