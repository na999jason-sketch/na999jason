#ifndef NOMINMAX
#define NOMINMAX
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <TlHelp32.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <BWAPI/Client/Client.h>
#include "pluto_bindings.h"
#include <MinHook.h>
#include <intrin.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cwchar>
#include <fstream>
#include <string>
#include <vector>
#include <utility>
#include <unordered_set>
#include <unordered_map>
#include <sstream>

static HMODULE g_self=nullptr;
static SRWLOCK g_logLock=SRWLOCK_INIT;
static HANDLE g_logHandle=INVALID_HANDLE_VALUE;
static unsigned g_logLines=0;
using PFNGameInit=void(*)(BWAPI::Game*);
using PFNCreateAI=BWAPI::AIModule*(*)();
static std::wstring dirOfW(HMODULE m){wchar_t p[32768]={};DWORD n=GetModuleFileNameW(m,p,(DWORD)(sizeof(p)/sizeof(p[0])));std::wstring s(p,n);auto cut=s.find_last_of(L"\\/");return cut==std::wstring::npos?L".":s.substr(0,cut);}
static std::string utf8(const std::wstring&w){if(w.empty())return {};int n=WideCharToMultiByte(CP_UTF8,0,w.data(),(int)w.size(),nullptr,0,nullptr,nullptr);std::string s(n,'\0');WideCharToMultiByte(CP_UTF8,0,w.data(),(int)w.size(),s.data(),n,nullptr,nullptr);return s;}
static std::string dirOf(HMODULE m){return utf8(dirOfW(m));}
static HANDLE openSharedLogHandle(bool truncate){
  const auto path=dirOfW(g_self)+L"\\plutoteam-x86-v111.log";
  HANDLE h=CreateFileW(path.c_str(),GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,truncate?CREATE_ALWAYS:OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,nullptr);
  if(h!=INVALID_HANDLE_VALUE && !truncate)SetFilePointer(h,0,nullptr,FILE_END);
  return h;
}
static bool openPersistentLog(){
  AcquireSRWLockExclusive(&g_logLock);
  if(g_logHandle!=INVALID_HANDLE_VALUE){ReleaseSRWLockExclusive(&g_logLock);return true;}
  g_logHandle=openSharedLogHandle(true);
  const bool ok=g_logHandle!=INVALID_HANDLE_VALUE;ReleaseSRWLockExclusive(&g_logLock);return ok;
}
static void logLine(const std::string&s){
  AcquireSRWLockExclusive(&g_logLock);
  if(g_logHandle==INVALID_HANDLE_VALUE)g_logHandle=openSharedLogHandle(false);
  if(g_logHandle!=INVALID_HANDLE_VALUE){
    DWORD wrote=0;WriteFile(g_logHandle,s.data(),(DWORD)s.size(),&wrote,nullptr);
    static const char eol[]="\r\n";WriteFile(g_logHandle,eol,2,&wrote,nullptr);++g_logLines;
    const bool urgent=s.find("FAIL")!=std::string::npos||s.find("SEH")!=std::string::npos||s.find("MATCH_")!=std::string::npos||s.find("RESIDENT")!=std::string::npos||s.find("BOOTSTRAP")!=std::string::npos;
    if(urgent||(g_logLines%64u)==0u)FlushFileBuffers(g_logHandle);
  }
  ReleaseSRWLockExclusive(&g_logLock);
}
static void flushLog(){AcquireSRWLockExclusive(&g_logLock);if(g_logHandle!=INVALID_HANDLE_VALUE)FlushFileBuffers(g_logHandle);ReleaseSRWLockExclusive(&g_logLock);}
static int countProcessByName(const wchar_t* wanted){
  int count=0;HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snap==INVALID_HANDLE_VALUE)return -1;
  PROCESSENTRY32W pe{};pe.dwSize=sizeof(pe);if(Process32FirstW(snap,&pe)){do{if(_wcsicmp(pe.szExeFile,wanted)==0)++count;}while(Process32NextW(snap,&pe));}
  CloseHandle(snap);return count;
}
static unsigned long long fileSizeOrZero(const std::wstring& path){WIN32_FILE_ATTRIBUTE_DATA d{};if(!GetFileAttributesExW(path.c_str(),GetFileExInfoStandard,&d))return 0;ULARGE_INTEGER u{};u.HighPart=d.nFileSizeHigh;u.LowPart=d.nFileSizeLow;return u.QuadPart;}
static bool fileExistsW(const std::wstring& path){DWORD a=GetFileAttributesW(path.c_str());return a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY);}
static bool ensureOriginalPlutoRuntimeLayout(const std::wstring& root){
  const auto sub=root+L"\\pluto";const auto nestedInfer=sub+L"\\pluto_infer.exe";const auto nestedWeights=sub+L"\\pluto_weights.bin";
  if(fileExistsW(nestedInfer)&&fileExistsW(nestedWeights)){logLine("pluto_runtime.layout=STANDARD");return true;}
  const auto flatInfer=root+L"\\pluto_infer.exe";const auto flatWeights=root+L"\\pluto_weights.bin";
  if(fileExistsW(flatInfer)&&fileExistsW(flatWeights)){
    if(!CreateDirectoryW(sub.c_str(),nullptr) && GetLastError()!=ERROR_ALREADY_EXISTS){logLine("pluto_runtime.layout=CREATE_SUBDIR_FAIL error="+std::to_string(GetLastError()));return false;}
    if(!CopyFileW(flatInfer.c_str(),nestedInfer.c_str(),FALSE)){logLine("pluto_runtime.layout=COPY_INFER_FAIL error="+std::to_string(GetLastError()));return false;}
    if(!CopyFileW(flatWeights.c_str(),nestedWeights.c_str(),FALSE)){logLine("pluto_runtime.layout=COPY_WEIGHTS_FAIL error="+std::to_string(GetLastError()));return false;}
    logLine("pluto_runtime.layout=FLAT_TO_STANDARD");return true;
  }
  logLine("pluto_runtime.layout=MISSING");return false;
}

static bool readFileRangeW(const std::wstring& path,unsigned long long off,void*buf,DWORD bytes){
  HANDLE h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
  if(h==INVALID_HANDLE_VALUE)return false;
  LARGE_INTEGER li{};li.QuadPart=(LONGLONG)off;
  bool ok=SetFilePointerEx(h,li,nullptr,FILE_BEGIN)!=0;DWORD got=0;
  if(ok)ok=ReadFile(h,buf,bytes,&got,nullptr)!=0&&got==bytes;
  CloseHandle(h);return ok;
}
static bool team4InferRuntimeReady(const std::wstring&path){
  unsigned char b[6]{};
  if(!readFileRangeW(path,59201,b,6))return false;
  // v110 deliberately requires the unmodified official 3-owner inference gate.
  const unsigned char expect[6]={0x41,0xB9,0x03,0x00,0x00,0x00};
  return std::memcmp(b,expect,6)==0;
}
static bool team4WeightsRuntimeReady(const std::wstring&path){
  HANDLE h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
  if(h==INVALID_HANDLE_VALUE)return false;
  unsigned char head[16]{};DWORD got=0;bool ok=ReadFile(h,head,16,&got,nullptr)!=0&&got==16;
  if(!ok||std::memcmp(head,"PLWB",4)!=0){CloseHandle(h);return false;}
  uint32_t ver=0;uint64_t hlen=0;std::memcpy(&ver,head+4,4);std::memcpy(&hlen,head+8,8);
  if(ver!=1||hlen<1024||hlen>1024*1024){CloseHandle(h);return false;}
  std::string hdr((size_t)hlen,'\0');ok=ReadFile(h,hdr.data(),(DWORD)hlen,&got,nullptr)!=0&&got==(DWORD)hlen;CloseHandle(h);
  if(!ok)return false;
  const size_t n=hdr.find("owner_emb.weight");if(n==std::string::npos)return false;
  const size_t s=hdr.find("\"shape\"",n);if(s==std::string::npos)return false;
  const size_t lb=hdr.find('[',s),rb=hdr.find(']',lb);if(lb==std::string::npos||rb==std::string::npos)return false;
  std::string shape=hdr.substr(lb+1,rb-lb-1);shape.erase(std::remove_if(shape.begin(),shape.end(),[](char c){return c==' '||c=='\t'||c=='\r'||c=='\n';}),shape.end());
  return shape=="3,256";
}
static volatile DWORD g_sehCode=0;static volatile uintptr_t g_sehAddress=0;static volatile uintptr_t g_sehEip=0;
static volatile uintptr_t g_sehAccessAddress=0;static volatile ULONG_PTR g_sehAccessType=~(ULONG_PTR)0;
static volatile uintptr_t g_sehEax=0,g_sehEbx=0,g_sehEcx=0,g_sehEdx=0,g_sehEsi=0,g_sehEdi=0,g_sehEbp=0,g_sehEsp=0;
static int captureSeh(EXCEPTION_POINTERS*ep){if(ep&&ep->ExceptionRecord){g_sehCode=ep->ExceptionRecord->ExceptionCode;g_sehAddress=(uintptr_t)ep->ExceptionRecord->ExceptionAddress;
if(ep->ExceptionRecord->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && ep->ExceptionRecord->NumberParameters>=2){g_sehAccessType=ep->ExceptionRecord->ExceptionInformation[0];g_sehAccessAddress=(uintptr_t)ep->ExceptionRecord->ExceptionInformation[1];}}
#if defined(_M_IX86)
if(ep&&ep->ContextRecord){g_sehEip=(uintptr_t)ep->ContextRecord->Eip;g_sehEax=ep->ContextRecord->Eax;g_sehEbx=ep->ContextRecord->Ebx;g_sehEcx=ep->ContextRecord->Ecx;g_sehEdx=ep->ContextRecord->Edx;g_sehEsi=ep->ContextRecord->Esi;g_sehEdi=ep->ContextRecord->Edi;g_sehEbp=ep->ContextRecord->Ebp;g_sehEsp=ep->ContextRecord->Esp;}
#endif
return EXCEPTION_EXECUTE_HANDLER;}
static DWORD onStartSeh(BWAPI::AIModule*m){g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;__try{m->onStart();return 0;}__except(captureSeh(GetExceptionInformation())){return g_sehCode;}}
static DWORD onEndSeh(BWAPI::AIModule*m,bool won){g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;__try{m->onEnd(won);return 0;}__except(captureSeh(GetExceptionInformation())){return g_sehCode;}}
static DWORD onFrameSeh(BWAPI::AIModule*m){
  g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;
  __try{m->onFrame();return 0;}
  __except(captureSeh(GetExceptionInformation())){return g_sehCode;}
}

#pragma pack(push,1)
struct LegacyCUnit336{ unsigned char b[336]; };
#pragma pack(pop)
static_assert(sizeof(LegacyCUnit336)==336,"CUnit size");

template<class T> static T rd(const unsigned char*p,size_t o){T v{};std::memcpy(&v,p+o,sizeof(v));return v;}
static bool readable(const void*p,size_t n){
  MEMORY_BASIC_INFORMATION mi{}; if(!VirtualQuery(p,&mi,sizeof(mi)))return false;
  if(mi.State!=MEM_COMMIT || (mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
  uintptr_t a=(uintptr_t)p; uintptr_t e=a+(uintptr_t)n; uintptr_t r=(uintptr_t)mi.BaseAddress+(uintptr_t)mi.RegionSize; return e>=a && e<=r;
}
static bool plausibleUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  auto hp=rd<int32_t>(p,0x08); auto spr=rd<uint32_t>(p,0x0c); auto x=rd<int16_t>(p,0x28); auto y=rd<int16_t>(p,0x2a);
  auto player=rd<uint8_t>(p,0x4c); auto order=rd<uint8_t>(p,0x4d); auto type=rd<uint16_t>(p,0x64);
  return spr!=0 && hp>0 && hp<(5000000*256) && x>=0&&x<=16384&&y>=0&&y<=16384&&player<12&&order<256&&type<234;
}
struct UnitStore{uintptr_t descriptor=0,begin=0,end=0,cap=0;int score=0;};
static UnitStore scanDescriptorRange(uintptr_t s,uintptr_t e,const char*tag){
  UnitStore best{}; MEMORY_BASIC_INFORMATION mi{}; uintptr_t a=s; unsigned long regions=0; unsigned long descriptors=0;
  logLine(std::string("checkpoint.scan_range.begin=")+tag);
  while(a<e && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;
    if(re<=a)break;
    uintptr_t lo=std::max(a,rs),hi=std::min(e,re);
    bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) &&
      (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && hi>lo && hi-lo>=12){
      ++regions;
      for(uintptr_t q=(lo+3)&~uintptr_t(3);q+12<=hi;q+=4){
        uint32_t b=0,en=0,c=0;
        std::memcpy(&b,(void*)q,4);std::memcpy(&en,(void*)(q+4),4);std::memcpy(&c,(void*)(q+8),4);
        if(!b||en<b||c<en)continue;uint32_t used=en-b,cap=c-b;
        if(used==0||used%336||cap%336)continue;uint32_t count=used/336,capacity=cap/336;
        if(count<2||count>3400||capacity<count||capacity>3400)continue;
        if(!readable((void*)(uintptr_t)b,std::min<uint32_t>(used,336*64)))continue;
        ++descriptors;int score=0;uint32_t step=std::max<uint32_t>(1,count/64);
        for(uint32_t i=0;i<count&&i<3400;i+=step)if(plausibleUnit((unsigned char*)(uintptr_t)(b+i*336)))++score;
        if(score>best.score){best={q,b,en,c,score};}
      }
    }
    a=re;
  }
  logLine(std::string("checkpoint.scan_range.end=")+tag+" regions="+std::to_string(regions)+" descriptors="+std::to_string(descriptors)+" best_score="+std::to_string(best.score));
  return best;
}
static uintptr_t profileSlotVA(uint32_t analyzedVa){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return 0;
  return (uintptr_t)exe+(uintptr_t)(analyzedVa-0x004A0000u);
}
static bool profileMatchActive(){
  const uintptr_t slot=profileSlotVA(0x0121758Du);
  if(!slot||!readable((void*)slot,1))return false;
  uint8_t v=0;std::memcpy(&v,(void*)slot,1);return v!=0;
}
static bool profileReplayActive(){
  const uintptr_t slot=profileSlotVA(0x01244580u);
  if(!slot||!readable((void*)slot,4))return true;
  uint32_t v=0;std::memcpy(&v,(void*)slot,4);return v!=0;
}
static uint32_t profileReadU32(uint32_t analyzedVa){
  uintptr_t slot=profileSlotVA(analyzedVa);if(!slot||!readable((void*)slot,4))return 0;
  uint32_t v=0;memcpy(&v,(void*)slot,4);return v;
}
static UnitStore findLegacyCUnitVector(){
  logLine("checkpoint.cunit_scan.enter");
  const uintptr_t poolSlot=profileSlotVA(0x010436F0u);
  const uintptr_t lengthSlot=profileSlotVA(0x010436F4u);
  logLine("profile_cunit.pool_slot="+std::to_string((unsigned long)poolSlot));
  logLine("profile_cunit.length_slot="+std::to_string((unsigned long)lengthSlot));
  if(!poolSlot||!lengthSlot||!readable((void*)poolSlot,4)||!readable((void*)lengthSlot,4)){
    logLine("profile_cunit=PROFILE_SLOTS_UNREADABLE");return {};
  }
  uint32_t begin=0,length=0;memcpy(&begin,(void*)poolSlot,4);memcpy(&length,(void*)lengthSlot,4);
  logLine("profile_cunit.pool_begin="+std::to_string((unsigned long)begin));
  logLine("profile_cunit.pool_length="+std::to_string(length));
  if(!begin||length<2||length>8192u){
    logLine("profile_cunit=INVALID_POOL_METADATA");return {};
  }
  const uint64_t bytes64=(uint64_t)length*336ull;
  if(bytes64>0xFFFFFFFFull||!readable((void*)(uintptr_t)begin,(size_t)bytes64)){
    logLine("profile_cunit=POOL_UNREADABLE");return {};
  }
  int present=0,plausible=0;
  for(uint32_t i=0;i<length;i++){
    auto*p=(unsigned char*)(uintptr_t)(begin+(uintptr_t)i*336u);
    if(rd<uint32_t>(p,0x0c)!=0 && rd<uint16_t>(p,0x64)<228){
      ++present;if(plausibleUnit(p))++plausible;
    }
  }
  const uint32_t active=profileReadU32(0x010436A4u);
  const uint32_t hidden=profileReadU32(0x010436B4u);
  const uint32_t scanner=profileReadU32(0x010436B8u);
  logLine("profile_cunit.present="+std::to_string(present)+" plausible="+std::to_string(plausible));
  logLine("profile_cunit.raw_heads.active="+std::to_string((unsigned long)active)+
          " hidden="+std::to_string((unsigned long)hidden)+
          " scanner="+std::to_string((unsigned long)scanner));
  auto inPool=[&](uint32_t p)->bool{
    if(!p)return true;uint64_t b=begin,e=(uint64_t)begin+bytes64;
    return p>=b && p<e && ((p-b)%336u)==0;
  };
  if(present<2||plausible<2||!active||!inPool(active)||!inPool(hidden)||!inPool(scanner)){
    logLine("profile_cunit=VALIDATION_FAIL");return {};
  }
  logLine("checkpoint.cunit_scan.global_select=PROFILE_13515_X86");
  logLine("checkpoint.cunit_scan.global_score="+std::to_string(present));
  logLine("checkpoint.cunit_scan.global_count="+std::to_string(length));
  logLine("profile_cunit=BOUND_VALIDATED");
  const uintptr_t end=(uintptr_t)((uint64_t)begin+bytes64);
  return {poolSlot,(uintptr_t)begin,end,end,present};
}

static uintptr_t g_scrVisibleUnitHead=0;
static uintptr_t g_scrHiddenUnitHead=0;
static uintptr_t g_scrScannerSweepHead=0;
static int g_linkPrevOff=0;
static int g_linkNextOff=4;
static std::vector<LegacyCUnit336> g_legacyCUnits(1700);
static std::vector<uintptr_t> g_legacyRawUnits;

#pragma pack(push,1)
struct LegacyBullet112{ unsigned char b[112]; };
struct LegacySprite36{ unsigned char b[36]; };
#pragma pack(pop)
static_assert(sizeof(LegacyBullet112)==112,"Bullet size");
static_assert(sizeof(LegacySprite36)==36,"Sprite size");

struct StableUnitSlot{
  uintptr_t raw=0;
  uint8_t sourceGeneration=0;
  uint8_t generation=0;
};
static std::array<StableUnitSlot,1700> g_stableUnitSlots{};
static std::array<LegacySprite36,1700> g_legacyUnitSprites{};
static std::unordered_map<uintptr_t,size_t> g_stableUnitLookup;

// Pluto-Team v103.4: v103.3 known-good first-match runtime + multi-match lifecycle fix.
// Strategy/inference/command generation remain entirely inside the original Pluto.
// The bridge reads SCR's real alliance matrix and keeps allied CUnits (units AND
// buildings) visible in the legacy/BWAPI observation. Direct commands that target
// an allied unit are rejected only as a fail-closed safety boundary.
// No replacement target or strategic decision is chosen here.
// IMPORTANT: official Pluto's neural owner embedding is still the original 3-way
// self/other/neutral model; v103.3 preserves v102 live ally/enemy/neutral distinctions and
// exposes allies to the game observation, but does not yet add a fourth NN category.
static bool g_teamCompatReady=false;
static int g_teamCompatSelf=-1;
static uint32_t g_teamCompatAllyMask=0;
static volatile LONG g_teamCompatBlockedCommands=0;
static int g_teamCompatLastAllyVisible=0;
static int g_teamCompatLastSelfVisible=0;
static int g_teamCompatLastEnemyVisible=0;
static int g_teamCompatLastNeutralVisible=0;
static bool teamCompatRawIsAlly(uintptr_t raw);

static uintptr_t g_legacyBulletHead=0;
static std::vector<LegacyBullet112> g_legacyBullets;
static std::vector<LegacySprite36> g_legacyBulletSprites;
static std::vector<uintptr_t> g_legacyRawBullets;
static std::unordered_map<uintptr_t,size_t> g_rawBulletIndex;

static bool presentScrUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  return rd<uint32_t>(p,0x0c)!=0 && rd<uint16_t>(p,0x64)<228;
}
static uintptr_t shadowForRaw(uintptr_t raw){
  if(!raw)return 0;
  auto it=g_stableUnitLookup.find(raw);
  if(it==g_stableUnitLookup.end()||it->second>=g_legacyCUnits.size())return 0;
  return (uintptr_t)&g_legacyCUnits[it->second];
}
static std::vector<uintptr_t> collectPresentRaw(const UnitStore&s){
  std::vector<uintptr_t> out;
  if(!s.begin||s.end<=s.begin)return out;
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  out.reserve(std::min<uint32_t>(count,1700));
  for(uint32_t i=0;i<count;i++){
    uintptr_t raw=s.begin+(uintptr_t)i*336;
    if(presentScrUnit((unsigned char*)raw))out.push_back(raw);
  }
  return out;
}
static uint16_t legacyHandleForRaw(uintptr_t raw){
  auto it=g_stableUnitLookup.find(raw);if(it==g_stableUnitLookup.end())return 0;
  const size_t i=it->second;if(i>=1700)return 0;
  return (uint16_t)((i+1)|((uint16_t)(g_stableUnitSlots[i].generation&31u)<<11));
}

static uintptr_t rawForLegacyHandle(uint16_t legacy){
  unsigned index=legacy&0x7ffu;
  if(!index||index>g_stableUnitSlots.size())return 0;--index;
  const auto&slot=g_stableUnitSlots[index];
  if(!slot.raw||slot.generation!=(uint8_t)(legacy>>11))return 0;
  return slot.raw;
}
static bool teamCompatLegacyIsAlly(uint16_t legacy){
  const uintptr_t raw=rawForLegacyHandle(legacy);
  return raw && teamCompatRawIsAlly(raw);
}
static void teamCompatLogBlocked(const char*kind,uint16_t legacy){
  const LONG n=InterlockedIncrement(&g_teamCompatBlockedCommands);
  if(n<=16 || (n%32)==0)
    logLine(std::string("TEAM_RUNTIME_ALLY_TARGET_BLOCK kind=")+kind+
            " legacy="+std::to_string((unsigned)legacy)+
            " total="+std::to_string((long)n));
}

using ScrPacket=std::vector<uint8_t>;
static uint16_t legacyWord(const uint8_t* p){return (uint16_t)(p[0]|((uint16_t)p[1]<<8));}
static void appendDword(ScrPacket& packet,uint32_t v){for(unsigned i=0;i<4;++i)packet.push_back((uint8_t)(v>>(8*i)));}
static unsigned legacyFixedCommandLength(uint8_t id){
  switch(id){
    case 0x0c:return 8;
    case 0x14:return 10;case 0x15:return 11;
    case 0x18:case 0x19:case 0x1b:case 0x1c:case 0x27:case 0x2a:case 0x2e:case 0x31:case 0x33:case 0x34:case 0x36:case 0x5a:return 1;
    case 0x1a:case 0x1e:case 0x21:case 0x22:case 0x25:case 0x26:case 0x28:case 0x2b:case 0x2c:case 0x2d:case 0x30:case 0x32:return 2;
    case 0x1f:case 0x20:case 0x23:case 0x29:case 0x35:return 3;
    case 0x2f:return 5;
    default:return 0;
  }
}
static uint32_t scrHandleForLegacy(uint16_t legacy){
  unsigned index=legacy&0x7ffu;
  if(!index||index>g_stableUnitSlots.size())return 0;--index;
  const auto&slot=g_stableUnitSlots[index];
  if(!slot.raw||slot.generation!=(uint8_t)(legacy>>11))return 0;
  const uint32_t rawStart=profileReadU32(0x010436F0u);
  const uint32_t rawLength=profileReadU32(0x010436F4u);
  if(!rawStart||!rawLength||slot.raw<(uintptr_t)rawStart)return 0;
  const uintptr_t delta=slot.raw-(uintptr_t)rawStart;
  if(delta%336u)return 0;
  const uint32_t rawIndex=(uint32_t)(delta/336u);
  if(rawIndex>=rawLength)return 0;
  const unsigned shift=rawLength>1700u?13u:11u;
  return (rawIndex+1u)|((uint32_t)slot.sourceGeneration<<shift);
}
// v111 behavior guard: LURKER_ONLY burrow policy.
// This is a command-safety compatibility filter only. It does not choose a build,
// unit composition, combat target, or replacement action for Pluto.
// - Burrowing research (BW command 0x30, tech 11) is dropped before SCR submission,
//   so no minerals/gas are spent on the unwanted upgrade.
// - Burrow/Unburrow (0x2c/0x2d) are allowed only when the current explicit legacy
//   selection is known and consists entirely of Zerg Lurkers.
// - Every blocked command is dropped only; no substitute command is invented.
static volatile LONG g_v111BurrowResearchBlocked=0;
static volatile LONG g_v111BurrowCommandBlocked=0;
static volatile LONG g_v111LurkerBurrowAllowed=0;
// v111.1 transient command recovery: a unit can die between Pluto's observation
// and SCR command translation. That stale legacy handle is normal gameplay churn,
// not a fatal runtime error. Drop that single Pluto decision batch and continue.
static volatile LONG g_v111TransientCommandDrops=0;
static volatile LONG g_v111TransientCommandDropStreak=0;
static bool g_v111SelectionKnown=false;
static bool g_v111SelectionAllLurkers=false;
static unsigned g_v111SelectionCount=0;
static int g_v111SelectionFirstType=-1;
static constexpr uint8_t kV111BurrowingTechId=11u;

static void team111ResetBurrowPolicyState(){
  InterlockedExchange(&g_v111BurrowResearchBlocked,0);
  InterlockedExchange(&g_v111BurrowCommandBlocked,0);
  InterlockedExchange(&g_v111LurkerBurrowAllowed,0);
  InterlockedExchange(&g_v111TransientCommandDrops,0);
  InterlockedExchange(&g_v111TransientCommandDropStreak,0);
  g_v111SelectionKnown=false;g_v111SelectionAllLurkers=false;g_v111SelectionCount=0;g_v111SelectionFirstType=-1;
}
static void team111ObserveExplicitSelection(uint8_t id,const uint8_t*p){
  // 0x09 is the canonical replacement selection used by Pluto before unit orders.
  // Treat additive/other selection forms conservatively as unknown so they can
  // never accidentally authorize a non-Lurker burrow.
  if(id!=0x09){g_v111SelectionKnown=false;g_v111SelectionAllLurkers=false;g_v111SelectionCount=0;g_v111SelectionFirstType=-1;return;}
  const unsigned count=p[1];bool all=count>0;int first=-1;
  for(unsigned i=0;i<count;++i){
    const uint16_t legacy=legacyWord(p+2+i*2);const uintptr_t raw=rawForLegacyHandle(legacy);
    if(!raw||!readable((void*)raw,0x66)){all=false;continue;}
    const int type=(int)rd<uint16_t>((unsigned char*)raw,0x64);
    if(first<0)first=type;
    if(type!=BWAPI::UnitTypes::Enum::Zerg_Lurker)all=false;
  }
  g_v111SelectionKnown=count>0;g_v111SelectionAllLurkers=g_v111SelectionKnown&&all;
  g_v111SelectionCount=count;g_v111SelectionFirstType=first;
}
static void team111LogBurrowBlock(const char*kind,uint8_t commandId){
  LONG n=0;
  if(commandId==0x30)n=InterlockedIncrement(&g_v111BurrowResearchBlocked);
  else n=InterlockedIncrement(&g_v111BurrowCommandBlocked);
  if(n<=16||(n%32)==0){
    logLine(std::string("V111_BURROW_BLOCK kind=")+kind+" command_id="+std::to_string((unsigned)commandId)+
      " selected_known="+(g_v111SelectionKnown?"1":"0")+
      " selected_all_lurkers="+(g_v111SelectionAllLurkers?"1":"0")+
      " selected_count="+std::to_string(g_v111SelectionCount)+
      " first_type="+std::to_string(g_v111SelectionFirstType)+" total="+std::to_string((long)n));
  }
}
static void team111LogLurkerBurrowAllow(uint8_t commandId){
  const LONG n=InterlockedIncrement(&g_v111LurkerBurrowAllowed);
  if(n<=16||(n%32)==0)logLine("V111_LURKER_BURROW_ALLOW command_id="+std::to_string((unsigned)commandId)+
    " selected_count="+std::to_string(g_v111SelectionCount)+" total="+std::to_string((long)n));
}


static bool translateLegacyCommands(const uint8_t* bytes,size_t length,std::vector<ScrPacket>& output,std::string& error){
  output.clear();error.clear();
  auto convert=[&](uint16_t id,uint32_t& result)->bool{
    if(!id){result=0;return true;}
    result=scrHandleForLegacy(id);
    if(!result){error="expired_or_unmapped_unit_handle="+std::to_string((unsigned)id);return false;}
    return true;
  };
  for(size_t offset=0;offset<length;){
    const uint8_t* p=bytes+offset;const uint8_t id=p[0];size_t size=0;
    if(id>=9&&id<=11){
      if(length-offset<2||p[1]>12){error="invalid_legacy_selection";return false;}
      size=2u+(size_t)p[1]*2u;
    }else{
      size=legacyFixedCommandLength(id);
      if(!size){error="unsupported_legacy_command="+std::to_string((unsigned)id);return false;}
    }
    if(size>length-offset){error="truncated_legacy_command";return false;}

    if(id>=9&&id<=11)team111ObserveExplicitSelection(id,p);

    // v111 LURKER_ONLY filter: drop only the unwanted command; never replace it.
    if(id==0x30 && size>=2 && p[1]==kV111BurrowingTechId){team111LogBurrowBlock("RESEARCH_BURROWING",id);offset+=size;continue;}
    if(id==0x2c||id==0x2d){
      if(!(g_v111SelectionKnown&&g_v111SelectionAllLurkers)){team111LogBurrowBlock(id==0x2c?"BURROW_NON_LURKER":"UNBURROW_NON_LURKER",id);offset+=size;continue;}
      team111LogLurkerBurrowAllow(id);
    }

    // v102 TeamRuntime safety boundary: never submit a direct allied-unit
    // selection/target produced by a 1v1-trained Pluto. Drop that packet only;
    // do not invent, redirect, or replace the command.
    bool blocked=false;
    if(id>=9&&id<=11){
      for(unsigned i=0;i<p[1];++i){
        const uint16_t old=legacyWord(p+2+i*2);
        if(old && teamCompatLegacyIsAlly(old)){teamCompatLogBlocked("selection",old);blocked=true;break;}
      }
    }else if(id==0x14||id==0x15){
      const uint16_t old=legacyWord(p+5);
      if(old && teamCompatLegacyIsAlly(old)){teamCompatLogBlocked(id==0x14?"target_14":"target_15",old);blocked=true;}
    }else if(id==0x29){
      const uint16_t old=legacyWord(p+1);
      if(old && teamCompatLegacyIsAlly(old)){teamCompatLogBlocked("target_29",old);blocked=true;}
    }
    if(blocked){offset+=size;continue;}

    ScrPacket result;
    if(id>=9&&id<=11){
      result.push_back((uint8_t)(0x63+id-9));result.push_back(p[1]);
      for(unsigned i=0;i<p[1];++i){
        const uint16_t old=legacyWord(p+2+i*2);if(!old){error="null_selection_handle";return false;}
        uint32_t mapped=0;if(!convert(old,mapped))return false;appendDword(result,mapped);
      }
    }else if(id==0x14||id==0x15){
      result.push_back((uint8_t)(id==0x14?0x60:0x61));
      result.insert(result.end(),p+1,p+5);
      uint32_t mapped=0;if(!convert(legacyWord(p+5),mapped))return false;appendDword(result,mapped);
      result.insert(result.end(),p+7,p+size);
    }else if(id==0x29){
      result.push_back(0x62);uint32_t mapped=0;if(!convert(legacyWord(p+1),mapped))return false;appendDword(result,mapped);
    }else result.assign(p,p+size);
    output.push_back(std::move(result));offset+=size;
  }
  return true;
}

static void convertLegacyUnitSprite(size_t slot,uintptr_t rawSprite){
  auto&dst=g_legacyUnitSprites[slot];std::memset(dst.b,0,sizeof(dst.b));
  if(!rawSprite||!readable((void*)rawSprite,40))return;
  std::memcpy(dst.b,(void*)rawSprite,20);
  uint32_t zero=0;std::memcpy(dst.b,&zero,4);std::memcpy(dst.b+4,&zero,4);
  uint32_t a=0,b=0;std::memcpy(&a,(void*)(rawSprite+20),4);std::memcpy(&b,(void*)(rawSprite+24),4);
  uint16_t v20=(uint16_t)a,v22=(uint16_t)b;std::memcpy(dst.b+20,&v20,2);std::memcpy(dst.b+22,&v22,2);
  if(readable((void*)(rawSprite+28),12))std::memcpy(dst.b+24,(void*)(rawSprite+28),12);
}
static bool stableSlotSet(const UnitStore&s,const std::vector<uintptr_t>&present,bool logValues){
  if(present.size()>1700u){logLine("stable_cunit_slots=OVERFLOW_GT_1700");return false;}
  std::unordered_set<uintptr_t> now(present.begin(),present.end());
  for(size_t i=0;i<g_stableUnitSlots.size();++i){
    auto&slot=g_stableUnitSlots[i];
    if(slot.raw && !now.count(slot.raw)){
      g_stableUnitLookup.erase(slot.raw);slot.raw=0;slot.sourceGeneration=0;
      std::memset(g_legacyCUnits[i].b,0,sizeof(g_legacyCUnits[i].b));
      std::memset(g_legacyUnitSprites[i].b,0,sizeof(g_legacyUnitSprites[i].b));
    }
  }
  for(uintptr_t raw:present){
    const uint8_t srcGen=rd<uint8_t>((unsigned char*)raw,165);
    auto found=g_stableUnitLookup.find(raw);
    if(found==g_stableUnitLookup.end()){
      size_t empty=g_stableUnitSlots.size();
      for(size_t i=0;i<g_stableUnitSlots.size();++i)if(!g_stableUnitSlots[i].raw){empty=i;break;}
      if(empty==g_stableUnitSlots.size()){logLine("stable_cunit_slots=NO_FREE_SLOT");return false;}
      auto&slot=g_stableUnitSlots[empty];slot.raw=raw;slot.sourceGeneration=srcGen;slot.generation=(uint8_t)((slot.generation+1)&31u);
      g_stableUnitLookup.emplace(raw,empty);
    }else{
      auto&slot=g_stableUnitSlots[found->second];
      if(slot.sourceGeneration!=srcGen){slot.sourceGeneration=srcGen;slot.generation=(uint8_t)((slot.generation+1)&31u);}
    }
  }
  g_legacyRawUnits=present;
  if(logValues){
    logLine("stable_cunit_slots.present="+std::to_string(present.size()));
    logLine("stable_cunit_slots.lookup="+std::to_string(g_stableUnitLookup.size()));
  }
  return true;
}
static bool projectStableLegacyUnitsFromPresent(const UnitStore&s,const std::vector<uintptr_t>&present,bool logValues){
  if(!stableSlotSet(s,present,logValues))return false;
  const uint32_t rawLength=(uint32_t)((s.end-s.begin)/336);
  const unsigned ptrOffsets[]={0,4,20,92,104,108,112,124,128,236,240,244,252,284};
  for(size_t i=0;i<g_stableUnitSlots.size();++i){
    auto&slot=g_stableUnitSlots[i];if(!slot.raw)continue;
    auto*src=(unsigned char*)slot.raw;auto&dst=g_legacyCUnits[i];
    std::memcpy(dst.b,src,336);
    for(unsigned off:ptrOffsets){
      uint32_t rawPtr=rd<uint32_t>(src,off);uint32_t legacy=(uint32_t)shadowForRaw(rawPtr);
      std::memcpy(dst.b+off,&legacy,4);
    }
    for(unsigned off=192;off<=216;off+=4){
      uint32_t rawPtr=rd<uint32_t>(src,off);
      if(g_stableUnitLookup.count(rawPtr)){uint32_t legacy=(uint32_t)shadowForRaw(rawPtr);std::memcpy(dst.b+off,&legacy,4);}
    }
    uint32_t rawSprite=rd<uint32_t>(src,12);convertLegacyUnitSprite(i,rawSprite);
    uint32_t spriteShadow=rawSprite?(uint32_t)(uintptr_t)&g_legacyUnitSprites[i]:0;
    std::memcpy(dst.b+12,&spriteShadow,4);
    std::memcpy(dst.b+165,&slot.generation,1);

    uint16_t high=rawLength>1700?rd<uint16_t>(src,306):0;
    for(unsigned n=0;n<8;++n){
      uint32_t id=(uint32_t)rd<uint16_t>(src,176+n*2)|(((uint32_t)(high>>(n*2))&3u)<<16);
      uint32_t index=id&(rawLength>1700?0x1fffu:0x7ffu);uint16_t legacy=0;
      if(index && index<=rawLength){
        uintptr_t loaded=s.begin+(uintptr_t)(index-1)*336u;
        const unsigned shift=rawLength>1700?13u:11u;
        if(readable((void*)loaded,336) && rd<uint8_t>((unsigned char*)loaded,165)==(uint8_t)(id>>shift))
          legacy=legacyHandleForRaw(loaded);
      }
      std::memcpy(dst.b+176+n*2,&legacy,2);
    }
  }


  // v101: preserve complete coherent CUnit chains. Allied CUnits are NOT hidden.
  // Units and buildings share the same CUnit owner field (+0x4C), therefore both
  // remain observable and use the exact same SCR alliance classification.
  const uint32_t rawActive=profileReadU32(0x010436A4u);
  const uint32_t rawHidden=profileReadU32(0x010436B4u);
  const uint32_t rawScanner=profileReadU32(0x010436B8u);
  g_scrVisibleUnitHead=shadowForRaw(rawActive);
  g_scrHiddenUnitHead=shadowForRaw(rawHidden);
  g_scrScannerSweepHead=shadowForRaw(rawScanner);
  if(logValues)logLine("TEAM_RUNTIME_CUNIT_LIST=ALLY_VISIBLE_FULL_CHAIN");
  if(logValues){
    logLine("profile_heads.raw.visible="+std::to_string((unsigned long)rawActive)+
            " hidden="+std::to_string((unsigned long)rawHidden)+
            " scanner="+std::to_string((unsigned long)rawScanner));
    logLine("profile_heads.shadow.visible="+std::to_string((unsigned long)g_scrVisibleUnitHead)+
            " hidden="+std::to_string((unsigned long)g_scrHiddenUnitHead)+
            " scanner="+std::to_string((unsigned long)g_scrScannerSweepHead));
  }
  // The public reference simply maps each list head through unit(raw); an
  // inaccessible hidden/scanner head therefore becomes null rather than a
  // fatal error. Preserve that behavior. The active head is different: if it
  // is non-null but not present in this asynchronous snapshot, treat the
  // snapshot as transient/torn and let the bounded retry path reacquire it.
  if(rawActive && !g_scrVisibleUnitHead){logLine("profile_heads=ACTIVE_NOT_MAPPED_TRANSIENT");return false;}
  if(logValues && rawHidden && !g_scrHiddenUnitHead)logLine("profile_heads.hidden_unmapped=REFERENCE_NULL");
  if(logValues && rawScanner && !g_scrScannerSweepHead)logLine("profile_heads.scanner_unmapped=REFERENCE_NULL");
  return g_scrVisibleUnitHead!=0;
}
static bool projectStableLegacyUnits(const UnitStore&s,bool logValues){
  const auto present=collectPresentRaw(s);
  return projectStableLegacyUnitsFromPresent(s,present,logValues);
}
static int buildLegacyCUnitShadow(const UnitStore&s){
  if(!projectStableLegacyUnits(s,true))return 0;
  return (int)g_legacyRawUnits.size();
}
static int refreshLegacyCUnitShadow(const UnitStore&s){
  if(!projectStableLegacyUnits(s,false))return 0;
  return (int)g_legacyRawUnits.size();
}
static int refreshLegacyCUnitShadowFromPresent(const UnitStore&s,const std::vector<uintptr_t>&present){
  if(!projectStableLegacyUnitsFromPresent(s,present,false))return 0;
  return (int)g_legacyRawUnits.size();
}

static uintptr_t shadowBulletForRaw(uintptr_t raw){
  if(!raw)return 0;
  auto it=g_rawBulletIndex.find(raw);
  if(it==g_rawBulletIndex.end()||it->second>=g_legacyBullets.size())return 0;
  return (uintptr_t)&g_legacyBullets[it->second];
}
static bool projectProfileBulletShadow(bool logValues){
  const uintptr_t headSlot=profileSlotVA(0x01034A78u);
  if(logValues)logLine("profile_bullet.head_slot="+std::to_string((unsigned long)headSlot));
  if(!headSlot||!readable((void*)headSlot,4)){
    logLine("profile_bullet=HEAD_SLOT_UNREADABLE");return false;
  }
  uint32_t rawHead=0;std::memcpy(&rawHead,(void*)headSlot,4);
  if(logValues)logLine("profile_bullet.raw_head="+std::to_string((unsigned long)rawHead));

  std::vector<uintptr_t> rawBullets;
  std::unordered_set<uintptr_t> visited;
  uintptr_t cur=rawHead;
  while(cur){
    if(rawBullets.size()>=8192u){logLine("profile_bullet=OVERFLOW_GT_8192");return false;}
    if(!visited.insert(cur).second){logLine("profile_bullet=CYCLE_DETECTED");return false;}
    if(!readable((void*)cur,112)){logLine("profile_bullet=NODE_UNREADABLE");return false;}
    rawBullets.push_back(cur);
    uint32_t next=rd<uint32_t>((unsigned char*)cur,4);
    if(next && !readable((void*)(uintptr_t)next,112)){logLine("profile_bullet=NEXT_UNREADABLE");return false;}
    cur=next;
  }

  g_legacyBullets.clear();g_legacyBulletSprites.clear();g_legacyRawBullets.clear();g_rawBulletIndex.clear();g_legacyBulletHead=0;
  g_legacyRawBullets=rawBullets;
  g_legacyBullets.resize(rawBullets.size());
  g_legacyBulletSprites.resize(rawBullets.size());
  g_rawBulletIndex.reserve(rawBullets.size()*2+1);
  for(size_t i=0;i<rawBullets.size();++i)g_rawBulletIndex.emplace(rawBullets[i],i);

  for(size_t i=0;i<rawBullets.size();++i){
    auto*src=(unsigned char*)rawBullets[i];
    std::memcpy(g_legacyBullets[i].b,src,112);
  }
  for(size_t i=0;i<rawBullets.size();++i){
    uintptr_t raw=rawBullets[i];auto*src=(unsigned char*)raw;auto&dst=g_legacyBullets[i];
    uint32_t prev=(uint32_t)shadowBulletForRaw(rd<uint32_t>(src,0));
    uint32_t next=(uint32_t)shadowBulletForRaw(rd<uint32_t>(src,4));
    std::memcpy(dst.b+0,&prev,4);std::memcpy(dst.b+4,&next,4);
    for(int off:{0x14,0x5c,0x64,0x68}){
      uint32_t rawUnit=rd<uint32_t>(src,(size_t)off);uint32_t u=(uint32_t)shadowForRaw(rawUnit);
      std::memcpy(dst.b+off,&u,4);
    }
    uint32_t rawSprite=rd<uint32_t>(src,0x0c);uint32_t spriteShadow=0;
    if(rawSprite){
      if(!readable((void*)(uintptr_t)rawSprite,40)){logLine("profile_bullet=SPRITE_UNREADABLE");return false;}
      auto&s=g_legacyBulletSprites[i];std::memset(s.b,0,sizeof(s.b));std::memcpy(s.b,(void*)(uintptr_t)rawSprite,20);
      uint32_t z=0;std::memcpy(s.b,&z,4);std::memcpy(s.b+4,&z,4);
      uint16_t v20=(uint16_t)rd<uint32_t>((unsigned char*)(uintptr_t)rawSprite,20);
      uint16_t v22=(uint16_t)rd<uint32_t>((unsigned char*)(uintptr_t)rawSprite,24);
      std::memcpy(s.b+20,&v20,2);std::memcpy(s.b+22,&v22,2);
      if(readable((void*)(uintptr_t)(rawSprite+28),12))std::memcpy(s.b+24,(void*)(uintptr_t)(rawSprite+28),12);
      spriteShadow=(uint32_t)(uintptr_t)&s;
    }
    std::memcpy(dst.b+0x0c,&spriteShadow,4);
  }
  g_legacyBulletHead=rawBullets.empty()?0:shadowBulletForRaw(rawBullets[0]);
  if(logValues){
    logLine("profile_bullet.active="+std::to_string(rawBullets.size()));
    logLine("profile_bullet.shadow_head="+std::to_string((unsigned long)g_legacyBulletHead));
    logLine("profile_bullet=BOUND_VALIDATED");
  }
  return rawHead==0 || g_legacyBulletHead!=0;
}
static bool buildLegacyBulletShadow(){return projectProfileBulletShadow(true);}
static bool refreshLegacyBulletShadow(){return projectProfileBulletShadow(false);}

static int profileLocalPlayerCandidate();
static int inferRace(int type){if(type<=59||(type>=106&&type<=131))return 1;if((type>=88&&type<=103)||(type>=132&&type<=157))return 0;if((type>=60&&type<=87)||type==97||(type>=159&&type<=173))return 2;return 5;}
static int projectLiveUnitsFromPresent(const std::vector<uintptr_t>&present,BWAPI::GameData&d){
  int out=0;std::array<int,12> counts{};std::array<int,12> race{};race.fill(5);
  const int previous=d.initialUnitCount;const int self=d.self;
  g_teamCompatLastAllyVisible=g_teamCompatLastSelfVisible=g_teamCompatLastEnemyVisible=g_teamCompatLastNeutralVisible=0;
  for(uintptr_t raw:present){
    auto*p=(unsigned char*)raw;if(!presentScrUnit(p))continue;
    const int owner=rd<uint8_t>(p,0x4c);const int type=rd<uint16_t>(p,0x64);
    if(owner>=0&&owner<12){counts[owner]++;race[owner]=inferRace(type);}
    const uint32_t sprite=rd<uint32_t>(p,0x0c);uint8_t visibility=0;
    if(sprite&&readable((void*)(uintptr_t)(sprite+12),1))std::memcpy(&visibility,(void*)(uintptr_t)(sprite+12),1);
    if(self>=0&&self<8 && owner!=self && owner!=11 && !(visibility&(1u<<self)))continue;
    if(out>=10000)break;
    auto&q=d.units[out];ZeroMemory(&q,sizeof(q));q.id=out;q.player=owner;q.type=type;q.positionX=rd<int16_t>(p,0x28);q.positionY=rd<int16_t>(p,0x2a);
    q.hitPoints=std::max(0,rd<int32_t>(p,0x08)/256);q.shields=rd<uint32_t>(p,0x60)/256;q.energy=rd<uint16_t>(p,0xa2)/256;q.order=rd<uint8_t>(p,0x4d);
    q.targetPositionX=rd<int16_t>(p,0x58);q.targetPositionY=rd<int16_t>(p,0x5a);q.orderTargetPositionX=q.targetPositionX;q.orderTargetPositionY=q.targetPositionY;
    q.exists=true;auto flags=rd<uint32_t>(p,0xdc);q.isCompleted=(flags&1)!=0;q.isCloaked=(flags&0x200)!=0;q.isBurrowed=(flags&0x10)!=0;q.isInvincible=(flags&0x04000000)!=0;
    for(bool&v:q.isVisible)v=false;
    const int visCount=(int)(sizeof(q.isVisible)/sizeof(q.isVisible[0]));
    for(int i=0;i<8&&i<visCount;++i)q.isVisible[i]=(owner==i)||((visibility&(1u<<i))!=0);
    if(owner==self)++g_teamCompatLastSelfVisible;
    else if(owner==11)++g_teamCompatLastNeutralVisible;
    else if(g_teamCompatReady && teamCompatRawIsAlly(raw))++g_teamCompatLastAllyVisible;
    else ++g_teamCompatLastEnemyVisible;
    ++out;
  }
  for(int i=out;i<previous&&i<10000;++i)ZeroMemory(&d.units[i],sizeof(d.units[i]));
  d.initialUnitCount=out;d.playerCount=0;
  for(int pl=0;pl<12;pl++)if(counts[pl]){d.playerCount=std::max(d.playerCount,pl+1);d.players[pl].race=race[pl];d.players[pl].isParticipating=true;d.players[pl].type=1;d.players[pl].isAlly[pl]=true;}
  return out;
}
static int projectLiveUnits(const UnitStore&s,BWAPI::GameData&d){
  return projectLiveUnitsFromPresent(collectPresentRaw(s),d);
}


static constexpr uintptr_t kLegacyGameBase=0x0057F0F0u;
static constexpr size_t kScrGameSize=96000u;
static uintptr_t g_scrGame=0;
static unsigned char* g_legacyGameShadow=nullptr;

static bool collectCoherentPresentRaw(const UnitStore&s,std::vector<uintptr_t>&out,uint32_t&frameOut){
  out.clear();frameOut=0;
  if(!g_scrGame||!readable((void*)(g_scrGame+332),4))return false;
  for(int attempt=0;attempt<4;++attempt){
    const uint32_t before=rd<uint32_t>((unsigned char*)g_scrGame,332);
    auto candidate=collectPresentRaw(s);
    const uint32_t after=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(before==after){out.swap(candidate);frameOut=after;return true;}
    Sleep(0);
  }
  return false;
}

static int scoreScrGameCandidate(uintptr_t g,int expectedLive,uint64_t* unitTotalOut=nullptr){
  if(!g || !readable((void*)g,kScrGameSize))return -1;
  const auto*p=(const unsigned char*)g;
  const uint16_t w=rd<uint16_t>(p,228),h=rd<uint16_t>(p,230);
  const uint32_t frame=rd<uint32_t>(p,332);
  if(w<32||w>256||h<32||h>256||frame==0||frame>50000000u)return -1;
  int score=200;
  int smallUp=0,totalUp=0;
  for(size_t i=0;i<12u*46u;i++){++totalUp;if(rd<uint8_t>(p,57792+i)<=3)++smallUp;}
  for(size_t i=0;i<12u*15u;i++){++totalUp;if(rd<uint8_t>(p,66108+i)<=3)++smallUp;}
  if(smallUp<totalUp*98/100)return -1;score+=smallUp;
  int smallTech=0,totalTech=0;
  for(size_t i=0;i<12u*24u;i++){++totalTech;if(rd<uint8_t>(p,56916+i)<=1)++smallTech;}
  for(size_t i=0;i<12u*20u;i++){++totalTech;if(rd<uint8_t>(p,65616+i)<=1)++smallTech;}
  if(smallTech<totalTech*95/100)return -1;score+=smallTech;
  uint64_t unitTotal=0;int badCounts=0;
  for(size_t i=0;i<228u*12u;i++){uint32_t v=rd<uint32_t>(p,12852+i*4);if(v>5000u)++badCounts;unitTotal+=v;}
  if(badCounts>4 || unitTotal<2 || unitTotal>20000)return -1;
  if(unitTotalOut)*unitTotalOut=unitTotal;
  score+=400;
  if(expectedLive>0){uint64_t diff=unitTotal>(uint64_t)expectedLive?unitTotal-expectedLive:(uint64_t)expectedLive-unitTotal;if(diff<=16)score+=500;else if(diff<=64)score+=250;}
  int goodSupply=0,totalSupply=0;
  for(int race=0;race<3;race++)for(int block=0;block<3;block++)for(int pl=0;pl<12;pl++){
    ++totalSupply;uint32_t v=rd<uint32_t>(p,12372+race*144+block*48+pl*4);if(v<5000u)++goodSupply;
  }
  if(goodSupply<totalSupply*95/100)return -1;score+=goodSupply;
  return score;
}

static uintptr_t profileScrGameCandidate(){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return 0;
  const uintptr_t base=(uintptr_t)exe;
  const uintptr_t slot=base+(0x00FA63CCu-0x004A0000u);
  if(!readable((void*)slot,4))return 0;
  uint32_t encoded=0;memcpy(&encoded,(void*)slot,4);
  return (uintptr_t)(encoded^0x10FAE560u);
}

static uintptr_t findScrGameBlock(int expectedLive){
  uintptr_t prof=profileScrGameCandidate();uint64_t total=0;int ps=scoreScrGameCandidate(prof,expectedLive,&total);
  logLine("scr_game.profile_candidate="+std::to_string((unsigned long)prof)+" score="+std::to_string(ps)+" unit_total="+std::to_string(total));
  if(ps>=1500){logLine("scr_game.select=PROFILE_VALIDATED");return prof;}
  SYSTEM_INFO si{};GetSystemInfo(&si);MEMORY_BASIC_INFORMATION mi{};uintptr_t a=(uintptr_t)si.lpMinimumApplicationAddress;
  uintptr_t best=0;int bestScore=-1;uint64_t bestTotal=0;unsigned long regions=0,candidates=0;
  while(a<(uintptr_t)si.lpMaximumApplicationAddress && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;if(re<=a)break;
    const bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) && (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && mi.RegionSize>=kScrGameSize){++regions;uintptr_t lo=(rs+15u)&~uintptr_t(15u),hi=re-kScrGameSize;
      for(uintptr_t q=lo;q<=hi;q+=16u){
        uint16_t w=0,h=0;uint32_t frame=0;memcpy(&w,(void*)(q+228),2);memcpy(&h,(void*)(q+230),2);if(w<32||w>256||h<32||h>256)continue;memcpy(&frame,(void*)(q+332),4);if(!frame||frame>50000000u)continue;
        uint64_t ut=0;int sc=scoreScrGameCandidate(q,expectedLive,&ut);if(sc<0)continue;++candidates;if(sc>bestScore){bestScore=sc;best=q;bestTotal=ut;}
      }
    }
    a=re;
  }
  logLine("scr_game.scan.regions="+std::to_string(regions)+" candidates="+std::to_string(candidates)+" best_score="+std::to_string(bestScore));
  logLine("scr_game.scan.best="+std::to_string((unsigned long)best)+" unit_total="+std::to_string(bestTotal));
  if(bestScore<1500){logLine("scr_game.select=UNRESOLVED");return 0;}
  logLine("scr_game.select=DYNAMIC_SCAN");return best;
}

static bool allocateLegacyGameShadow(){
  if(g_legacyGameShadow)return true;
  void* p=VirtualAlloc(nullptr,kScrGameSize,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
  if(!p){logLine("legacy_game.alloc=FAIL gle="+std::to_string(GetLastError()));return false;}
  if((uintptr_t)p>0xFFFFFFFFu){VirtualFree(p,0,MEM_RELEASE);logLine("legacy_game.alloc=OUT_OF_X86_RANGE");return false;}
  g_legacyGameShadow=(unsigned char*)p;
  logLine("legacy_game.allocated_shadow="+std::to_string((unsigned long)(uintptr_t)g_legacyGameShadow));
  return true;
}

static bool syncLegacyGameShadow(uintptr_t g){
  if(!g_legacyGameShadow||!g||!readable((void*)g,kScrGameSize))return false;
  memcpy(g_legacyGameShadow,(void*)g,kScrGameSize);
  return true;
}



// SC:R ActiveTileArray bridge. The original Pluto reads the BW 1.16.1
// pointer at 0x6D1260. We do not synthesize tile state: we validate and expose
// SC:R's live map_tile_flags() allocation through a pointer cell and relocate
// only Pluto's known absolute operands that load 0x6D1260.
static uint32_t g_scrActiveTileArray=0;
static uint32_t g_legacyActiveTilePtr=0;
static uintptr_t g_activeTileProfileSlot=0;

// Legacy BW 1.16.1 onStart globals. The original Pluto reads the local player
// id from 0x512688 and clears the selection/control-group cells at
// 0x5124D8..0x51250C. These are ABI cells only: the local player value comes
// directly from SCR, while Pluto's legacy writes stay isolated in this shadow.
static uint32_t g_legacyLocalPlayerId=0;
alignas(4) static unsigned char g_legacyStartSelection[0x38]{};

// Legacy BW Players[12] block. SCR keeps the same 36-byte player records but
// at a relocated runtime allocation. Pluto onStart reads these records directly
// for slot type/race/team/name. Preserve Pluto's reads by copying the real SCR
// records into a 12*36 shadow and relocating only operands that point inside
// 0x57EEE0..0x57F08F.
static constexpr uint32_t kLegacyPlayersBase=0x0057EEE0u;
static constexpr size_t kLegacyPlayersBytes=12u*36u;
alignas(4) static unsigned char g_legacyPlayersShadow[kLegacyPlayersBytes]{};
static uint32_t g_scrPlayers=0;

static bool teamCompatRawIsAlly(uintptr_t raw){
  if(!g_teamCompatReady||!raw||!readable((void*)raw,336))return false;
  const int owner=rd<uint8_t>((unsigned char*)raw,0x4c);
  if(g_teamCompatSelf<0||g_teamCompatSelf>=8||owner<0||owner>=8||owner==g_teamCompatSelf)return false;
  return (g_teamCompatAllyMask&(1u<<(unsigned)owner))!=0;
}
static void teamCompatBindRelations(const BWAPI::GameData&d){
  const bool wasReady=g_teamCompatReady;const int oldSelf=g_teamCompatSelf;const uint32_t oldMask=g_teamCompatAllyMask;
  g_teamCompatSelf=d.self;g_teamCompatAllyMask=0;
  if(d.self>=0&&d.self<8){
    for(int i=0;i<8;++i)
      if(i!=d.self && d.players[i].isParticipating && d.players[d.self].isAlly[i])
        g_teamCompatAllyMask|=(1u<<(unsigned)i);
  }
  g_teamCompatReady=true;
  if(!wasReady||oldSelf!=g_teamCompatSelf||oldMask!=g_teamCompatAllyMask)
    logLine("TEAM_RUNTIME_RELATIONS self="+std::to_string(g_teamCompatSelf)+
            " ally_mask="+std::to_string((unsigned long)g_teamCompatAllyMask));
}

static void teamRuntimeLogAllySamples(const BWAPI::GameData&d,uint32_t frame){
  if(!g_teamCompatReady||g_teamCompatSelf<0||g_teamCompatSelf>=8)return;
  int shown=0;
  for(int i=0;i<d.initialUnitCount && i<10000 && shown<8;i++){
    const auto&u=d.units[i];
    const int owner=u.player;
    if(owner<0||owner>=8||owner==g_teamCompatSelf)continue;
    if((g_teamCompatAllyMask&(1u<<(unsigned)owner))==0)continue;
    logLine("TEAM_RUNTIME_ALLY_CUNIT relation=ALLY owner="+std::to_string(owner)+
            " type="+std::to_string(u.type)+
            " x="+std::to_string(u.positionX)+
            " y="+std::to_string(u.positionY)+
            " frame="+std::to_string(frame));
    ++shown;
  }
  if(shown==0)
    logLine("TEAM_RUNTIME_ALLY_CUNIT relation=ALLY visible_samples=0 frame="+std::to_string(frame));
}


// v102 model-boundary owner rewrite.
// Original Pluto's tensor builder still emits 0=self,1=other-player,2=neutral.
// The prepared v102 inference runtime has a 4-row owner embedding. Immediately
// before Pluto signals its SHM request event we rewrite only cat[:,1]:
//   0 self, 1 ally, 2 enemy, 3 neutral.
// Relation comes only from the actual SCR CUnit owner + Game::alliances already
// validated by v101. No strategy, target replacement, or command is created here.
static HMODULE g_team4PlutoModule=nullptr;
using PFNSetEvent=BOOL (WINAPI*)(HANDLE);
static PFNSetEvent g_originalSetEvent=nullptr;
static volatile LONG g_team4RewriteSeq=0;
static volatile LONG g_team4RewriteFatal=0;
static volatile LONG g_team4RewriteEnabled=1;
static thread_local bool g_insideTeam4SetEvent=false;

static int team4RelationForOwner(int owner){
  if(g_teamCompatSelf>=0&&g_teamCompatSelf<8&&owner==g_teamCompatSelf)return 0;
  if(owner>=8)return 3;
  if(owner>=0&&owner<8 && (g_teamCompatAllyMask&(1u<<(unsigned)owner)))return 1;
  return 2;
}
static int team4MatchOtherRow(int type,int x,int y,int order,bool*usedFallback,bool*ambiguous,bool*matchedAny){
  if(usedFallback)*usedFallback=false;
  if(ambiguous)*ambiguous=false;
  if(matchedAny)*matchedAny=false;

  int exactBits=0,posBits=0;

  // v104: match against the exact LEGACY SHADOW that original Pluto just
  // observed, not the moving raw SCR CUnit pool.
  //
  // The v103.3 trajectory proved that raw-live matching drifted badly late
  // game: unmatched rows were defaulted to ENEMY and created dozens of fake
  // enemies. The legacy shadow is refreshed from the same coherent snapshot
  // before original Pluto builds the request, so it removes that timing drift
  // without inventing any game state.
  for(size_t i=0;i<g_stableUnitSlots.size();++i){
    if(!g_stableUnitSlots[i].raw)continue;
    auto*p=g_legacyCUnits[i].b;
    const int owner=(int)rd<uint8_t>(p,0x4c);
    if(owner<0||owner>=8||owner==g_teamCompatSelf)continue;
    if((int)rd<uint16_t>(p,0x64)!=type)continue;
    if((int)rd<int16_t>(p,0x28)!=x||(int)rd<int16_t>(p,0x2a)!=y)continue;

    if(matchedAny)*matchedAny=true;
    const int rel=team4RelationForOwner(owner);
    if(rel!=1&&rel!=2)continue;

    posBits|=(rel==1?1:2);
    if((int)rd<uint8_t>(p,0x4d)==order)
      exactBits|=(rel==1?1:2);
  }

  int bits=exactBits;
  if(!bits){
    bits=posBits;
    if(bits&&usedFallback)*usedFallback=true;
  }

  if(bits==1)return 1; // ally
  if(bits==2)return 2; // enemy
  if(bits==3){
    if(ambiguous)*ambiguous=true;
    return 2;          // fail-closed ambiguity
  }
  return 2;            // unmatched default-other
}
// ---------------- v103.3 delayed passive recorder ----------------
// Critical regression rule: NOTHING recorder-related runs before the first
// original Pluto onFrame has returned successfully. The first inference path is
// therefore the v102 path byte-for-byte at the hook level.
//
// After that first successful frame, the recorder is armed. On later requests
// it copies the already-rewritten canonical SHM payload into a pre-reserved
// buffer (no disk I/O in SetEvent). The worker writes request+response only
// after original Pluto onFrame returns.
//
// First model request is intentionally not recorded.
static SRWLOCK g_recLock=SRWLOCK_INIT;
static HANDLE g_recHandle=INVALID_HANDLE_VALUE;
static std::vector<unsigned char> g_recPending;
static volatile LONG g_recArmed=0;
static uint32_t g_recPendingReqSeq=0,g_recPendingFrame=0,g_recPendingN=0;
static uint32_t g_recPendingSelf=0,g_recPendingAlly=0,g_recPendingEnemy=0,g_recPendingNeutral=0;
static uint32_t g_recPendingFallback=0,g_recPendingUnmatched=0,g_recPendingAmbiguous=0;
static bool g_recPendingValid=false;
static uint32_t g_recGeneration=0,g_recSteps=0;
static uint64_t g_recBytes=0;
static const uint64_t kRecorderCap=1536ull*1024ull*1024ull;

#pragma pack(push,1)
struct RecFileHeaderV1033{
  char magic[8];uint32_t version;uint32_t generation;uint32_t self;uint32_t allyMask;uint32_t headerBytes;uint32_t reserved;
};
struct RecStepHeaderV1033{
  char magic[4];uint32_t headerBytes;uint32_t payloadBytes;uint32_t responseBytes;
  uint32_t reqSeq;uint32_t respSeq;uint32_t frame;uint32_t n;
  uint32_t selfCount;uint32_t allyCount;uint32_t enemyCount;uint32_t neutralCount;
  uint32_t fallback;uint32_t unmatched;uint32_t ambiguous;uint32_t allyTargetBlockedTotal;
};
struct RecEndHeaderV1033{
  char magic[4];uint32_t headerBytes;uint32_t generation;uint32_t won;
  uint32_t finalFrame;uint32_t steps;uint64_t bytes;
};
#pragma pack(pop)
static_assert(sizeof(RecFileHeaderV1033)==32,"rec header");
static_assert(sizeof(RecStepHeaderV1033)==64,"rec step");
static_assert(sizeof(RecEndHeaderV1033)==32,"rec end");

static bool rec33WriteAll(const void*p,DWORD n){
  if(g_recHandle==INVALID_HANDLE_VALUE)return false;
  DWORD done=0;return WriteFile(g_recHandle,p,n,&done,nullptr)!=0&&done==n;
}
static void recorder33Close(){
  AcquireSRWLockExclusive(&g_recLock);
  if(g_recHandle!=INVALID_HANDLE_VALUE){
    FlushFileBuffers(g_recHandle);CloseHandle(g_recHandle);g_recHandle=INVALID_HANDLE_VALUE;
  }
  g_recPending.clear();g_recPendingValid=false;
  InterlockedExchange(&g_recArmed,0);
  ReleaseSRWLockExclusive(&g_recLock);
}
static bool recorder33ArmAfterFirstFrame(uint32_t generation,int self,uint32_t allyMask){
  recorder33Close();
  AcquireSRWLockExclusive(&g_recLock);
  g_recGeneration=generation;g_recSteps=0;g_recBytes=0;g_recPendingValid=false;
  // Reserve worst practical payload once, outside SetEvent hook.
  g_recPending.clear();g_recPending.reserve(650000u);
  wchar_t name[128]{};swprintf_s(name,L"\\plutoteam-v103.3-trajectory-g%u.ptrj",generation);
  const auto path=dirOfW(g_self)+name;
  g_recHandle=CreateFileW(path.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,nullptr);
  if(g_recHandle==INVALID_HANDLE_VALUE){
    ReleaseSRWLockExclusive(&g_recLock);
    logLine("TEAM_TRAINING_RECORDER=OPEN_FAIL_NONFATAL");
    return false;
  }
  RecFileHeaderV1033 h{};std::memcpy(h.magic,"PTRJ103",7);h.version=1;h.generation=generation;
  h.self=(uint32_t)std::max(self,0);h.allyMask=allyMask;h.headerBytes=sizeof(h);
  const bool ok=rec33WriteAll(&h,sizeof(h));g_recBytes=ok?sizeof(h):0;
  if(ok)InterlockedExchange(&g_recArmed,1);
  ReleaseSRWLockExclusive(&g_recLock);
  logLine(std::string("TEAM_TRAINING_RECORDER=")+(ok?"ARMED_AFTER_FIRST_PLUTO_FRAME":"HEADER_FAIL_NONFATAL")+
          " generation="+std::to_string(generation)+" file="+utf8(path));
  return ok;
}
static void recorder33CaptureRequest(void*view,int n,uint32_t selfCount,uint32_t allyCount,uint32_t enemyCount,uint32_t neutralCount,uint32_t fallback,uint32_t unmatched,uint32_t ambiguous){
  if(!InterlockedCompareExchange(&g_recArmed,0,0)||!view||n<1||n>1024)return;
  auto*b=(unsigned char*)view;
  uint32_t reqSeq=0;std::memcpy(&reqSeq,b+0x40,4);
  uint32_t frame=0;if(g_scrGame&&readable((void*)(g_scrGame+332u),4))frame=rd<uint32_t>((unsigned char*)g_scrGame,332);
  const size_t bytes=0x30u+(size_t)n*6u*8u+(size_t)n*109u*4u+(size_t)n*2u+20u+233u+292u*4u+128u*128u*2u+128u*128u+4u*8u;

  AcquireSRWLockExclusive(&g_recLock);
  if(g_recHandle==INVALID_HANDLE_VALUE){ReleaseSRWLockExclusive(&g_recLock);return;}
  if(g_recPending.capacity()<bytes){
    // Never allocate unexpectedly in the SetEvent hook. Skip this sample.
    logLine("TEAM_TRAINING_RECORDER=CAPACITY_SKIP_NONFATAL bytes="+std::to_string(bytes));
    ReleaseSRWLockExclusive(&g_recLock);return;
  }
  g_recPending.resize(bytes);
  unsigned char*outp=g_recPending.data();size_t o=0;
  auto cp=[&](const void*p,size_t z){std::memcpy(outp+o,p,z);o+=z;};
  cp(b+0x0c0,0x30);
  cp(b+0x100,(size_t)n*6u*8u);
  cp(b+0x0c100,(size_t)n*109u*4u);
  cp(b+0x79100,(size_t)n);cp(b+0x79500,(size_t)n);
  cp(b+0x79900,20);cp(b+0x79940,233);cp(b+0x79a40,292u*4u);
  cp(b+0x79f00,128u*128u*2u);cp(b+0x81f00,128u*128u);cp(b+0x85f00,4u*8u);
  if(o!=bytes){g_recPending.clear();ReleaseSRWLockExclusive(&g_recLock);return;}
  g_recPendingReqSeq=reqSeq;g_recPendingFrame=frame;g_recPendingN=(uint32_t)n;
  g_recPendingSelf=selfCount;g_recPendingAlly=allyCount;g_recPendingEnemy=enemyCount;g_recPendingNeutral=neutralCount;
  g_recPendingFallback=fallback;g_recPendingUnmatched=unmatched;g_recPendingAmbiguous=ambiguous;g_recPendingValid=true;
  ReleaseSRWLockExclusive(&g_recLock);
}
static void recorder33CommitResponse(){
  if(!InterlockedCompareExchange(&g_recArmed,0,0)||!g_team4PlutoModule)return;
  auto*c=(unsigned char*)g_team4PlutoModule+0x52140u;if(!readable(c,0x20))return;
  uint32_t shm=0;uint8_t use=0;std::memcpy(&shm,c+0x18,4);std::memcpy(&use,c+0x1c,1);
  if(!use||!shm)return;auto*b=(unsigned char*)(uintptr_t)shm;
  if(!readable(b+0x80,4)||!readable(b+0x85f40,0x28))return;
  uint32_t respSeq=0;std::memcpy(&respSeq,b+0x80,4);

  AcquireSRWLockExclusive(&g_recLock);
  if(g_recHandle==INVALID_HANDLE_VALUE||!g_recPendingValid||respSeq!=g_recPendingReqSeq){
    ReleaseSRWLockExclusive(&g_recLock);return;
  }
  const uint64_t projected=g_recBytes+sizeof(RecStepHeaderV1033)+g_recPending.size()+0x28u;
  if(projected>kRecorderCap){
    g_recPendingValid=false;g_recPending.clear();ReleaseSRWLockExclusive(&g_recLock);
    logLine("TEAM_TRAINING_RECORDER=CAP_REACHED_NONFATAL");return;
  }
  RecStepHeaderV1033 h{};std::memcpy(h.magic,"STEP",4);h.headerBytes=sizeof(h);
  h.payloadBytes=(uint32_t)g_recPending.size();h.responseBytes=0x28;h.reqSeq=g_recPendingReqSeq;h.respSeq=respSeq;
  h.frame=g_recPendingFrame;h.n=g_recPendingN;h.selfCount=g_recPendingSelf;h.allyCount=g_recPendingAlly;
  h.enemyCount=g_recPendingEnemy;h.neutralCount=g_recPendingNeutral;h.fallback=g_recPendingFallback;
  h.unmatched=g_recPendingUnmatched;h.ambiguous=g_recPendingAmbiguous;
  h.allyTargetBlockedTotal=(uint32_t)InterlockedCompareExchange(&g_teamCompatBlockedCommands,0,0);
  const bool ok=rec33WriteAll(&h,sizeof(h))&&rec33WriteAll(g_recPending.data(),(DWORD)g_recPending.size())&&rec33WriteAll(b+0x85f40,0x28);
  if(ok){
    g_recBytes=projected;++g_recSteps;
    if(g_recSteps<=4||(g_recSteps%128u)==0u)
      logLine("TEAM_TRAINING_RECORDER=STEP_PASS step="+std::to_string(g_recSteps)+" req="+std::to_string(respSeq)+" frame="+std::to_string(g_recPendingFrame)+" N="+std::to_string(g_recPendingN));
  }else logLine("TEAM_TRAINING_RECORDER=WRITE_FAIL_NONFATAL");
  g_recPendingValid=false;g_recPending.clear();
  ReleaseSRWLockExclusive(&g_recLock);
}
static void recorder33End(bool won,uint32_t finalFrame){
  AcquireSRWLockExclusive(&g_recLock);
  if(g_recHandle!=INVALID_HANDLE_VALUE){
    RecEndHeaderV1033 e{};std::memcpy(e.magic,"END!",4);e.headerBytes=sizeof(e);e.generation=g_recGeneration;
    e.won=won?1u:0u;e.finalFrame=finalFrame;e.steps=g_recSteps;e.bytes=g_recBytes;
    if(rec33WriteAll(&e,sizeof(e)))g_recBytes+=sizeof(e);
    FlushFileBuffers(g_recHandle);
  }
  const uint32_t steps=g_recSteps;const uint64_t bytes=g_recBytes;
  ReleaseSRWLockExclusive(&g_recLock);
  logLine("TEAM_TRAINING_RECORDER=END generation="+std::to_string(g_recGeneration)+" won="+(won?"1":"0")+
          " steps="+std::to_string(steps)+" bytes="+std::to_string(bytes));
  recorder33Close();
}

// Static combat/support classifier inherited from v109. It is used only to decide
// whether an allied row is eligible to contribute friendly combat context.
// Economy/production bodies are never eligible. This classifier itself does not
// decide any Pluto action.
static bool team108ExcludedProductionBody(int type){
  using namespace BWAPI::UnitTypes::Enum;
  return type==Zerg_Larva || type==Zerg_Egg || type==Zerg_Cocoon ||
         type==Zerg_Lurker_Egg || type==Zerg_Overlord ||
         type==Spell_Scanner_Sweep || type==Spell_Disruption_Web ||
         type==Spell_Dark_Swarm || type==Special_Map_Revealer ||
         type==Terran_Civilian;
}
static bool team108AllyIsFriendlyForce(int type){
  if(type<0 || type>=BWAPI::UnitTypes::Enum::MAX)return false;
  const BWAPI::UnitType ut(type);
  if(ut.isWorker())return false;
  if(team108ExcludedProductionBody(type))return false;
  if(ut.isBuilding()){
    // Static defensive combat structures count as friendly force, while
    // economy/production/tech buildings remain non-owned context.
    if(type==BWAPI::UnitTypes::Enum::Terran_Bunker)return true;
    return ut.canAttack();
  }
  return ut.canAttack() || ut.isSpellcaster() || ut.isDetector() || ut.spaceProvided()>0;
}

// v109 early-army playstyle preference. No model weights are changed and no
// build order is scripted. The runtime self-calibrates Pluto's own 20-way
// action IDs from commands Pluto actually emits in THIS match:
//   worker-production evidence = Train/Morph of a BWAPI worker
//   army-production evidence   = Train/Morph of a combat/support unit
// Only when those resolve to distinct action IDs and BOTH actions are currently
// valid does v109 occasionally mask the learned worker-production action for a
// single inference request. Every other action (build/tech/expand/tactics) stays
// available, the mask is restored immediately after that inference, and there
// is a cooldown. If Pluto has no valid army-production alternative, v109 does
// nothing. This is a preference nudge, not a fixed build order.
static volatile LONG g_v109WorkerVotes[20]{};
static volatile LONG g_v109ArmyVotes[20]{};
static volatile LONG g_v109EligibleRequests=0;
static volatile LONG g_v109Nudges=0;
static volatile LONG g_v109MaskedAction=-1;
static volatile LONG g_v109MaskedOriginal=0;
static volatile LONG g_v109LastBiasFrame=-100000;
static constexpr uint32_t kV109PreferenceEndFrame=7200u;
static constexpr int kV109MinWorkersForBias=10;
static constexpr LONG kV109MaxNudges=18;
static constexpr LONG kV109EligibleCadence=3; // bias 1 of every 3 eligible requests
static constexpr uint32_t kV109CooldownFrames=96u;

static void team109ResetPreferenceState(){
  for(int i=0;i<20;++i){InterlockedExchange(&g_v109WorkerVotes[i],0);InterlockedExchange(&g_v109ArmyVotes[i],0);}
  InterlockedExchange(&g_v109EligibleRequests,0);InterlockedExchange(&g_v109Nudges,0);
  InterlockedExchange(&g_v109MaskedAction,-1);InterlockedExchange(&g_v109MaskedOriginal,0);
  InterlockedExchange(&g_v109LastBiasFrame,-100000);
}
static int team109BestPureAction(bool worker){
  int best=-1;LONG bestVotes=0;
  for(int i=0;i<20;++i){
    const LONG w=InterlockedCompareExchange(&g_v109WorkerVotes[i],0,0);
    const LONG a=InterlockedCompareExchange(&g_v109ArmyVotes[i],0,0);
    const bool pure=worker?(w>0&&a==0):(a>0&&w==0);
    const LONG votes=worker?w:a;
    if(pure&&votes>bestVotes){best=i;bestVotes=votes;}
  }
  return best;
}
static void team109ApplyEarlyArmyPreference(unsigned char*b,uint8_t*actionMask,int selfWorkers){
  if(!b||!actionMask||!g_scrGame||!readable((void*)(g_scrGame+332u),4))return;
  const uint32_t frame=rd<uint32_t>((unsigned char*)g_scrGame,332u);
  if(frame>kV109PreferenceEndFrame||selfWorkers<kV109MinWorkersForBias)return;
  if(InterlockedCompareExchange(&g_v109Nudges,0,0)>=kV109MaxNudges)return;
  const int workerAction=team109BestPureAction(true);
  const int armyAction=team109BestPureAction(false);
  if(workerAction<0||armyAction<0||workerAction==armyAction)return;
  if(actionMask[workerAction]==0||actionMask[armyAction]==0)return;
  const LONG eligible=InterlockedIncrement(&g_v109EligibleRequests);
  if((eligible%kV109EligibleCadence)!=0)return;
  const LONG last=InterlockedCompareExchange(&g_v109LastBiasFrame,0,0);
  if(last>=0 && frame<(uint32_t)last+kV109CooldownFrames)return;
  // Fail-safe: preserve at least one known valid alternative (armyAction).
  const uint8_t old=actionMask[workerAction];
  actionMask[workerAction]=0;
  InterlockedExchange(&g_v109MaskedOriginal,(LONG)old);
  InterlockedExchange(&g_v109MaskedAction,workerAction);
  InterlockedExchange(&g_v109LastBiasFrame,(LONG)frame);
  const LONG n=InterlockedIncrement(&g_v109Nudges);
  logLine("V109_EARLY_ARMY_BIAS=APPLIED frame="+std::to_string(frame)+
          " nudge="+std::to_string((long)n)+" workers="+std::to_string(selfWorkers)+
          " worker_action="+std::to_string(workerAction)+" army_action="+std::to_string(armyAction)+
          " mode=ONE_REQUEST_MASK_COOLDOWN_PLUTO_ALTERNATIVE");
}

// v112 argument-level early pressure.
//
// Unlike v109, v112 NEVER edits Pluto's 20-way top-level action mask. It learns
// arg1 tokens from Pluto's own emitted Train/Morph commands and temporarily masks
// only a learned worker-production arg token when at least one learned army arg
// token is valid in the SAME request. Pluto still chooses the action and the
// replacement military unit. No fixed build order, unit type, attack timing,
// expansion rule, or tech rule is scripted.
//
// Pressure schedule:
//   frame 0..3999    strong: 2 of 3 eligible requests
//   frame 4000..5999 medium: 1 of 2
//   frame 6000..7499 light : 1 of 3
//   frame >=7500      OFF   : original Pluto strategy, no v112 mask edits
// A strongly negative official Pluto value disables/weakens the opening nudge.
static volatile LONG g_v112WorkerArgVotes[233]{};
static volatile LONG g_v112ArmyArgVotes[233]{};
static volatile LONG g_v112EligibleRequests=0;
static volatile LONG g_v112Biases=0;
static volatile LONG g_v112MaskedArg=-1;
static volatile LONG g_v112MaskedArgOriginal=0;
static volatile LONG g_v112LastBiasFrame=-100000;
static volatile LONG g_v112WinKnown=0;
static volatile LONG g_v112WinMilli=0;
static constexpr uint32_t kV112PressureEndFrame=7500u;
static constexpr int kV112MinWorkers=9;
static constexpr int kV112ArgCount=233;

static void team112ResetEarlyPressureState(){
  for(int i=0;i<kV112ArgCount;++i){InterlockedExchange(&g_v112WorkerArgVotes[i],0);InterlockedExchange(&g_v112ArmyArgVotes[i],0);}
  InterlockedExchange(&g_v112EligibleRequests,0);InterlockedExchange(&g_v112Biases,0);
  InterlockedExchange(&g_v112MaskedArg,-1);InterlockedExchange(&g_v112MaskedArgOriginal,0);
  InterlockedExchange(&g_v112LastBiasFrame,-100000);
  InterlockedExchange(&g_v112WinKnown,0);InterlockedExchange(&g_v112WinMilli,0);
}
static void team112RestoreArgMaskInView(unsigned char*b){
  const LONG arg=InterlockedExchange(&g_v112MaskedArg,-1);
  const LONG old=InterlockedExchange(&g_v112MaskedArgOriginal,0);
  if(!b||arg<0||arg>=kV112ArgCount||old==0)return;
  auto*argMask=reinterpret_cast<uint8_t*>(b+0x79940u);
  if(readable(argMask,kV112ArgCount))argMask[arg]=(uint8_t)old;
}
static int team112BestPureArg(bool worker,const uint8_t*argMask){
  int best=-1;LONG bestVotes=0;
  for(int i=0;i<kV112ArgCount;++i){
    const LONG w=InterlockedCompareExchange(&g_v112WorkerArgVotes[i],0,0);
    const LONG a=InterlockedCompareExchange(&g_v112ArmyArgVotes[i],0,0);
    const bool pure=worker?(w>0&&a==0):(a>0&&w==0);
    const LONG votes=worker?w:a;
    if(pure&&votes>bestVotes&&(!argMask||argMask[i]!=0)){best=i;bestVotes=votes;}
  }
  return best;
}
static int team112PressureStage(uint32_t frame){
  if(frame>=kV112PressureEndFrame)return 0;
  if(frame<4000u)return 1; // strong
  if(frame<6000u)return 2; // medium
  return 3;                // light
}
static bool team112CadenceAllows(int stage,LONG eligible){
  if(stage==1)return (eligible%3)!=0; // 2/3
  if(stage==2)return (eligible%2)==0; // 1/2
  if(stage==3)return (eligible%3)==0; // 1/3
  return false;
}
static uint32_t team112CooldownForStage(int stage){return stage==1?24u:(stage==2?48u:72u);}
static void team112ApplyEarlyPressureArgBias(unsigned char*b,uint8_t*argMask,int selfWorkers){
  if(!b||!argMask||!g_scrGame||!readable((void*)(g_scrGame+332u),4))return;
  // Defensive restore if a previous response was skipped before normal restore.
  team112RestoreArgMaskInView(b);
  const uint32_t frame=rd<uint32_t>((unsigned char*)g_scrGame,332u);
  if(frame>=kV112PressureEndFrame||selfWorkers<kV112MinWorkers)return;
  int stage=team112PressureStage(frame);if(stage==0)return;
  const LONG winKnown=InterlockedCompareExchange(&g_v112WinKnown,0,0);
  const LONG winMilli=InterlockedCompareExchange(&g_v112WinMilli,0,0);
  if(winKnown){
    if(winMilli<=-350)return;               // badly losing: original Pluto only
    if(winMilli<=-200)stage=3;             // losing: only light pressure
  }
  const int workerArg=team112BestPureArg(true,argMask);
  const int armyArg=team112BestPureArg(false,argMask);
  if(workerArg<0||armyArg<0||workerArg==armyArg)return;
  if(argMask[workerArg]==0||argMask[armyArg]==0)return;
  const LONG eligible=InterlockedIncrement(&g_v112EligibleRequests);
  if(!team112CadenceAllows(stage,eligible))return;
  const LONG last=InterlockedCompareExchange(&g_v112LastBiasFrame,0,0);
  const uint32_t cooldown=team112CooldownForStage(stage);
  if(last>=0&&frame<(uint32_t)last+cooldown)return;
  const uint8_t old=argMask[workerArg];if(!old)return;
  argMask[workerArg]=0;
  InterlockedExchange(&g_v112MaskedArgOriginal,(LONG)old);
  InterlockedExchange(&g_v112MaskedArg,workerArg);
  InterlockedExchange(&g_v112LastBiasFrame,(LONG)frame);
  const LONG n=InterlockedIncrement(&g_v112Biases);
  logLine("V112_EARLY_PRESSURE=APPLIED frame="+std::to_string(frame)+
          " bias="+std::to_string((long)n)+" stage="+std::to_string(stage)+
          " workers="+std::to_string(selfWorkers)+" worker_arg="+std::to_string(workerArg)+
          " army_arg_available="+std::to_string(armyArg)+" win_milli="+std::to_string((long)winMilli)+
          " mode=ARG_MASK_ONE_REQUEST_PLUTO_CHOOSES_ALTERNATIVE");
}

// v110 observation-only ally separation.
//
// Goal: allied combat units must NOT look like owned army during normal macro /
// production composition reasoning, while still being available as friendly
// combat strength when an actual visible engagement exists.
//
// Stock Pluto still has only three owner semantics (SELF / OTHER / NEUTRAL), so
// v110 does not invent a fourth learned owner. Instead:
//   - every actual ally row is NON-OWNED (NEUTRAL) by default;
//   - an allied combat/support row is exposed as SELF context only while it is
//     within a local radius of an actually visible enemy row in this SAME
//     observation;
//   - ally actor/target masks remain 0, so this never grants control or targeting;
//   - v109 early-army preference code is unchanged and runs after this projection.
//
// This is observation plumbing only. It never orders an attack, defense, retreat,
// production, tech, or expansion action.
static constexpr int kV110AllyCombatContextRadiusPx=512;
static bool team110AllyInCombatContext(int x,int y,const int*enemyX,const int*enemyY,int enemyCount){
  if(!enemyX||!enemyY||enemyCount<=0)return false;
  const long long rr=(long long)kV110AllyCombatContextRadiusPx*(long long)kV110AllyCombatContextRadiusPx;
  for(int i=0;i<enemyCount;++i){
    const long long dx=(long long)x-(long long)enemyX[i];
    const long long dy=(long long)y-(long long)enemyY[i];
    if(dx*dx+dy*dy<=rr)return true;
  }
  return false;
}

static bool team4RewriteShmOwners(void*view){
  if(!view||!g_teamCompatReady||g_teamCompatSelf<0||g_teamCompatSelf>=8)return false;
  auto*b=(unsigned char*)view;
  if(!readable(b,0x100))return false;
  uint32_t magic=0,ack=0;std::memcpy(&magic,b+0x00,4);std::memcpy(&ack,b+0x10,4);
  if(magic!=0x4D534C50u||ack!=0x4D534C50u)return false; // 'PLSM'
  int32_t n=0;std::memcpy(&n,b+0x0c0,4);
  if(n<1||n>1024)return false;
  const size_t intsBytes=(size_t)n*6u*8u,contBytes=(size_t)n*109u*4u;
  if(!readable(b+0x100,intsBytes)||!readable(b+0x0C100,contBytes)||
     !readable(b+0x79100,(size_t)n)||!readable(b+0x79500,(size_t)n)||
     !readable(b+0x79900,20u)||!readable(b+0x79940,233u))return false;
  auto*cat=reinterpret_cast<int64_t*>(b+0x100);
  auto*cont=reinterpret_cast<float*>(b+0x0C100);
  auto*actorMask=reinterpret_cast<uint8_t*>(b+0x79100);
  auto*targetMask=reinterpret_cast<uint8_t*>(b+0x79500);
  auto*actionMask=reinterpret_cast<uint8_t*>(b+0x79900);
  auto*argMask=reinterpret_cast<uint8_t*>(b+0x79940);

  // First pass: resolve actual SCR relation exactly once and collect visible enemy
  // positions. Do NOT rewrite owners yet, because an ally row early in the array
  // may need an enemy row that appears later in the same observation.
  int8_t rowRel[1024]{}; // 0=self,1=ally,2=enemy,3=neutral
  int rowX[1024]{},rowY[1024]{},rowType[1024]{};
  int enemyX[1024]{},enemyY[1024]{},enemyAnchorCount=0;
  int unmatched=0,ambig=0,fallback=0;
  rowRel[0]=0;rowType[0]=(int)cat[0];
  for(int r=1;r<n;++r){
    const int64_t old=cat[(size_t)r*6u+1u];
    rowType[r]=(int)cat[(size_t)r*6u+0u];
    if(old==0){rowRel[r]=0;continue;}
    if(old==2){rowRel[r]=3;continue;}
    if(old!=1){
      logLine("V110_SHM_OWNER_REWRITE=INVALID_OLD_OWNER_FAIL_CLOSED row="+std::to_string(r)+" value="+std::to_string((long long)old));
      return false;
    }
    const int type=rowType[r];
    const int order=(int)cat[(size_t)r*6u+2u];
    const float fx=cont[(size_t)r*109u+0u],fy=cont[(size_t)r*109u+1u];
    const int x=(int)(fx*4096.0f+(fx>=0?0.5f:-0.5f));
    const int y=(int)(fy*4096.0f+(fy>=0?0.5f:-0.5f));
    rowX[r]=x;rowY[r]=y;
    bool usedFallback=false,ambiguous=false,matchedAny=false;
    const int relation=team4MatchOtherRow(type,x,y,order,&usedFallback,&ambiguous,&matchedAny);
    if(usedFallback)++fallback;
    if(ambiguous)++ambig;
    if(!matchedAny)++unmatched;
    if(relation==1){
      rowRel[r]=1;
    }else{
      rowRel[r]=2;
      if(enemyAnchorCount<1024){enemyX[enemyAnchorCount]=x;enemyY[enemyAnchorCount]=y;++enemyAnchorCount;}
    }
  }

  int ally=0,enemy=0,neutral=0,self=0,samples=0;
  int allyCombatExposed=0,allyCombatNeutral=0,allyNonCombatNeutral=0;
  int allyActorMaskCleared=0,allyTargetMaskCleared=0;
  int selfWorkers=0;
  cat[1]=0; // row 0 is the stock self sentinel row, same as v109.
  for(int r=1;r<n;++r){
    const int rel=rowRel[r];
    const int type=rowType[r];
    if(rel==0){
      cat[(size_t)r*6u+1u]=0;++self;
      if(type>=0&&type<BWAPI::UnitTypes::Enum::MAX&&BWAPI::UnitType(type).isWorker())++selfWorkers;
      continue;
    }
    if(rel==3){cat[(size_t)r*6u+1u]=2;++neutral;continue;}
    if(rel==2){cat[(size_t)r*6u+1u]=1;++enemy;continue;}

    ++ally;
    const bool combatCapable=team108AllyIsFriendlyForce(type);
    const bool combatContext=combatCapable&&team110AllyInCombatContext(rowX[r],rowY[r],enemyX,enemyY,enemyAnchorCount);
    // Official stock Pluto vocabulary: 0=self, 1=other/enemy, 2=neutral.
    // Crucially, allied army is NOT SELF outside a local visible engagement.
    cat[(size_t)r*6u+1u]=combatContext?0:2;
    if(combatContext)++allyCombatExposed;
    else if(combatCapable)++allyCombatNeutral;
    else ++allyNonCombatNeutral;
    if(actorMask[r]!=0){actorMask[r]=0;++allyActorMaskCleared;}
    if(targetMask[r]!=0){targetMask[r]=0;++allyTargetMaskCleared;}
    if(samples<8){
      const LONG seq=InterlockedCompareExchange(&g_team4RewriteSeq,0,0);
      if(seq<8)logLine("V110_ALLY_CONTEXT_SAMPLE row="+std::to_string(r)+" type="+std::to_string(type)+
        " combat_capable="+(combatCapable?std::string("1"):std::string("0"))+
        " near_visible_enemy="+(combatContext?std::string("1"):std::string("0"))+
        " model_owner="+std::to_string(combatContext?0:2)+" x="+std::to_string(rowX[r])+" y="+std::to_string(rowY[r]));
      ++samples;
    }
  }

  // v112: top-level action mask bias is intentionally disabled. Only the
  // learned worker arg token may be hidden for one request before frame 7500.
  (void)actionMask;
  team112ApplyEarlyPressureArgBias(b,argMask,selfWorkers);
  const LONG seq=InterlockedIncrement(&g_team4RewriteSeq);
  if(seq<=16||(seq%64)==0)
    logLine("V110_SHM_OWNER_REWRITE=PASS seq="+std::to_string((long)seq)+" N="+std::to_string(n)+
            " self="+std::to_string(self)+" ally="+std::to_string(ally)+" enemy="+std::to_string(enemy)+
            " neutral="+std::to_string(neutral)+" enemy_anchors="+std::to_string(enemyAnchorCount)+
            " ally_combat_exposed="+std::to_string(allyCombatExposed)+
            " ally_combat_neutral="+std::to_string(allyCombatNeutral)+
            " ally_noncombat_neutral="+std::to_string(allyNonCombatNeutral)+
            " fallback="+std::to_string(fallback)+" unmatched="+std::to_string(unmatched)+" ambiguous="+std::to_string(ambig)+
            " ally_actor_mask_cleared="+std::to_string(allyActorMaskCleared)+
            " ally_target_mask_cleared="+std::to_string(allyTargetMaskCleared));
  if(unmatched>0 && (seq<=16||(seq%64)==0))
    logLine("V110_OWNER_MATCH_DIAG unmatched="+std::to_string(unmatched)+" source=LEGACY_SHADOW_EXACT_OBSERVATION");
  return true;
}
static bool team4ClientShmReady(){
  if(!g_team4PlutoModule)return false;
  auto*c=(unsigned char*)g_team4PlutoModule+0x52140u; // DAT_63fd2140 - image base 0x63f80000
  if(!readable(c,0x20))return false;
  uint8_t use=0;std::memcpy(&use,c+0x1c,1);
  uint32_t shm=0;std::memcpy(&shm,c+0x18,4);
  if(!use||!shm||!readable((void*)(uintptr_t)shm,0x20))return false;
  uint32_t magic=0,ack=0;std::memcpy(&magic,(void*)(uintptr_t)shm,4);std::memcpy(&ack,(void*)((uintptr_t)shm+0x10),4);
  return magic==0x4D534C50u&&ack==0x4D534C50u;
}
static BOOL WINAPI team4SetEventHook(HANDLE h){
  if(InterlockedCompareExchange(&g_team4RewriteEnabled,0,0)!=0 && !g_insideTeam4SetEvent&&g_team4PlutoModule){
    auto*c=(unsigned char*)g_team4PlutoModule+0x52140u;
    if(readable(c,0x20)){
      HANDLE req=nullptr;uint32_t shm=0;uint8_t use=0;
      std::memcpy(&req,c+0x10,sizeof(req));std::memcpy(&shm,c+0x18,4);std::memcpy(&use,c+0x1c,1);
      if(req&&h==req&&use&&shm){
        g_insideTeam4SetEvent=true;
        if(!team4RewriteShmOwners((void*)(uintptr_t)shm)){
          InterlockedExchange(&g_team4RewriteFatal,1);
          logLine("TEAM4_SHM_OWNER_REWRITE=FAIL_CLOSED");
        }
        g_insideTeam4SetEvent=false;
      }
    }
  }
  return g_originalSetEvent?g_originalSetEvent(h):FALSE;
}
static bool installTeam4OwnerRewriteHook(HMODULE pluto){
  g_team4PlutoModule=pluto;
  HMODULE k=GetModuleHandleW(L"kernel32.dll");
  auto target=(LPVOID)(k?GetProcAddress(k,"SetEvent"):nullptr);
  if(!target){logLine("TEAM4_SET_EVENT_HOOK=NO_TARGET_FAIL_CLOSED");return false;}
  MH_STATUS st=MH_Initialize();if(st==MH_ERROR_ALREADY_INITIALIZED)st=MH_OK;
  if(st==MH_OK)st=MH_CreateHook(target,(LPVOID)&team4SetEventHook,reinterpret_cast<LPVOID*>(&g_originalSetEvent));
  if(st==MH_OK)st=MH_EnableHook(target);
  if(st!=MH_OK){logLine("TEAM4_SET_EVENT_HOOK=MINHOOK_FAIL code="+std::to_string((int)st));return false;}
  logLine("TEAM4_SET_EVENT_HOOK=INSTALLED");
  return true;
}

// Legacy BWAPI command-staging ABI used directly by the pinned Pluto binary.
// v99 keeps Pluto observation/inference/decision on the proven resident worker,
// translates its original 1.16.1 gameplay packets using the verified rules,
// then queues those SC:R packets for submission ONLY from SC:R's verified game
// thread frame callsites. A one-frame pending turn preserves the reference
// bridge's measured observation-to-effect delay. Any mismatch fails closed.
alignas(16) static unsigned char g_legacyCommandBuffer[512]{};
static volatile uint32_t g_legacyCommandSize=0;
static uint32_t g_legacyMultiplayerFlag=0;
static uint16_t g_legacyGameModeWord=2;
static constexpr LONG kMaxCapturedFlushes=16;
static volatile LONG g_legacyFlushCount=0;
static volatile LONG g_legacyFlushOverflow=0;
static uint32_t g_legacyFlushSizes[kMaxCapturedFlushes]{};
alignas(16) static unsigned char g_legacyFlushBuffers[kMaxCapturedFlushes][512]{};

static unsigned char* team109ClientShmView(){
  if(!g_team4PlutoModule)return nullptr;
  auto*c=(unsigned char*)g_team4PlutoModule+0x52140u;
  if(!readable(c,0x20))return nullptr;
  uint8_t use=0;uint32_t shm=0;std::memcpy(&shm,c+0x18,4);std::memcpy(&use,c+0x1c,1);
  if(!use||!shm||!readable((void*)(uintptr_t)shm,0x85f40u+0x28u))return nullptr;
  return (unsigned char*)(uintptr_t)shm;
}
static void team109RestoreOneRequestMask(){
  const LONG action=InterlockedExchange(&g_v109MaskedAction,-1);
  const LONG old=InterlockedExchange(&g_v109MaskedOriginal,0);
  if(action<0||action>=20||old==0)return;
  auto*b=team109ClientShmView();if(!b)return;
  auto*mask=reinterpret_cast<uint8_t*>(b+0x79900u);
  if(readable(mask,20))mask[action]=(uint8_t)old;
}
struct Team109ProdEvidence{bool worker=false;bool army=false;int workerType=-1;int armyType=-1;};
static void team109ClassifyLegacyBuffer(const uint8_t*bytes,size_t length,Team109ProdEvidence&e){
  if(!bytes||!length)return;
  for(size_t offset=0;offset<length;){
    const uint8_t*p=bytes+offset;const uint8_t id=p[0];size_t size=0;
    if(id>=9&&id<=11){if(length-offset<2||p[1]>12)return;size=2u+(size_t)p[1]*2u;}
    else {size=legacyFixedCommandLength(id);if(!size)return;}
    if(size>length-offset)return;
    if((id==0x1f||id==0x23) && size>=3){
      const int type=(int)legacyWord(p+1);
      if(type>=0&&type<BWAPI::UnitTypes::Enum::MAX){
        BWAPI::UnitType ut(type);
        if(ut.isWorker()){e.worker=true;e.workerType=type;}
        else if(team108AllyIsFriendlyForce(type)){e.army=true;e.armyType=type;}
      }
    }else if(id==0x27){
      // Carrier interceptor / Reaver scarab production is unambiguously army-side.
      e.army=true;e.armyType=-2;
    }
    offset+=size;
  }
}
static void team109ObserveDecision(uint32_t frame){
  // First restore the temporary request mask so no preference state can leak
  // into the next request if Pluto reuses the SHM buffer.
  team109RestoreOneRequestMask();
  auto*b=team109ClientShmView();if(!b||!readable(b+0x85f40u,0x28u))return;
  int64_t action=-1,arg1=0,arg2=0,arg3=0;float value=0.0f;
  std::memcpy(&action,b+0x85f40u,8);std::memcpy(&arg1,b+0x85f48u,8);
  std::memcpy(&arg2,b+0x85f50u,8);std::memcpy(&arg3,b+0x85f58u,8);std::memcpy(&value,b+0x85f60u,4);
  if(action<0||action>=20)return;
  Team109ProdEvidence e{};
  LONG flushes=InterlockedCompareExchange(&g_legacyFlushCount,0,0);
  if(flushes<0)flushes=0;if(flushes>kMaxCapturedFlushes)flushes=kMaxCapturedFlushes;
  for(LONG i=0;i<flushes;++i){uint32_t n=g_legacyFlushSizes[i];if(n>512u)n=512u;team109ClassifyLegacyBuffer(g_legacyFlushBuffers[i],n,e);}
  uint32_t n=g_legacyCommandSize;if(n>512u)n=512u;team109ClassifyLegacyBuffer(g_legacyCommandBuffer,n,e);
  if(e.worker==e.army)return; // none or mixed: do not learn a potentially shared action.
  LONG w=0,a=0;
  if(e.worker){w=InterlockedIncrement(&g_v109WorkerVotes[(int)action]);a=InterlockedCompareExchange(&g_v109ArmyVotes[(int)action],0,0);}
  else {a=InterlockedIncrement(&g_v109ArmyVotes[(int)action]);w=InterlockedCompareExchange(&g_v109WorkerVotes[(int)action],0,0);}
  if((w+a)<=4 || ((w+a)%8)==0){
    logLine("V109_PREF_LEARN frame="+std::to_string(frame)+" action="+std::to_string((long long)action)+
      " evidence="+(e.worker?std::string("WORKER_PRODUCTION"):std::string("ARMY_PRODUCTION"))+
      " unit_type="+std::to_string(e.worker?e.workerType:e.armyType)+
      " worker_votes="+std::to_string((long)w)+" army_votes="+std::to_string((long)a)+
      " arg1="+std::to_string((long long)arg1)+" arg2="+std::to_string((long long)arg2)+
      " arg3="+std::to_string((long long)arg3));
  }
}
static void team109LogPreferenceSummary(uint32_t frame){
  std::ostringstream s;s<<"V109_PREF_SUMMARY frame="<<frame<<" nudges="<<InterlockedCompareExchange(&g_v109Nudges,0,0)<<" map=";
  bool first=true;for(int i=0;i<20;++i){LONG w=InterlockedCompareExchange(&g_v109WorkerVotes[i],0,0),a=InterlockedCompareExchange(&g_v109ArmyVotes[i],0,0);if(!w&&!a)continue;if(!first)s<<",";first=false;s<<i<<":W"<<w<<"/A"<<a;}
  logLine(s.str());
}

static void team112RestoreOneRequestArgMask(){
  auto*b=team109ClientShmView();if(!b)return;
  team112RestoreArgMaskInView(b);
}
static void team112ObserveDecision(uint32_t frame){
  // Restore immediately after Pluto returns so no arg preference leaks into the
  // next request, then learn the response arg token from Pluto's real command.
  team112RestoreOneRequestArgMask();
  auto*b=team109ClientShmView();if(!b||!readable(b+0x85f40u,0x28u))return;
  int64_t action=-1,arg1=-1,arg2=0,arg3=0;
  std::memcpy(&action,b+0x85f40u,8);std::memcpy(&arg1,b+0x85f48u,8);
  std::memcpy(&arg2,b+0x85f50u,8);std::memcpy(&arg3,b+0x85f58u,8);
  if(arg1<0||arg1>=kV112ArgCount)return;
  Team109ProdEvidence e{};
  LONG flushes=InterlockedCompareExchange(&g_legacyFlushCount,0,0);
  if(flushes<0)flushes=0;if(flushes>kMaxCapturedFlushes)flushes=kMaxCapturedFlushes;
  for(LONG i=0;i<flushes;++i){uint32_t n=g_legacyFlushSizes[i];if(n>512u)n=512u;team109ClassifyLegacyBuffer(g_legacyFlushBuffers[i],n,e);}
  uint32_t n=g_legacyCommandSize;if(n>512u)n=512u;team109ClassifyLegacyBuffer(g_legacyCommandBuffer,n,e);
  if(e.worker==e.army)return;
  LONG w=0,a=0;
  if(e.worker){w=InterlockedIncrement(&g_v112WorkerArgVotes[(int)arg1]);a=InterlockedCompareExchange(&g_v112ArmyArgVotes[(int)arg1],0,0);}
  else {a=InterlockedIncrement(&g_v112ArmyArgVotes[(int)arg1]);w=InterlockedCompareExchange(&g_v112WorkerArgVotes[(int)arg1],0,0);}
  if((w+a)<=4||((w+a)%8)==0){
    logLine("V112_ARG_LEARN frame="+std::to_string(frame)+" action="+std::to_string((long long)action)+
      " arg1="+std::to_string((long long)arg1)+
      " evidence="+(e.worker?std::string("WORKER_PRODUCTION"):std::string("ARMY_PRODUCTION"))+
      " unit_type="+std::to_string(e.worker?e.workerType:e.armyType)+
      " worker_votes="+std::to_string((long)w)+" army_votes="+std::to_string((long)a)+
      " arg2="+std::to_string((long long)arg2)+" arg3="+std::to_string((long long)arg3));
  }
}
static void team112LogPressureSummary(uint32_t frame){
  std::ostringstream out;out<<"V112_EARLY_PRESSURE_SUMMARY frame="<<frame
    <<" biases="<<InterlockedCompareExchange(&g_v112Biases,0,0)
    <<" eligible="<<InterlockedCompareExchange(&g_v112EligibleRequests,0,0)
    <<" frame7500_plus_original_pluto=1 arg_map=";
  bool first=true;
  for(int i=0;i<kV112ArgCount;++i){
    LONG w=InterlockedCompareExchange(&g_v112WorkerArgVotes[i],0,0),a=InterlockedCompareExchange(&g_v112ArmyArgVotes[i],0,0);
    if(!w&&!a)continue;if(!first)out<<",";first=false;out<<i<<":W"<<w<<"/A"<<a;
  }
  logLine(out.str());
}

// v111 reads the official Pluto response struct directly from the existing SHM.
// Response layout is <int64 action,arg,pos,unit,float win,float logprob> (0x28 bytes).
// Official/reconstructed semantics: win = P(win) - P(loss), therefore
// P(win) = (win + 1) / 2 for this two-outcome head. Logging is observation-only.
static uint32_t g_v111LastWinRespSeq=0;
static uint32_t g_v111LastWinLogFrame=0;
static bool g_v111HaveWin=false;
static float g_v111LastWin=0.0f;
static float g_v111LastLoggedWin=0.0f;
static float g_v111MinWin=1.0f;
static float g_v111MaxWin=-1.0f;
static void team111ResetWinValueState(){
  g_v111LastWinRespSeq=0;g_v111LastWinLogFrame=0;g_v111HaveWin=false;
  g_v111LastWin=0.0f;g_v111LastLoggedWin=0.0f;g_v111MinWin=1.0f;g_v111MaxWin=-1.0f;
}
static void team111ObserveWinValue(uint32_t frame){
  auto*b=team109ClientShmView();if(!b||!readable(b+0x80u,4)||!readable(b+0x85f40u,0x28u))return;
  uint32_t respSeq=0;std::memcpy(&respSeq,b+0x80u,4);
  if(!respSeq||respSeq==g_v111LastWinRespSeq)return;
  g_v111LastWinRespSeq=respSeq;
  int64_t action=-1;float win=0.0f,logprob=0.0f;
  std::memcpy(&action,b+0x85f40u,8);std::memcpy(&win,b+0x85f60u,4);std::memcpy(&logprob,b+0x85f64u,4);
  if(!std::isfinite(win)||!std::isfinite(logprob)||win<-1.001f||win>1.001f){
    logLine("V111_PLUTO_WIN_VALUE=INVALID_NONFATAL frame="+std::to_string(frame)+" resp_seq="+std::to_string(respSeq));return;
  }
  g_v111LastWin=win;InterlockedExchange(&g_v112WinMilli,(LONG)std::lround((double)win*1000.0));InterlockedExchange(&g_v112WinKnown,1);if(!g_v111HaveWin){g_v111MinWin=g_v111MaxWin=win;}else{g_v111MinWin=std::min(g_v111MinWin,win);g_v111MaxWin=std::max(g_v111MaxWin,win);}
  const bool due=!g_v111HaveWin || frame>=g_v111LastWinLogFrame+240u || std::fabs(win-g_v111LastLoggedWin)>=0.10f;
  g_v111HaveWin=true;
  if(!due)return;
  g_v111LastWinLogFrame=frame;g_v111LastLoggedWin=win;
  const double pwin=(double)(win+1.0f)*50.0;
  char line[320]{};
  std::snprintf(line,sizeof(line),"V111_PLUTO_WIN_VALUE frame=%u resp_seq=%u value=%.6f pwin_percent=%.2f action=%lld logprob=%.6f source=OFFICIAL_SHM_RESPONSE",
    frame,respSeq,(double)win,pwin,(long long)action,(double)logprob);
  logLine(line);
}
static void team111LogWinValueSummary(uint32_t frame,bool won){
  if(!g_v111HaveWin){logLine("V111_PLUTO_WIN_SUMMARY frame="+std::to_string(frame)+" available=0 won="+(won?std::string("1"):std::string("0")));return;}
  char line[256]{};
  std::snprintf(line,sizeof(line),"V111_PLUTO_WIN_SUMMARY frame=%u available=1 last=%.6f min=%.6f max=%.6f pwin_last_percent=%.2f won=%d",
    frame,(double)g_v111LastWin,(double)g_v111MinWin,(double)g_v111MaxWin,(double)((g_v111LastWin+1.0f)*50.0),won?1:0);
  logLine(line);
}

static std::string packetHex(const ScrPacket& p);
struct PendingScrTurn{uint32_t frame=0;std::vector<ScrPacket> packets;};
static SRWLOCK g_pendingTurnLock=SRWLOCK_INIT;
static std::vector<PendingScrTurn> g_pendingTurns;
static volatile LONG g_commandSendFailed=0;
static volatile LONG g_gameThreadHookReady=0;
static volatile LONG g_gameThreadHookSeen=0;
static volatile LONG g_submittedPackets=0;
static volatile LONG g_matchCommandsArmed=0;
static volatile LONG g_translateLogSequence=0;
static volatile LONG g_sendLogSequence=0;
static DWORD g_gameThreadId=0;
static uint32_t g_lastHookFrame=0;
using PFNGetTickCount=DWORD (WINAPI*)();
static PFNGetTickCount g_originalGetTickCount=nullptr;
static thread_local bool g_insideGameTickHook=false;
static volatile DWORD g_sendSehCode=0;

static bool executableAddress(uintptr_t p){
  MEMORY_BASIC_INFORMATION mi{};if(!p||!VirtualQuery((void*)p,&mi,sizeof(mi)))return false;
  if(mi.State!=MEM_COMMIT || (mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
  const DWORD x=mi.Protect&0xffu;
  return x==PAGE_EXECUTE||x==PAGE_EXECUTE_READ||x==PAGE_EXECUTE_READWRITE||x==PAGE_EXECUTE_WRITECOPY;
}
static bool sendPacketSeh(void (__cdecl*send)(const uint8_t*,size_t),const ScrPacket&packet){
  g_sendSehCode=0;
  __try{send(packet.data(),packet.size());return true;}
  __except((g_sendSehCode=GetExceptionCode(),EXCEPTION_EXECUTE_HANDLER)){return false;}
}
static void clearPendingTurns(){AcquireSRWLockExclusive(&g_pendingTurnLock);g_pendingTurns.clear();ReleaseSRWLockExclusive(&g_pendingTurnLock);}
static bool queueTranslatedTurn(uint32_t frame,std::vector<ScrPacket>&&packets){
  if(packets.empty())return true;
  if(InterlockedCompareExchange(&g_commandSendFailed,0,0))return false;
  bool ok=true;AcquireSRWLockExclusive(&g_pendingTurnLock);
  if(g_pendingTurns.size()>=128u)ok=false;
  else g_pendingTurns.push_back(PendingScrTurn{frame,std::move(packets)});
  ReleaseSRWLockExclusive(&g_pendingTurnLock);
  if(!ok){InterlockedExchange(&g_commandSendFailed,1);logLine("scr_command_pending=OVERFLOW_FAIL_CLOSED");}
  return ok;
}
static void drainPendingTurnsOnGameThread(uint32_t frame){
  if(InterlockedCompareExchange(&g_commandSendFailed,0,0))return;
  if(profileReadU32(0x01244580u)){InterlockedExchange(&g_commandSendFailed,1);clearPendingTurns();logLine("scr_send_command=REPLAY_REJECTED_FAIL_CLOSED");return;}
  if(g_lastHookFrame && frame<g_lastHookFrame){clearPendingTurns();logLine("scr_game_thread.frame_reset pending=DISCARDED");}
  g_lastHookFrame=frame;
  std::vector<PendingScrTurn> due;
  AcquireSRWLockExclusive(&g_pendingTurnLock);
  for(auto it=g_pendingTurns.begin();it!=g_pendingTurns.end();){
    if(it->frame>=frame){++it;continue;}
    due.push_back(std::move(*it));it=g_pendingTurns.erase(it);
  }
  ReleaseSRWLockExclusive(&g_pendingTurnLock);
  if(due.empty())return;
  const uintptr_t sendVa=profileSlotVA(0x007DA250u);
  if(!executableAddress(sendVa)){
    InterlockedExchange(&g_commandSendFailed,1);clearPendingTurns();logLine("scr_send_command=ADDRESS_NOT_EXECUTABLE_FAIL_CLOSED");return;
  }
  auto send=reinterpret_cast<void (__cdecl*)(const uint8_t*,size_t)>(sendVa);
  for(auto&turn:due){
    unsigned sent=0;
    for(auto&packet:turn.packets){
      if(packet.empty()||packet.size()>512u||!sendPacketSeh(send,packet)){
        InterlockedExchange(&g_commandSendFailed,1);clearPendingTurns();
        logLine("scr_send_command=SEH_OR_PACKET_FAIL_CLOSED code="+std::to_string((unsigned long)g_sendSehCode));return;
      }
      ++sent;InterlockedIncrement(&g_submittedPackets);
    }
    const LONG sendSeq=InterlockedIncrement(&g_sendLogSequence);
    if(sendSeq<=12 || (sendSeq%32)==0)logLine("scr_send_command=PASS seq="+std::to_string((long)sendSeq)+" game_frame="+std::to_string(frame)+" queued_frame="+std::to_string(turn.frame)+" packets="+std::to_string(sent)+" first="+(turn.packets.empty()?std::string():packetHex(turn.packets.front())));
  }
}
static DWORD WINAPI gameTickHook(){
  const uintptr_t caller=(uintptr_t)_ReturnAddress();
  const bool frameCall=caller==profileSlotVA(0x0076E02Fu)||caller==profileSlotVA(0x0077D112u);
  if(frameCall && InterlockedCompareExchange(&g_gameThreadHookReady,0,0) && !g_insideGameTickHook){
    g_insideGameTickHook=true;g_gameThreadId=GetCurrentThreadId();
    if(InterlockedCompareExchange(&g_gameThreadHookSeen,1,0)==0)
      logLine("scr_game_thread_hook=ACTIVE thread="+std::to_string((unsigned long)g_gameThreadId)+" caller="+std::to_string((unsigned long)caller));
    if(InterlockedCompareExchange(&g_matchCommandsArmed,0,0) && g_scrGame && readable((void*)(g_scrGame+332),4))drainPendingTurnsOnGameThread(rd<uint32_t>((unsigned char*)g_scrGame,332));
    g_insideGameTickHook=false;
  }
  return g_originalGetTickCount?g_originalGetTickCount():0;
}
static bool installGameThreadCommandHook(){
  const uintptr_t importSlot=profileSlotVA(0x00DD01C4u);
  if(!importSlot||!readable((void*)importSlot,4)){logLine("scr_game_thread_hook=IMPORT_SLOT_UNREADABLE");return false;}
  uintptr_t target=0;memcpy(&target,(void*)importSlot,4);
  auto kernel=GetModuleHandleW(L"kernel32.dll");
  const uintptr_t expected=(uintptr_t)(kernel?GetProcAddress(kernel,"GetTickCount"):nullptr);
  const uintptr_t sendVa=profileSlotVA(0x007DA250u);
  logLine("scr_game_thread_hook.import="+std::to_string((unsigned long)target)+" winapi="+std::to_string((unsigned long)expected));
  logLine("scr_send_command.addr="+std::to_string((unsigned long)sendVa));
  if(!expected||!executableAddress(expected)){logLine("scr_game_thread_hook=GETTICKCOUNT_NOT_EXECUTABLE_FAIL_CLOSED");return false;}
  if(target!=expected)logLine("scr_game_thread_hook.import_note=IAT_TARGET_DIFFERS_FROM_WINAPI_ACCEPTED_REFERENCE_BEHAVIOR");
  if(!executableAddress(sendVa)){logLine("scr_send_command=PROFILE_ADDRESS_REJECTED_FAIL_CLOSED");return false;}
  MH_STATUS st=MH_Initialize();if(st==MH_ERROR_ALREADY_INITIALIZED)st=MH_OK;
  if(st==MH_OK)st=MH_CreateHook((LPVOID)expected,(LPVOID)&gameTickHook,reinterpret_cast<LPVOID*>(&g_originalGetTickCount));
  if(st==MH_OK)st=MH_EnableHook((LPVOID)expected);
  if(st!=MH_OK){logLine("scr_game_thread_hook=MINHOOK_FAIL code="+std::to_string((int)st));return false;}
  InterlockedExchange(&g_gameThreadHookReady,1);
  logLine("scr_game_thread_hook=INSTALLED callsite_a="+std::to_string((unsigned long)profileSlotVA(0x0076E02Fu))+" callsite_b="+std::to_string((unsigned long)profileSlotVA(0x0077D112u)));
  return true;
}

static void __cdecl legacyCommandFlushStub(){
  uint32_t n=g_legacyCommandSize;if(n>sizeof(g_legacyCommandBuffer))n=(uint32_t)sizeof(g_legacyCommandBuffer);
  LONG index=InterlockedIncrement(&g_legacyFlushCount)-1;
  if(index>=0&&index<kMaxCapturedFlushes){g_legacyFlushSizes[index]=n;if(n)memcpy(g_legacyFlushBuffers[index],g_legacyCommandBuffer,n);}
  else InterlockedExchange(&g_legacyFlushOverflow,1);
  g_legacyCommandSize=0;
}

static uint32_t profilePlayersCandidate(){
  const uint32_t a=profileReadU32(0x0101F0E4u);
  const uint32_t b=profileReadU32(0x01240E38u);
  if(!a&&!b)return 0;
  return (0xFB5969C2u-a)^b;
}

static int scorePlayersCandidate(uint32_t p){
  if(!p||!readable((void*)(uintptr_t)p,kLegacyPlayersBytes))return -1;
  int score=0;
  for(int i=0;i<12;i++){
    auto*r=(unsigned char*)(uintptr_t)(p+i*36u);
    uint32_t id=rd<uint32_t>(r,0);
    uint8_t type=rd<uint8_t>(r,8),race=rd<uint8_t>(r,9),team=rd<uint8_t>(r,10);
    if(id<16)score+=2;
    if(type<16)score+=3;
    if(race<8)score+=3;
    if(team<16)score+=2;
  }
  return score;
}

static bool resolveLegacyPlayers(){
  const uint32_t cand=profilePlayersCandidate();
  const int score=scorePlayersCandidate(cand);
  logLine("legacy_players.profile_candidate="+std::to_string((unsigned long)cand)+" score="+std::to_string(score));
  if(score<80){logLine("legacy_players.select=REJECTED");return false;}
  g_scrPlayers=cand;
  memcpy(g_legacyPlayersShadow,(void*)(uintptr_t)g_scrPlayers,kLegacyPlayersBytes);
  logLine("legacy_players.select=PROFILE_VALIDATED");
  logLine("legacy_players.scr_base="+std::to_string((unsigned long)g_scrPlayers));
  for(int i=0;i<8;i++){
    auto*r=g_legacyPlayersShadow+i*36u;
    logLine("legacy_players.slot["+std::to_string(i)+"].type="+std::to_string((int)rd<uint8_t>(r,8))+
            " race="+std::to_string((int)rd<uint8_t>(r,9))+" team="+std::to_string((int)rd<uint8_t>(r,10)));
  }
  return true;
}

static bool refreshLegacyPlayers(){
  const uint32_t now=profilePlayersCandidate();
  if(!now||scorePlayersCandidate(now)<80)return false;
  if(now!=g_scrPlayers){logLine("legacy_players.pointer_changed="+std::to_string((unsigned long)g_scrPlayers)+"->"+std::to_string((unsigned long)now));g_scrPlayers=now;}
  memcpy(g_legacyPlayersShadow,(void*)(uintptr_t)g_scrPlayers,kLegacyPlayersBytes);
  return true;
}

// v99: mirror SCR's real participant/team/alliance state into BWAPI GameData.
// This is observation compatibility only: Pluto still performs all strategy/decision making.
static bool projectRealPlayerRelations(BWAPI::GameData& d,bool logValues){
  if(!g_scrGame||!g_scrPlayers||!readable((void*)g_scrGame,kScrGameSize)||!readable((void*)(uintptr_t)g_scrPlayers,kLegacyPlayersBytes))return false;
  const uintptr_t gameTypeBase=profileSlotVA(0x01240E58u);
  if(!gameTypeBase||!readable((void*)(gameTypeBase+40u),2))return false;
  uint16_t gameType=0;memcpy(&gameType,(void*)(gameTypeBase+40u),2);
  d.gameType=gameType;d.playerCount=12;d.forceCount=(d.gameType==BWAPI::GameTypes::Top_vs_Bottom)?3:1;d.enemy=-1;d.neutral=11;
  if(d.forceCount==3){std::strcpy(d.forces[1].name,"Top");std::strcpy(d.forces[2].name,"Bottom");}
  for(unsigned i=0;i<12;++i){
    auto& p=d.players[i];auto*raw=(unsigned char*)(uintptr_t)(g_scrPlayers+i*36u);
    p.race=rd<uint8_t>(raw,9);p.type=rd<uint8_t>(raw,8);p.isNeutral=(i==11);
    p.isParticipating=i<8 && (p.type==BWAPI::PlayerTypes::Player || p.type==BWAPI::PlayerTypes::Computer);
    const uint8_t team=rd<uint8_t>(raw,10);p.force=(p.isParticipating&&d.forceCount==3&&team<=2)?team:0;
    p.startLocationX=p.startLocationY=-1;
    for(unsigned j=0;j<12;++j){
      auto*other=(unsigned char*)(uintptr_t)(g_scrPlayers+j*36u);
      const uint8_t ot=rd<uint8_t>(other,8);
      const bool otherParticipates=j<8 && (ot==BWAPI::PlayerTypes::Player || ot==BWAPI::PlayerTypes::Computer);
      const uint8_t alliance=rd<uint8_t>((unsigned char*)g_scrGame,58692u+i*12u+j);
      p.isAlly[j]=(i==j)||(p.isParticipating&&otherParticipates&&alliance!=0);
      p.isEnemy[j]=p.isParticipating&&otherParticipates&&!p.isAlly[j];
    }
    if(i<8){
      const uint16_t sx=rd<uint16_t>((unsigned char*)g_scrGame,58928u+i*4u);
      const uint16_t sy=rd<uint16_t>((unsigned char*)g_scrGame,58928u+i*4u+2u);
      if(i==(unsigned)d.self&&sx&&sy){p.startLocationX=(int)sx/32-2;p.startLocationY=(int)sy/32-1;}
    }
    if(d.enemy<0&&p.isParticipating&&i!=(unsigned)d.self&&p.isEnemy[d.self])d.enemy=(int)i;
  }
  if(logValues){
    logLine("gamedata.relations=BOUND_REAL_SCR gameType="+std::to_string((int)gameType)+" forceCount="+std::to_string(d.forceCount)+" self="+std::to_string(d.self)+" enemy="+std::to_string(d.enemy));
    for(unsigned i=0;i<8;++i)if(d.players[i].isParticipating){
      auto*raw=(unsigned char*)(uintptr_t)(g_scrPlayers+i*36u);
      logLine("gamedata.relation.player["+std::to_string(i)+"].type="+std::to_string((int)d.players[i].type)+" race="+std::to_string((int)d.players[i].race)+" team="+std::to_string((int)rd<uint8_t>(raw,10))+" force="+std::to_string((int)d.players[i].force)+" ally_to_self="+std::to_string((int)d.players[i].isAlly[d.self])+" enemy_to_self="+std::to_string((int)d.players[i].isEnemy[d.self]));
    }
  }
  return d.self>=0&&d.self<8&&d.players[d.self].isParticipating;
}

static bool patchPlutoLegacyPlayersOperands(HMODULE pluto){
  if(!g_legacyPlayersShadow){logLine("reloc98.players_exact=NO_SHADOW");return false;}
  auto*base=(unsigned char*)pluto;size_t found=0,patched=0;uint32_t minRva=0xffffffffu,maxRva=0;
  for(const auto& b:pluto_bindings){
    if(b.expected<kLegacyPlayersBase || b.expected>=kLegacyPlayersBase+kLegacyPlayersBytes)continue;
    ++found;minRva=std::min(minRva,b.rva);maxRva=std::max(maxRva,b.rva);
    if(!readable(base+b.rva,4)){logLine("reloc98.players_exact=RVA_UNREADABLE rva="+std::to_string(b.rva));return false;}
    uint32_t cur=0;memcpy(&cur,base+b.rva,4);
    if(cur!=b.expected){logLine("reloc98.players_exact=MISMATCH rva="+std::to_string(b.rva)+" expected="+std::to_string(b.expected)+" got="+std::to_string(cur));return false;}
    const uint32_t nv=(uint32_t)((uintptr_t)g_legacyPlayersShadow+(uintptr_t)(b.expected-kLegacyPlayersBase));
    DWORD old=0;if(!VirtualProtect(base+b.rva,4,PAGE_EXECUTE_READWRITE,&old)){logLine("reloc98.players_exact=PROTECT_FAIL");return false;}
    memcpy(base+b.rva,&nv,4);FlushInstructionCache(GetCurrentProcess(),base+b.rva,4);DWORD tmp=0;VirtualProtect(base+b.rva,4,old,&tmp);++patched;
  }
  logLine("reloc98.players_exact.found="+std::to_string(found));
  logLine("reloc98.players_exact.rva_min="+std::to_string(minRva)+" rva_max="+std::to_string(maxRva));
  logLine("reloc98.players_exact.patched="+std::to_string(patched));
  if(found!=25 || patched!=found){logLine("reloc98.players_exact=VALIDATION_FAIL");return false;}
  logLine("reloc98.players_operands=PASS_EXACT_BINDINGS");return true;
}

static bool refreshLegacyCommandEnvironment(){
  // SCR profile: is_multiplayer is a byte at analyzed VA 0x123F7BC.
  uintptr_t mpSlot=profileSlotVA(0x0123F7BCu);
  if(!mpSlot||!readable((void*)mpSlot,1))return false;
  uint8_t mp=0;memcpy(&mp,(void*)mpSlot,1);
  g_legacyMultiplayerFlag=mp?1u:0u;
  g_legacyGameModeWord=2; // matches BWAPI/legacy-view game type used by the pinned Pluto port
  return true;
}

static bool patchPlutoLegacyCommandAbi(HMODULE pluto){
  if(!refreshLegacyCommandEnvironment()){logLine("reloc98.command_abi=SCR_ENV_UNREADABLE");return false;}
  auto*base=(unsigned char*)pluto;
  size_t found=0,patched=0,c59688c=0,c596904=0,c654880=0,c654aa0=0,c485a40=0;
  for(const auto& b:pluto_bindings){
    uint32_t nv=0;bool use=true;
    switch(b.expected){
      case 0x0059688cu:nv=(uint32_t)(uintptr_t)&g_legacyMultiplayerFlag;++c59688c;break;
      case 0x00596904u:nv=(uint32_t)(uintptr_t)&g_legacyGameModeWord;++c596904;break;
      case 0x00654880u:nv=(uint32_t)(uintptr_t)g_legacyCommandBuffer;++c654880;break;
      case 0x00654aa0u:nv=(uint32_t)(uintptr_t)&g_legacyCommandSize;++c654aa0;break;
      case 0x00485a40u:nv=(uint32_t)(uintptr_t)&legacyCommandFlushStub;++c485a40;break;
      default:use=false;break;
    }
    if(!use)continue;++found;
    if(!readable(base+b.rva,4)){logLine("reloc98.command_abi=RVA_UNREADABLE rva="+std::to_string(b.rva));return false;}
    uint32_t cur=0;memcpy(&cur,base+b.rva,4);
    if(cur!=b.expected){logLine("reloc98.command_abi=MISMATCH rva="+std::to_string(b.rva)+" expected="+std::to_string(b.expected)+" got="+std::to_string(cur));return false;}
    DWORD old=0;if(!VirtualProtect(base+b.rva,4,PAGE_EXECUTE_READWRITE,&old)){logLine("reloc98.command_abi=PROTECT_FAIL");return false;}
    memcpy(base+b.rva,&nv,4);FlushInstructionCache(GetCurrentProcess(),base+b.rva,4);DWORD tmp=0;VirtualProtect(base+b.rva,4,old,&tmp);++patched;
  }
  logLine("reloc98.command_abi.found="+std::to_string(found)+" patched="+std::to_string(patched));
  logLine("reloc98.command_abi.counts.59688c="+std::to_string(c59688c)+" 596904="+std::to_string(c596904)+" 654880="+std::to_string(c654880)+" 654aa0="+std::to_string(c654aa0)+" 485a40="+std::to_string(c485a40));
  logLine("legacy_command.multiplayer="+std::to_string(g_legacyMultiplayerFlag)+" game_mode_word="+std::to_string((unsigned)g_legacyGameModeWord));
  if(c59688c!=2||c596904!=2||c654880!=4||c654aa0!=8||c485a40!=2||patched!=found){logLine("reloc98.command_abi=VALIDATION_FAIL");return false;}
  g_legacyCommandSize=0;g_legacyFlushCount=0;g_legacyFlushOverflow=0;
  memset(g_legacyCommandBuffer,0,sizeof(g_legacyCommandBuffer));memset(g_legacyFlushSizes,0,sizeof(g_legacyFlushSizes));memset(g_legacyFlushBuffers,0,sizeof(g_legacyFlushBuffers));
  logLine("reloc98.command_abi=PASS_EXACT_BINDINGS");
  return true;
}



static bool team111IsTransientUnitHandleError(const std::string& error){
  static const std::string prefix="expired_or_unmapped_unit_handle=";
  return error.compare(0,prefix.size(),prefix)==0;
}
static void team111ClearCapturedLegacyCommands(){
  g_legacyCommandSize=0;g_legacyFlushCount=0;g_legacyFlushOverflow=0;
  memset(g_legacyCommandBuffer,0,sizeof(g_legacyCommandBuffer));
  memset(g_legacyFlushSizes,0,sizeof(g_legacyFlushSizes));
  memset(g_legacyFlushBuffers,0,sizeof(g_legacyFlushBuffers));
}
static bool team111DropTransientCommandBatch(uint32_t frame,const char* source,const std::string& error){
  const LONG total=InterlockedIncrement(&g_v111TransientCommandDrops);
  const LONG streak=InterlockedIncrement(&g_v111TransientCommandDropStreak);
  if(total<=16 || (total%32)==0){
    logLine(std::string("V1111_COMMAND_TRANSIENT_DROP frame=")+std::to_string(frame)+
      " source="+source+" reason="+error+
      " total="+std::to_string((long)total)+" streak="+std::to_string((long)streak)+
      " policy=DROP_THIS_PLUTO_DECISION_CONTINUE_NEXT_FRAME");
  }
  // Drop the whole decision batch. Sending only a suffix after a stale selection
  // could apply an order to the previous SCR selection, which is unsafe.
  team111ClearCapturedLegacyCommands();
  return true;
}

static std::string hexPrefix(const unsigned char* p,size_t n,size_t cap=96){
  std::ostringstream ss;const char*hex="0123456789ABCDEF";size_t m=std::min(n,cap);
  for(size_t i=0;i<m;i++){ss<<hex[p[i]>>4]<<hex[p[i]&15];}
  if(n>m)ss<<"...";return ss.str();
}

static std::string packetHex(const ScrPacket& p){return hexPrefix(p.data(),p.size(),256);}
static bool translateAndValidateLegacyCommands(uint32_t frame){
  if(g_legacyFlushOverflow){logLine("legacy_command_flush=CAPTURE_OVERFLOW_FAIL_CLOSED");return false;}
  std::vector<ScrPacket> all;LONG flushes=g_legacyFlushCount;
  if(flushes<0||flushes>kMaxCapturedFlushes){logLine("legacy_command_flush=COUNT_INVALID_FAIL_CLOSED");return false;}
  for(LONG i=0;i<flushes;++i){
    const uint32_t n=g_legacyFlushSizes[i];if(n>512u){logLine("legacy_command_flush=OVERFLOW_FAIL_CLOSED");return false;}
    if(!n)continue;
    const LONG detailSeq=InterlockedCompareExchange(&g_translateLogSequence,0,0)+1;
    if(detailSeq<=12 || (detailSeq%32)==0){logLine("legacy_command_flush.legacy_bytes="+std::to_string(n)+" frame="+std::to_string(frame));logLine("legacy_command_flush.legacy_hex="+hexPrefix(g_legacyFlushBuffers[i],n));}
    std::vector<ScrPacket> packets;std::string error;
    if(!translateLegacyCommands(g_legacyFlushBuffers[i],n,packets,error)){
      if(team111IsTransientUnitHandleError(error))return team111DropTransientCommandBatch(frame,"FLUSH",error);
      logLine("legacy_command_flush.translate=FAIL_CLOSED "+error);return false;
    }
    for(auto& p:packets)all.push_back(std::move(p));
  }
  const uint32_t n=g_legacyCommandSize;
  if(n>512u){logLine("legacy_command_queue=OVERFLOW_FAIL_CLOSED bytes="+std::to_string(n));return false;}
  if(n){
    const LONG detailSeq=InterlockedCompareExchange(&g_translateLogSequence,0,0)+1;
    if(detailSeq<=12 || (detailSeq%32)==0){logLine("original_pluto.legacy_command_bytes="+std::to_string(n)+" frame="+std::to_string(frame));logLine("original_pluto.legacy_command_hex="+hexPrefix(g_legacyCommandBuffer,n));}
    std::vector<ScrPacket> packets;std::string error;
    if(!translateLegacyCommands(g_legacyCommandBuffer,n,packets,error)){
      if(team111IsTransientUnitHandleError(error))return team111DropTransientCommandBatch(frame,"QUEUE",error);
      logLine("scr_command_translation=FAIL_CLOSED "+error);return false;
    }
    for(auto& p:packets)all.push_back(std::move(p));
  }
  if(!all.empty()){
    const LONG seq=InterlockedIncrement(&g_translateLogSequence);
    const bool verbose=seq<=12 || (seq%32)==0;
    if(verbose){
      logLine("scr_command_translation=PASS seq="+std::to_string((long)seq)+" packets="+std::to_string(all.size())+" frame="+std::to_string(frame));
      for(size_t i=0;i<all.size();++i)logLine("scr_command_packet["+std::to_string(i)+"]="+packetHex(all[i]));
    }
    const size_t queued=all.size();
    if(!queueTranslatedTurn(frame,std::move(all))){logLine("scr_command_sink=QUEUE_FAIL_CLOSED");return false;}
    if(verbose)logLine("scr_command_sink=QUEUED_FOR_GAME_THREAD packets="+std::to_string(queued)+" frame="+std::to_string(frame));
  }
  InterlockedExchange(&g_v111TransientCommandDropStreak,0);
  team111ClearCapturedLegacyCommands();
  return true;
}

static int profileLocalPlayerCandidate(){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return -1;
  uintptr_t slot=(uintptr_t)exe+(0x00FCACF4u-0x004A0000u);
  if(!readable((void*)slot,4))return -1;
  uint32_t v=0;memcpy(&v,(void*)slot,4);return v<8?(int)v:-1;
}

static uint32_t profileActiveTileCandidate(){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return 0;
  g_activeTileProfileSlot=(uintptr_t)exe+(0x01049478u-0x004A0000u);
  if(!readable((void*)g_activeTileProfileSlot,4))return 0;
  uint32_t p=0;memcpy(&p,(void*)g_activeTileProfileSlot,4);return p;
}

static bool readableNonExecSpan(uintptr_t begin,size_t bytes,unsigned*regionsOut=nullptr){
  if(regionsOut)*regionsOut=0;if(!begin||!bytes)return false;
  const uintptr_t end=begin+(uintptr_t)bytes;if(end<begin)return false;
  uintptr_t cur=begin;unsigned regions=0;
  while(cur<end){
    MEMORY_BASIC_INFORMATION mi{};if(!VirtualQuery((void*)cur,&mi,sizeof(mi)))return false;
    if(mi.State!=MEM_COMMIT||(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
    if(mi.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY))return false;
    const uintptr_t re=(uintptr_t)mi.BaseAddress+(uintptr_t)mi.RegionSize;if(re<=cur)return false;
    cur=std::min(end,re);++regions;if(regions>64)return false;
  }
  if(regionsOut)*regionsOut=regions;return true;
}

static int scoreActiveTileCandidate(uint32_t p,int w,int h,const UnitStore& store,int local,int* checkedOut=nullptr,int* visibleOut=nullptr){
  if(checkedOut)*checkedOut=0;if(visibleOut)*visibleOut=0;
  if(!p||w<=0||h<=0||w>256||h>256)return -1;
  const size_t count=(size_t)w*(size_t)h,bytes=count*4u;unsigned regions=0;
  // The profile slot is the authoritative source. Validate the complete map-tile
  // buffer as committed, non-executable data even if it crosses VM regions.
  if(!readableNonExecSpan((uintptr_t)p,bytes,&regions))return -1;
  std::unordered_set<uint32_t> distinct;
  const size_t step=std::max<size_t>(1,count/1024u);
  for(size_t i=0;i<count;i+=step){
    uint32_t v=0;memcpy(&v,(void*)((uintptr_t)p+i*4u),4);distinct.insert(v);
    if(distinct.size()>256)break;
  }
  if(distinct.size()<2)return -1;
  int score=300+(int)std::min<size_t>(distinct.size(),128u)+(int)std::min<unsigned>(regions,8u)*4;
  // Own-unit visibility is only a diagnostic cross-check. It must not reject
  // the verified profile pointer because unit ownership/list membership can
  // legitimately differ during setup, observers, team games, and transitions.
  int checked=0,visible=0;
  if(local>=0&&local<8){
    auto raws=collectPresentRaw(store);
    for(uintptr_t raw:raws){
      auto*u=(unsigned char*)raw;if(rd<uint8_t>(u,0x4c)!=(uint8_t)local)continue;
      int x=rd<int16_t>(u,0x28),y=rd<int16_t>(u,0x2a),tx=x/32,ty=y/32;
      if(tx<0||tx>=w||ty<0||ty>=h)continue;
      uint32_t f=0;memcpy(&f,(void*)((uintptr_t)p+4u*((size_t)ty*(size_t)w+(size_t)tx)),4);
      ++checked;if((f&(1u<<local))==0)++visible;if(checked>=64)break;
    }
    if(checked>=2 && visible*100>=checked*70)score+=visible*4;
  }
  if(checkedOut)*checkedOut=checked;if(visibleOut)*visibleOut=visible;
  return score;
}

static bool resolveActiveTileArray(const UnitStore& store,int w,int h){
  const int local=profileLocalPlayerCandidate();
  const uint32_t cand=profileActiveTileCandidate();int checked=0,visible=0;
  const int score=scoreActiveTileCandidate(cand,w,h,store,local,&checked,&visible);
  logLine("active_tile.profile_slot="+std::to_string((unsigned long)g_activeTileProfileSlot));
  logLine("active_tile.profile_candidate="+std::to_string((unsigned long)cand)+" score="+std::to_string(score));
  logLine("active_tile.validation_mode=PROFILE_STRUCTURAL_NONEXEC_SPAN");
  logLine("active_tile.local_player="+std::to_string(local)+" own_checked="+std::to_string(checked)+" visible_hits="+std::to_string(visible));
  if(score<300){logLine("active_tile.select=REJECTED");return false;}
  g_scrActiveTileArray=cand;g_legacyActiveTilePtr=cand;
  logLine("active_tile.select=PROFILE_VALIDATED");
  logLine("active_tile.ptr="+std::to_string((unsigned long)g_scrActiveTileArray));
  return true;
}

static bool refreshActiveTileArray(int w,int h,const UnitStore& store){
  if(!g_activeTileProfileSlot||!readable((void*)g_activeTileProfileSlot,4))return false;
  uint32_t now=0;memcpy(&now,(void*)g_activeTileProfileSlot,4);
  if(now!=g_scrActiveTileArray){
    int checked=0,visible=0;int local=profileLocalPlayerCandidate();
    int score=scoreActiveTileCandidate(now,w,h,store,local,&checked,&visible);
    logLine("active_tile.pointer_changed="+std::to_string((unsigned long)g_scrActiveTileArray)+"->"+std::to_string((unsigned long)now)+" score="+std::to_string(score));
    if(score<300)return false;g_scrActiveTileArray=now;
  }
  g_legacyActiveTilePtr=g_scrActiveTileArray;return true;
}


#pragma pack(push,1)
struct Legacy57F1Compat {
  unsigned char pad0[0x1D4];
  short value_f1d4;
  short value_f1d6;
  unsigned char pad1[0x64];
  unsigned long value_f23c;
};
#pragma pack(pop)
static Legacy57F1Compat g_legacy57f1{};

static bool patchAbs32(unsigned char* insn,int immOff,const unsigned char* sig,int sigLen,uintptr_t target,const char* tag){
  if(memcmp(insn,sig,sigLen)!=0){logLine(std::string("reloc98.")+tag+".signature=MISMATCH");return false;}
  if(target>0xFFFFFFFFu){logLine(std::string("reloc98.")+tag+".target=OUT_OF_X86_RANGE");return false;}
  DWORD old=0;if(!VirtualProtect(insn,sigLen,PAGE_EXECUTE_READWRITE,&old)){logLine(std::string("reloc98.")+tag+".protect=FAIL");return false;}
  uint32_t v=(uint32_t)target;memcpy(insn+immOff,&v,4);FlushInstructionCache(GetCurrentProcess(),insn,sigLen);
  DWORD tmp=0;VirtualProtect(insn,sigLen,old,&tmp);
  logLine(std::string("reloc98.")+tag+"=PASS");return true;
}
static bool patchPlutoLegacy57F1Block(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char s1[5]={0xA1,0x3C,0xF2,0x57,0x00};
  const unsigned char s2[7]={0x0F,0xBF,0x05,0xD4,0xF1,0x57,0x00};
  const unsigned char s3[7]={0x0F,0xBF,0x15,0xD6,0xF1,0x57,0x00};
  bool a=patchAbs32(b+0xBC1B,1,s1,5,(uintptr_t)&g_legacy57f1.value_f23c,"rva_bc1b_f23c");
  bool c=patchAbs32(b+0xBC26,3,s2,7,(uintptr_t)&g_legacy57f1.value_f1d4,"rva_bc26_f1d4");
  bool d=patchAbs32(b+0xBC33,3,s3,7,(uintptr_t)&g_legacy57f1.value_f1d6,"rva_bc33_f1d6");
  return a&&c&&d;
}

static bool patchOperand32(HMODULE pluto,uint32_t rva,uint32_t expected,uint32_t value,const char* tag){
  unsigned char* p=(unsigned char*)pluto+rva;
  uint32_t cur=0;memcpy(&cur,p,4);
  if(cur!=expected){
    std::ostringstream os;os<<"reloc98."<<tag<<".expected="<<expected<<" actual="<<cur;logLine(os.str());
    return false;
  }
  DWORD old=0;if(!VirtualProtect(p,4,PAGE_EXECUTE_READWRITE,&old)){logLine(std::string("reloc98.")+tag+".protect=FAIL");return false;}
  memcpy(p,&value,4);FlushInstructionCache(GetCurrentProcess(),p,4);
  DWORD tmp=0;VirtualProtect(p,4,old,&tmp);
  logLine(std::string("reloc98.")+tag+"=PASS");return true;
}

static bool patchPlutoLegacyStartGlobals(HMODULE pluto){
  const int local=profileLocalPlayerCandidate();
  if(local<0||local>=8){logLine("legacy_start.local_player=UNRESOLVED");return false;}
  g_legacyLocalPlayerId=(uint32_t)local;
  memset(g_legacyStartSelection,0,sizeof(g_legacyStartSelection));
  logLine("legacy_start.local_player="+std::to_string(local));
  bool ok=true;
  uintptr_t lp=(uintptr_t)&g_legacyLocalPlayerId;
  if(lp>0xFFFFFFFFu){logLine("reloc98.start_globals=OUT_OF_X86_RANGE");return false;}
  ok=patchOperand32(pluto,0x14BF,0x00512688u,(uint32_t)lp,"rva_14bf_512688")&&ok;
  struct StartCell{uint32_t rva;uint32_t old;};
  static const StartCell cells[]={
    {0x1542,0x005124D8u},{0x154C,0x005124F4u},{0x1556,0x005124DCu},{0x1560,0x005124F8u},
    {0x156A,0x005124E0u},{0x1574,0x005124FCu},{0x157E,0x005124E4u},{0x1588,0x00512500u},
    {0x1592,0x005124E8u},{0x159C,0x00512504u},{0x15A6,0x005124ECu},{0x15B0,0x00512508u},
    {0x15BA,0x005124F0u},{0x15C4,0x0051250Cu}
  };
  for(const auto& c:cells){
    const uint32_t off=c.old-0x005124D8u;
    uintptr_t target=(uintptr_t)g_legacyStartSelection+off;
    if(target>0xFFFFFFFFu){logLine("reloc98.start_globals.cell=OUT_OF_X86_RANGE");return false;}
    std::ostringstream tag;tag<<"rva_"<<std::hex<<c.rva<<"_start_"<<c.old;
    ok=patchOperand32(pluto,c.rva,c.old,(uint32_t)target,tag.str().c_str())&&ok;
  }
  logLine(std::string("reloc98.start_globals=")+(ok?"PASS":"FAIL"));
  return ok;
}

static bool patchPlutoLegacyGameOperands(HMODULE pluto){
  if(!g_legacyGameShadow){logLine("reloc98.game_exact=NO_SHADOW");return false;}
  auto*base=(unsigned char*)pluto;size_t found=0,patched=0;uint32_t minRva=0xffffffffu,maxRva=0;size_t early=0;
  bool aFrame=false,aMapW=false,aMapH=false,aUpgrade=false,aLegacy7536=false;
  for(const auto& b:pluto_bindings){
    if(b.expected<kLegacyGameBase || b.expected>=kLegacyGameBase+kScrGameSize)continue;
    ++found;minRva=std::min(minRva,b.rva);maxRva=std::max(maxRva,b.rva);if(b.rva<0x30000u)++early;
    if(b.expected==0x0057F23Cu)aFrame=true;if(b.expected==0x0057F1D4u)aMapW=true;if(b.expected==0x0057F1D6u)aMapH=true;
    if(b.expected==0x0058D2B0u)aUpgrade=true;if(b.expected==0x0057FD3Cu)aLegacy7536=true;
    if(!readable(base+b.rva,4)){logLine("reloc98.game_exact=RVA_UNREADABLE rva="+std::to_string(b.rva));return false;}
    uint32_t cur=0;memcpy(&cur,base+b.rva,4);
    if(cur!=b.expected){logLine("reloc98.game_exact=MISMATCH rva="+std::to_string(b.rva)+" expected="+std::to_string(b.expected)+" got="+std::to_string(cur));return false;}
    const uint32_t nv=(uint32_t)((uintptr_t)g_legacyGameShadow+(uintptr_t)(b.expected-kLegacyGameBase));
    DWORD old=0;if(!VirtualProtect(base+b.rva,4,PAGE_EXECUTE_READWRITE,&old)){logLine("reloc98.game_exact=PROTECT_FAIL");return false;}
    memcpy(base+b.rva,&nv,4);FlushInstructionCache(GetCurrentProcess(),base+b.rva,4);DWORD tmp=0;VirtualProtect(base+b.rva,4,old,&tmp);++patched;
  }
  logLine("reloc98.game_exact.found="+std::to_string(found));
  logLine("reloc98.game_exact.rva_min="+std::to_string(minRva)+" rva_max="+std::to_string(maxRva)+" early_lt_30000="+std::to_string(early));
  logLine("reloc98.game_exact.anchor.frame="+std::string(aFrame?"YES":"NO")+" mapw="+(aMapW?std::string("YES"):std::string("NO"))+" maph="+(aMapH?std::string("YES"):std::string("NO"))+" upgrade="+(aUpgrade?std::string("YES"):std::string("NO"))+" legacy7536="+(aLegacy7536?std::string("YES"):std::string("NO")));
  logLine("reloc98.game_exact.patched="+std::to_string(patched));
  if(found<100 || patched!=found || !aFrame||!aMapW||!aMapH||!aUpgrade||!aLegacy7536){logLine("reloc98.game_exact=VALIDATION_FAIL");return false;}
  logLine("reloc98.game_operands=PASS_EXACT_BINDINGS");return true;
}

static bool patchPlutoCUnitHead628430(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sigEbx[6]={0x8B,0x1D,0x30,0x84,0x62,0x00};
  const unsigned char sigEdi[6]={0x8B,0x3D,0x30,0x84,0x62,0x00};
  const uintptr_t target=(uintptr_t)&g_scrVisibleUnitHead;
  bool a=patchAbs32(b+0x33F7D,2,sigEbx,6,target,"rva_33f7d_628430");
  bool c=patchAbs32(b+0xBD6B,2,sigEbx,6,target,"rva_bd6b_628430");
  bool d=patchAbs32(b+0x3B787,2,sigEdi,6,target,"rva_3b787_628430");
  return a&&c&&d;
}

static bool patchPlutoUnitNodeTableBase(HMODULE pluto){
  if(g_legacyCUnits.empty()){logLine("reloc98.unit_table=NO_SHADOW_UNITS");return false;}
  uintptr_t basePtr=(uintptr_t)&g_legacyCUnits[0];
  if(basePtr>0xFFFFFFFFu || basePtr+0xA5u>0xFFFFFFFFu){logLine("reloc98.unit_table=OUT_OF_X86_RANGE");return false;}
  uint32_t base=(uint32_t)basePtr;
  uint32_t negBase=0u-base;
  uint32_t generationBase=base+0xA5u;
  logLine("reloc98.unit_table.shadow_base="+std::to_string((unsigned long)base));
  bool ok=true;
  // Pluto computes unit slot indices by adding/subtracting BW 1.16.1's
  // UnitNodeTable base (0x59CCA8). Redirect only those validated operands
  // to the start of our contiguous 336-byte legacy CUnit shadow.
  ok=patchOperand32(pluto,0xAAF4,0xFFA63358u,negBase,"rva_aaf4_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0xAB44,0xFFA63358u,negBase,"rva_ab44_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3134B,0x0059CD4Du,generationBase,"rva_3134b_59cd4d")&&ok;
  ok=patchOperand32(pluto,0x31351,0x0059CCA8u,base,"rva_31351_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3408D,0xFFA63358u,negBase,"rva_3408d_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x341B4,0xFFA63358u,negBase,"rva_341b4_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x343D8,0xFFA63358u,negBase,"rva_343d8_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3C2D9,0x0059CD4Du,generationBase,"rva_3c2d9_59cd4d")&&ok;
  ok=patchOperand32(pluto,0x3C2DE,0x0059CCA8u,base,"rva_3c2de_59cca8")&&ok;
  logLine(std::string("reloc98.unit_table=")+(ok?"PASS":"FAIL"));
  return ok;
}

static bool patchPlutoCUnitHead6283EC(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x2D,0xEC,0x83,0x62,0x00};
  return patchAbs32(b+0x34149,2,sig,6,(uintptr_t)&g_scrHiddenUnitHead,"rva_34149_6283ec");
}

static bool patchPlutoCUnitHead6283F4(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x2D,0xF4,0x83,0x62,0x00};
  return patchAbs32(b+0x34250,2,sig,6,(uintptr_t)&g_scrScannerSweepHead,"rva_34250_6283f4");
}


static bool projectRealMapVisibility(BWAPI::GameData&d){
  if(!g_scrActiveTileArray||d.self<0||d.self>=8||d.mapWidth<=0||d.mapWidth>256||d.mapHeight<=0||d.mapHeight>256)return false;
  const size_t count=(size_t)d.mapWidth*(size_t)d.mapHeight;
  if(!readableNonExecSpan(g_scrActiveTileArray,count*4u,nullptr))return false;
  for(int y=0;y<d.mapHeight;++y)for(int x=0;x<d.mapWidth;++x){
    uint32_t f=0;std::memcpy(&f,(void*)(g_scrActiveTileArray+4u*((size_t)y*(size_t)d.mapWidth+(size_t)x)),4);
    d.isVisible[x][y]=(f&(1u<<d.self))==0;
    d.isExplored[x][y]=(f&(1u<<(d.self+8)))==0;
    d.hasCreep[x][y]=d.isVisible[x][y]&&(f&0x40400000u)!=0;
    d.isOccupied[x][y]=d.isVisible[x][y]&&(f&0x08000000u)!=0;
  }
  return true;
}

static bool patchPlutoActiveTileArray6D1260(HMODULE pluto){
  if(!g_scrActiveTileArray){logLine("reloc98.active_tile=NO_SCR_POINTER");return false;}
  uintptr_t cell=(uintptr_t)&g_legacyActiveTilePtr;
  if(cell>0xFFFFFFFFu){logLine("reloc98.active_tile=CELL_OUT_OF_X86_RANGE");return false;}
  bool ok=true;uint32_t target=(uint32_t)cell;
  ok=patchOperand32(pluto,0x342B7,0x006D1260u,target,"rva_342b7_6d1260")&&ok;
  ok=patchOperand32(pluto,0x3B657,0x006D1260u,target,"rva_3b657_6d1260")&&ok;
  ok=patchOperand32(pluto,0x3B6FD,0x006D1260u,target,"rva_3b6fd_6d1260")&&ok;
  logLine(std::string("reloc98.active_tile=")+(ok?"PASS":"FAIL"));return ok;
}

static bool patchPlutoBulletHead64DEC4(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x1D,0xC4,0xDE,0x64,0x00};
  return patchAbs32(b+0xBC75,2,sig,6,(uintptr_t)&g_legacyBulletHead,"rva_bc75_64dec4");
}

static unsigned char g_reloc57fd3c[0x10000]{};

static bool patchPlutoLegacy57FD3C(HMODULE pluto){
  unsigned char* p=(unsigned char*)pluto+0x7536;
  const unsigned char expect[7]={0x0F,0xB6,0x90,0x3C,0xFD,0x57,0x00};
  if(memcmp(p,expect,7)!=0){
    logLine("reloc_probe.rva_7536_signature=MISMATCH");
    return false;
  }
  // Preserve the exact instruction shape; change only its disp32.
  // movzx edx, byte ptr [eax + disp32]
  uintptr_t compat=(uintptr_t)g_reloc57fd3c;
  if(compat>0xFFFFFFFFu){
    logLine("reloc_probe.compat_ptr=OUT_OF_X86_RANGE");
    return false;
  }
  unsigned char repl[7]={0x0F,0xB6,0x90,0,0,0,0};
  uint32_t disp=(uint32_t)compat;
  memcpy(repl+3,&disp,4);
  DWORD old=0;
  if(!VirtualProtect(p,7,PAGE_EXECUTE_READWRITE,&old)){
    logLine("reloc_probe.virtualprotect=FAIL gle="+std::to_string(GetLastError()));
    return false;
  }
  memcpy(p,repl,7);
  FlushInstructionCache(GetCurrentProcess(),p,7);
  DWORD tmp=0;VirtualProtect(p,7,old,&tmp);
  logLine("reloc_probe.rva_7536_signature=PASS");
  logLine("reloc_probe.rva_7536_patched=PASS");
  logLine("reloc_probe.compat_base="+std::to_string((unsigned long)compat));
  return true;
}

static int mapLegacyPlutoDataPages(){
  // MEM_RESERVE base addresses must honor Windows allocation granularity (normally 64 KiB).
  // These four 64 KiB blocks cover every legacy absolute data page currently observed in Pluto.
  const uintptr_t blocks[]={0x00510000,0x00570000,0x00580000,0x00590000};
  int mapped=0;
  SYSTEM_INFO si{};GetSystemInfo(&si);
  logLine("legacy_probe.allocation_granularity="+std::to_string((unsigned long)si.dwAllocationGranularity));
  for(uintptr_t a:blocks){
    MEMORY_BASIC_INFORMATION mbi{};
    if(!VirtualQuery((LPCVOID)a,&mbi,sizeof(mbi))){
      logLine("legacy_probe.virtualquery_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(GetLastError()));
      continue;
    }
    if(mbi.State==MEM_FREE){
      void*p=VirtualAlloc((LPVOID)a,0x10000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
      if(p==(void*)a){
        ++mapped;
        logLine("legacy_probe.mapped_block="+std::to_string((unsigned long)a));
      }else{
        DWORD gle=GetLastError();
        logLine("legacy_probe.map_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(gle));
        if(p)VirtualFree(p,0,MEM_RELEASE);
      }
    }else{
      logLine("legacy_probe.block_occupied="+std::to_string((unsigned long)a)+
              " state="+std::to_string((unsigned long)mbi.State)+
              " base="+std::to_string((unsigned long)(uintptr_t)mbi.BaseAddress)+
              " size="+std::to_string((unsigned long)mbi.RegionSize));
    }
  }
  return mapped;
}

static DWORD findLegacyCUnitVectorSeh(UnitStore*out){__try{*out=findLegacyCUnitVector();return 0;}__except(EXCEPTION_EXECUTE_HANDLER){return GetExceptionCode();}}
static DWORD WINAPI boot(LPVOID){
  if(!openPersistentLog())return 90;
  logLine("BOOTSTRAP_LOG=PASS_SHARED_WIN32_HANDLE");
  logLine("PLUTOTEAMRUNTIME_V112_RESIDENT=LOADED");logLine("V112_BASELINE=V1111_STABLE_RUNTIME_PLUS_V110_ALLY_PLUS_V111_SAFETY_VALUE");logLine("TEAM_TRAINING_RECORDER=DISABLED_V112_NO_TRAINING");logLine("architecture=x86");logLine("policy=original-pluto-model-with-argument-level-opening-pressure-only");logLine("TEAM_RUNTIME_MODE=STOCK3_V110_ALLY_CONTEXT_PLUS_V112_ARG_PRESSURE_PLUS_LURKER_ONLY_PLUS_WIN_VALUE_LOG");logLine("TEAM_RUNTIME_RELATION_SOURCE=SCR_GAME_ALLIANCES_58692");logLine("TEAM_RUNTIME_CUNIT_OWNER_OFFSET=0x4C");logLine("TEAM_RUNTIME_POLICY=PLUTO_CHOSES_ALL_ACTIONS_V112_ONLY_TEMPORARILY_MASKS_LEARNED_WORKER_ARG_WHEN_ARMY_ARG_AVAILABLE");logLine("TEAM_RUNTIME_MODEL_OWNER_ENCODING=OFFICIAL_STOCK_SELF0_OTHER1_NEUTRAL2");logLine("TEAM_RUNTIME_ALLY_ROLE_POLICY=ALL_ALLY_NONOWNED_BY_DEFAULT_COMBAT_FORCE_TO_SELF_ONLY_NEAR_VISIBLE_ENEMY");logLine("TEAM_RUNTIME_ALLY_CONTROL_POLICY=ACTOR0_TARGET0_PLUS_DROP_ONLY_SAFETY");logLine("TEAM_RUNTIME_PLUTO_MODEL=OFFICIAL_UNMODIFIED_NO_TRAINING");logLine("V112_TOP_LEVEL_ACTION_MASK_BIAS=DISABLED");logLine("V112_EARLY_PRESSURE=SELF_CALIBRATING_ARG1_WORKER_SUPPRESSION_ONLY");logLine("V112_PRESSURE_WINDOW=F0_3999_STRONG_2OF3_F4000_5999_MEDIUM_1OF2_F6000_7499_LIGHT_1OF3_F7500_PLUS_OFF");logLine("V112_FRAME_7500_PLUS=ORIGINAL_PLUTO_STRATEGY_100_PERCENT");logLine("V112_VALUE_GUARD=VALUE_LE_NEG035_OFF_NEG035_TO_NEG020_LIGHT");logLine("V111_BURROW_POLICY=LURKER_ONLY_RESEARCH_DROP_NONLURKER_BURROW_DROP_LURKER_ALLOW");logLine("V111_PLUTO_WIN_VALUE_SOURCE=OFFICIAL_SHM_RESPONSE_OFFSET_0x85F60");logLine("V111_WIN_VALUE_SEMANTICS=P_WIN_MINUS_P_LOSS_PWIN_EQUALS_VALUE_PLUS_1_OVER_2");
  logLine("TEAM4_OWNER_MATCH_SOURCE=LEGACY_SHADOW_EXACT_OBSERVATION");logLine("TEAM_RUNTIME_ENGINE_GATE_PATCH=NONE_STOCK3_REQUIRED");logLine("teamruntime112=V1111_STABLE_RUNTIME+V112_ARGUMENT_LEVEL_EARLY_PRESSURE");
  logLine("checkpoint.boot.before_cunit_scan");
  UnitStore store{};
  DWORD scanEc=findLegacyCUnitVectorSeh(&store);
  if(scanEc){logLine("checkpoint.cunit_scan.SEH_EXCEPTION code="+std::to_string(scanEc));return 12;}
  logLine("checkpoint.boot.after_cunit_scan");
  logLine("scr_cunit_vector.descriptor="+std::to_string((unsigned long)store.descriptor));logLine("scr_cunit_vector.score="+std::to_string(store.score));
  if(store.score<2){logLine("scr_cunit_vector=UNRESOLVED");return 10;} logLine("scr_cunit_vector=BOUND");
  logLine("cunit_store.begin="+std::to_string((unsigned long)store.begin)+" end="+std::to_string((unsigned long)store.end)+" cap="+std::to_string((unsigned long)store.cap));
  const std::wstring d=dirOfW(g_self);
  SetCurrentDirectoryW(d.c_str());SetDllDirectoryW(d.c_str());
  const bool runtimeReady=ensureOriginalPlutoRuntimeLayout(d);
  const std::wstring plutoDll=d+L"\\pluto.dll";
  HMODULE pluto=LoadLibraryW(plutoDll.c_str());if(!pluto){logLine("original_pluto.load=FAIL error="+std::to_string(GetLastError()));return 1;}logLine("original_pluto.load=PASS");
  wchar_t plutoPath[32768]={};DWORD plutoPathLen=GetModuleFileNameW(pluto,plutoPath,(DWORD)(sizeof(plutoPath)/sizeof(plutoPath[0])));std::wstring plutoDir(plutoPath,plutoPathLen);auto ps=plutoDir.find_last_of(L"\\/");if(ps!=std::wstring::npos)plutoDir=plutoDir.substr(0,ps);
  std::wstring inferPath=plutoDir+L"\\pluto\\pluto_infer.exe";std::wstring weightsPath=plutoDir+L"\\pluto\\pluto_weights.bin";
  logLine("pluto.module_path_utf8="+utf8(std::wstring(plutoPath,plutoPathLen)));
  logLine("pluto_runtime.ready="+std::string(runtimeReady?"YES":"NO"));
  logLine("pluto_infer.file_size="+std::to_string(fileSizeOrZero(inferPath)));
  logLine("pluto_weights.file_size="+std::to_string(fileSizeOrZero(weightsPath)));
  if(!runtimeReady || fileSizeOrZero(inferPath)==0 || fileSizeOrZero(weightsPath)==0){logLine("pluto_runtime=REJECTED_MISSING_STOCK_INFERENCE_FILES");return 1;}
  if(!team4InferRuntimeReady(inferPath)){logLine("V111_STOCK_ENGINE=NOT_OFFICIAL_3WAY_FAIL_CLOSED expected_gate=3");return 32;}
  if(!team4WeightsRuntimeReady(weightsPath)){logLine("V111_STOCK_WEIGHTS=NOT_3WAY_FAIL_CLOSED expected_owner_shape=3x256");return 33;}
  logLine("V111_STOCK_ENGINE=OFFICIAL_3WAY_GATE_VERIFIED offset=59203 value=3");
  logLine("V111_STOCK_WEIGHTS=OWNER_EMB_3X256_VERIFIED");
  int inferBeforeStart=countProcessByName(L"pluto_infer.exe");logLine("pluto_infer.process_count.after_load="+std::to_string(inferBeforeStart));if(inferBeforeStart>0){logLine("pluto_infer.stale_process=REJECTED_FAIL_CLOSED");return 25;}
  auto gameInit=(PFNGameInit)GetProcAddress(pluto,"gameInit");auto createAI=(PFNCreateAI)GetProcAddress(pluto,"newAIModule");if(!gameInit||!createAI){logLine("original_pluto.exports=FAIL");return 2;}
  auto*data=new BWAPI::GameData();ZeroMemory(data,sizeof(*data));
  const int bootstrapSelf=profileLocalPlayerCandidate();if(bootstrapSelf<0||bootstrapSelf>=8){logLine("gamedata.bootstrap_self=UNRESOLVED_FAIL_CLOSED");return 26;}
  data->self=bootstrapSelf;data->neutral=11;
  int n=projectLiveUnits(store,*data);logLine("live_units="+std::to_string(n));if(n<2)return 11;
  g_scrGame=findScrGameBlock(n);
  if(!g_scrGame){logLine("legacy_game=UNRESOLVED_FAIL_CLOSED");return 13;}
  data->mapWidth=rd<uint16_t>((unsigned char*)g_scrGame,228);data->mapHeight=rd<uint16_t>((unsigned char*)g_scrGame,230);data->frameCount=rd<uint32_t>((unsigned char*)g_scrGame,332);
  logLine("scr_game.ptr="+std::to_string((unsigned long)g_scrGame));
  logLine("scr_game.mapWidth="+std::to_string(data->mapWidth)+" mapHeight="+std::to_string(data->mapHeight)+" frame="+std::to_string(data->frameCount));
  if(!allocateLegacyGameShadow()){logLine("legacy_game.alloc=FAIL_CLOSED");return 14;}
  if(!syncLegacyGameShadow(g_scrGame)){logLine("legacy_game.sync=FAIL_CLOSED");return 14;}
  logLine("legacy_game.shadow_base="+std::to_string((unsigned long)(uintptr_t)g_legacyGameShadow));
  logLine("legacy_game.shadow_size="+std::to_string((unsigned long)kScrGameSize));
  if(!patchPlutoLegacyGameOperands(pluto)){logLine("legacy_game.reloc=FAIL_CLOSED");return 22;}
  logLine("legacy_game=BOUND_RELOCATED_REAL_SCR_GAME");
  if(!resolveLegacyPlayers()){logLine("legacy_players=UNRESOLVED_FAIL_CLOSED");return 28;}
  if(!patchPlutoLegacyPlayersOperands(pluto)){logLine("legacy_players.reloc=FAIL_CLOSED");return 29;}
  logLine("legacy_players=BOUND_REAL_SCR_PLAYERS");
  // v99: use SCR's real participant/team/alliance matrix instead of guessing the first non-self slot.
  int self=profileLocalPlayerCandidate();
  if(self<0||self>=8){logLine("gamedata.self=UNRESOLVED_FAIL_CLOSED");return 26;}
  data->self=self;data->neutral=11;
  if(!projectRealPlayerRelations(*data,true)){logLine("gamedata.relations=UNRESOLVED_FAIL_CLOSED");return 30;}
  teamCompatBindRelations(*data);
  int teamProjected=projectLiveUnits(store,*data);
  if(teamProjected<1){logLine("TEAM_RUNTIME_INITIAL_PROJECT=FAIL_CLOSED");return 31;}
  // projectLiveUnits refreshes unit/player occupancy fields; restore authoritative
  // SCR team/force/alliance metadata before constructing GameImpl.
  if(!projectRealPlayerRelations(*data,false)){logLine("TEAM_RUNTIME_INITIAL_RELATION_RESTORE=FAIL_CLOSED");return 31;}
  teamCompatBindRelations(*data);
  logLine("TEAM_RUNTIME owner_mode=ALLY_VISIBLE self_visible="+std::to_string(g_teamCompatLastSelfVisible)+" ally_visible="+std::to_string(g_teamCompatLastAllyVisible)+" enemy_visible="+std::to_string(g_teamCompatLastEnemyVisible)+" neutral_visible="+std::to_string(g_teamCompatLastNeutralVisible));
  teamRuntimeLogAllySamples(*data,data->frameCount);
  int enemy=data->enemy;data->isInGame=true;
  logLine("gamedata.initialUnitCount="+std::to_string(data->initialUnitCount));
  logLine("gamedata.playerCount="+std::to_string(data->playerCount));
  logLine("gamedata.self="+std::to_string(self)+" enemy="+std::to_string(enemy)+" neutral="+std::to_string(data->neutral));
  for(int p=0;p<12;p++)if(data->players[p].isParticipating){int pc=0;for(int u=0;u<data->initialUnitCount;u++)if(data->units[u].player==p)++pc;logLine("gamedata.player["+std::to_string(p)+"].units="+std::to_string(pc)+" race="+std::to_string(data->players[p].race));}
  logLine("gamedata.mapWidth="+std::to_string(data->mapWidth)+" mapHeight="+std::to_string(data->mapHeight));
  BWAPI::BWAPIClient.data=data;auto*game=new BWAPI::GameImpl(data);BWAPI::BroodwarPtr=game;logLine("checkpoint.gameimpl.constructed");
  gameInit(game);logLine("checkpoint.original_pluto.gameInit.PASS");auto*module=createAI();if(!module){logLine("original_pluto.newAIModule=FAIL");return 3;}logLine("checkpoint.original_pluto.newAIModule.PASS");
  game->onMatchStart();logLine("checkpoint.bwapi.onMatchStart.PASS");
  logLine("reloc_probe.mode=pluto-teamruntime-v101-ally-visible-recognition-coherent-state-game-thread-send");
  // Do not patch 0x57F1xx/0x57FD3C to zero-filled compatibility buffers anymore.
  // Original Pluto now reads the actual SCR Game state through relocated legacy Game operands.
  int headLen=buildLegacyCUnitShadow(store);
  logLine("legacy_cunit_shadow.count="+std::to_string(headLen));
  if(!g_scrVisibleUnitHead || headLen<2){logLine("legacy_cunit_shadow=UNRESOLVED");return 15;}
  logLine("legacy_cunit_shadow=BOUND");
  bool reloc628430=patchPlutoCUnitHead628430(pluto);
  logLine(std::string("reloc98.patch_all_628430=")+(reloc628430?"PASS":"FAIL"));
  if(!reloc628430)return 16;
  bool relocUnitTable=patchPlutoUnitNodeTableBase(pluto);
  logLine(std::string("reloc98.patch_unit_table=")+(relocUnitTable?"PASS":"FAIL"));
  if(!relocUnitTable)return 21;
  bool reloc6283ec=patchPlutoCUnitHead6283EC(pluto);
  logLine(std::string("reloc98.patch_6283ec=")+(reloc6283ec?"PASS":"FAIL"));
  if(!reloc6283ec)return 17;
  bool reloc6283f4=patchPlutoCUnitHead6283F4(pluto);
  logLine(std::string("reloc98.patch_6283f4=")+(reloc6283f4?"PASS":"FAIL"));
  if(!reloc6283f4)return 18;
  if(!resolveActiveTileArray(store,data->mapWidth,data->mapHeight)){logLine("active_tile=UNRESOLVED_FAIL_CLOSED");return 23;}
  if(!patchPlutoActiveTileArray6D1260(pluto)){logLine("active_tile.reloc=FAIL_CLOSED");return 24;}
  logLine("active_tile=BOUND_REAL_SCR");
  if(!projectRealMapVisibility(*data)){logLine("gamedata.map_visibility=FAIL_CLOSED");return 30;}
  logLine("gamedata.map_visibility=BOUND_REAL_SCR");
  if(!buildLegacyBulletShadow()){logLine("profile_bullet=UNRESOLVED_FAIL_CLOSED");return 19;}
  logLine("profile_bullet_shadow=BOUND");
  bool reloc64dec4=patchPlutoBulletHead64DEC4(pluto);
  logLine(std::string("reloc98.patch_64dec4=")+(reloc64dec4?"PASS":"FAIL"));
  if(!reloc64dec4)return 20;
  if(!patchPlutoLegacyStartGlobals(pluto)){logLine("legacy_start_globals=FAIL_CLOSED");return 27;}
  logLine("legacy_start_globals=BOUND_REAL_LOCAL_PLAYER");
  if(!patchPlutoLegacyCommandAbi(pluto)){logLine("legacy_command_abi=FAIL_CLOSED");return 28;}
  logLine("legacy_command_abi=BOUND_TRANSLATION_GAME_THREAD_SEND");
  if(!installTeam4OwnerRewriteHook(pluto)){logLine("TEAM4_SHM_OWNER_HOOK=FAIL_CLOSED");return 34;}
  InterlockedExchange(&g_team4RewriteFatal,0);
  InterlockedExchange(&g_team4RewriteEnabled,1);
  logLine("V112_SHM_OWNER_HOOK=ARMED_V110_ALLY_CONTEXT_PLUS_V112_ARG_PRESSURE_PLUS_LURKER_ONLY_PLUS_WIN_VALUE");
  DWORD ec=onStartSeh(module);if(ec){
    logLine("original_pluto.onStart=SEH_EXCEPTION code="+std::to_string(ec));
    logLine("seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
    logLine("seh.eip="+std::to_string((unsigned long)g_sehEip));
    logLine("seh.access_type="+std::to_string((unsigned long)g_sehAccessType));
    logLine("seh.access_address="+std::to_string((unsigned long)g_sehAccessAddress));
    logLine("seh.regs.eax="+std::to_string((unsigned long)g_sehEax)+" ebx="+std::to_string((unsigned long)g_sehEbx)+" ecx="+std::to_string((unsigned long)g_sehEcx)+" edx="+std::to_string((unsigned long)g_sehEdx)+" esi="+std::to_string((unsigned long)g_sehEsi)+" edi="+std::to_string((unsigned long)g_sehEdi)+" ebp="+std::to_string((unsigned long)g_sehEbp)+" esp="+std::to_string((unsigned long)g_sehEsp));
    if(readable((void*)g_sehEip,16)){std::ostringstream hs;hs<<"seh.code16=";auto*q=(unsigned char*)g_sehEip;const char*hex="0123456789ABCDEF";for(int i=0;i<16;i++){hs<<hex[q[i]>>4]<<hex[q[i]&15];}logLine(hs.str());}
    uintptr_t pb=(uintptr_t)pluto;
    if(g_sehAddress>=pb)logLine("seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
    if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)logLine("seh.class=legacy_bw_absolute_address");
    else if(g_sehAddress>=pb)logLine("seh.class=pluto_code");
    else logLine("seh.class=other");
    return 4;
  }logLine("original_pluto.onStart=PASS");
  if(!team4ClientShmReady()){logLine("TEAM4_SHM_TRANSPORT=NOT_ACTIVE_FAIL_CLOSED");return 35;}
  logLine("TEAM4_SHM_TRANSPORT=ACTIVE");
  if(!installGameThreadCommandHook()){logLine("scr_command_sink=GAME_THREAD_HOOK_FAIL_CLOSED");return 29;}
  logLine("scr_command_sink=ARMED_GAME_THREAD_ONE_FRAME_DELAY");
  InterlockedExchange(&g_matchCommandsArmed,1);
  logLine("pluto_infer.process_count.after_onStart="+std::to_string(countProcessByName(L"pluto_infer.exe")));
  logLine("reloc_probe.onStart_with_real_local_player_and_relocated_game=PASS");
  unsigned matchGeneration=1;
  team109ResetPreferenceState();
  team112ResetEarlyPressureState();
  team111ResetBurrowPolicyState();
  team111ResetWinValueState();
  logLine("MATCH_START generation=1 frame="+std::to_string(data->frameCount));
  logLine("PLUTOTEAMRUNTIME_V104_MULTI_MATCH_STABLE_LOOP=START");
  for(;;){
    int lastCmd=0;unsigned diagFrame=0;bool matchEndedNormally=false;unsigned inactiveStreak=0;
    // The resident worker observes SCR asynchronously. Bullet list links can be
    // rewritten by the game thread while we traverse them. Never feed such a
    // torn snapshot to Pluto: skip the whole observation and retry. Persistent
    // failures still fail closed after a bounded streak.
    unsigned bulletRefreshFailStreak=0;
    // Unit pool/head pointers are also read from a resident worker while the
    // game thread may move units between active/hidden lists. A one-frame torn
    // view must never terminate a healthy match. Retry whole observations, but
    // remain fail-closed if the mismatch persists.
    unsigned cunitRefreshFailStreak=0;
    while(true){
      const bool matchActiveNow=profileMatchActive();
      if(!matchActiveNow){
        ++inactiveStreak;
        if(diagFrame>=3 && inactiveStreak>=8){matchEndedNormally=true;logLine("MATCH_END_DETECTED generation="+std::to_string(matchGeneration)+" reason=game_loop_inactive_debounced streak="+std::to_string(inactiveStreak));break;}
        Sleep(42);continue;
      }
      inactiveStreak=0;
    ++diagFrame; if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_sleep");
    Sleep(42);if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_sleep");
    std::vector<uintptr_t> framePresent;uint32_t coherentFrame=0;
    if(!collectCoherentPresentRaw(store,framePresent,coherentFrame)){
      if(!profileMatchActive()){matchEndedNormally=true;logLine("MATCH_END_DETECTED generation="+std::to_string(matchGeneration)+" reason=state_unavailable");break;}
      if(diagFrame<=3||diagFrame%120==0)logLine("cunit_snapshot=FRAME_CHANGED_RETRY_SKIP");
      continue;
    }
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].cunit_snapshot frame="+std::to_string(coherentFrame)+" present="+std::to_string(framePresent.size()));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_projectLiveUnits");
    data->self=profileLocalPlayerCandidate();if(data->self<0||data->self>=8){logLine("gamedata.self.live=UNRESOLVED_FAIL_CLOSED");break;}
    int live=projectLiveUnitsFromPresent(framePresent,*data);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_projectLiveUnits live="+std::to_string(live));
    if(diagFrame<=3||diagFrame%120==0)logLine("TEAM_RUNTIME owner_mode=ALLY_VISIBLE self_visible="+std::to_string(g_teamCompatLastSelfVisible)+" ally_visible="+std::to_string(g_teamCompatLastAllyVisible)+" enemy_visible="+std::to_string(g_teamCompatLastEnemyVisible)+" neutral_visible="+std::to_string(g_teamCompatLastNeutralVisible)+" frame="+std::to_string(coherentFrame));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_shadow_refresh");
    int shadowLive=refreshLegacyCUnitShadowFromPresent(store,framePresent);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_shadow_refresh live="+std::to_string(shadowLive));
    if(shadowLive!=(int)framePresent.size()){
      ++cunitRefreshFailStreak;
      if(!profileMatchActive()){
        matchEndedNormally=true;
        logLine("MATCH_END_DETECTED generation="+std::to_string(matchGeneration)+" reason=cunit_state_unavailable");
        break;
      }
      if(cunitRefreshFailStreak<8){
        logLine("cunit_snapshot=SHADOW_COUNT_MISMATCH_TRANSIENT_RETRY_SKIP "+std::to_string(shadowLive)+"/"+std::to_string(framePresent.size())+" streak="+std::to_string(cunitRefreshFailStreak)+" frame="+std::to_string(coherentFrame));
        continue;
      }
      logLine("cunit_snapshot=SHADOW_COUNT_MISMATCH_FAIL_CLOSED "+std::to_string(shadowLive)+"/"+std::to_string(framePresent.size())+" streak="+std::to_string(cunitRefreshFailStreak));
      break;
    }
    if(cunitRefreshFailStreak){
      logLine("cunit_snapshot=RECOVERED retries="+std::to_string(cunitRefreshFailStreak)+" frame="+std::to_string(coherentFrame));
      cunitRefreshFailStreak=0;
    }
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].gamedata_accessible="+std::to_string(live)+" legacy_present="+std::to_string(shadowLive));
    if(live<2){if(!profileMatchActive()){matchEndedNormally=true;logLine("MATCH_END_DETECTED generation="+std::to_string(matchGeneration)+" reason=units_gone");break;}logLine("live_units_transient_lt2=SKIP");continue;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_game_shadow_refresh");
    if(!syncLegacyGameShadow(g_scrGame)){logLine("legacy_game.live_refresh=FAIL_CLOSED");break;}
    data->mapWidth=rd<uint16_t>((unsigned char*)g_scrGame,228);data->mapHeight=rd<uint16_t>((unsigned char*)g_scrGame,230);data->frameCount=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_game_shadow_refresh frame="+std::to_string(data->frameCount));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_active_tile_refresh");
    if(!refreshActiveTileArray(data->mapWidth,data->mapHeight,store)){logLine("active_tile.live_refresh=FAIL_CLOSED");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_active_tile_refresh ptr="+std::to_string((unsigned long)g_scrActiveTileArray));
    if(!projectRealMapVisibility(*data)){logLine("gamedata.map_visibility.live_refresh=FAIL_CLOSED");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].map_visibility=REAL_SCR");
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_bullet_refresh");
    if(!refreshLegacyBulletShadow()){
      ++bulletRefreshFailStreak;
      if(!profileMatchActive()){
        matchEndedNormally=true;
        logLine("MATCH_END_DETECTED generation="+std::to_string(matchGeneration)+" reason=bullet_state_unavailable");
        break;
      }
      if(bulletRefreshFailStreak<8){
        logLine("profile_bullet.live_refresh=TRANSIENT_RETRY_SKIP streak="+std::to_string(bulletRefreshFailStreak)+" frame="+std::to_string(coherentFrame));
        continue;
      }
      logLine("profile_bullet.live_refresh=FAIL_CLOSED streak="+std::to_string(bulletRefreshFailStreak));
      break;
    }
    if(bulletRefreshFailStreak){
      logLine("profile_bullet.live_refresh=RECOVERED retries="+std::to_string(bulletRefreshFailStreak)+" frame="+std::to_string(coherentFrame));
      bulletRefreshFailStreak=0;
    }
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_bullet_refresh active="+std::to_string(g_legacyRawBullets.size()));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_players_refresh");
    if(!refreshLegacyPlayers()){logLine("legacy_players.live_refresh=FAIL_CLOSED");break;}
    if(!projectRealPlayerRelations(*data,false)){logLine("gamedata.relations.live_refresh=FAIL_CLOSED");break;}
    teamCompatBindRelations(*data);
    if(diagFrame<=3||diagFrame%120==0)teamRuntimeLogAllySamples(*data,coherentFrame);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_players_refresh enemy="+std::to_string(data->enemy));
    const uint32_t finalObservationFrame=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(finalObservationFrame!=coherentFrame){
      if(diagFrame<=3||diagFrame%120==0)logLine("observation_snapshot=FRAME_DRIFT_DISCARDED start="+std::to_string(coherentFrame)+" end="+std::to_string(finalObservationFrame));
      continue;
    }
    data->frameCount=coherentFrame;
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].observation_snapshot=COHERENT frame="+std::to_string(coherentFrame));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_bwapi_onMatchFrame");
    game->onMatchFrame();
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_bwapi_onMatchFrame");
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].pluto_infer.process_count.before_onFrame="+std::to_string(countProcessByName(L"pluto_infer.exe")));
    if(InterlockedCompareExchange(&g_commandSendFailed,0,0)){logLine("scr_command_sink.live=SEND_FAILED_FAIL_CLOSED");break;}
    if(!refreshLegacyCommandEnvironment()){logLine("legacy_command_env.live_refresh=FAIL_CLOSED");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_pluto_onFrame");
    ec=onFrameSeh(module);
    team112ObserveDecision(data->frameCount);
    team109ObserveDecision(data->frameCount);
    team111ObserveWinValue(data->frameCount);
    recorder33CommitResponse();
    if(diagFrame==1 && ec==0 && InterlockedCompareExchange(&g_team4RewriteFatal,0,0)==0){
      logLine("TEAM_TRAINING_RECORDER=CONFIRMED_DISABLED_V112");
    }
    if(InterlockedCompareExchange(&g_team4RewriteFatal,0,0)){logLine("V110_SHM_OWNER_REWRITE.live=FATAL_FAIL_CLOSED");break;}
    if(diagFrame>=60 && InterlockedCompareExchange(&g_team4RewriteSeq,0,0)==0){logLine("V110_SHM_OWNER_REWRITE.live=NEVER_TRIGGERED_FAIL_CLOSED");break;}
    if(!translateAndValidateLegacyCommands(data->frameCount)){logLine("scr_command_translation.live=FAIL_CLOSED");break;}
    if(InterlockedCompareExchange(&g_commandSendFailed,0,0)){logLine("scr_command_sink.live=POST_TRANSLATE_SEND_FAILED_FAIL_CLOSED");break;}
    if(diagFrame<=3||diagFrame%120==0)logLine("scr_command_submitted.total="+std::to_string((long)InterlockedCompareExchange(&g_submittedPackets,0,0))+" hook_seen="+std::to_string((long)InterlockedCompareExchange(&g_gameThreadHookSeen,0,0)));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_pluto_onFrame seh="+std::to_string(ec));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].pluto_infer.process_count.after_onFrame="+std::to_string(countProcessByName(L"pluto_infer.exe")));
    if(ec){
      logLine("original_pluto.onFrame=SEH_EXCEPTION code="+std::to_string(ec));
      logLine("onframe.seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
      logLine("onframe.seh.eip="+std::to_string((unsigned long)g_sehEip));
      logLine("onframe.seh.access_type="+std::to_string((unsigned long)g_sehAccessType));
      logLine("onframe.seh.access_address="+std::to_string((unsigned long)g_sehAccessAddress));
      logLine("onframe.seh.regs.eax="+std::to_string((unsigned long)g_sehEax)+" ebx="+std::to_string((unsigned long)g_sehEbx)+" ecx="+std::to_string((unsigned long)g_sehEcx)+" edx="+std::to_string((unsigned long)g_sehEdx)+" esi="+std::to_string((unsigned long)g_sehEsi)+" edi="+std::to_string((unsigned long)g_sehEdi)+" ebp="+std::to_string((unsigned long)g_sehEbp)+" esp="+std::to_string((unsigned long)g_sehEsp));
      if(readable((void*)g_sehEip,16)){std::ostringstream hs;hs<<"onframe.seh.code16=";auto*q=(unsigned char*)g_sehEip;const char*hex="0123456789ABCDEF";for(int i=0;i<16;i++){hs<<hex[q[i]>>4]<<hex[q[i]&15];}logLine(hs.str());}
      if(g_sehEip>=16 && readable((void*)(g_sehEip-16),48)){std::ostringstream hs;hs<<"onframe.seh.code_window_m16_p32=";auto*q=(unsigned char*)(g_sehEip-16);const char*hex="0123456789ABCDEF";for(int i=0;i<48;i++){hs<<hex[q[i]>>4]<<hex[q[i]&15];}logLine(hs.str());}
      if(readable((void*)g_sehEsp,64)){std::ostringstream ss;ss<<"onframe.seh.stack16=";auto*q=(uint32_t*)g_sehEsp;for(int i=0;i<16;i++){if(i)ss<<",";ss<<q[i];}logLine(ss.str());}
      uintptr_t pb=(uintptr_t)pluto;
      if(g_sehAddress>=pb)
        logLine("onframe.seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
      if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)
        logLine("onframe.seh.class=legacy_bw_absolute_address");
      else if(g_sehAddress>=pb)
        logLine("onframe.seh.class=pluto_code");
      else
        logLine("onframe.seh.class=other");
      break;
    }
    if(data->unitCommandCount!=lastCmd){logLine("pluto_bwapi_unit_commands="+std::to_string(data->unitCommandCount));lastCmd=data->unitCommandCount;}
    if(data->unitCommandCount>0){logLine("scr_command_sink=UNRESOLVED_FAIL_CLOSED");data->unitCommandCount=0;lastCmd=0;}
    }
    if(!matchEndedNormally){logLine("MATCH_LOOP_STOPPED_FATAL generation="+std::to_string(matchGeneration));break;}

    // End the just-finished match while commands are disarmed. This follows the
    // reference bridge lifecycle: AIModule::onEnd first, then GameImpl::onMatchEnd.
    InterlockedExchange(&g_matchCommandsArmed,0);clearPendingTurns();g_lastHookFrame=0;
    g_legacyCommandSize=0;g_legacyFlushCount=0;g_legacyFlushOverflow=0;
    std::memset(g_legacyCommandBuffer,0,sizeof(g_legacyCommandBuffer));
    const int endedSelf=data?data->self:-1;bool won=false;
    if(data&&g_scrGame&&endedSelf>=0&&endedSelf<8&&readable((void*)(g_scrGame+58896u+(unsigned)endedSelf),1))won=rd<uint8_t>((unsigned char*)g_scrGame,58896u+(unsigned)endedSelf)==3;
    const uint32_t recorderFinalFrame=(g_scrGame&&readable((void*)(g_scrGame+332u),4))?rd<uint32_t>((unsigned char*)g_scrGame,332):0;
    if(InterlockedCompareExchange(&g_recArmed,0,0))recorder33End(won,recorderFinalFrame);
    team109LogPreferenceSummary(recorderFinalFrame);
    team112LogPressureSummary(recorderFinalFrame);
    team111LogWinValueSummary(recorderFinalFrame,won);
    logLine("V111_BURROW_SUMMARY research_blocked="+std::to_string((long)InterlockedCompareExchange(&g_v111BurrowResearchBlocked,0,0))+
      " command_blocked="+std::to_string((long)InterlockedCompareExchange(&g_v111BurrowCommandBlocked,0,0))+
      " lurker_allowed="+std::to_string((long)InterlockedCompareExchange(&g_v111LurkerBurrowAllowed,0,0)));
    logLine("V1111_TRANSIENT_COMMAND_SUMMARY dropped_decision_batches="+
      std::to_string((long)InterlockedCompareExchange(&g_v111TransientCommandDrops,0,0))+
      " final_streak="+std::to_string((long)InterlockedCompareExchange(&g_v111TransientCommandDropStreak,0,0)));

    // v103.4: original Pluto onEnd tears down EngineClient and signals reqEvent.
    // The old SHM can still contain our already rewritten owner value 3.
    // Never re-run the 0/1/2 -> 0/1/2/3 rewrite during this shutdown signal.
    // The real SetEvent still goes through to originalSetEvent below.
    InterlockedExchange(&g_team4RewriteEnabled,0);
    logLine("TEAM4_OWNER_REWRITE=DISARMED_FOR_ONEND generation="+std::to_string(matchGeneration));
    if(module){DWORD endEc=onEndSeh(module,won);logLine(std::string("original_pluto.onEnd=")+(endEc?"SEH_EXCEPTION":"PASS")+" generation="+std::to_string(matchGeneration)+" won="+(won?"1":"0")+(endEc?" code="+std::to_string(endEc):std::string()));}
    if(game){game->onMatchEnd();logLine("bwapi.onMatchEnd=PASS generation="+std::to_string(matchGeneration));}
    logLine("TEAM4_OWNER_REWRITE=ONEND_BYPASS_COMPLETE generation="+std::to_string(matchGeneration));
    BWAPI::BroodwarPtr=nullptr;BWAPI::BWAPIClient.data=nullptr;
    if(game){delete game;game=nullptr;}if(data){delete data;data=nullptr;}module=nullptr;
    logLine("MATCH_END generation="+std::to_string(matchGeneration)+" submitted_total="+std::to_string((long)InterlockedCompareExchange(&g_submittedPackets,0,0)));
    flushLog();

    g_teamCompatReady=false;g_teamCompatSelf=-1;g_teamCompatAllyMask=0;
    // Clear per-match identities without reallocating the fixed legacy CUnit table,
    // so Pluto's one-time patched UnitNodeTable base remains valid across matches.
    g_stableUnitLookup.clear();g_legacyRawUnits.clear();
    for(auto&slot:g_stableUnitSlots)slot={};
    std::memset(g_legacyCUnits.data(),0,g_legacyCUnits.size()*sizeof(LegacyCUnit336));
    std::memset(g_legacyUnitSprites.data(),0,g_legacyUnitSprites.size()*sizeof(LegacySprite36));
    g_scrVisibleUnitHead=g_scrHiddenUnitHead=g_scrScannerSweepHead=0;
    g_legacyBullets.clear();g_legacyBulletSprites.clear();g_legacyRawBullets.clear();g_rawBulletIndex.clear();g_legacyBulletHead=0;
    g_legacyLocalPlayerId=0;std::memset(g_legacyStartSelection,0,sizeof(g_legacyStartSelection));
    InterlockedExchange(&g_commandSendFailed,0);InterlockedExchange(&g_submittedPackets,0);InterlockedExchange(&g_translateLogSequence,0);InterlockedExchange(&g_sendLogSequence,0);InterlockedExchange(&g_teamCompatBlockedCommands,0);
    InterlockedExchange(&g_team4RewriteFatal,0);
    g_insideTeam4SetEvent=false;
    team109ResetPreferenceState();
  team112ResetEarlyPressureState();
    team111ResetBurrowPolicyState();
    team111ResetWinValueState();
    logLine("TEAM4_OWNER_REWRITE=PER_MATCH_FATAL_RESET generation="+std::to_string(matchGeneration+1));

    logLine("MATCH_WAIT_NEXT generation="+std::to_string(matchGeneration+1));
    UnitStore nextStore{};uintptr_t nextGame=0;int nextSelf=-1;int nextLive=0;
    for(;;){
      Sleep(100);
      if(profileReplayActive()||!profileMatchActive())continue;
      nextSelf=profileLocalPlayerCandidate();if(nextSelf<0||nextSelf>=8)continue;
      DWORD nextScan=findLegacyCUnitVectorSeh(&nextStore);if(nextScan||nextStore.score<2){Sleep(150);continue;}
      auto nextPresent=collectPresentRaw(nextStore);if(nextPresent.size()<2){Sleep(150);continue;}
      nextGame=findScrGameBlock((int)nextPresent.size());if(!nextGame){Sleep(150);continue;}
      const uint16_t nw=rd<uint16_t>((unsigned char*)nextGame,228),nh=rd<uint16_t>((unsigned char*)nextGame,230);
      const uint32_t nf=rd<uint32_t>((unsigned char*)nextGame,332);if(nw<32||nh<32||!nf){Sleep(150);continue;}
      nextLive=(int)nextPresent.size();break;
    }

    store=nextStore;g_scrGame=nextGame;
    data=new BWAPI::GameData();ZeroMemory(data,sizeof(*data));data->self=nextSelf;data->neutral=11;
    int projected=projectLiveUnits(store,*data);if(projected<2){logLine("MATCH_RESTART=PROJECT_UNITS_FAIL_CLOSED");break;}
    data->mapWidth=rd<uint16_t>((unsigned char*)g_scrGame,228);data->mapHeight=rd<uint16_t>((unsigned char*)g_scrGame,230);data->frameCount=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(!syncLegacyGameShadow(g_scrGame)){logLine("MATCH_RESTART=GAME_SHADOW_FAIL_CLOSED");break;}
    if(!resolveLegacyPlayers()||!refreshLegacyPlayers()){logLine("MATCH_RESTART=PLAYERS_FAIL_CLOSED");break;}
    data->self=nextSelf;data->neutral=11;
    if(!projectRealPlayerRelations(*data,true)){logLine("MATCH_RESTART=RELATIONS_FAIL_CLOSED");break;}
    teamCompatBindRelations(*data);
    int restartTeamProjected=projectLiveUnits(store,*data);
    if(restartTeamProjected<1){logLine("MATCH_RESTART=TEAM_RUNTIME_PROJECT_FAIL_CLOSED");break;}
    if(!projectRealPlayerRelations(*data,false)){logLine("MATCH_RESTART=TEAM_RUNTIME_RELATION_RESTORE_FAIL_CLOSED");break;}
    teamCompatBindRelations(*data);
    logLine("TEAM_RUNTIME restart owner_mode=ALLY_VISIBLE self_visible="+std::to_string(g_teamCompatLastSelfVisible)+" ally_visible="+std::to_string(g_teamCompatLastAllyVisible)+" enemy_visible="+std::to_string(g_teamCompatLastEnemyVisible)+" neutral_visible="+std::to_string(g_teamCompatLastNeutralVisible));
    teamRuntimeLogAllySamples(*data,data->frameCount);
    int newEnemy=data->enemy;data->isInGame=true;
    BWAPI::BWAPIClient.data=data;game=new BWAPI::GameImpl(data);BWAPI::BroodwarPtr=game;gameInit(game);module=createAI();
    if(!module){logLine("MATCH_RESTART=NEW_AI_NULL_FAIL_CLOSED");break;}
    game->onMatchStart();
    int restartShadow=buildLegacyCUnitShadow(store);if(!g_scrVisibleUnitHead||restartShadow<2){logLine("MATCH_RESTART=CUNIT_SHADOW_FAIL_CLOSED");break;}
    if(!resolveActiveTileArray(store,data->mapWidth,data->mapHeight)||!projectRealMapVisibility(*data)){logLine("MATCH_RESTART=ACTIVE_TILE_FAIL_CLOSED");break;}
    if(!buildLegacyBulletShadow()){logLine("MATCH_RESTART=BULLET_FAIL_CLOSED");break;}
    g_legacyLocalPlayerId=(uint32_t)nextSelf;std::memset(g_legacyStartSelection,0,sizeof(g_legacyStartSelection));
    if(!refreshLegacyCommandEnvironment()){logLine("MATCH_RESTART=COMMAND_ENV_FAIL_CLOSED");break;}
    g_legacyCommandSize=0;g_legacyFlushCount=0;g_legacyFlushOverflow=0;std::memset(g_legacyCommandBuffer,0,sizeof(g_legacyCommandBuffer));std::memset(g_legacyFlushSizes,0,sizeof(g_legacyFlushSizes));std::memset(g_legacyFlushBuffers,0,sizeof(g_legacyFlushBuffers));
    recorder33Close();
    DWORD restartEc=onStartSeh(module);if(restartEc){logLine("MATCH_RESTART=ONSTART_SEH_FAIL_CLOSED code="+std::to_string(restartEc));break;}
    if(!team4ClientShmReady()){logLine("MATCH_RESTART=TEAM4_SHM_NOT_ACTIVE_FAIL_CLOSED");break;}
    logLine("MATCH_RESTART=TEAM4_SHM_ACTIVE");
    int inferCount=countProcessByName(L"pluto_infer.exe");
    for(int settle=0;settle<20 && inferCount!=1;++settle){Sleep(100);inferCount=countProcessByName(L"pluto_infer.exe");}
    if(inferCount!=1){logLine("MATCH_RESTART=INFER_PROCESS_FAIL_CLOSED count="+std::to_string(inferCount));break;}
    InterlockedExchange(&g_team4RewriteFatal,0);
    InterlockedExchange(&g_team4RewriteEnabled,1);
    logLine("TEAM4_OWNER_REWRITE=REARMED_FOR_NEW_MATCH");
    ++matchGeneration;InterlockedExchange(&g_matchCommandsArmed,1);
    logLine("MATCH_START generation="+std::to_string(matchGeneration)+" frame="+std::to_string(data->frameCount)+" self="+std::to_string(nextSelf)+" live="+std::to_string(nextLive)+" infer_count="+std::to_string(inferCount));
    flushLog();
  }
  InterlockedExchange(&g_matchCommandsArmed,0);clearPendingTurns();recorder33Close();flushLog();
  return 0;
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){if(r==DLL_PROCESS_ATTACH){g_self=h;DisableThreadLibraryCalls(h);HANDLE t=CreateThread(nullptr,0,boot,nullptr,0,nullptr);if(t)CloseHandle(t);}return TRUE;}
