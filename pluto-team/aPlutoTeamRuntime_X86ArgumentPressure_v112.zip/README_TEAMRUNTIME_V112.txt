aPlutoTeamRuntime v112 - Argument-Level Early Pressure

Purpose
- Preserve official unmodified Pluto model/inference/strategy.
- Preserve v110 ally observation semantics.
- Preserve v111 LURKER_ONLY burrow policy and win/value logging.
- Preserve v111.1 transient stale-unit-handle recovery.
- Replace v109 top-level action masking with a safer self-calibrating arg1-level opening preference.

Opening pressure
- Frame 0-3999: STRONG, worker-production arg hidden on 2/3 eligible requests.
- Frame 4000-5999: MEDIUM, 1/2 eligible requests.
- Frame 6000-7499: LIGHT, 1/3 eligible requests.
- Frame >=7500: OFF. No v112 strategic mask edits; original Pluto strategy 100%.
- Minimum own workers: 9.
- The worker arg token and army arg tokens are learned from Pluto's own real Train/Morph commands.
- A worker arg is hidden only if a learned army arg is simultaneously valid in the same request.
- Pluto itself chooses the alternative military unit. No unit/build order is scripted.

Value guard
- official Pluto value <= -0.35: opening pressure disabled for that request.
- -0.35 < value <= -0.20: pressure reduced to LIGHT.
- otherwise: normal frame-stage pressure.

Expected log markers
V112_ARG_LEARN
V112_EARLY_PRESSURE=APPLIED
V112_EARLY_PRESSURE_SUMMARY
V112_FRAME_7500_PLUS=ORIGINAL_PLUTO_STRATEGY_100_PERCENT
V111_PLUTO_WIN_VALUE
V111_BURROW_BLOCK / V111_LURKER_BURROW_ALLOW
V1111_COMMAND_TRANSIENT_DROP (only when a stale unit handle occurs)
