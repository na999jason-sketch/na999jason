# aPlutoTeam Phase2B v1

Scope: first executable PyTorch reconstruction of the shipped Pluto model trunk.

Implemented in this v1:
- six categorical unit embeddings + continuous unit features
- unit input SwiGLU
- unit -> map scatter
- 136-channel spatial planes
- spatial CNN
- S32 -> unit injection + null token
- six-layer unit transformer
- global + action history projections
- slow-memory initialization and first tick
- attention-GRU first step
- 20-way action head
- shipped solo win head

Not yet implemented:
- argument head chain
- coarse/fine position head
- unit pointer head
- UAT corrections
- exact int8mv activation quantisation/kernels

Therefore this phase compares the official Phase2A action and win only as diagnostics. It does
not claim bit-exact parity and does not fail CI solely because the FP32 reconstruction differs
from the official int8mv engine.

The JSON artifact records SHA-256 fingerprints and statistics for every major intermediate stage,
so subsequent versions can localize the first divergence.
