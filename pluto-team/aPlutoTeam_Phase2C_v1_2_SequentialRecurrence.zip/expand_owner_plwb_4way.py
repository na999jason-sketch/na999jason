from __future__ import annotations
import argparse, copy, json, struct
from pathlib import Path

def align64(n: int) -> int:
    return (n + 63) & ~63

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()

    src = Path(args.input)
    raw = src.read_bytes()
    if raw[:4] != b"PLWB":
        raise SystemExit("not PLWB")
    ver = struct.unpack_from("<I", raw, 4)[0]
    hlen = struct.unpack_from("<Q", raw, 8)[0]
    if ver != 1:
        raise SystemExit(f"unsupported PLWB version {ver}")

    h0, h1 = 16, 16 + hlen
    header = json.loads(raw[h0:h1].decode("utf-8"))
    total = int(header["total_bytes"])
    base = len(raw) - total
    if base < h1 or base % 64:
        raise SystemExit(f"bad data base {base}")

    tensors = header["tensors"]
    owner = None
    for t in tensors:
        if t["name"] == "owner_emb.weight":
            owner = t
            break
    if owner is None:
        raise SystemExit("owner_emb.weight missing")
    if list(owner["shape"]) != [3, 256]:
        raise SystemExit(f"expected [3,256], got {owner['shape']}")
    if owner.get("dtype", "float32") != "float32":
        raise SystemExit(f"expected float32 owner emb, got {owner.get('dtype')}")
    if int(owner["nbytes"]) != 3 * 256 * 4:
        raise SystemExit(f"unexpected owner nbytes {owner['nbytes']}")
    if owner.get("scale_offset") is not None:
        raise SystemExit("unexpected owner scale")

    old_data = raw[base:]
    off = int(owner["offset"])
    old_n = int(owner["nbytes"])
    old_owner = old_data[off:off+old_n]
    if len(old_owner) != old_n:
        raise SystemExit("truncated owner data")

    row = 256 * 4
    r0 = old_owner[0*row:1*row]
    r1 = old_owner[1*row:2*row]
    r2 = old_owner[2*row:3*row]
    new_owner = r0 + r1 + r1 + r2
    delta = len(new_owner) - len(old_owner)
    assert delta == 1024

    new_data = old_data[:off] + new_owner + old_data[off+old_n:]
    new_header = copy.deepcopy(header)
    new_header["total_bytes"] = int(header["total_bytes"]) + delta
    old_label = str(header.get("label", "pluto"))
    new_header["label"] = old_label + "-team4seed"

    for t in new_header["tensors"]:
        toff = int(t["offset"])
        if t["name"] == "owner_emb.weight":
            t["shape"] = [4, 256]
            t["nbytes"] = 4 * 256 * 4
        else:
            if toff >= off + old_n:
                t["offset"] = toff + delta
        if t.get("scale_offset") is not None:
            so = int(t["scale_offset"])
            if so >= off + old_n:
                t["scale_offset"] = so + delta

    hb = json.dumps(new_header, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    new_base = align64(16 + len(hb))
    out = bytearray()
    out += b"PLWB"
    out += struct.pack("<I", 1)
    out += struct.pack("<Q", len(hb))
    out += hb
    out += b"\0" * (new_base - len(out))
    out += new_data

    if len(out) - new_base != int(new_header["total_bytes"]):
        raise SystemExit("rebuilt total_bytes mismatch")

    dst = Path(args.output)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(out)

    report = {
        "input_bytes": len(raw),
        "output_bytes": len(out),
        "old_base": base,
        "new_base": new_base,
        "owner_old_shape": [3,256],
        "owner_new_shape": [4,256],
        "owner_mapping": {
            "new[0]": "old[0] self",
            "new[1]": "old[1] other -> ally seed",
            "new[2]": "old[1] other -> enemy seed",
            "new[3]": "old[2] neutral",
        },
        "owner_bytes_delta": delta,
        "old_label": old_label,
        "new_label": new_header["label"],
    }
    print(json.dumps(report, indent=2))
    print("FOURWAY_OWNER_PLWB_BUILD=PASS")

if __name__ == "__main__":
    main()
