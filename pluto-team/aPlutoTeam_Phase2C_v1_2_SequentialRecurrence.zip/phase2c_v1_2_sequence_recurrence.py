from __future__ import annotations
import argparse, hashlib, itertools, json, math, os, struct, subprocess, threading, time
from pathlib import Path
import numpy as np
import torch
from pluto_trunk import PlutoFirstStep, linear, rms, swiglu

RESP=struct.Struct('<qqqqff')
REQ_HDR=struct.Struct('<iiiIqqqq')

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c: raise EOFError(f'expected {n}, got {len(b)}')
        b+=c
    return bytes(b)

def parse_resp(raw):
    a,arg,pos,unit,win,lp=RESP.unpack(raw)
    return {'action':int(a),'arg':int(arg),'pos':int(pos),'unit':int(unit),'win':float(win),'logprob':float(lp),'hex':raw.hex()}

def req_size(n): return 0x30+n*48+n*436+n+n+20+233+292*4+128*128*2+128*128+32

def parse_req(raw):
    n,w,h,flags,f0,f1,f2,f3=REQ_HDR.unpack_from(raw,0)
    if (w,h)!=(128,128) or len(raw)!=req_size(n): raise ValueError('bad request')
    off=0x30
    cat=np.frombuffer(raw,dtype='<i8',count=n*6,offset=off).copy().reshape(n,6);off+=n*48
    cont=np.frombuffer(raw,dtype='<f4',count=n*109,offset=off).copy().reshape(n,109);off+=n*436
    actor=np.frombuffer(raw,dtype=np.uint8,count=n,offset=off).copy();off+=n
    target=np.frombuffer(raw,dtype=np.uint8,count=n,offset=off).copy();off+=n
    action_mask=np.frombuffer(raw,dtype=np.uint8,count=20,offset=off).copy();off+=20
    arg_mask=np.frombuffer(raw,dtype=np.uint8,count=233,offset=off).copy();off+=233
    glob=np.frombuffer(raw,dtype='<f4',count=292,offset=off).copy();off+=292*4
    bits=np.frombuffer(raw,dtype='<u2',count=128*128,offset=off).copy().reshape(128,128);off+=128*128*2
    static=np.frombuffer(raw,dtype=np.uint8,count=128*128,offset=off).copy().reshape(128,128);off+=128*128
    hist=np.frombuffer(raw,dtype='<i8',count=4,offset=off).copy();off+=32
    return {'n':n,'cat':torch.from_numpy(cat).long(),'cont':torch.from_numpy(cont).float(),
            'global':torch.from_numpy(glob).float(),'bits':torch.from_numpy(bits.astype(np.int64,copy=False)).long(),
            'static':torch.from_numpy(static.astype(np.int64,copy=False)).long(),'hist':torch.from_numpy(hist).long(),
            'action_mask':action_mask,'actor_mask':actor,'target_mask':target,'arg_mask':arg_mask,
            'forced':[f0,f1,f2,f3]}

def run_engine_sequence(exe,weights,requests,stderr_path,timeout_s=120):
    cmd=[str(exe),'--blob',str(weights),'--backend','int8mv','--threads','1','--seed','123456789','--argmax']
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=flags,bufsize=0)
    err=[]
    def drain():
        while True:
            c=p.stderr.read(65536)
            if not c: break
            err.append(c)
    th=threading.Thread(target=drain,daemon=True);th.start()
    try:
        hs=read_exact(p.stdout,0x88)
        magic,ver,fps,maxu,step,label,build=struct.unpack('<4sIiiq48s64s',hs)
        if magic.rstrip(b'\0')!=b'PLO1' or ver!=3: raise RuntimeError('bad handshake')
        out=[]
        for r in requests:
            p.stdin.write(r);p.stdin.flush()
            out.append(read_exact(p.stdout,0x28))
        p.stdin.close()
        try: rc=p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired: p.kill();rc=p.wait(timeout=10)
        th.join(timeout=10)
        stderr_path.write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
        if rc!=0: raise RuntimeError(f'engine exit {rc}')
        return out
    finally:
        if p.poll() is None: p.kill();p.wait(timeout=10)

def slow_tick_variant(m,h,cache,mode):
    w=m.w
    x=rms(h,w['gru.slow_enc.in_norm.weight']);x=linear(x,w['gru.slow_enc.in_proj.weight'])
    new=[]
    for i in range(4):
        a=rms(x,w[f'gru.slow_enc.layers.{i}.norm_input.weight'])
        old=cache[i]
        cn=rms(old[1:],w[f'gru.slow_enc.layers.{i}.norm_cache.weight'])
        kv_old=linear(cn,w[f'gru.slow_enc.layers.{i}.kv_cache.weight'])
        kv_new=linear(a,w[f'gru.slow_enc.layers.{i}.kv_input.weight']).unsqueeze(0)
        K,V=torch.cat([kv_old,kv_new],dim=0).chunk(2,dim=-1)
        q=linear(a,w[f'gru.slow_enc.layers.{i}.q_proj.weight'])
        att=m.mha(q,K,V,8)
        x_att=x+linear(att,w[f'gru.slow_enc.layers.{i}.out_proj.weight'])
        ff_in=rms(x_att,w[f'gru.slow_enc.layers.{i}.ff_norm.weight'])
        x_ff=x_att+swiglu(ff_in,w[f'gru.slow_enc.layers.{i}.ff.gate_up.weight'],w[f'gru.slow_enc.layers.{i}.ff.down.weight'])
        appended={'input':x,'attn':x_att,'ff':x_ff}[mode]
        new.append(torch.cat([old[1:],appended.unsqueeze(0)],dim=0))
        x=x_ff
    return torch.stack(new,dim=0)

def prepare_feature(m,req):
    u0=m.encode_units(req['cat'],req['cont'])
    planes=m.assemble_planes(u0,req['cont'],req['bits'],req['static'])
    _,s32,s8=m.spatial_encoder(planes)
    u1=m.inject_spatial(u0,s32,req['cont'])
    U=m.encoder(u1)
    xt=m.global_hist(req['global'],req['hist'])
    return {'s8':s8,'U':U,'xt':xt,'mask':torch.from_numpy(req['action_mask'].astype(bool,copy=False))}

def run_variant(m,features,cfg):
    h=m.w['gru.h0'].clone();cache=m.slow_init();acts=[];raw=[]
    cadence=cfg.get('cadence',0);mode=cfg.get('mode');source=cfg.get('source')
    for i,f in enumerate(features):
        h_before=h
        h=m.gru_step(f['xt'],h,f['s8'],f['U'],cache[3])
        logits=linear(h,m.w['action_head.weight']).float()
        raw_a=int(torch.argmax(logits).item())
        z=logits.clone();z[~f['mask']]=-1e30
        act=int(torch.argmax(z).item())
        raw.append(raw_a);acts.append(act)
        if cadence and ((i+1)%cadence==0):
            src=h_before if source=='pre' else h
            cache=slow_tick_variant(m,src,cache,mode)
    return acts,raw

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--team4-exe',required=True);ap.add_argument('--team4-weights',required=True)
    ap.add_argument('--sequence',required=True);ap.add_argument('--out',required=True)
    a=ap.parse_args();seq=Path(a.sequence);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    man=json.loads((seq/'manifest.json').read_text(encoding='utf-8'))
    req_raw=[];live=[];meta=[]
    for x in man['items']:
        r=(seq/x['request_file']).read_bytes(); rr=(seq/x['response_file']).read_bytes()
        if hashlib.sha256(r).hexdigest()!=x['request_sha256']: raise SystemExit('request SHA mismatch')
        req_raw.append(r);live.append(rr);meta.append(x)
    print(f'SEQUENCE_REQUESTS={len(req_raw)} frames={meta[0]["frame"]}..{meta[-1]["frame"]}')

    off_raw=run_engine_sequence(Path(a.team4_exe),Path(a.team4_weights),req_raw,out/'official_sequence.stderr.txt')
    off=[parse_resp(x) for x in off_raw]; livep=[parse_resp(x) for x in live]
    exact=sum(x==y for x,y in zip(off_raw,live)); action_live=sum(x['action']==y['action'] for x,y in zip(off,livep))
    print(f'OFFICIAL_PERSISTENT_VS_LIVE exact={exact}/{len(off)} action={action_live}/{len(off)}')
    print('OFFICIAL_ACTIONS', [x['action'] for x in off[:24]])

    m=PlutoFirstStep(Path(a.team4_weights),'center01')
    reqs=[parse_req(r) for r in req_raw]
    with torch.inference_mode():
        features=[]
        for i,r in enumerate(reqs,1):
            features.append(prepare_feature(m,r))
            if i<=4 or i%16==0: print(f'FEATURE_READY {i}/{len(reqs)} N={r["n"]}')
        variants=[{'name':'never','cadence':0,'mode':None,'source':None}]
        for source,mode,cad in itertools.product(['pre','post'],['input','attn','ff'],[1,2,4,8,16,32]):
            variants.append({'name':f'{source}_{mode}_every{cad}','cadence':cad,'mode':mode,'source':source})
        results=[]
        oracle=[x['action'] for x in off]
        for cfg in variants:
            acts,raw=run_variant(m,features,cfg)
            match=sum(a==b for a,b in zip(acts,oracle)); rawmatch=sum(a==b for a,b in zip(raw,oracle))
            first_bad=next((i+1 for i,(a,b) in enumerate(zip(acts,oracle)) if a!=b),None)
            results.append({'config':cfg,'masked_match':match,'raw_match':rawmatch,'first_bad':first_bad,'actions':acts})
        results.sort(key=lambda x:(-x['masked_match'],-x['raw_match'],x['first_bad'] or 10**9,x['config']['name']))
    print('TOP_SEQUENCE_LAYOUTS')
    for i,r in enumerate(results[:12],1): print(i,json.dumps({k:r[k] for k in ['config','masked_match','raw_match','first_bad']},sort_keys=True))
    best=results[0]
    report={'format':'pluto-team-phase2c-v1.2-sequence-recurrence','steps':len(off),
            'official_persistent_vs_live_exact':exact,'official_persistent_vs_live_action':action_live,
            'official_actions':[x['action'] for x in off], 'best':best,'top':results[:12]}
    (out/'phase2c_v1_2_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    with (out/'phase2c_v1_2_summary.txt').open('w',encoding='utf-8') as f:
        f.write('aPlutoTeam Phase2C v1.2 Sequential Recurrent Ordering\n')
        f.write(f'steps={len(off)}\n')
        f.write(f'official_persistent_vs_live_exact={exact}/{len(off)}\n')
        f.write(f'official_persistent_vs_live_action={action_live}/{len(off)}\n')
        f.write(f'best_masked_match={best["masked_match"]}/{len(off)}\n')
        f.write(f'best_raw_match={best["raw_match"]}/{len(off)}\n')
        f.write('best_config='+json.dumps(best['config'],sort_keys=True)+'\n')
        f.write(f'first_bad={best["first_bad"]}\n')
        if best['masked_match']==len(off): f.write('PHASE2C_V1_2_RECURRENT_SEQUENCE=FULL_ACTION_MATCH\n')
        elif best['masked_match']>=int(len(off)*0.90): f.write('PHASE2C_V1_2_RECURRENT_SEQUENCE=STRONG_CANDIDATE\n')
        else: f.write('PHASE2C_V1_2_RECURRENT_SEQUENCE=NEEDS_DEEPER_TIMING_PROBE\n')
        f.write('PHASE2C_V1_2_DIAGNOSTIC_COMPLETE=PASS\n')
    print((out/'phase2c_v1_2_summary.txt').read_text())

if __name__=='__main__': main()
