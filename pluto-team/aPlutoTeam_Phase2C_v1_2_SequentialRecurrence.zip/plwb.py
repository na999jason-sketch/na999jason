from __future__ import annotations
import json, math, struct
from dataclasses import dataclass
from pathlib import Path
import numpy as np

DTYPE_BYTES = {"float32": 4, "float16": 2, "bfloat16": 2, "int8": 1}

@dataclass(frozen=True)
class TensorInfo:
    name: str
    shape: tuple[int, ...]
    offset: int
    nbytes: int
    dtype: str
    scale_offset: int | None = None
    scale_len: int | None = None
    @property
    def numel(self): return math.prod(self.shape)
    @property
    def scale_axis(self):
        if self.scale_len is None: return None
        if self.scale_len == self.shape[0]: return 0
        if len(self.shape) > 1 and self.scale_len == self.shape[1]: return 1
        raise ValueError(f"{self.name}: unsupported scale axis")

class PLWB:
    def __init__(self, path):
        self.path = Path(path)
        self.raw = self.path.read_bytes()
        if self.raw[:4] != b"PLWB": raise ValueError("not PLWB")
        self.version = struct.unpack_from("<I", self.raw, 4)[0]
        if self.version != 1: raise ValueError(f"unsupported version {self.version}")
        self.header_len = struct.unpack_from("<Q", self.raw, 8)[0]
        h0, h1 = 16, 16 + self.header_len
        self.header = json.loads(self.raw[h0:h1].decode("utf-8"))
        self.total_bytes = int(self.header["total_bytes"])
        self.base = len(self.raw) - self.total_bytes
        self.tensors = []
        for d in self.header["tensors"]:
            self.tensors.append(TensorInfo(
                d["name"], tuple(int(x) for x in d["shape"]), int(d["offset"]), int(d["nbytes"]),
                d.get("dtype", "float32"),
                None if d.get("scale_offset") is None else int(d["scale_offset"]),
                None if d.get("scale_len") is None else int(d["scale_len"]),
            ))
        self.by_name = {t.name:t for t in self.tensors}

    def _slice(self, off, n):
        a = self.base + off
        return memoryview(self.raw)[a:a+n]

    def raw_array(self, name):
        t = self.by_name[name]; b = self._slice(t.offset, t.nbytes)
        if t.dtype == "float32": return np.frombuffer(b, dtype="<f4").reshape(t.shape)
        if t.dtype == "float16": return np.frombuffer(b, dtype="<f2").reshape(t.shape).astype(np.float32)
        if t.dtype == "bfloat16":
            u = np.frombuffer(b, dtype="<u2").astype(np.uint32) << 16
            return u.view("<f4").reshape(t.shape)
        if t.dtype == "int8": return np.frombuffer(b, dtype=np.int8).reshape(t.shape)
        raise ValueError(t.dtype)

    def dequantized(self, name):
        t = self.by_name[name]
        a = self.raw_array(name)
        if t.dtype != "int8": return a.astype(np.float32, copy=False)
        s = np.frombuffer(self._slice(t.scale_offset, 4*t.scale_len), dtype="<f4")
        sh = [1]*len(t.shape); sh[t.scale_axis] = t.scale_len
        return a.astype(np.float32) * s.reshape(sh)
