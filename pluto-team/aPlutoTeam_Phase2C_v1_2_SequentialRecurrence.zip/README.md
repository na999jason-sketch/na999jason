# aPlutoTeam Phase2C v1.2 — Sequential Recurrent Ordering

Phase2C v1.1 proved that fresh first-step action parity is 8/8 only when the initial slow cache is read **without a pre-GRU slow tick**. This package fixes that first-step ordering in `pluto_trunk.py` and moves to the next requirement for training: recurrent sequence parity.

It packages the first 64 consecutive clean v104 requests (frames 469..940) and their recorder responses. The workflow starts one patched official four-way `pluto_infer.exe`, feeds all 64 requests through the same process, and uses those persistent-engine actions as the recurrence oracle. It then precomputes the expensive observation trunk once per request and grids slow-cache update timing across:

- no slow update;
- cache append point: input / post-attention / post-FF;
- hidden source: pre-GRU or post-GRU;
- cadence: every 1 / 2 / 4 / 8 / 16 / 32 decisions.

The owner embedding remains the policy-preserving four-way seed. No training is performed.

Success criterion: `PHASE2C_V1_2_RECURRENT_SEQUENCE=FULL_ACTION_MATCH`.
