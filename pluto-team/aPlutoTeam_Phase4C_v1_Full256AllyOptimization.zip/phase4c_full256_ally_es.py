from __future__ import annotations
import argparse, hashlib, json, math, shutil, struct, subprocess, threading
from pathlib import Path
import numpy as np

RESP=struct.Struct('<qqqqff')
REQ_HDR=struct.Struct('<iiiIqqqq')
WORKER_TYPES={7,41,64}
BUILDING_MIN=106
BUILDING_MAX=201

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c:
            raise EOFError(f'expected {n}, got {len(b)}')
        b+=c
    return bytes(b)

def parse_resp(raw):
    a,arg,pos,unit,win,lp=RESP.unpack(raw)
    return {'action':int(a),'arg':int(arg),'pos':int(pos),'unit':int(unit),
            'win':float(win),'logprob':float(lp),'hex':raw.hex()}

def req_n(raw):
    return REQ_HDR.unpack_from(raw,0)[0]

def is_protected_asset(unit_type:int)->bool:
    return unit_type in WORKER_TYPES or BUILDING_MIN <= unit_type <= BUILDING_MAX

def rewrite_teacher(raw:bytes, category:str)->bytes:
    # Do NOT repeat the failed v105 "all allies = SELF" shortcut.
    # Peace/enemy-preserve: allies are non-hostile/non-controllable context.
    # Ally threat: only allied workers/buildings are protection assets.
    out=bytearray(raw)
    n=req_n(raw)
    off=0x30
    for r in range(n):
        p=off+r*48
        typ=struct.unpack_from('<q',out,p)[0]
        owner=struct.unpack_from('<q',out,p+8)[0]
        if owner==1:
            new_owner=0 if category=='ally_threat' and is_protected_asset(int(typ)) else 3
            struct.pack_into('<q',out,p+8,new_owner)
    return bytes(out)

def load_owner(path:Path):
    raw=bytearray(path.read_bytes())
    if raw[:4]!=b'PLWB':
        raise ValueError('not PLWB')
    hlen=struct.unpack_from('<Q',raw,8)[0]
    hdr=json.loads(raw[16:16+hlen].decode('utf-8'))
    base=len(raw)-int(hdr['total_bytes'])
    t=next(x for x in hdr['tensors'] if x['name']=='owner_emb.weight')
    if list(t['shape'])!=[4,256] or int(t['nbytes'])!=4096:
        raise ValueError(f'bad owner tensor {t}')
    off=base+int(t['offset'])
    arr=np.frombuffer(raw,dtype='<f4',count=1024,offset=off).copy().reshape(4,256)
    return raw,off,arr

def patch_owner_row(path:Path,row:np.ndarray):
    raw,off,_=load_owner(path)
    row=np.asarray(row,dtype='<f4').reshape(256)
    raw[off+1024:off+2048]=row.tobytes()
    path.write_bytes(raw)

def run_engine_sequence(exe:Path,weights:Path,requests:list[bytes],stderr_path:Path,timeout_s=600):
    cmd=[str(exe),'--blob',str(weights),'--backend','int8mv','--threads','1',
         '--seed','123456789','--argmax']
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                       creationflags=flags,bufsize=0)
    err=[]
    def drain():
        while True:
            c=p.stderr.read(65536)
            if not c:
                break
            err.append(c)
    th=threading.Thread(target=drain,daemon=True)
    th.start()
    try:
        hs=read_exact(p.stdout,0x88)
        magic,ver,*_=struct.unpack('<4sIiiq48s64s',hs)
        if magic.rstrip(b'\0')!=b'PLO1' or ver!=3:
            raise RuntimeError('bad handshake')
        out=[]
        for r in requests:
            p.stdin.write(r); p.stdin.flush()
            out.append(parse_resp(read_exact(p.stdout,0x28)))
        p.stdin.close()
        try:
            rc=p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            p.kill(); rc=p.wait(timeout=10)
        th.join(timeout=10)
        stderr_path.write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
        if rc!=0:
            raise RuntimeError(f'engine exit {rc}')
        return out
    finally:
        if p.poll() is None:
            p.kill(); p.wait(timeout=10)

def score_responses(got,target,items):
    score=0.0; maxscore=0.0; am=0; exact4=0
    for g,t,m in zip(got,target,items):
        w=float(m.get('weight',1.0))
        cat=m['category']
        # Two priorities from the actual failures:
        # 1) stop ally-base loiter / ally-target behavior,
        # 2) still react when protected ally assets are threatened.
        if cat=='peace_block':
            w*=3.0
        elif cat=='ally_threat':
            w*=4.0
        pts=0.0
        if g['action']==t['action']:
            pts+=8; am+=1
        if g['arg']==t['arg']:
            pts+=2
        if g['unit']==t['unit']:
            pts+=2
        if g['pos']==t['pos']:
            pts+=1
        pts+=0.5*max(0.0,1.0-min(1.0,abs(g['win']-t['win'])/0.25))
        if (g['action'],g['arg'],g['pos'],g['unit'])==(t['action'],t['arg'],t['pos'],t['unit']):
            exact4+=1
        score+=w*pts
        maxscore+=w*13.5
    return {'score':score,'normalized':score/maxscore if maxscore else 0.0,
            'action_match':am,'exact_int4':exact4}

def category_scores(got,target,items):
    out={}
    cats=sorted(set(m['category'] for m in items))
    for cat in cats:
        ids=[i for i,m in enumerate(items) if m['category']==cat]
        out[cat]=score_responses([got[i] for i in ids],[target[i] for i in ids],[items[i] for i in ids])
    return out

def preserve_floor(cat_scores):
    return min(cat_scores[x]['action_match'] for x in ('peace_dense','peace_block','enemy_preserve'))

def scalar_reward(rec,baseline):
    # Official-engine black-box objective. No PyTorch parity dependency.
    r=rec['overall']['normalized']
    c=rec['category']; b=baseline['category']
    # Strong penalty for breaking ordinary behavior relative to neutral baseline.
    for x in ('peace_dense','peace_block','enemy_preserve'):
        deficit=max(0,b[x]['action_match']-c[x]['action_match'])
        r-=0.045*deficit
    # Reward actual protected-asset defense improvement.
    r+=0.035*(c['ally_threat']['action_match']-b['ally_threat']['action_match'])
    r+=0.20*(c['ally_threat']['normalized']-b['ally_threat']['normalized'])
    return float(r)

def rms(x):
    return float(np.sqrt(np.mean(np.asarray(x,dtype=np.float64)**2)))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--exe',required=True)
    ap.add_argument('--weights',required=True)
    ap.add_argument('--samples',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--generations',type=int,default=8)
    ap.add_argument('--directions',type=int,default=4)
    a=ap.parse_args()

    exe=Path(a.exe); base=Path(a.weights); samples=Path(a.samples); out=Path(a.out)
    out.mkdir(parents=True,exist_ok=True)
    logs=out/'logs'; logs.mkdir(exist_ok=True)

    man=json.loads((samples/'manifest.json').read_text(encoding='utf-8'))
    items=man['samples']; raws=[]
    for m in items:
        r=(samples/m['file']).read_bytes()
        if hashlib.sha256(r).hexdigest()!=m['sha256']:
            raise SystemExit(f'SHA mismatch {m["file"]}')
        raws.append(r)
    if len(raws)!=48:
        raise SystemExit(f'expected 48 samples, got {len(raws)}')

    teacher_raw=[rewrite_teacher(r,m['category']) for r,m in zip(raws,items)]

    # Search set: six chronological samples from each category.
    keep=[]
    for cat in ('peace_dense','enemy_preserve','peace_block','ally_threat'):
        ids=[i for i,m in enumerate(items) if m['category']==cat]
        keep.extend(ids[::2][:6])
    keep=sorted(keep)
    sitems=[items[i] for i in keep]
    sraw=[raws[i] for i in keep]
    steacher_raw=[teacher_raw[i] for i in keep]

    # Teacher responses are generated by the official Pluto engine itself.
    teacher_search=run_engine_sequence(exe,base,steacher_raw,logs/'teacher_search.stderr.txt')
    teacher_full_fwd=run_engine_sequence(exe,base,teacher_raw,logs/'teacher_full_fwd.stderr.txt')
    rev=list(range(len(raws)-1,-1,-1))
    teacher_full_rev=run_engine_sequence(exe,base,[teacher_raw[i] for i in rev],logs/'teacher_full_rev.stderr.txt')

    _,_,anchors=load_owner(base)
    self_row=anchors[0].copy()
    enemy_row=anchors[2].copy()
    neutral_row=anchors[3].copy()

    # Natural owner-embedding scale. Exploration is in the full 256-D space.
    anchor_scale=float(np.median([
        rms(self_row-neutral_row),
        rms(enemy_row-neutral_row),
        rms(self_row-enemy_row)
    ]))
    if not math.isfinite(anchor_scale) or anchor_scale<=1e-8:
        raise SystemExit('bad anchor scale')

    work=out/'candidate_weights.bin'
    eval_counter=0

    def evaluate_row(row,stage,full_mode='search'):
        nonlocal eval_counter
        eval_counter+=1
        shutil.copy2(base,work)
        patch_owner_row(work,row)
        tag=f'{eval_counter:04d}_{stage}'
        if full_mode=='search':
            rr=sraw; ii=sitems; tt=teacher_search
        elif full_mode=='fwd':
            rr=raws; ii=items; tt=teacher_full_fwd
        elif full_mode=='rev':
            rr=[raws[i] for i in rev]
            ii=[items[i] for i in rev]
            tt=teacher_full_rev
        else:
            raise ValueError(full_mode)
        got=run_engine_sequence(exe,work,rr,logs/f'{tag}_{full_mode}.stderr.txt')
        rec={'stage':stage,'mode':full_mode,
             'overall':score_responses(got,tt,ii),
             'category':category_scores(got,tt,ii),
             'row':np.asarray(row,dtype=np.float32).copy()}
        return rec

    # Neutral baseline.
    baseline_search=evaluate_row(neutral_row,'neutral','search')
    baseline_fwd=evaluate_row(neutral_row,'neutral','fwd')
    baseline_rev=evaluate_row(neutral_row,'neutral','rev')
    base_reward=scalar_reward(baseline_search,baseline_search)
    print(f'BASE anchor_scale={anchor_scale:.8g} search={baseline_search["overall"]["normalized"]:.6f} '
          f'threat={baseline_search["category"]["ally_threat"]["action_match"]}/6',flush=True)

    rng=np.random.default_rng(20261005)
    center=neutral_row.copy()
    best_pool=[]
    trace=[]

    # Full-dimensional antithetic evolution strategy.
    for gen in range(a.generations):
        sigma=(0.14*(0.82**gen))*anchor_scale
        step=(0.11*(0.88**gen))*anchor_scale
        dirs=[]
        pair_records=[]
        gvec=np.zeros(256,dtype=np.float64)

        for j in range(a.directions):
            d=rng.standard_normal(256).astype(np.float64)
            d/=max(rms(d),1e-12)
            plus=center + sigma*d
            minus=center - sigma*d
            rp=evaluate_row(plus,f'g{gen+1:02d}_d{j+1:02d}_plus','search')
            rm=evaluate_row(minus,f'g{gen+1:02d}_d{j+1:02d}_minus','search')
            sp=scalar_reward(rp,baseline_search)
            sm=scalar_reward(rm,baseline_search)
            rp['reward']=sp; rm['reward']=sm
            best_pool.extend([rp,rm])
            pair_records.append((sp,sm))
            gvec+=(sp-sm)*d
            print(f'ES g={gen+1} d={j+1} plus={sp:.6f} minus={sm:.6f} '
                  f'plusThreat={rp["category"]["ally_threat"]["action_match"]}/6 '
                  f'minusThreat={rm["category"]["ally_threat"]["action_match"]}/6',flush=True)

        gr=rms(gvec)
        if gr>1e-12:
            gvec/=gr
            proposed=center + step*gvec
        else:
            proposed=center.copy()

        # Keep search bounded around neutral but allow truly arbitrary directions.
        delta=proposed-neutral_row
        maxdist=0.75*anchor_scale
        dr=rms(delta)
        if dr>maxdist:
            proposed=neutral_row + delta*(maxdist/dr)

        rc=evaluate_row(proposed,f'g{gen+1:02d}_center','search')
        rc['reward']=scalar_reward(rc,baseline_search)
        best_pool.append(rc)

        # Greedy center update: keep whichever is best among current proposal and all pairs in generation.
        gen_candidates=[rc]+best_pool[-(2*a.directions+1):-1]
        winner=max(gen_candidates,key=lambda z:z['reward'])
        if winner['reward'] >= rc['reward']:
            center=winner['row'].copy()
        else:
            center=proposed.copy()

        trace.append({
            'generation':gen+1,'sigma':sigma,'step':step,'gradient_rms':gr,
            'center_reward':rc['reward'],'winner_reward':winner['reward'],
            'center_distance_rms':rms(center-neutral_row)
        })
        print(f'ES_GEN_DONE g={gen+1} centerReward={rc["reward"]:.6f} '
              f'winner={winner["reward"]:.6f} dist={rms(center-neutral_row):.8g}',flush=True)

    # Rank distinct search candidates and full-validate top 6 plus final center.
    def search_key(r):
        c=r['category']
        return (r.get('reward',-999.0),
                c['ally_threat']['action_match'],
                c['peace_block']['action_match'],
                r['overall']['normalized'])

    distinct=[]
    seen=set()
    for r in sorted(best_pool,key=search_key,reverse=True):
        h=hashlib.sha256(np.asarray(r['row'],dtype='<f4').tobytes()).hexdigest()
        if h in seen:
            continue
        seen.add(h)
        if rms(r['row']-neutral_row) < 0.01*anchor_scale:
            continue
        distinct.append(r)
        if len(distinct)>=6:
            break

    validations=[]
    for k,r in enumerate(distinct,1):
        rf=evaluate_row(r['row'],f'validate{k:02d}','fwd')
        rr=evaluate_row(r['row'],f'validate{k:02d}','rev')
        validations.append({'search':r,'fwd':rf,'rev':rr})

    def deploy_metrics(v):
        nf=baseline_fwd['category']; nr=baseline_rev['category']
        cf=v['fwd']['category']; cr=v['rev']['category']
        preserve_ok=True
        for x in ('peace_dense','peace_block','enemy_preserve'):
            if cf[x]['action_match'] < nf[x]['action_match']-1:
                preserve_ok=False
            if cr[x]['action_match'] < nr[x]['action_match']-1:
                preserve_ok=False
        tf0=nf['ally_threat']; tr0=nr['ally_threat']
        tf=cf['ally_threat']; tr=cr['ally_threat']
        no_threat_regression=(tf['action_match']>=tf0['action_match'] and tr['action_match']>=tr0['action_match'])
        improved=(
            tf['action_match']>tf0['action_match'] or tr['action_match']>tr0['action_match'] or
            (tf['normalized']+tr['normalized']) >= (tf0['normalized']+tr0['normalized'])+0.04
        )
        distinct_ok=rms(v['fwd']['row']-neutral_row) >= 0.01*anchor_scale
        deploy=bool(preserve_ok and no_threat_regression and improved and distinct_ok)
        return {
            'preserve_ok':preserve_ok,'no_threat_regression':no_threat_regression,
            'threat_improved':improved,'distinct':distinct_ok,'deployable':deploy,
            'threat_fwd':[tf['action_match'],tf0['action_match'],tf['normalized'],tf0['normalized']],
            'threat_rev':[tr['action_match'],tr0['action_match'],tr['normalized'],tr0['normalized']]
        }

    for v in validations:
        v['metrics']=deploy_metrics(v)

    deployable=[v for v in validations if v['metrics']['deployable']]
    if deployable:
        def val_key(v):
            mf=v['metrics']
            return (
                v['fwd']['category']['ally_threat']['action_match']+
                v['rev']['category']['ally_threat']['action_match'],
                v['fwd']['category']['ally_threat']['normalized']+
                v['rev']['category']['ally_threat']['normalized'],
                v['fwd']['overall']['normalized']+v['rev']['overall']['normalized']
            )
        best=max(deployable,key=val_key)
        best_row=np.asarray(best['fwd']['row'],dtype='<f4')
        best_row.tofile(out/'ally_embedding_phase4c_f32.bin')
        (out/'ally_embedding_phase4c.json').write_text(json.dumps({
            'vector':[float(x) for x in best_row],
            'distance_from_neutral_rms':rms(best_row-neutral_row),
            'anchor_scale':anchor_scale,
            'metrics':best['metrics']
        },indent=2),encoding='utf-8')
        cls='FULL256_ALLY_SIGNAL_FOUND'
        deploy=True
    else:
        best=None
        cls='NO_DEPLOYABLE_FULL256_ALLY_SIGNAL'
        deploy=False

    def strip(r):
        return {
            'stage':r['stage'],'mode':r['mode'],
            'overall':r['overall'],'category':r['category'],
            'distance_from_neutral_rms':rms(r['row']-neutral_row),
            'reward':r.get('reward')
        }

    report={
        'format':'pluto-team-phase4c-v1-official-engine-full256-es',
        'samples':len(items),'search_samples':len(sitems),
        'generations':a.generations,'directions_per_generation':a.directions,
        'optimizer':'antithetic evolution strategy over all 256 ALLY embedding dimensions',
        'oracle':'official patched Pluto int8mv; no PyTorch action parity dependency',
        'teacher_rule':'peace/enemy: allies -> neutral; ally_threat: allied workers/buildings -> self and allied combat/mobile -> neutral; masks unchanged',
        'anchor_scale':anchor_scale,
        'neutral_fwd':strip(baseline_fwd),'neutral_rev':strip(baseline_rev),
        'trace':trace,
        'validations':[{
            'search':strip(v['search']),
            'fwd':strip(v['fwd']),
            'rev':strip(v['rev']),
            'metrics':v['metrics']
        } for v in validations],
        'deployable':deploy,'classification':cls
    }
    (out/'phase4c_v1_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

    if best:
        m=best['metrics']
        detail=(f'threat_fwd={m["threat_fwd"][0]}/{m["threat_fwd"][1]} '
                f'threat_rev={m["threat_rev"][0]}/{m["threat_rev"][1]}')
    else:
        detail='no candidate passed dual-order protected-asset validation'

    summary='\n'.join([
        'aPlutoTeam Phase4C v1 Official-Engine Full-256D ALLY Optimization',
        f'samples={len(items)} search_samples={len(sitems)}',
        f'generations={a.generations} directions={a.directions}',
        f'anchor_scale={anchor_scale:.8g}',
        f'deployable={deploy} result_class={cls}',
        detail,
        'PHASE4C_V1_FULL256_ALLY_OPTIMIZATION=PASS'
    ])+'\n'
    (out/'phase4c_v1_summary.txt').write_text(summary,encoding='utf-8')
    print(summary,flush=True)
    work.unlink(missing_ok=True)

if __name__=='__main__':
    main()
