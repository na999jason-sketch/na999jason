# aPlutoTeam Phase4C v1 — Official-Engine Full-256D ALLY Optimization

This phase abandons SELF/ENEMY/NEUTRAL linear mixing.

It searches all 256 values of `owner_emb[1]` directly with an antithetic evolution strategy.
Every candidate is evaluated by the official patched Pluto `int8mv` engine. PyTorch parity is not used
as the acceptance oracle.

Teacher:
- Peace / enemy-preserve scenes: allied units are non-hostile team context (NEUTRAL teacher).
- Ally-threat scenes: allied workers/buildings are friendly protected assets (SELF teacher);
  allied combat/mobile units remain non-controllable team context (NEUTRAL teacher).
- Actor and target masks remain unchanged.

Acceptance:
- Candidate must be distinct from NEUTRAL.
- Peace / enemy-preserve behavior cannot regress by more than one action per category.
- Protected-asset threat behavior cannot regress in either forward or reverse validation order.
- It must improve protected-asset behavior in action match or score.
- Only then is `ally_embedding_phase4c_f32.bin` emitted.

Known empirical motivation:
- ALLY=ENEMY caused hostile behavior.
- ALLY=SELF caused severe ally-target/loiter/stim behavior.
- Phase4A collapsed to NEUTRAL.
- Phase4B found no deployable direction in the 2-D anchor plane.
