# aPlutoTeam Phase4D v1 — Relation-Only Low-Rank Adapter

Phase4C showed that moving only `owner_emb[1]` cannot cleanly separate:
- ordinary allied presence (must not cause loiter/target/stim behavior), and
- protected allied assets under enemy pressure.

Phase4D keeps the original Pluto strategy network and creates a **virtual ALLY-only channel inside
the existing first input projection**, without adding a new strategic rule.

## How the channel is isolated

`cat_norm` is a layer norm over the concatenated categorical embeddings.  We construct a 256-D
marker direction `q` satisfying:

- `q·(gamma * SELF) = 0`
- `q·(gamma * ENEMY) = 0`
- `q·(gamma * NEUTRAL) = 0`
- `q·gamma = 0`
- `q·beta = 0`

Therefore a rank-1 weight change on the owner slice of `input_proj.0.gate_up.weight` is zero for
SELF/ENEMY/NEUTRAL after layer norm and can fire only for the marked ALLY row.

The marker row itself is kept extremely close to NEUTRAL.  The adapter uses four high-impact
SwiGLU hidden units and eight trainable coordinates (same/opposite gate-value patterns).

## Training / validation

- Teacher and scoring use the official Pluto executable.
- Search uses the official all-FP32 `pk` backend so the input-projection rows can be patched exactly.
- Final candidate is re-quantized back into the original `int8mv` tensor and must pass a second
  official-engine validation.
- No PyTorch action parity is used as the acceptance oracle.
- If validation fails, no runtime weights are emitted.

This is relation interpretation, not a handcrafted combat/defense policy: the original Pluto
network still chooses actions.
