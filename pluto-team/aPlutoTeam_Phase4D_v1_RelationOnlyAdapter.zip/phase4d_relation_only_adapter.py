from __future__ import annotations
import argparse, hashlib, json, math, os, shutil, struct, subprocess, threading
from pathlib import Path
import numpy as np

RESP=struct.Struct('<qqqqff')
REQ_HDR=struct.Struct('<iiiIqqqq')
EMB_NAMES=[
    "unit_type_emb.weight","owner_emb.weight","order_emb.weight",
    "last_action_emb.weight","train_type_emb.weight","research_type_emb.weight"
]
WORKER_TYPES={7,41,64}
BUILDING_MIN=106
BUILDING_MAX=201
LN_EPS=1e-5

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c:
            raise EOFError(f'expected {n}, got {len(b)}')
        b+=c
    return bytes(b)

def parse_resp(raw):
    a,arg,pos,unit,win,lp=RESP.unpack(raw)
    return {'action':int(a),'arg':int(arg),'pos':int(pos),'unit':int(unit),
            'win':float(win),'logprob':float(lp),'hex':raw.hex()}

def run_engine_sequence(exe,weights,backend,threads,requests,stderr_path,timeout_s=900):
    cmd=[str(exe),'--blob',str(weights),'--backend',backend,'--threads',str(threads),
         '--seed','123456789','--argmax']
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                       creationflags=flags,bufsize=0)
    err=[]
    def drain():
        while True:
            c=p.stderr.read(65536)
            if not c: break
            err.append(c)
    th=threading.Thread(target=drain,daemon=True); th.start()
    try:
        hs=read_exact(p.stdout,0x88)
        magic,ver,*_=struct.unpack('<4sIiiq48s64s',hs)
        if magic.rstrip(b'\0')!=b'PLO1' or ver!=3:
            raise RuntimeError('bad handshake')
        out=[]
        for r in requests:
            p.stdin.write(r); p.stdin.flush()
            out.append(parse_resp(read_exact(p.stdout,0x28)))
        p.stdin.close()
        try:
            rc=p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            p.kill(); rc=p.wait(timeout=10)
        th.join(timeout=10)
        Path(stderr_path).write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
        if rc!=0: raise RuntimeError(f'engine exit {rc}')
        return out
    finally:
        if p.poll() is None:
            p.kill(); p.wait(timeout=10)

def read_header(path):
    path=Path(path)
    with path.open('rb') as f:
        pre=f.read(16)
        if pre[:4]!=b'PLWB': raise ValueError('not PLWB')
        ver=struct.unpack_from('<I',pre,4)[0]
        if ver!=1: raise ValueError(ver)
        hlen=struct.unpack_from('<Q',pre,8)[0]
        hdr=json.loads(f.read(hlen).decode('utf-8'))
    base=path.stat().st_size-int(hdr['total_bytes'])
    by={x['name']:x for x in hdr['tensors']}
    return hdr,by,base

def read_f32_tensor(path,name):
    hdr,by,base=read_header(path); t=by[name]
    if t.get('dtype','float32')!='float32':
        raise ValueError(f'{name} not float32')
    count=math.prod(t['shape'])
    with Path(path).open('rb') as f:
        f.seek(base+int(t['offset']))
        b=f.read(count*4)
    return np.frombuffer(b,dtype='<f4').copy().reshape(tuple(t['shape']))

def write_f32_owner_row(path,row_index,row):
    hdr,by,base=read_header(path); t=by['owner_emb.weight']
    if t.get('dtype','float32')!='float32' or list(t['shape'])!=[4,256]:
        raise ValueError(t)
    row=np.asarray(row,dtype='<f4').reshape(256)
    off=base+int(t['offset'])+row_index*256*4
    with Path(path).open('r+b') as f:
        f.seek(off); f.write(row.tobytes())

def read_f32_row_slice(path,tname,row,c0,c1):
    hdr,by,base=read_header(path); t=by[tname]
    if t.get('dtype','float32')!='float32' or len(t['shape'])!=2:
        raise ValueError(t)
    cols=int(t['shape'][1])
    off=base+int(t['offset'])+(row*cols+c0)*4
    with Path(path).open('rb') as f:
        f.seek(off); b=f.read((c1-c0)*4)
    return np.frombuffer(b,dtype='<f4').copy()

def write_f32_row_slice(path,tname,row,c0,values):
    hdr,by,base=read_header(path); t=by[tname]
    cols=int(t['shape'][1]); v=np.asarray(values,dtype='<f4')
    off=base+int(t['offset'])+(row*cols+c0)*4
    with Path(path).open('r+b') as f:
        f.seek(off); f.write(v.tobytes())

def req_n(raw): return REQ_HDR.unpack_from(raw,0)[0]

def parse_cat(raw):
    n=req_n(raw); off=0x30
    return np.frombuffer(raw,dtype='<i8',count=n*6,offset=off).copy().reshape(n,6)

def is_protected_asset(unit_type):
    return int(unit_type) in WORKER_TYPES or BUILDING_MIN <= int(unit_type) <= BUILDING_MAX

def rewrite_teacher(raw,category):
    out=bytearray(raw); n=req_n(raw); off=0x30
    for r in range(n):
        p=off+r*48
        typ=struct.unpack_from('<q',out,p)[0]
        owner=struct.unpack_from('<q',out,p+8)[0]
        if owner==1:
            new_owner=0 if category=='ally_threat' and is_protected_asset(typ) else 3
            struct.pack_into('<q',out,p+8,new_owner)
    return bytes(out)

def rewrite_all_allies(raw,new_owner):
    out=bytearray(raw); n=req_n(raw); off=0x30
    for r in range(n):
        p=off+r*48+8
        owner=struct.unpack_from('<q',out,p)[0]
        if owner==1: struct.pack_into('<q',out,p,int(new_owner))
    return bytes(out)

def score_responses(got,target,items):
    score=0.; maxscore=0.; am=0; exact4=0
    for g,t,m in zip(got,target,items):
        w=float(m.get('weight',1.0))
        cat=m['category']
        if cat=='peace_block': w*=3.0
        elif cat=='ally_threat': w*=4.0
        pts=0.
        if g['action']==t['action']: pts+=8; am+=1
        if g['arg']==t['arg']: pts+=2
        if g['unit']==t['unit']: pts+=2
        if g['pos']==t['pos']: pts+=1
        pts+=0.5*max(0.,1.-min(1.,abs(g['win']-t['win'])/0.25))
        if (g['action'],g['arg'],g['pos'],g['unit'])==(t['action'],t['arg'],t['pos'],t['unit']):
            exact4+=1
        score+=w*pts; maxscore+=w*13.5
    return {'score':score,'normalized':score/maxscore,'action_match':am,'exact_int4':exact4}

def category_scores(got,target,items):
    out={}
    for cat in sorted(set(m['category'] for m in items)):
        ids=[i for i,m in enumerate(items) if m['category']==cat]
        out[cat]=score_responses([got[i] for i in ids],[target[i] for i in ids],[items[i] for i in ids])
    return out

def reward(rec,neutral):
    r=rec['overall']['normalized']
    c=rec['category']; n=neutral['category']
    for x in ('peace_dense','peace_block','enemy_preserve'):
        r-=0.055*max(0,n[x]['action_match']-c[x]['action_match'])
    r+=0.050*(c['ally_threat']['action_match']-n['ally_threat']['action_match'])
    r+=0.25*(c['ally_threat']['normalized']-n['ally_threat']['normalized'])
    return float(r)

def rms(x):
    x=np.asarray(x,dtype=np.float64)
    return float(np.sqrt(np.mean(x*x)))

def orthogonal_marker(owner, gamma, beta, seed=20261005):
    # q is exactly orthogonal to every term that makes the adapter fire for
    # SELF/ENEMY/NEUTRAL after cat layernorm:
    # q·(gamma*e_k)=0, q·gamma=0, q·beta=0.
    C=np.stack([
        gamma*owner[0],
        gamma*owner[2],
        gamma*owner[3],
        gamma,
        beta,
    ],axis=0).astype(np.float64)
    rng=np.random.default_rng(seed)
    q=rng.standard_normal(256)
    gram=C@C.T
    proj=C.T @ (np.linalg.pinv(gram,rcond=1e-12) @ (C@q))
    q=q-proj
    q/=max(rms(q),1e-12)
    residual=np.max(np.abs(C@q))
    return q.astype(np.float32),float(residual)

def compute_marker_activation(fp32_path,raws,ally_row,q,owner_start):
    embs={n:read_f32_tensor(fp32_path,n) for n in EMB_NAMES}
    gamma_all=read_f32_tensor(fp32_path,'cat_norm.weight').reshape(-1)
    beta_all=read_f32_tensor(fp32_path,'cat_norm.bias').reshape(-1)
    dims=[x.shape[1] for x in embs.values()]
    catdim=sum(dims)
    if gamma_all.size!=catdim: raise ValueError((gamma_all.size,catdim))
    vals=[]
    for raw in raws:
        cat=parse_cat(raw)
        for row in cat:
            if int(row[1])!=1: continue
            pieces=[]
            for i,n in enumerate(EMB_NAMES):
                if i==1: pieces.append(ally_row)
                else: pieces.append(embs[n][int(row[i])])
            z=np.concatenate(pieces).astype(np.float64)
            mu=z.mean(); var=((z-mu)**2).mean()
            yn=(z-mu)/math.sqrt(var+LN_EPS)
            y=yn*gamma_all+beta_all
            vals.append(float(np.dot(q,y[owner_start:owner_start+256])))
    if not vals: raise ValueError('no ally rows')
    a=np.asarray(vals,dtype=np.float64)
    med=float(np.median(a))
    if abs(med)<1e-8:
        med=float(np.median(np.abs(a)))
    return med,{'count':len(vals),'min':float(a.min()),'max':float(a.max()),
                'median':float(np.median(a)),'median_abs':float(np.median(np.abs(a))),
                'mean':float(a.mean()),'std':float(a.std())}

def select_hidden_units(fp32_path,count=4):
    gate=read_f32_tensor(fp32_path,'input_proj.0.gate_up.weight')
    down=read_f32_tensor(fp32_path,'input_proj.0.down.weight')
    if gate.shape[0]%2: raise ValueError(gate.shape)
    mid=gate.shape[0]//2
    if down.shape[1]!=mid: raise ValueError((gate.shape,down.shape))
    norms=np.linalg.norm(down.astype(np.float64),axis=0)
    ids=np.argsort(norms)[::-1][:count]
    return [int(x) for x in ids],gate.shape,down.shape,[float(norms[x]) for x in ids]

def set_fp32_adapter(fp32_path,owner_row,q,activation_ref,hidden_ids,coeffs,owner_start,base_slices):
    write_f32_owner_row(fp32_path,1,owner_row)
    hdr,by,base=read_header(fp32_path)
    gate_shape=tuple(by['input_proj.0.gate_up.weight']['shape'])
    mid=gate_shape[0]//2
    coeffs=np.asarray(coeffs,dtype=np.float64).reshape(len(hidden_ids),2)
    scale_vec=q.astype(np.float64)/float(activation_ref)
    for i,j in enumerate(hidden_ids):
        cs,co=coeffs[i]
        cg=cs+co
        cv=cs-co
        write_f32_row_slice(fp32_path,'input_proj.0.gate_up.weight',j,owner_start,
                            base_slices[(j,'g')]+cg*scale_vec)
        write_f32_row_slice(fp32_path,'input_proj.0.gate_up.weight',mid+j,owner_start,
                            base_slices[(j,'v')]+cv*scale_vec)

def clear_fp32_adapter(fp32_path,owner_row,hidden_ids,owner_start,base_slices):
    write_f32_owner_row(fp32_path,1,owner_row)
    hdr,by,base=read_header(fp32_path); mid=int(by['input_proj.0.gate_up.weight']['shape'][0])//2
    for j in hidden_ids:
        write_f32_row_slice(fp32_path,'input_proj.0.gate_up.weight',j,owner_start,base_slices[(j,'g')])
        write_f32_row_slice(fp32_path,'input_proj.0.gate_up.weight',mid+j,owner_start,base_slices[(j,'v')])

def quantize_patch_int8(src_path,dst_path,owner_row,q,activation_ref,hidden_ids,coeffs,owner_start):
    shutil.copy2(src_path,dst_path)
    hdr,by,base=read_header(dst_path)
    # owner is fp32
    write_f32_owner_row(dst_path,1,owner_row)
    t=by['input_proj.0.gate_up.weight']
    if t.get('dtype')!='int8':
        raise ValueError(f'gate tensor not int8: {t.get("dtype")}')
    shape=tuple(int(x) for x in t['shape'])
    rows,cols=shape
    with Path(dst_path).open('rb') as f:
        f.seek(base+int(t['offset']))
        qb=f.read(int(t['nbytes']))
        f.seek(base+int(t['scale_offset']))
        sb=f.read(4*int(t['scale_len']))
    qarr=np.frombuffer(qb,dtype=np.int8).copy().reshape(shape)
    scales=np.frombuffer(sb,dtype='<f4').copy()
    if int(t['scale_len'])==rows:
        arr=qarr.astype(np.float32)*scales[:,None]
        axis=0
    elif int(t['scale_len'])==cols:
        arr=qarr.astype(np.float32)*scales[None,:]
        axis=1
    else:
        raise ValueError(('scale_len',t['scale_len'],shape))
    mid=rows//2
    coeffs=np.asarray(coeffs,dtype=np.float64).reshape(len(hidden_ids),2)
    sv=q.astype(np.float64)/float(activation_ref)
    for i,j in enumerate(hidden_ids):
        cs,co=coeffs[i]
        arr[j,owner_start:owner_start+256]+=((cs+co)*sv).astype(np.float32)
        arr[mid+j,owner_start:owner_start+256]+=((cs-co)*sv).astype(np.float32)
    if axis==0:
        ns=np.max(np.abs(arr),axis=1)/127.0
        ns=np.where(ns>1e-12,ns,1.0).astype('<f4')
        nq=np.clip(np.rint(arr/ns[:,None]),-127,127).astype(np.int8)
    else:
        ns=np.max(np.abs(arr),axis=0)/127.0
        ns=np.where(ns>1e-12,ns,1.0).astype('<f4')
        nq=np.clip(np.rint(arr/ns[None,:]),-127,127).astype(np.int8)
    with Path(dst_path).open('r+b') as f:
        f.seek(base+int(t['offset'])); f.write(nq.tobytes())
        f.seek(base+int(t['scale_offset'])); f.write(ns.tobytes())
    return {'scale_axis':axis,'shape':shape,'scale_min':float(ns.min()),'scale_max':float(ns.max())}

def summarize(rec):
    return {'overall':rec['overall'],'category':rec['category']}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--exe',required=True)
    ap.add_argument('--int8-weights',required=True)
    ap.add_argument('--fp32-weights',required=True)
    ap.add_argument('--samples',required=True)
    ap.add_argument('--out',required=True)
    a=ap.parse_args()
    exe=Path(a.exe); int8=Path(a.int8_weights); fp32=Path(a.fp32_weights)
    samples=Path(a.samples); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    logs=out/'logs'; logs.mkdir(exist_ok=True)

    man=json.loads((samples/'manifest.json').read_text(encoding='utf-8'))
    items=man['samples']; raws=[]
    for m in items:
        b=(samples/m['file']).read_bytes()
        if hashlib.sha256(b).hexdigest()!=m['sha256']: raise SystemExit('sample SHA mismatch')
        raws.append(b)
    teachers=[rewrite_teacher(r,m['category']) for r,m in zip(raws,items)]
    rev=list(range(len(raws)-1,-1,-1))

    # Search subset: 6/category.
    keep=[]
    for cat in ('peace_dense','enemy_preserve','peace_block','ally_threat'):
        ids=[i for i,m in enumerate(items) if m['category']==cat]
        keep.extend(ids[::2][:6])
    keep=sorted(keep)
    sraw=[raws[i] for i in keep]; sitems=[items[i] for i in keep]
    steach=[teachers[i] for i in keep]

    # Base FP32 teacher is official Pluto with team relations projected only for supervision.
    teacher_search=run_engine_sequence(exe,fp32,'pk',4,steach,logs/'teacher_search_pk.stderr.txt')
    teacher_fwd=run_engine_sequence(exe,fp32,'pk',4,teachers,logs/'teacher_fwd_pk.stderr.txt')
    teacher_rev=run_engine_sequence(exe,fp32,'pk',4,[teachers[i] for i in rev],logs/'teacher_rev_pk.stderr.txt')

    owner=read_f32_tensor(fp32,'owner_emb.weight')
    cat_gamma=read_f32_tensor(fp32,'cat_norm.weight').reshape(-1)
    cat_beta=read_f32_tensor(fp32,'cat_norm.bias').reshape(-1)
    unit_dim=int(read_f32_tensor(fp32,'unit_type_emb.weight').shape[1])
    owner_start=unit_dim
    gamma=cat_gamma[owner_start:owner_start+256].astype(np.float32)
    beta=cat_beta[owner_start:owner_start+256].astype(np.float32)

    q,resid=orthogonal_marker(owner,gamma,beta)
    anchor_scale=float(np.median([rms(owner[0]-owner[3]),rms(owner[2]-owner[3])]))
    marker_rms=0.005*anchor_scale
    ally_marker=(owner[3].astype(np.float64)+marker_rms*q.astype(np.float64)).astype(np.float32)

    hidden_ids,gate_shape,down_shape,hidden_norms=select_hidden_units(fp32,4)
    mid=gate_shape[0]//2
    base_slices={}
    for j in hidden_ids:
        base_slices[(j,'g')]=read_f32_row_slice(fp32,'input_proj.0.gate_up.weight',j,owner_start,owner_start+256)
        base_slices[(j,'v')]=read_f32_row_slice(fp32,'input_proj.0.gate_up.weight',mid+j,owner_start,owner_start+256)

    activation_ref,actstats=compute_marker_activation(fp32,sraw,ally_marker,q,owner_start)
    if abs(activation_ref)<1e-7: raise SystemExit('marker activation too small')
    print(f'RELATION_MARKER residual={resid:.3e} anchor={anchor_scale:.8g} marker_rms={marker_rms:.8g} activation={activation_ref:.8g}',flush=True)
    print(f'HIDDEN_IDS={hidden_ids} norms={hidden_norms} gate_shape={gate_shape} down_shape={down_shape}',flush=True)

    def eval_fp32(coeffs,tag,mode='search'):
        set_fp32_adapter(fp32,ally_marker,q,activation_ref,hidden_ids,coeffs,owner_start,base_slices)
        if mode=='search':
            rr,ii,tt=sraw,sitems,teacher_search
        elif mode=='fwd':
            rr,ii,tt=raws,items,teacher_fwd
        elif mode=='rev':
            rr=[raws[i] for i in rev]; ii=[items[i] for i in rev]; tt=teacher_rev
        else: raise ValueError(mode)
        got=run_engine_sequence(exe,fp32,'pk',4,rr,logs/f'{tag}_{mode}.stderr.txt')
        rec={'coeffs':[float(x) for x in coeffs],'overall':score_responses(got,tt,ii),
             'category':category_scores(got,tt,ii)}
        return rec

    # Direct neutral reference: owner1 == neutral, no adapter.
    clear_fp32_adapter(fp32,owner[3],hidden_ids,owner_start,base_slices)
    got=run_engine_sequence(exe,fp32,'pk',4,sraw,logs/'neutral_search_pk.stderr.txt')
    neutral_search={'overall':score_responses(got,teacher_search,sitems),
                    'category':category_scores(got,teacher_search,sitems)}
    got=run_engine_sequence(exe,fp32,'pk',4,raws,logs/'neutral_fwd_pk.stderr.txt')
    neutral_fwd={'overall':score_responses(got,teacher_fwd,items),
                 'category':category_scores(got,teacher_fwd,items)}
    got=run_engine_sequence(exe,fp32,'pk',4,[raws[i] for i in rev],logs/'neutral_rev_pk.stderr.txt')
    neutral_rev={'overall':score_responses(got,teacher_rev,[items[i] for i in rev]),
                 'category':category_scores(got,teacher_rev,[items[i] for i in rev])}

    coeff=np.zeros(8,dtype=np.float64)
    cur=eval_fp32(coeff,'marker0','search')
    cur_reward=reward(cur,neutral_search)
    history=[]
    best_seen=[(cur_reward,coeff.copy(),cur)]
    print(f'MARKER_BASE reward={cur_reward:.6f} action={cur["overall"]["action_match"]}/24 threat={cur["category"]["ally_threat"]["action_match"]}/6',flush=True)

    # 8 relation-only adapter basis coordinates = 4 high-impact SwiGLU units × {same, opposite gate/value}.
    for pidx,step in enumerate([1.0,0.55,0.30],1):
        for k in range(8):
            trials=[]
            for sign in (-1.0,+1.0):
                cand=coeff.copy(); cand[k]+=sign*step
                rec=eval_fp32(cand,f'p{pidx}_k{k}_{ "m" if sign<0 else "p"}','search')
                rw=reward(rec,neutral_search)
                trials.append((rw,cand,rec))
                best_seen.append((rw,cand.copy(),rec))
                print(f'ADAPT pass={pidx} k={k} sign={sign:+.0f} step={step:.2f} reward={rw:.6f} '
                      f'peace={rec["category"]["peace_block"]["action_match"]}/6 '
                      f'threat={rec["category"]["ally_threat"]["action_match"]}/6',flush=True)
            winner=max(trials,key=lambda x:x[0])
            if winner[0]>cur_reward+1e-8:
                cur_reward,coeff,cur=winner
        history.append({'pass':pidx,'step':step,'reward':cur_reward,'coeffs':coeff.tolist()})
        print(f'PASS_DONE {pidx} reward={cur_reward:.6f} coeffs={coeff.tolist()}',flush=True)

    # Full validate best three unique candidates.
    uniq=[]; seen=set()
    for rw,c,r in sorted(best_seen,key=lambda x:x[0],reverse=True):
        key=tuple(np.round(c,6))
        if key in seen: continue
        seen.add(key); uniq.append((rw,c,r))
        if len(uniq)>=3: break
    vals=[]
    for i,(rw,c,srec) in enumerate(uniq,1):
        f=eval_fp32(c,f'val{i}','fwd')
        r=eval_fp32(c,f'val{i}','rev')
        vals.append({'reward':rw,'coeffs':c.copy(),'search':srec,'fwd':f,'rev':r})

    def metrics(v,nf,nr):
        cf=v['fwd']['category']; cr=v['rev']['category']
        preserve=all(cf[x]['action_match']>=nf[x]['action_match']-1 and
                     cr[x]['action_match']>=nr[x]['action_match']-1
                     for x in ('peace_dense','peace_block','enemy_preserve'))
        tf,tf0=cf['ally_threat'],nf['ally_threat']
        tr,tr0=cr['ally_threat'],nr['ally_threat']
        noregress=tf['action_match']>=tf0['action_match'] and tr['action_match']>=tr0['action_match']
        improve=(tf['action_match']>tf0['action_match'] or tr['action_match']>tr0['action_match'] or
                 tf['normalized']+tr['normalized']>=tf0['normalized']+tr0['normalized']+0.04)
        return {'preserve_ok':preserve,'no_threat_regression':noregress,'threat_improved':improve,
                'deployable':bool(preserve and noregress and improve),
                'threat_fwd':[tf['action_match'],tf0['action_match'],tf['normalized'],tf0['normalized']],
                'threat_rev':[tr['action_match'],tr0['action_match'],tr['normalized'],tr0['normalized']]}

    for v in vals: v['metrics_fp32']=metrics(v,neutral_fwd,neutral_rev)
    fp32_ok=[v for v in vals if v['metrics_fp32']['deployable']]

    int8_report=None; deploy=False; final_weights=None
    if fp32_ok:
        best=max(fp32_ok,key=lambda v:(
            v['fwd']['category']['ally_threat']['action_match']+v['rev']['category']['ally_threat']['action_match'],
            v['fwd']['category']['ally_threat']['normalized']+v['rev']['category']['ally_threat']['normalized']
        ))
        candidate_int8=out/'candidate_team4_relation_adapter_int8.bin'
        qinfo=quantize_patch_int8(int8,candidate_int8,ally_marker,q,activation_ref,hidden_ids,best['coeffs'],owner_start)

        # int8 teachers/neutral references generated from the unmodified four-way int8 model.
        i8_teacher_fwd=run_engine_sequence(exe,int8,'int8mv',1,teachers,logs/'i8_teacher_fwd.stderr.txt')
        i8_teacher_rev=run_engine_sequence(exe,int8,'int8mv',1,[teachers[i] for i in rev],logs/'i8_teacher_rev.stderr.txt')
        neutral_i8=out/'neutral_team4_int8.bin'
        shutil.copy2(int8,neutral_i8); write_f32_owner_row(neutral_i8,1,owner[3])
        ni_f=run_engine_sequence(exe,neutral_i8,'int8mv',1,raws,logs/'i8_neutral_fwd.stderr.txt')
        ni_r=run_engine_sequence(exe,neutral_i8,'int8mv',1,[raws[i] for i in rev],logs/'i8_neutral_rev.stderr.txt')
        nif={'overall':score_responses(ni_f,i8_teacher_fwd,items),'category':category_scores(ni_f,i8_teacher_fwd,items)}
        nir={'overall':score_responses(ni_r,i8_teacher_rev,[items[i] for i in rev]),'category':category_scores(ni_r,i8_teacher_rev,[items[i] for i in rev])}
        ci_f=run_engine_sequence(exe,candidate_int8,'int8mv',1,raws,logs/'i8_candidate_fwd.stderr.txt')
        ci_r=run_engine_sequence(exe,candidate_int8,'int8mv',1,[raws[i] for i in rev],logs/'i8_candidate_rev.stderr.txt')
        cif={'overall':score_responses(ci_f,i8_teacher_fwd,items),'category':category_scores(ci_f,i8_teacher_fwd,items)}
        cir={'overall':score_responses(ci_r,i8_teacher_rev,[items[i] for i in rev]),'category':category_scores(ci_r,i8_teacher_rev,[items[i] for i in rev])}
        iv={'fwd':cif,'rev':cir}
        im=metrics(iv,nif,nir)
        int8_report={'quantization':qinfo,'neutral_fwd':nif,'neutral_rev':nir,
                     'candidate_fwd':cif,'candidate_rev':cir,'metrics':im}
        neutral_i8.unlink(missing_ok=True)
        if im['deployable']:
            deploy=True
            final_weights=out/'pluto_weights_team4_relation_adapter_int8.bin'
            candidate_int8.replace(final_weights)
        else:
            candidate_int8.unlink(missing_ok=True)

    recipe={
        'format':'pluto-team-phase4d-v1-relation-only-low-rank-adapter',
        'owner_vocab':'SELF0 ALLY1 ENEMY2 NEUTRAL3',
        'marker':{
            'q':[float(x) for x in q],
            'orthogonality_residual':resid,
            'anchor_scale':anchor_scale,'marker_rms':marker_rms,
            'ally_owner_row':[float(x) for x in ally_marker],
            'activation_ref':activation_ref,'activation_stats':actstats,
        },
        'adapter':{
            'owner_input_column_start':owner_start,
            'hidden_ids':hidden_ids,'hidden_down_norms':hidden_norms,
            'basis':'each hidden id has same(gate,value) and opposite(gate,value) coordinates',
            'best_coeffs':vals[0]['coeffs'].tolist() if vals else coeff.tolist()
        },
        'fp32_neutral_fwd':neutral_fwd,'fp32_neutral_rev':neutral_rev,
        'fp32_validations':[{
            'reward':v['reward'],'coeffs':v['coeffs'].tolist(),
            'fwd':summarize(v['fwd']),'rev':summarize(v['rev']),
            'metrics':v['metrics_fp32']} for v in vals],
        'int8_validation':int8_report,
        'deployable':deploy,
        'classification':'RELATION_ONLY_ADAPTER_INT8_FOUND' if deploy else (
            'FP32_RELATION_SIGNAL_FOUND_INT8_NOT_YET' if fp32_ok else 'NO_DEPLOYABLE_RELATION_ONLY_ADAPTER'
        )
    }
    (out/'phase4d_v1_report.json').write_text(json.dumps(recipe,indent=2),encoding='utf-8')
    (out/'phase4d_adapter_recipe.json').write_text(json.dumps(recipe['marker']|recipe['adapter'],indent=2),encoding='utf-8')

    summary='\n'.join([
        'aPlutoTeam Phase4D v1 Relation-Only Low-Rank Adapter',
        f'orthogonality_residual={resid:.3e}',
        f'hidden_ids={hidden_ids}',
        f'fp32_deployable_candidates={len(fp32_ok)}',
        f'int8_deployable={deploy}',
        f'result_class={recipe["classification"]}',
        'PHASE4D_V1_RELATION_ONLY_ADAPTER=PASS'
    ])+'\n'
    (out/'phase4d_v1_summary.txt').write_text(summary,encoding='utf-8')
    print(summary,flush=True)

    # Restore the big FP32 file is unnecessary; workflow deletes it.
    if not deploy:
        (out/'NO_RUNTIME_WEIGHTS.txt').write_text(
            'No int8 runtime weights emitted because the relation-only adapter did not pass validation.\n',
            encoding='utf-8')

if __name__=='__main__':
    main()
