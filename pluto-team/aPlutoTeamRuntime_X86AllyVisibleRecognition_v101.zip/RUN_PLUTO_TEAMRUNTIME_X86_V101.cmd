@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v101-launch.log"

>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V101_LAUNCHER=START
>>"%LAUNCHLOG%" echo ROOT=%ROOT%
echo === aPlutoTeamRuntime v101 x86 Ally-Visible Recognition ===
echo [NOTE] This is NOT pure v99. It is a separate in-game ally-recognition experiment.

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV101.dll" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing: %%~F
  >>"%LAUNCHLOG%" echo FAIL missing: %%~F
  echo Copy the original pluto.dll beside this CMD.
  pause
  exit /b 1
)

if exist "%ROOT%\pluto\pluto_infer.exe" if exist "%ROOT%\pluto\pluto_weights.bin" goto runtime_ready
if exist "%ROOT%\pluto_infer.exe" if exist "%ROOT%\pluto_weights.bin" (
  if not exist "%ROOT%\pluto" mkdir "%ROOT%\pluto"
  copy /Y "%ROOT%\pluto_infer.exe" "%ROOT%\pluto\pluto_infer.exe" >nul || goto runtime_fail
  copy /Y "%ROOT%\pluto_weights.bin" "%ROOT%\pluto\pluto_weights.bin" >nul || goto runtime_fail
  goto runtime_ready
)

echo [FAIL] Original Pluto inference files are missing.
>>"%LAUNCHLOG%" echo FAIL inference files missing
pause
exit /b 2

:runtime_fail
echo [FAIL] Could not create original Pluto runtime layout.
>>"%LAUNCHLOG%" echo FAIL runtime layout
pause
exit /b 3

:runtime_ready
tasklist /FI "IMAGENAME eq pluto_infer.exe" 2^>nul | find /I "pluto_infer.exe" ^>nul
if not errorlevel 1 (
  echo [FAIL] stale pluto_infer.exe is already running.
  echo Run: taskkill /IM pluto_infer.exe /F
  >>"%LAUNCHLOG%" echo FAIL stale pluto_infer.exe
  pause
  exit /b 5
)

del /q "%ROOT%\plutoteam-x86-v101.log" 2>nul
del /q "%ROOT%\plutoteam-x86-v101-inject.log" 2>nul

echo.
echo TEST: use a 2v2 or 3v3 melee/custom team game.
echo Allied units AND buildings should remain visible to the bridge and log as ALLY.
echo Start SC:R 32-bit and enter the FIRST game.
echo Press any key ONCE to inject v101 TeamRuntime.
echo Do NOT inject again for later games in the same StarCraft.exe.
pause >nul

echo [INFO] injecting...
>>"%LAUNCHLOG%" echo INJECT_START
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV101.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
>>"%LAUNCHLOG%" echo INJECT_EXIT=%RC%

echo.
echo === INJECT RESULT ===
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
  echo [FAIL] injection stage failed.
  pause
  exit /b %RC%
)

timeout /t 2 /nobreak >nul
if exist "%ROOT%\plutoteam-x86-v101.log" (
  echo [PASS] TeamRuntime v101 log created.
  echo Watch for TEAM_RUNTIME owner_mode=ALLY_VISIBLE and TEAM_RUNTIME_ALLY_CUNIT relation=ALLY.
) else (
  echo [FAIL] runtime log missing.
)
pause
