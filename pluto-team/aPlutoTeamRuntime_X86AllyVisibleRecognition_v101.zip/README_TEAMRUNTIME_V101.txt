aPlutoTeamRuntime v101 x86 — Ally-Visible Recognition (IN-GAME)
================================================================

GOAL
----
Apply the verified self/ally/enemy/neutral relation classifier to the real
resident SC:R Pluto bridge now, so allied CUnits are visible and classified
in a live 2v2/3v3 game.

v101 is separate from pure PlutoSCR v99 and from v100 ALLY_OPAQUE.

LIVE RELATION SOURCES
---------------------
CUnit owner: +0x4C
SCR Game::alliances: offset 58692

All units and buildings are CUnits. There is no special guessed building rule:
an allied player's unit OR building is classified by the same real owner/alliance path.

v101 CHANGES
------------
- Does NOT hide allied CUnits.
- Keeps full active/hidden/scanner legacy CUnit chains.
- Keeps CUnit and bullet pointers to allied units.
- Includes visible allied units/buildings in GameData.
- Logs self_visible / ally_visible / enemy_visible / neutral_visible.
- Logs up to 8 visible allied CUnit samples (owner/type/x/y).
- Keeps the original Pluto inference/decision/command generation.
- Direct allied selection/target packets are drop-only safety; no target replacement,
  no bridge strategy, no invented command.

IMPORTANT LIMIT
---------------
The stock official Pluto NN still has its original 3-way owner embedding:
    self / other-player / neutral

So v101 gives real IN-GAME BRIDGE-LEVEL ally recognition and makes allied
units/buildings observable, but the stock NN still internally collapses ally
and enemy into its old "other-player" category. True model-level ally reasoning
needs the 4-way Pluto-Team model path later.

EXPECTED LOG
------------
PLUTOTEAMRUNTIME_V101_RESIDENT=LOADED
TEAM_RUNTIME_MODE=ALLY_VISIBLE_RECOGNITION
TEAM_RUNTIME_RELATIONS self=... ally_mask=...
TEAM_RUNTIME owner_mode=ALLY_VISIBLE self_visible=... ally_visible=... enemy_visible=... neutral_visible=...
TEAM_RUNTIME_ALLY_CUNIT relation=ALLY owner=... type=... x=... y=... frame=...
TEAM_RUNTIME_ALLY_TARGET_BLOCK ...   (only if the 1v1 policy directly targets an ally)

TEST
----
1. Download the GitHub Actions artifact.
2. Add exact official Pluto runtime:
     pluto.dll
     pluto\pluto_infer.exe
     pluto\pluto_weights.bin
3. Start SC:R 32-bit and enter a 2v2 or 3v3 game.
4. Run RUN_PLUTO_TEAMRUNTIME_X86_V101.cmd ONCE.
5. Let ally units move nearby and let the ally construct buildings.
6. Send back plutoteam-x86-v101.log.

PASS
----
- ally_mask != 0
- ally_visible > 0 while ally CUnits are visible
- TEAM_RUNTIME_ALLY_CUNIT samples belong to the ally player
- game/commands continue normally
- no ally filtering remains
