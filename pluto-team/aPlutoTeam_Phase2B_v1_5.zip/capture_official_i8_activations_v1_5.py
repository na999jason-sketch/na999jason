from __future__ import annotations
import argparse, hashlib, json, os, re, struct, subprocess, threading, time
from pathlib import Path

HANDSHAKE_SIZE = 0x88
RESPONSE_SIZE = 0x28
CALL_RE = re.compile(r"c(?P<idx>\d+)_M(?P<M>\d+)_K(?P<K>\d+)_N(?P<N>\d+)", re.I)

def read_exact(pipe, n):
    b = bytearray()
    while len(b) < n:
        c = pipe.read(n-len(b))
        if not c:
            raise EOFError(f"wanted {n}, got {len(b)}")
        b.extend(c)
    return bytes(b)

def pack_request():
    n=2; W=H=128; flags=0
    parts=[struct.pack("<iiiIqqqq",n,W,H,flags,0,0,0,0)]
    cats=[[0,0,0,0,0,0],[0,1,23,0,228,0]]
    cont=[[0.0]*109 for _ in range(n)]
    cont[1][0]=0.5; cont[1][1]=0.5; cont[1][2]=1.0; cont[1][22]=1.0
    for r in cats: parts.append(struct.pack("<"+"q"*6,*r))
    for r in cont: parts.append(struct.pack("<"+"f"*109,*r))
    parts += [bytes([1,1]), bytes([1,1]), bytes([1]*20), bytes([1]*233)]
    parts += [struct.pack("<"+"f"*292,*([0.0]*292))]
    parts += [bytes(128*128*2), bytes(128*128), struct.pack("<qqqq",0,0,0,0)]
    return b"".join(parts)

def parse_hs(raw):
    magic,ver,fps,mu,step,label,build=struct.unpack("<4sIiiq48s64s",raw)
    z=lambda b:b.split(b"\0",1)[0].decode(errors="replace")
    return {"magic":magic.decode(errors="replace"),"version":ver,"frames_per_step":fps,
            "max_units":mu,"model_step":step,"label":z(label),"build":z(build)}

def parse_resp(raw):
    a,arg,pos,u,win,lp=struct.unpack("<qqqqff",raw)
    return {"action":a,"arg":arg,"pos":pos,"unit":u,"win":float(win),
            "logprob":float(lp),"hex":raw.hex()}

def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1<<20),b""):
            h.update(chunk)
    return h.hexdigest()

def analyze_file(p:Path):
    name=p.name
    m=CALL_RE.search(name)
    rec={"name":name,"relative":str(p),"bytes":p.stat().st_size,"sha256":sha256(p)}
    if m:
        rec.update({k:int(v) for k,v in m.groupdict().items()})
        M,K,N=rec["M"],rec["K"],rec["N"]
        low=name.lower()
        if low.endswith("_a.bin") and p.stat().st_size==M*K*4:
            import array, math
            a=array.array("f")
            with open(p,"rb") as f:a.frombytes(f.read())
            if a:
                vals=list(a)
                rec["kind"]="activation_fp32"
                rec["min"]=min(vals);rec["max"]=max(vals)
                rec["mean"]=sum(vals)/len(vals)
                rec["l2"]=math.sqrt(sum(float(x)*float(x) for x in vals))
        elif low.endswith("_q.bin") and p.stat().st_size==M*K:
            rec["kind"]="activation_u8"
        elif low.endswith("_s.bin") and p.stat().st_size in (M*4,4):
            rec["kind"]="scale_fp32"
        elif low.endswith("_zp.bin") and p.stat().st_size in (M, M*4, 1, 4):
            rec["kind"]="zero_point"
    return rec

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe",required=True)
    ap.add_argument("--blob",required=True)
    ap.add_argument("--out",required=True)
    ap.add_argument("--timeout",type=int,default=120)
    args=ap.parse_args()

    out=Path(args.out).resolve()
    dumpdir=out/"i8dump"
    selected=out/"selected_small_calls"
    dumpdir.mkdir(parents=True,exist_ok=True)
    selected.mkdir(parents=True,exist_ok=True)
    stderr_path=out/"official_i8_resid.log"
    req=pack_request()
    (out/"request_other_center.bin").write_bytes(req)

    env=os.environ.copy()
    env["BWRL_I8_DUMP"]="1"
    env["BWRL_DUMP_RESID"]="1"

    cmd=[str(Path(args.exe).resolve()),"--blob",str(Path(args.blob).resolve()),
         "--backend","int8mv","--threads","1","--seed","123456789","--argmax","--verbose"]
    print("I8_DUMP_PROBE_START",flush=True)
    print("COMMAND"," ".join(cmd),flush=True)
    t0=time.monotonic()
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                       cwd=dumpdir,env=env,bufsize=0)

    def drain():
        with open(stderr_path,"wb") as f:
            while True:
                c=p.stderr.read(65536)
                if not c:break
                f.write(c);f.flush()
    th=threading.Thread(target=drain,daemon=True);th.start()

    timed_out=threading.Event()
    def kill():
        timed_out.set()
        try:p.kill()
        except:pass
    timer=threading.Timer(args.timeout,kill);timer.daemon=True;timer.start()

    hs=resp=err=None
    try:
        hs=parse_hs(read_exact(p.stdout,HANDSHAKE_SIZE))
        print("HANDSHAKE",json.dumps(hs),flush=True)
        p.stdin.write(req);p.stdin.flush()
        resp=parse_resp(read_exact(p.stdout,RESPONSE_SIZE))
        print("RESPONSE",json.dumps(resp),flush=True)
        p.stdin.close()
        p.wait(timeout=20)
    except Exception as e:
        err=f"{type(e).__name__}: {e}"
        try:p.kill();p.wait(timeout=10)
        except:pass
    finally:
        timer.cancel();th.join(timeout=10)

    elapsed=time.monotonic()-t0
    all_files=[x for x in dumpdir.rglob("*") if x.is_file()]
    manifest=[]
    copied=[]
    for f in sorted(all_files):
        rec=analyze_file(f)
        manifest.append(rec)
        M=rec.get("M")
        # Preserve all small M<=4 dynamic-activation call files for exact later comparison.
        # This captures unit-path and M=1 GRU/head matvec inputs without uploading huge conv dumps.
        if M is not None and M<=4 and f.stat().st_size<=8*1024*1024:
            dest=selected/f.name
            shutil.copy2(f,dest)
            copied.append({"name":f.name,"bytes":f.stat().st_size,"sha256":sha256(dest)})
    # Also preserve the first 12 and last 12 dump filenames even when large via metadata only.
    report={
        "format":"pluto-team-phase2b-v1.5-official-i8-activation-capture",
        "elapsed_s":elapsed,"timeout":timed_out.is_set(),"error":err,
        "handshake":hs,"response":resp,
        "dump_file_count":len(all_files),
        "dump_total_bytes":sum(f.stat().st_size for f in all_files),
        "selected_file_count":len(copied),
        "selected_total_bytes":sum(x["bytes"] for x in copied),
        "first_dump_names":[f.name for f in sorted(all_files)[:12]],
        "last_dump_names":[f.name for f in sorted(all_files)[-12:]],
        "manifest":manifest,
        "selected":copied,
    }
    (out/"i8_dump_manifest.json").write_text(json.dumps(report,indent=2),encoding="utf-8")

    with (out/"i8_dump_summary.txt").open("w",encoding="utf-8") as f:
        f.write("Pluto-Team Phase2B v1.5 official int8 activation capture\n")
        f.write(f"elapsed_s={elapsed:.3f}\n")
        f.write(f"timeout={timed_out.is_set()} error={err}\n")
        f.write(f"response={resp}\n")
        f.write(f"dump_file_count={len(all_files)} dump_total_bytes={report['dump_total_bytes']}\n")
        f.write(f"selected_file_count={len(copied)} selected_total_bytes={report['selected_total_bytes']}\n")
        f.write("first_dump_names="+json.dumps(report["first_dump_names"])+"\n")
        f.write("last_dump_names="+json.dumps(report["last_dump_names"])+"\n")
        f.write("PHASE2B_V1_5_I8_ACTIVATION_CAPTURE=PASS\n")

    print((out/"i8_dump_summary.txt").read_text(encoding="utf-8"),flush=True)

    if timed_out.is_set() or err:
        raise SystemExit(2)
    if not resp or resp["action"]!=12 or resp["arg"]!=43 or resp["pos"]!=54:
        raise SystemExit("official response regression")
    if len(all_files)==0:
        raise SystemExit("BWRL_I8_DUMP produced no files")

if __name__=="__main__":
    import shutil
    main()
