# aPlutoTeam Phase2B v1.5 — Official int8 activation capture

v1.4 result:
- all 16 coordinate/slow-cache variants failed to reproduce official FP32 action=12.
- coordinate-plane convention had no effect on this synthetic probe.
- slow-cache variants changed the result, but none matched.

So v1.5 stops guessing and asks the official engine for its own dynamic quantisation inputs.

The official binary exposes `BWRL_I8_DUMP`.
This workflow:
1. runs the known `other_center` request against the exact official int8mv model,
2. enables `BWRL_I8_DUMP=1` and `BWRL_DUMP_RESID=1`,
3. captures every generated dump filename/size/SHA256 into a manifest,
4. preserves all small M<=4 call dumps (unit-path and M=1 recurrent/head calls),
5. verifies that the official response is still action=12, arg=43, pos=54.

This is diagnostic only. No training and no model mutation.
