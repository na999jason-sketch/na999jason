# aPlutoTeam Phase4B v1 — Protected-Asset Ally Semantic Search

Purpose: reject the failed ALLY=SELF and ALLY=NEUTRAL shortcuts and search for a distinct ALLY owner embedding while all original Pluto weights remain frozen.

Teacher semantics:
- Peace / non-threat team scenes: every allied unit uses NEUTRAL semantics, preventing pursuit, stim, support or other self-like behavior around ally armies.
- Ally-threat scenes: only allied workers and buildings use SELF semantics; allied combat/mobile units remain NEUTRAL. Actor/target masks are unchanged, so allied units remain non-controllable.
- Enemy-preserve scenes: allies use NEUTRAL semantics and real enemies remain ENEMY.

Search:
- The candidate row is N + a*(S-N) + b*(E-N).
- a and b may be negative, so the search is not limited to convex anchor mixtures.
- 24 samples are used for coarse/refine search; top distinct candidates are revalidated on all 48 samples.
- A candidate is deployable only if it is distinct from neutral, preserves peace/enemy behavior within one action, and improves ally-threat teacher matching.
- If those requirements are not met, no deployable embedding file is emitted.

This phase does not modify Pluto strategy or any runtime command rule. It only searches owner_emb[1].
