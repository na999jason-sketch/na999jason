from __future__ import annotations
import argparse, hashlib, json, math, shutil, struct, subprocess, threading
from pathlib import Path
import numpy as np

RESP=struct.Struct('<qqqqff')
REQ_HDR=struct.Struct('<iiiIqqqq')
WORKER_TYPES={7,41,64}
BUILDING_MIN=106
BUILDING_MAX=201


def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c: raise EOFError(f'expected {n}, got {len(b)}')
        b+=c
    return bytes(b)

def parse_resp(raw):
    a,arg,pos,unit,win,lp=RESP.unpack(raw)
    return {'action':int(a),'arg':int(arg),'pos':int(pos),'unit':int(unit),'win':float(win),'logprob':float(lp),'hex':raw.hex()}

def req_n(raw): return REQ_HDR.unpack_from(raw,0)[0]

def is_protected_asset(unit_type:int)->bool:
    return unit_type in WORKER_TYPES or BUILDING_MIN <= unit_type <= BUILDING_MAX

def rewrite_teacher(raw:bytes, category:str)->bytes:
    """Team teacher without v105's ALLY=SELF failure.

    - All allied combat/mobile units become NEUTRAL semantics.
    - In ally_threat only allied workers/buildings become SELF semantics,
      while actor/target masks remain untouched, so they remain non-controllable.
    - Other categories map every ally to NEUTRAL semantics.
    """
    out=bytearray(raw); n=req_n(raw); off=0x30
    for r in range(n):
        p=off+r*48
        typ=struct.unpack_from('<q',out,p)[0]
        owner=struct.unpack_from('<q',out,p+8)[0]
        if owner==1:
            new_owner=0 if category=='ally_threat' and is_protected_asset(int(typ)) else 3
            struct.pack_into('<q',out,p+8,new_owner)
    return bytes(out)

def load_plwb_owner(path:Path):
    raw=bytearray(path.read_bytes())
    if raw[:4]!=b'PLWB': raise ValueError('not PLWB')
    hlen=struct.unpack_from('<Q',raw,8)[0]
    hdr=json.loads(raw[16:16+hlen].decode('utf-8'))
    base=len(raw)-int(hdr['total_bytes'])
    t=next(x for x in hdr['tensors'] if x['name']=='owner_emb.weight')
    if list(t['shape'])!=[4,256] or int(t['nbytes'])!=4096: raise ValueError(f'bad owner tensor {t}')
    off=base+int(t['offset'])
    arr=np.frombuffer(raw,dtype='<f4',count=4*256,offset=off).copy().reshape(4,256)
    return raw,off,arr

def patch_owner_affine(path:Path,a:float,b:float):
    raw,off,x=load_plwb_owner(path)
    # N + a*(S-N) + b*(E-N), allowing negative directions outside anchor simplex.
    row=(x[3] + a*(x[0]-x[3]) + b*(x[2]-x[3])).astype('<f4')
    raw[off+1024:off+2048]=row.tobytes()
    path.write_bytes(raw)
    return row

def run_engine_sequence(exe:Path,weights:Path,requests:list[bytes],stderr_path:Path,timeout_s=600):
    cmd=[str(exe),'--blob',str(weights),'--backend','int8mv','--threads','1','--seed','123456789','--argmax']
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=flags,bufsize=0)
    err=[]
    def drain():
        while True:
            c=p.stderr.read(65536)
            if not c: break
            err.append(c)
    th=threading.Thread(target=drain,daemon=True); th.start()
    try:
        hs=read_exact(p.stdout,0x88)
        magic,ver,*_=struct.unpack('<4sIiiq48s64s',hs)
        if magic.rstrip(b'\0')!=b'PLO1' or ver!=3: raise RuntimeError('bad handshake')
        out=[]
        for r in requests:
            p.stdin.write(r); p.stdin.flush(); out.append(parse_resp(read_exact(p.stdout,0x28)))
        p.stdin.close()
        try: rc=p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired: p.kill(); rc=p.wait(timeout=10)
        th.join(timeout=10); stderr_path.write_text(b''.join(err).decode(errors='replace'),encoding='utf-8')
        if rc!=0: raise RuntimeError(f'engine exit {rc}')
        return out
    finally:
        if p.poll() is None: p.kill(); p.wait(timeout=10)

def score_responses(got,target,items):
    score=0.0; maxscore=0.0; am=0; exact4=0
    for g,t,m in zip(got,target,items):
        w=float(m.get('weight',1.0))
        if m['category']=='ally_threat': w*=3.0
        pts=0.0
        if g['action']==t['action']: pts+=8; am+=1
        if g['arg']==t['arg']: pts+=2
        if g['unit']==t['unit']: pts+=2
        if g['pos']==t['pos']: pts+=1
        pts+=0.5*max(0.0,1.0-min(1.0,abs(g['win']-t['win'])/0.25))
        if (g['action'],g['arg'],g['pos'],g['unit'])==(t['action'],t['arg'],t['pos'],t['unit']): exact4+=1
        score+=w*pts; maxscore+=w*13.5
    return {'score':score,'normalized':score/maxscore if maxscore else 0,'action_match':am,'exact_int4':exact4}

def category_scores(got,target,items):
    out={}
    for cat in sorted(set(m['category'] for m in items)):
        idx=[i for i,m in enumerate(items) if m['category']==cat]
        out[cat]=score_responses([got[i] for i in idx],[target[i] for i in idx],[items[i] for i in idx])
    return out

def candidate_key(rec):
    c=rec['category']
    # First preserve ordinary/non-team behavior, then improve defense, then total score.
    preserve=min(c['peace_dense']['action_match'],c['peace_block']['action_match'],c['enemy_preserve']['action_match'])
    threat=c['ally_threat']['action_match']
    threat_score=c['ally_threat']['normalized']
    return (preserve, threat, threat_score, rec['overall']['normalized'])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--exe',required=True); ap.add_argument('--weights',required=True); ap.add_argument('--samples',required=True); ap.add_argument('--out',required=True)
    a=ap.parse_args(); exe=Path(a.exe); base=Path(a.weights); samples=Path(a.samples); out=Path(a.out); out.mkdir(parents=True,exist_ok=True); logs=out/'logs'; logs.mkdir(exist_ok=True)
    man=json.loads((samples/'manifest.json').read_text(encoding='utf-8')); items=man['samples']; raws=[]
    for m in items:
        r=(samples/m['file']).read_bytes()
        if hashlib.sha256(r).hexdigest()!=m['sha256']: raise SystemExit(f'SHA mismatch {m["file"]}')
        raws.append(r)
    if len(raws)!=48: raise SystemExit(f'expected 48 samples, got {len(raws)}')
    teacher_raw=[rewrite_teacher(r,m['category']) for r,m in zip(raws,items)]
    teacher=run_engine_sequence(exe,base,teacher_raw,logs/'teacher.stderr.txt')

    # Deterministic 24-sample search set: six samples from each category.
    keep=[]
    for cat in ('peace_dense','enemy_preserve','peace_block','ally_threat'):
        ids=[i for i,m in enumerate(items) if m['category']==cat]
        keep.extend(ids[::2][:6])
    keep=sorted(keep)
    sitems=[items[i] for i in keep]; sraw=[raws[i] for i in keep]; steacher=[teacher[i] for i in keep]

    work=out/'candidate_weights.bin'; results=[]
    def evaluate(ab,stage,full=False):
        aa,bb=ab; shutil.copy2(base,work); row=patch_owner_affine(work,aa,bb)
        rr=raws if full else sraw; ii=items if full else sitems; tt=teacher if full else steacher
        tag=f'{stage}_a{aa:+.2f}_b{bb:+.2f}'.replace('+','p').replace('-','m')
        got=run_engine_sequence(exe,work,rr,logs/f'{tag}.stderr.txt')
        rec={'stage':stage,'a':aa,'b':bb,'full':full,'overall':score_responses(got,tt,ii),'category':category_scores(got,tt,ii),'row':row}
        print(f"CAND {stage} a={aa:+.2f} b={bb:+.2f} full={int(full)} preserve={min(rec['category'][x]['action_match'] for x in ('peace_dense','peace_block','enemy_preserve'))} threat={rec['category']['ally_threat']['action_match']} overall={rec['overall']['normalized']:.6f}",flush=True)
        return rec

    # Baseline neutral on all 48.
    neutral=evaluate((0.0,0.0),'neutral',True)

    # Coarse affine search around neutral, including directions outside the SELF/ENEMY/NEUTRAL simplex.
    vals=(-0.30,-0.15,0.0,0.15,0.30)
    coarse=[]
    for aa in vals:
        for bb in vals:
            if aa==0 and bb==0: continue
            coarse.append(evaluate((aa,bb),'coarse',False))
    coarse.sort(key=candidate_key,reverse=True)

    # Refine around top 3 coarse points at 0.05 spacing.
    seen={(round(r['a'],4),round(r['b'],4)) for r in coarse}; refine=[]
    for seed in coarse[:3]:
        for da in (-0.10,-0.05,0,0.05,0.10):
            for db in (-0.10,-0.05,0,0.05,0.10):
                aa=round(seed['a']+da,4); bb=round(seed['b']+db,4)
                if abs(aa)>0.5 or abs(bb)>0.5 or (aa==0 and bb==0) or (aa,bb) in seen: continue
                seen.add((aa,bb)); refine.append(evaluate((aa,bb),'refine',False))
    search=coarse+refine; search.sort(key=candidate_key,reverse=True)

    # Full validation for top 8 distinct search candidates.
    full=[]
    chosen=[]
    for r in search:
        ab=(r['a'],r['b'])
        if ab not in chosen:
            chosen.append(ab)
        if len(chosen)>=8: break
    for ab in chosen: full.append(evaluate(ab,'validate',True))
    full.sort(key=candidate_key,reverse=True)
    best=full[0] if full else neutral

    nc=neutral['category']; bc=best['category']
    neutral_threat=nc['ally_threat']['action_match']; best_threat=bc['ally_threat']['action_match']
    neutral_ts=nc['ally_threat']['normalized']; best_ts=bc['ally_threat']['normalized']
    preserve_ok=all(bc[x]['action_match'] >= nc[x]['action_match']-1 for x in ('peace_dense','peace_block','enemy_preserve'))
    distinct=(abs(best['a'])+abs(best['b']))>=0.049
    threat_improved=(best_threat>neutral_threat) or (best_threat==neutral_threat and best_ts>=neutral_ts+0.03)
    deployable=bool(distinct and preserve_ok and threat_improved)
    cls='DISTINCT_ALLY_SIGNAL_FOUND' if deployable else 'NO_DEPLOYABLE_DISTINCT_ALLY_SIGNAL'

    row=np.asarray(best['row'],dtype='<f4')
    if deployable:
        row.tofile(out/'ally_embedding_phase4b_f32.bin')
        (out/'ally_embedding_phase4b.json').write_text(json.dumps({'a':best['a'],'b':best['b'],'vector':[float(x) for x in row]},indent=2),encoding='utf-8')

    def strip(r):
        return {'stage':r['stage'],'a':r['a'],'b':r['b'],'full':r['full'],'overall':r['overall'],'category':r['category']}
    report={'format':'pluto-team-phase4b-v1-protected-asset-teacher','sample_count':len(items),
            'teacher_rule':'all allied combat/mobile units -> NEUTRAL; in ally_threat only allied workers/buildings -> SELF; actor masks unchanged',
            'workers':sorted(WORKER_TYPES),'building_type_range':[BUILDING_MIN,BUILDING_MAX],
            'neutral_baseline':strip(neutral),'best':strip(best),'deployable':deployable,'classification':cls,
            'validated':[strip(r) for r in full], 'search_top':[strip(r) for r in search[:20]]}
    (out/'phase4b_v1_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    summary='\n'.join([
        'aPlutoTeam Phase4B v1 Protected-Asset Ally Semantic Search',
        f'samples={len(items)} search_samples={len(sitems)}',
        f'neutral_threat_action={neutral_threat}/12 neutral_threat_score={neutral_ts:.6f}',
        f'best a={best["a"]:+.4f} b={best["b"]:+.4f} threat_action={best_threat}/12 threat_score={best_ts:.6f}',
        f'preserve_ok={preserve_ok} distinct={distinct} threat_improved={threat_improved}',
        f'deployable={deployable} result_class={cls}',
        'PHASE4B_V1_PROTECTED_ASSET_SEARCH=PASS'])+'\n'
    (out/'phase4b_v1_summary.txt').write_text(summary,encoding='utf-8'); print(summary,flush=True)
    work.unlink(missing_ok=True)

if __name__=='__main__': main()
