from __future__ import annotations
import argparse, json, math, struct
from pathlib import Path

FILE_HDR=struct.Struct("<8s6I")          # 32
STEP_HDR=struct.Struct("<4s15I")         # 64
END_HDR=struct.Struct("<4s5IQ")          # 32
RESP=struct.Struct("<qqqqfI")

def request_sizes(n:int):
    return {
        "request_header":0x30,
        "cat":n*6*8,
        "cont":n*109*4,
        "actor":n,
        "target":n,
        "action_mask":20,
        "arg_mask":233,
        "global":292*4,
        "bits":128*128*2,
        "static":128*128,
        "hist":4*8,
    }

def split_payload(payload:bytes,n:int):
    sizes=request_sizes(n); off=0; out={}
    for k,z in sizes.items():
        out[k]=memoryview(payload)[off:off+z];off+=z
    if off!=len(payload):
        raise ValueError(f"payload length mismatch {off} != {len(payload)}")
    return out

def iter_file(path:Path):
    with path.open("rb") as f:
        h=f.read(FILE_HDR.size)
        if len(h)!=FILE_HDR.size: raise ValueError("short file header")
        magic,ver,gen,self_id,ally_mask,hbytes,res=FILE_HDR.unpack(h)
        if not magic.startswith(b"PTRJ103") or ver!=1 or hbytes!=32:
            raise ValueError(f"bad file header {magic} v{ver} h={hbytes}")
        meta={"generation":gen,"self":self_id,"ally_mask":ally_mask}
        while True:
            tag=f.read(4)
            if not tag: return meta
            f.seek(-4,1)
            if tag==b"STEP":
                raw=f.read(STEP_HDR.size)
                vals=STEP_HDR.unpack(raw)
                _,hbytes,pbytes,rbytes,req,resp,frame,n,sc,ac,ec,nc,fb,un,amb,blocked=vals
                if hbytes!=64 or rbytes!=40 or not(1<=n<=1024): raise ValueError("bad step header")
                payload=f.read(pbytes); response=f.read(rbytes)
                if len(payload)!=pbytes or len(response)!=rbytes: raise ValueError("truncated step")
                yield ("step",meta,{
                    "req_seq":req,"resp_seq":resp,"frame":frame,"n":n,
                    "counts":{"self":sc,"ally":ac,"enemy":ec,"neutral":nc},
                    "fallback":fb,"unmatched":un,"ambiguous":amb,
                    "ally_target_blocked_total":blocked,
                    "payload":payload,"response":response
                })
            elif tag==b"END!":
                raw=f.read(END_HDR.size)
                _,hbytes,gen,won,frame,steps,bytes_written=END_HDR.unpack(raw)
                yield ("end",meta,{"generation":gen,"won":bool(won),"final_frame":frame,"steps":steps,"bytes":bytes_written})
                return
            else:
                raise ValueError(f"unknown tag {tag!r} at {f.tell()}")

def rows(step):
    n=step["n"]; parts=split_payload(step["payload"],n)
    cats=struct.iter_unpack("<6q",parts["cat"])
    cont=struct.iter_unpack("<109f",parts["cont"])
    for i,(c,x) in enumerate(zip(cats,cont)):
        yield i,c,x

def summarize(path:Path):
    steps=0; maxn=0; owner_tot=[0,0,0,0]; bad_owner=0
    fallback=unmatched=amb=0; enemy_steps=ally_steps=threat_steps=ally_hp_drop_steps=0
    last_ally_hp=None; last_blocked=0; direct_blocks=0; terminal=None
    action_hist={}
    for kind,meta,obj in iter_file(path):
        if kind=="end":
            terminal=obj;continue
        steps+=1; maxn=max(maxn,obj["n"]); fallback+=obj["fallback"];unmatched+=obj["unmatched"];amb+=obj["ambiguous"]
        if obj["counts"]["ally"]>0: ally_steps+=1
        if obj["counts"]["enemy"]>0: enemy_steps+=1
        direct_blocks=max(direct_blocks,obj["ally_target_blocked_total"])
        resp=RESP.unpack(obj["response"])
        action_hist[str(resp[0])]=action_hist.get(str(resp[0]),0)+1

        rs=list(rows(obj))
        allies=[]; enemies=[]; ally_hp=0.0
        for i,c,x in rs:
            owner=int(c[1])
            if 0<=owner<4: owner_tot[owner]+=1
            else: bad_owner+=1
            if owner==1:
                allies.append((float(x[0])*4096.0,float(x[1])*4096.0,float(x[2])+float(x[3])))
                ally_hp += max(0.0,float(x[2]))+max(0.0,float(x[3]))
            elif owner==2:
                enemies.append((float(x[0])*4096.0,float(x[1])*4096.0))
        # Purely factual/proxy labels for dataset selection, not bridge strategy:
        # enemy_near_ally = any enemy within 384px of an ally.
        near=False
        for ax,ay,_ in allies:
            for ex,ey in enemies:
                if (ax-ex)*(ax-ex)+(ay-ey)*(ay-ey) <= 384.0*384.0:
                    near=True;break
            if near:break
        if near: threat_steps+=1
        if last_ally_hp is not None and ally_hp+0.02 < last_ally_hp:
            ally_hp_drop_steps+=1
        last_ally_hp=ally_hp
    return {
        "format":"PTRJ103",
        "file":path.name,
        "steps":steps,"max_units":maxn,
        "owner_row_totals":{"self":owner_tot[0],"ally":owner_tot[1],"enemy":owner_tot[2],"neutral":owner_tot[3]},
        "bad_owner_rows":bad_owner,
        "steps_with_ally":ally_steps,"steps_with_enemy":enemy_steps,
        "enemy_near_ally_proxy_steps":threat_steps,
        "ally_normalized_hp_drop_steps":ally_hp_drop_steps,
        "fallback_total":fallback,"unmatched_total":unmatched,"ambiguous_total":amb,
        "direct_ally_target_blocks_max":direct_blocks,
        "actions":action_hist,
        "terminal":terminal,
    }

def synth(path:Path):
    n=3
    sizes=request_sizes(n); pbytes=sum(sizes.values())
    payload=bytearray(pbytes)
    off=0x30
    cats=[(0,0,0,0,0,0),(37,1,23,0,228,0),(37,2,23,0,228,0)]
    for r,c in enumerate(cats):
        struct.pack_into("<6q",payload,off+r*48,*c)
    cont_off=0x30+n*48
    a=[0.0]*109;a[0]=0.25;a[1]=0.25;a[2]=1.0
    e=[0.0]*109;e[0]=0.26;e[1]=0.25;e[2]=1.0
    struct.pack_into("<109f",payload,cont_off+1*436,*a)
    struct.pack_into("<109f",payload,cont_off+2*436,*e)
    fh=FILE_HDR.pack(b"PTRJ103\0",1,1,1,0b1010000,32,0)
    sh=STEP_HDR.pack(b"STEP",64,pbytes,40,1,1,100,3,1,1,1,0,0,0,0,0)
    resp=RESP.pack(6,0,0,-1,0.1,0)
    eh=END_HDR.pack(b"END!",32,1,1,200,1,len(fh)+len(sh)+pbytes+40)
    path.write_bytes(fh+sh+payload+resp+eh)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("files",nargs="*")
    ap.add_argument("--selftest",action="store_true")
    ap.add_argument("--json-out")
    args=ap.parse_args()
    if args.selftest:
        p=Path("ptrj103_synthetic.ptrj");synth(p);r=summarize(p);p.unlink()
        assert r["steps"]==1 and r["owner_row_totals"]["ally"]==1 and r["owner_row_totals"]["enemy"]==1
        assert r["enemy_near_ally_proxy_steps"]==1 and r["terminal"]["won"] is True
        print("PTRJ103_PARSER_SELFTEST=PASS");return
    if not args.files: raise SystemExit("give one or more .ptrj files")
    reports=[summarize(Path(x)) for x in args.files]
    text=json.dumps(reports,indent=2)
    print(text)
    if args.json_out: Path(args.json_out).write_text(text,encoding="utf-8")

if __name__=="__main__":
    main()
