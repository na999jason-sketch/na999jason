import argparse, json, struct, subprocess, threading
from pathlib import Path
HS=0x88; RESP=0x28
def rex(p,n):
    b=bytearray()
    while len(b)<n:
        c=p.read(n-len(b))
        if not c: raise EOFError
        b+=c
    return bytes(b)
def req(owner):
    n=2; parts=[struct.pack("<iiiIqqqq",n,128,128,0,0,0,0,0)]
    cats=[[0,0,0,0,0,0],[0,owner,23,0,228,0]]; cont=[[0.0]*109 for _ in range(n)]
    cont[1][0]=cont[1][1]=0.5;cont[1][2]=cont[1][22]=1.0
    for r in cats:parts.append(struct.pack("<6q",*r))
    for r in cont:parts.append(struct.pack("<109f",*r))
    parts += [bytes([1,1]),bytes([1,1]),bytes([1]*20),bytes([1]*233),struct.pack("<292f",*([0.0]*292)),bytes(128*128*2),bytes(128*128),struct.pack("<4q",0,0,0,0)]
    return b"".join(parts)
def run(exe,blob,owner):
    p=subprocess.Popen([str(exe),"--blob",str(blob),"--backend","int8mv","--threads","1","--seed","123456789","--argmax"],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    err=[]
    t=threading.Thread(target=lambda:err.append(p.stderr.read()),daemon=True);t.start()
    hs=rex(p.stdout,HS);p.stdin.write(req(owner));p.stdin.flush();r=rex(p.stdout,RESP);p.stdin.close();p.wait(20);t.join(2)
    return r.hex()
ap=argparse.ArgumentParser();ap.add_argument("--root",required=True);a=ap.parse_args()
root=Path(a.root); p=root/"pluto"
offe=p/"pluto_infer.official.exe"; offw=p/"pluto_weights.official.bin"; te=p/"pluto_infer.exe"; tw=p/"pluto_weights.bin"
refs={0:run(offe,offw,0),1:run(offe,offw,1),2:run(offe,offw,2)}
cases={0:run(te,tw,0),1:run(te,tw,1),2:run(te,tw,2),3:run(te,tw,3)}
checks={"self":cases[0]==refs[0],"ally":cases[1]==refs[1],"enemy":cases[2]==refs[1],"neutral":cases[3]==refs[2],"ally_enemy":cases[1]==cases[2]}
print(json.dumps(checks,indent=2))
if not all(checks.values()):raise SystemExit(2)
print("V103_3_TEAM4_PREP_PARITY=PASS")
