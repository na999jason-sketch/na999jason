@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$files=@(); $files += Get-ChildItem -File 'plutoteam-v103.3-trajectory-g*.ptrj' -ErrorAction SilentlyContinue; if(Test-Path 'plutoteam-x86-v103.3.log'){$files += Get-Item 'plutoteam-x86-v103.3.log'}; if(!$files){Write-Host '[FAIL] no v103.3 training data'; exit 1}; Compress-Archive -Force -Path ($files.FullName) -DestinationPath 'plutoteam-v103.3-training-data.zip'"
if errorlevel 1 exit /b 1
echo [PASS] plutoteam-v103.3-training-data.zip
pause
