aPlutoTeamRuntime v103.3 — v102 rollback baseline + delayed passive recorder
=============================================================================

Reason for this branch
----------------------
v102 was proven in real 3v3 play: original Pluto completed inference and commands.
v103/v103.1/v103.2 all regressed before the first inference completed.

The v103.2 live log proved the original EngineClient was already performing an
orderly shutdown wake (quit=1, req=0, resp=0, N=0) during the first onFrame.
Therefore the req/resp guards were not the root cause.

v103.3 is rebuilt from the KNOWN-GOOD v102 source, not from v103.2.

Isolation rule
--------------
The first original Pluto onFrame follows the v102 hook/runtime path.
No trajectory file is opened, no recorder buffer is touched, and no recorder
state is armed before that first onFrame returns successfully.

Only AFTER that successful frame:
- a PTRJ103 recorder file is opened;
- a 650 KB request buffer is pre-reserved outside the SetEvent hook;
- later requests are copied after the v102 four-way rewrite;
- disk writes happen only after onFrame returns.

The first inference step is intentionally omitted from the dataset.

Not included
------------
- no req_seq guard;
- no quit-aware SetEvent classification;
- no legacy-shadow row-matching change;
- no bridge strategy or ally-defense logic.

Those changes stay out until the v102 baseline remains stable with recording.
