@echo off
setlocal
cd /d "%~dp0"
taskkill /IM pluto_infer.exe /F >nul 2>nul
if not exist "pluto\pluto_infer.official.exe" exit /b 1
if not exist "pluto\pluto_weights.official.bin" exit /b 2
copy /Y "pluto\pluto_infer.official.exe" "pluto\pluto_infer.exe" >nul
copy /Y "pluto\pluto_weights.official.bin" "pluto\pluto_weights.bin" >nul
echo [PASS] official Pluto restored
pause
