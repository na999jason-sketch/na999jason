from __future__ import annotations
import hashlib, math
import numpy as np
import torch
import torch.nn.functional as F
from plwb import PLWB

RMS_EPS = 1e-6
LN_EPS = 1e-5

class WeightStore:
    def __init__(self, blob: PLWB):
        self.blob = blob
        self.cache = {}
    def __getitem__(self, name):
        if name not in self.cache:
            arr = np.array(self.blob.dequantized(name), dtype=np.float32, copy=True)
            self.cache[name] = torch.from_numpy(arr)
        return self.cache[name]

def linear(x, W, b=None):
    return F.linear(x, W, b)

def ln(x, weight, bias, eps=LN_EPS):
    return F.layer_norm(x, (x.shape[-1],), weight, bias, eps)

def rms(x, weight, eps=RMS_EPS):
    return x * torch.rsqrt(x.square().mean(dim=-1, keepdim=True) + eps) * weight

def swiglu(x, gate_up, down):
    y = linear(x, gate_up)
    g, v = y.chunk(2, dim=-1)
    return linear(F.silu(g) * v, down)

def rms_swiglu(x, prefix, w):
    return swiglu(x, w[prefix+".gate_up.weight"], w[prefix+".down.weight"])

def tensor_stats(x):
    xf = x.float().detach().cpu().contiguous()
    a = xf.numpy()
    return {
        "shape": list(a.shape),
        "mean": float(a.mean()),
        "std": float(a.std()),
        "min": float(a.min()),
        "max": float(a.max()),
        "l2": float(np.sqrt(np.square(a, dtype=np.float64).sum())),
        "sha256_f32": hashlib.sha256(a.astype("<f4", copy=False).tobytes()).hexdigest(),
    }

def coord_planes(mode="center01"):
    ar = torch.arange(128, dtype=torch.float32)
    if mode == "center01":
        q = (ar + 0.5) / 128.0
    elif mode == "edge01":
        q = ar / 128.0
    elif mode == "center_m11":
        q = ((ar + 0.5) / 128.0) * 2.0 - 1.0
    elif mode == "edge_m11":
        q = (ar / 127.0) * 2.0 - 1.0
    else:
        raise ValueError(mode)
    yy, xx = torch.meshgrid(q, q, indexing="ij")
    return torch.stack([xx, yy], dim=0)

class PlutoFirstStep:
    """FP32 dequantized reconstruction through first-step action + win heads.

    This intentionally stops before autoregressive arg/position/unit heads.
    Phase2B v1 is a trunk/action diagnostic, not a claim of complete parity.
    """
    def __init__(self, weights_path, coord_mode="center01"):
        self.blob = PLWB(weights_path)
        self.w = WeightStore(self.blob)
        self.coord_mode = coord_mode

    def encode_units(self, cat, cont):
        w = self.w
        names = [
            "unit_type_emb.weight","owner_emb.weight","order_emb.weight",
            "last_action_emb.weight","train_type_emb.weight","research_type_emb.weight"
        ]
        es = [w[n][cat[:,i]] for i,n in enumerate(names)]
        e = torch.cat(es, dim=-1)
        e = ln(e, w["cat_norm.weight"], w["cat_norm.bias"])
        c = linear(cont, w["continuous_proj.0.weight"], w["continuous_proj.0.bias"])
        c = ln(c, w["continuous_proj.1.weight"], w["continuous_proj.1.bias"])
        x = torch.cat([e,c], dim=-1)
        x = swiglu(x, w["input_proj.0.gate_up.weight"], w["input_proj.0.down.weight"])
        return ln(x, w["input_proj.1.weight"], w["input_proj.1.bias"])

    def assemble_planes(self, u0, cont, bits, static):
        w = self.w
        unit_features = linear(u0, w["unit_spatial_proj.weight"])  # N,109
        grid = torch.zeros(128*128, 109, dtype=torch.float32)
        count = torch.zeros(128*128, dtype=torch.float32)
        x = torch.clamp((cont[:,0] * 128.0).to(torch.int64), 0, 127)
        y = torch.clamp((cont[:,1] * 128.0).to(torch.int64), 0, 127)
        idx = y*128 + x
        grid.index_add_(0, idx, unit_features)
        count.index_add_(0, idx, torch.ones_like(idx, dtype=torch.float32))
        denom = torch.sqrt(torch.clamp(count, min=1.0)).unsqueeze(-1)
        grid = (grid / denom).reshape(128,128,109).permute(2,0,1)
        count_plane = torch.log1p(count).reshape(1,128,128)

        bp = torch.stack([((bits >> i) & 1).float() for i in range(16)], dim=0)
        sp = torch.stack([((static >> i) & 1).float() for i in range(8)], dim=0)
        coords = coord_planes(self.coord_mode)
        return torch.cat([bp, coords, grid, count_plane, sp], dim=0).unsqueeze(0)

    def conv(self, x, prefix, stride=1, padding=1):
        w = self.w
        W = w[prefix+".conv.weight"]
        bname = prefix+".conv.bias"
        b = w[bname] if bname in self.blob.by_name else None
        return F.conv2d(x, W, b, stride=stride, padding=padding)

    @staticmethod
    def ln2d(x, weight, bias):
        y = x.permute(0,2,3,1)
        y = ln(y, weight, bias)
        return y.permute(0,3,1,2)

    @staticmethod
    def glu2d(x):
        a,b = x.chunk(2, dim=1)
        return F.silu(a)*b

    def spatial_encoder(self, planes):
        w = self.w
        x = self.conv(planes, "spatial_enc.stem", stride=2, padding=1)
        x = F.silu(x)
        x = self.ln2d(x, w["spatial_enc.stem_norm.weight"], w["spatial_enc.stem_norm.bias"])
        s64 = x
        cin = [128,128,256]
        for s in range(3):
            x0 = x
            xnorm = self.ln2d(
                x, w[f"spatial_enc.stage_norms.{s}.weight"], w[f"spatial_enc.stage_norms.{s}.bias"]
            )
            h = self.glu2d(self.conv(xnorm, f"spatial_enc.stages.{s}.0", stride=1, padding=1))
            h = self.glu2d(self.conv(h, f"spatial_enc.stages.{s}.1", stride=1, padding=1))
            h = self.conv(h, f"spatial_enc.stages.{s}.2", stride=2, padding=1)
            skip = self.conv(x0, f"spatial_enc.stages.{s}.3", stride=2, padding=0)
            x = h + skip
            if s == 0: s32 = x
        s8 = self.ln2d(x, w["spatial_enc.out_norm.weight"], w["spatial_enc.out_norm.bias"])
        return s64, s32, s8

    def inject_spatial(self, u0, s32, cont):
        w = self.w
        x = torch.clamp((cont[:,0] * 32.0).to(torch.int64),0,31)
        y = torch.clamp((cont[:,1] * 32.0).to(torch.int64),0,31)
        g = s32[0,:,y,x].transpose(0,1).contiguous()
        z = linear(g, w["spatial_proj.0.weight"])
        z = ln(z, w["spatial_proj.1.weight"], w["spatial_proj.1.bias"])
        u1 = u0 + z
        u1 = u1.clone()
        u1[0] = w["null_unit_enc"]
        return u1

    def encoder(self, x):
        w = self.w
        H, HD = 12, 64
        for i in range(6):
            a = rms(x, w[f"encoder.layers.{i}.norm1.weight"])
            qkv = linear(a, w[f"encoder.layers.{i}.wqkv.weight"])
            q,k,v = qkv.reshape(x.shape[0],3,H,HD).unbind(1)
            q = rms(q, w[f"encoder.layers.{i}.q_norm.weight"])
            k = rms(k, w[f"encoder.layers.{i}.k_norm.weight"])
            # [H,N,HD]
            qh, kh, vh = q.transpose(0,1), k.transpose(0,1), v.transpose(0,1)
            scores = (qh @ kh.transpose(-2,-1)) / math.sqrt(HD)
            att = torch.softmax(scores, dim=-1) @ vh
            att = att.transpose(0,1).reshape(x.shape[0],768)
            x = x + linear(att, w[f"encoder.layers.{i}.wo.weight"])
            b = rms(x, w[f"encoder.layers.{i}.norm2.weight"])
            ff = swiglu(b, w[f"encoder.layers.{i}.ff.gate_up.weight"], w[f"encoder.layers.{i}.ff.down.weight"])
            x = x + ff
        return rms(x, w["encoder_norm.weight"])

    def global_hist(self, glob, hist):
        w = self.w
        g = linear(glob, w["global_proj.0.weight"], w["global_proj.0.bias"])
        g = ln(g, w["global_proj.1.weight"], w["global_proj.1.bias"])
        e = w["action_hist_emb.weight"][hist].reshape(-1)
        ah = linear(e, w["action_hist_proj.0.weight"], w["action_hist_proj.0.bias"])
        ah = ln(ah, w["action_hist_proj.1.weight"], w["action_hist_proj.1.bias"])
        return torch.cat([g,ah], dim=-1)

    def mha(self, q, K, V, heads):
        D = q.shape[-1]; hd = D//heads
        qh = q.reshape(heads,hd)
        kh = K.reshape(K.shape[0],heads,hd).transpose(0,1)
        vh = V.reshape(V.shape[0],heads,hd).transpose(0,1)
        score = (qh[:,None,:] * kh).sum(-1) / math.sqrt(hd)
        p = torch.softmax(score, dim=-1)
        return (p[:,:,None] * vh).sum(1).reshape(D)

    def slow_init(self):
        nt = self.w["gru.slow_enc.null_token"]   # 4,1024
        return nt[:,None,:].expand(4,128,1024).clone()

    def slow_tick(self, h, cache):
        w = self.w
        x = rms(h, w["gru.slow_enc.in_norm.weight"])
        x = linear(x, w["gru.slow_enc.in_proj.weight"])
        new = []
        for i in range(4):
            a = rms(x, w[f"gru.slow_enc.layers.{i}.norm_input.weight"])
            old = cache[i]
            cn = rms(old[1:], w[f"gru.slow_enc.layers.{i}.norm_cache.weight"])
            kv_old = linear(cn, w[f"gru.slow_enc.layers.{i}.kv_cache.weight"])
            kv_new = linear(a, w[f"gru.slow_enc.layers.{i}.kv_input.weight"]).unsqueeze(0)
            kv = torch.cat([kv_old,kv_new], dim=0)
            K,V = kv.chunk(2,dim=-1)
            q = linear(a, w[f"gru.slow_enc.layers.{i}.q_proj.weight"])
            att = self.mha(q,K,V,8)
            x = x + linear(att, w[f"gru.slow_enc.layers.{i}.out_proj.weight"])
            ff_in = rms(x, w[f"gru.slow_enc.layers.{i}.ff_norm.weight"])
            x = x + swiglu(
                ff_in,
                w[f"gru.slow_enc.layers.{i}.ff.gate_up.weight"],
                w[f"gru.slow_enc.layers.{i}.ff.down.weight"],
            )
            new.append(torch.cat([old[1:],x.unsqueeze(0)],dim=0))
        return torch.stack(new,dim=0)

    def gru_step(self, xt, h, s8, U, M):
        w = self.w; d=4096; da=512
        hq = h @ w["gru.W_hq"]
        hr,hz,hn = hq[:3*d].chunk(3)
        qs,qu,qsl = hq[3*d:].chunk(3)
        xi = linear(xt, w["gru.W_i.weight"], w["gru.W_i.bias"])
        xr,xz,xn = xi.chunk(3)
        att = torch.zeros(3*d)
        srcs = [
            (qs, s8[0].permute(1,2,0).reshape(-1,384), "gru.spatial_kv_proj.weight", "gru.w_out_s"),
            (qu, U, "gru.unit_kv_proj.weight", "gru.w_out_u"),
            (qsl, M, "gru.slow_kv_proj.weight", "gru.w_out_slow"),
        ]
        for q,src,pn,wn in srcs:
            K,V = linear(src,w[pn]).chunk(2,dim=-1)
            read = self.mha(q,K,V,8)
            att = att + read @ w[wn]
        ar,az,an = att.chunk(3)
        r = torch.sigmoid(xr+hr+ar)
        z = torch.sigmoid(xz+hz+az)
        n = torch.tanh(xn + r*hn + an)
        return (1-z)*n + z*h

    def resmlp(self, x, prefix, blocks=3):
        w=self.w
        y=linear(x,w[prefix+".in_proj.weight"])
        for i in range(blocks):
            a=rms(y,w[f"{prefix}.norms.{i}.weight"])
            y=y+swiglu(a,w[f"{prefix}.blocks.{i}.gate_up.weight"],w[f"{prefix}.blocks.{i}.down.weight"])
        y=rms(y,w[prefix+".final_norm.weight"])
        return linear(y,w[prefix+".out_proj.weight"])

    def win_value(self, top):
        logits=self.resmlp(top,"solo_win_head")
        p=torch.softmax(logits.double(),dim=-1)
        return float((p[0]-p[1]).item()), logits

    def forward_first(self, req):
        cat=req["cat"]; cont=req["cont"]
        u0=self.encode_units(cat,cont)
        planes=self.assemble_planes(u0,cont,req["bits"],req["static"])
        s64,s32,s8=self.spatial_encoder(planes)
        u1=self.inject_spatial(u0,s32,cont)
        U=self.encoder(u1)
        xt=self.global_hist(req["global"],req["hist"])

        h0=self.w["gru.h0"].clone()
        c0=self.slow_init()
        c1=self.slow_tick(h0,c0)
        h1=self.gru_step(xt,h0,s8,U,c1[3])
        action_logits=linear(h1,self.w["action_head.weight"])
        action=int(torch.argmax(action_logits).item())
        win,win_logits=self.win_value(c1[3,-1])

        # Also report no-tick win: useful for checking first-prelude ordering.
        win0,win0_logits=self.win_value(c0[3,-1])
        return {
            "action": action,
            "win": win,
            "win_no_tick": win0,
            "action_logits": action_logits,
            "win_logits": win_logits,
            "stages": {
                "u0": tensor_stats(u0),
                "planes": tensor_stats(planes),
                "s64": tensor_stats(s64),
                "s32": tensor_stats(s32),
                "s8": tensor_stats(s8),
                "U": tensor_stats(U),
                "xt": tensor_stats(xt),
                "slow_top": tensor_stats(c1[3]),
                "h1": tensor_stats(h1),
                "action_logits": tensor_stats(action_logits),
                "win_logits": tensor_stats(win_logits),
            }
        }
