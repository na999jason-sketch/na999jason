# aPlutoTeam Phase2B v1.2 — bounded FP32 isolation

v1.1 proved that the all-FP32 PLWB can be built, but the official `pk` backend stayed inside
one probe for more than an hour because the probe itself had no watchdog around the blocking
pipe reads.

v1.2 fixes the experiment design rather than waiting indefinitely:

- official int8mv probe: 1 thread, hard 120 second watchdog
- official FP32 `pk` probe: 4 threads, hard 900 second watchdog
- stdout progress markers before/after handshake, request, response
- a timeout is recorded as a valid diagnostic result instead of hanging the workflow
- PyTorch FP32 forward runs only if the official FP32 response actually completes
- job-level timeout: 35 minutes
- cleanup and diagnostic artifact upload run with `if: always()`

Interpretation:
- official FP32 finishes and matches PyTorch -> implement exact int8mv quantization next
- official FP32 finishes and differs -> keep fixing architecture/order/initial state
- official FP32 hits 900 s watchdog -> stop using full official FP32 forward as the parity oracle;
  switch to smaller/internal activation diagnostics instead

This phase does not train or alter Pluto.
