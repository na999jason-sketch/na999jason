import torch
from pluto_trunk import coord_planes, rms, tensor_stats

def test_coord_shapes():
    for mode in ["center01","edge01","center_m11","edge_m11"]:
        c=coord_planes(mode)
        assert tuple(c.shape)==(2,128,128)
        assert torch.isfinite(c).all()

def test_rms():
    x=torch.tensor([[1.0,2.0,3.0]])
    w=torch.ones(3)
    y=rms(x,w)
    assert y.shape==x.shape
    assert torch.isfinite(y).all()

def test_stats():
    s=tensor_stats(torch.arange(6,dtype=torch.float32).reshape(2,3))
    assert s["shape"]==[2,3]
    assert len(s["sha256_f32"])==64
