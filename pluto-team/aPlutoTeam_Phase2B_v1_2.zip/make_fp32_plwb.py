from __future__ import annotations
import argparse, copy, hashlib, json, struct
from pathlib import Path
import numpy as np
from plwb import PLWB

def align64(n: int) -> int:
    return (n + 63) & ~63

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--manifest", required=True)
    args = ap.parse_args()

    src = PLWB(args.input)
    hdr = copy.deepcopy(src.header)
    hdr["dtype"] = "float32"
    hdr["label"] = str(hdr.get("label","pluto")) + "_fp32_recon"

    entries = []
    cursor = 0
    for t in src.tensors:
        cursor = align64(cursor)
        nbytes = t.numel * 4
        entries.append({
            "name": t.name,
            "shape": list(t.shape),
            "offset": cursor,
            "nbytes": nbytes,
            "dtype": "float32",
        })
        cursor += nbytes

    total_bytes = align64(cursor)
    hdr["tensors"] = entries
    hdr["total_bytes"] = total_bytes

    hb = json.dumps(hdr, separators=(",",":"), ensure_ascii=False).encode("utf-8")
    base = align64(16 + len(hb))

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("wb") as f:
        f.write(b"PLWB")
        f.write(struct.pack("<I", 1))
        f.write(struct.pack("<Q", len(hb)))
        f.write(hb)
        if f.tell() < base:
            f.write(b"\0" * (base - f.tell()))

        for i, (t, e) in enumerate(zip(src.tensors, entries), 1):
            a = np.asarray(src.dequantized(t.name), dtype="<f4")
            if a.shape != t.shape:
                raise RuntimeError((t.name, a.shape, t.shape))
            f.seek(base + e["offset"])
            f.write(a.tobytes(order="C"))
            if i % 20 == 0 or i == len(entries):
                print(f"[{i}/{len(entries)}] {t.name} {t.shape}")

        f.truncate(base + total_bytes)

    # Validate our output with the same parser.
    check = PLWB(out)
    assert len(check.tensors) == 269
    assert sum(t.numel for t in check.tensors) == 315040001
    assert all(t.dtype == "float32" for t in check.tensors)

    sha = hashlib.sha256(out.read_bytes()).hexdigest()
    manifest = {
        "format": "pluto-team-phase2b-v1.1-fp32-plwb",
        "source": str(args.input),
        "output": str(out),
        "output_bytes": out.stat().st_size,
        "output_sha256": sha,
        "base": check.base,
        "total_bytes": check.total_bytes,
        "tensor_count": len(check.tensors),
        "parameter_count": sum(t.numel for t in check.tensors),
        "label": check.header.get("label"),
    }
    Path(args.manifest).write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    print("FP32_PLWB_EXPORT=PASS")

if __name__ == "__main__":
    main()
