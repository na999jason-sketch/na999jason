from __future__ import annotations
import argparse, json, math, time
from pathlib import Path
import torch
from pluto_trunk import PlutoFirstStep

OFFICIAL_PHASE2A = {
    "other_center": {
        "action": 12,
        "arg": 43,
        "pos": 54,
        "unit": -1,
        "win": 0.08457028865814209,
        "logprob": -9.002854347229004,
        "response_hex": "0c000000000000002b000000000000003600000000000000ffffffffffffffff3033ad3db10b10c1",
    }
}

def make_other_center():
    n=2
    cat=torch.zeros((n,6),dtype=torch.long)
    cont=torch.zeros((n,109),dtype=torch.float32)
    cat[1]=torch.tensor([0,1,23,0,228,0])
    cont[1,0]=0.5
    cont[1,1]=0.5
    cont[1,2]=1.0
    cont[1,22]=1.0
    return {
        "cat":cat,
        "cont":cont,
        "global":torch.zeros(292,dtype=torch.float32),
        "bits":torch.zeros((128,128),dtype=torch.int64),
        "static":torch.zeros((128,128),dtype=torch.int64),
        "hist":torch.zeros(4,dtype=torch.long),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--weights",required=True)
    ap.add_argument("--out",required=True)
    ap.add_argument("--coord-mode",default="center01",
                    choices=["center01","edge01","center_m11","edge_m11"])
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)

    torch.set_grad_enabled(False)
    t0=time.time()
    m=PlutoFirstStep(args.weights,args.coord_mode)
    load_s=time.time()-t0

    t1=time.time()
    r=m.forward_first(make_other_center())
    run_s=time.time()-t1

    off=OFFICIAL_PHASE2A["other_center"]
    report={
        "format":"pluto-team-phase2b-v1",
        "scope":"FP32 dequantized first-step trunk through action + solo win heads",
        "coord_mode":args.coord_mode,
        "official_phase2a":off,
        "pytorch":{
            "action":r["action"],
            "win":r["win"],
            "win_no_tick":r["win_no_tick"],
            "action_top5": [
                {"id":int(i),"logit":float(r["action_logits"][i])}
                for i in torch.topk(r["action_logits"],5).indices.tolist()
            ],
        },
        "comparison":{
            "action_match": r["action"]==off["action"],
            "win_abs_error_tick": abs(r["win"]-off["win"]),
            "win_abs_error_no_tick": abs(r["win_no_tick"]-off["win"]),
        },
        "timing_seconds":{"model_init":load_s,"forward_first":run_s},
        "stages":r["stages"],
        "notes":[
            "This phase does not implement arg/position/unit autoregressive heads yet.",
            "Official int8mv quantizes activations u8 dynamically; this reconstruction is FP32 after dequantizing shipped int8 weights, so bit-exact output is not expected yet.",
            "Action/win comparison is diagnostic and is not used as a CI pass/fail gate in v1.",
        ],
    }
    (out/"phase2b_v1_report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    with (out/"phase2b_v1_summary.txt").open("w",encoding="utf-8") as f:
        f.write("Pluto-Team Phase2B v1\n")
        f.write(f"coord_mode={args.coord_mode}\n")
        f.write(f"official_action={off['action']} pytorch_action={r['action']} match={r['action']==off['action']}\n")
        f.write(f"official_win={off['win']:.12g} pytorch_win_tick={r['win']:.12g} abs_err={abs(r['win']-off['win']):.12g}\n")
        f.write(f"pytorch_win_no_tick={r['win_no_tick']:.12g} abs_err={abs(r['win_no_tick']-off['win']):.12g}\n")
        f.write(f"model_init_s={load_s:.3f} forward_s={run_s:.3f}\n")
        f.write("top5="+json.dumps(report["pytorch"]["action_top5"])+"\n")
        f.write("STRUCTURAL_FORWARD=PASS\n")
    print((out/"phase2b_v1_summary.txt").read_text())

if __name__=="__main__":
    main()
