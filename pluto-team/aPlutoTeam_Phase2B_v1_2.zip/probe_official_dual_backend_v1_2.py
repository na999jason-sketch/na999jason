from __future__ import annotations
import argparse, json, os, struct, subprocess, threading, time
from pathlib import Path

HANDSHAKE_SIZE = 0x88
RESPONSE_SIZE = 0x28

def read_exact(pipe, n):
    b = bytearray()
    while len(b) < n:
        c = pipe.read(n - len(b))
        if not c:
            raise EOFError(f"wanted {n}, got {len(b)}")
        b.extend(c)
    return bytes(b)

def pack_request():
    n = 2; W = H = 128; flags = 0
    parts = [struct.pack("<iiiIqqqq", n, W, H, flags, 0, 0, 0, 0)]
    cats = [[0,0,0,0,0,0], [0,1,23,0,228,0]]
    cont = [[0.0]*109 for _ in range(n)]
    cont[1][0] = 0.5
    cont[1][1] = 0.5
    cont[1][2] = 1.0
    cont[1][22] = 1.0
    for r in cats:
        parts.append(struct.pack("<" + "q"*6, *r))
    for r in cont:
        parts.append(struct.pack("<" + "f"*109, *r))
    parts += [bytes([1,1]), bytes([1,1]), bytes([1]*20), bytes([1]*233)]
    parts += [struct.pack("<" + "f"*292, *([0.0]*292))]
    parts += [bytes(128*128*2), bytes(128*128), struct.pack("<qqqq",0,0,0,0)]
    return b"".join(parts)

def parse_hs(raw):
    magic, ver, fps, mu, step, label, build = struct.unpack("<4sIiiq48s64s", raw)
    z = lambda b: b.split(b"\0",1)[0].decode(errors="replace")
    return {
        "magic": magic.decode(errors="replace"),
        "version": ver,
        "frames_per_step": fps,
        "max_units": mu,
        "model_step": step,
        "label": z(label),
        "build": z(build),
    }

def parse_resp(raw):
    a, arg, pos, u, win, lp = struct.unpack("<qqqqff", raw)
    return {
        "action": a, "arg": arg, "pos": pos, "unit": u,
        "win": float(win), "logprob": float(lp), "hex": raw.hex()
    }

def run_bounded(exe, blob, backend, threads, timeout_s, out_log):
    env = os.environ.copy()
    env["BWRL_DUMP_RESID"] = "1"
    cmd = [
        str(exe), "--blob", str(blob), "--backend", backend,
        "--threads", str(threads), "--seed", "123456789",
        "--argmax", "--verbose",
    ]
    print(f"PROBE_START backend={backend} threads={threads} timeout_s={timeout_s}", flush=True)
    print("COMMAND", " ".join(cmd), flush=True)

    t0 = time.monotonic()
    p = subprocess.Popen(
        cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, env=env
    )

    timed_out = threading.Event()
    def watchdog():
        timed_out.set()
        print(f"PROBE_WATCHDOG_TIMEOUT backend={backend} elapsed_s={time.monotonic()-t0:.1f}", flush=True)
        try:
            p.kill()
        except Exception:
            pass

    timer = threading.Timer(timeout_s, watchdog)
    timer.daemon = True
    timer.start()

    hs = None
    resp = None
    error = None
    try:
        hs = parse_hs(read_exact(p.stdout, HANDSHAKE_SIZE))
        print(f"PROBE_HANDSHAKE backend={backend} label={hs['label']} build={hs['build']}", flush=True)

        p.stdin.write(pack_request())
        p.stdin.flush()
        print(f"PROBE_REQUEST_SENT backend={backend}", flush=True)

        resp = parse_resp(read_exact(p.stdout, RESPONSE_SIZE))
        print(f"PROBE_RESPONSE backend={backend} {resp}", flush=True)

        p.stdin.close()
        p.wait()
    except Exception as e:
        error = f"{type(e).__name__}: {e}"
        try:
            if p.poll() is None:
                p.kill()
            p.wait(timeout=10)
        except Exception:
            pass
    finally:
        timer.cancel()

    try:
        err = p.stderr.read().decode("utf-8", errors="replace")
    except Exception:
        err = ""
    Path(out_log).write_text(err, encoding="utf-8")

    elapsed = time.monotonic() - t0
    status = "ok"
    if timed_out.is_set():
        status = "timeout"
    elif error is not None or p.returncode not in (0, None):
        status = "error"

    result = {
        "status": status,
        "backend": backend,
        "threads": threads,
        "timeout_s": timeout_s,
        "elapsed_s": elapsed,
        "returncode": p.returncode,
        "command": cmd,
        "handshake": hs,
        "response": resp,
        "error": error,
        "stderr_log": str(out_log),
    }
    print(f"PROBE_END backend={backend} status={status} elapsed_s={elapsed:.1f}", flush=True)
    return result

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exe", required=True)
    ap.add_argument("--int8", required=True)
    ap.add_argument("--fp32", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--int8-threads", type=int, default=1)
    ap.add_argument("--fp32-threads", type=int, default=4)
    ap.add_argument("--int8-timeout", type=int, default=120)
    ap.add_argument("--fp32-timeout", type=int, default=900)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    i8 = run_bounded(
        Path(args.exe), Path(args.int8), "int8mv",
        args.int8_threads, args.int8_timeout,
        out / "official_int8_resid.log",
    )

    fp = run_bounded(
        Path(args.exe), Path(args.fp32), "pk",
        args.fp32_threads, args.fp32_timeout,
        out / "official_fp32_resid.log",
    )

    rep = {
        "format": "pluto-team-phase2b-v1.2-official-dual-backend-bounded",
        "int8": i8,
        "fp32": fp,
        "known_phase2a_int8_action": 12,
        "known_phase2a_int8_win": 0.08457028865814209,
    }
    (out / "official_dual_backend_v1_2.json").write_text(
        json.dumps(rep, indent=2), encoding="utf-8"
    )

    with (out / "official_probe_status.txt").open("w", encoding="utf-8") as f:
        f.write(f"int8_status={i8['status']} elapsed_s={i8['elapsed_s']:.3f}\n")
        f.write(f"fp32_status={fp['status']} elapsed_s={fp['elapsed_s']:.3f}\n")
        if i8["response"]:
            f.write(f"int8_response={i8['response']}\n")
        if fp["response"]:
            f.write(f"fp32_response={fp['response']}\n")

    # Important: a bounded FP32 timeout is a diagnostic result, not a workflow hang.
    # We intentionally exit 0 so cleanup/artifact upload always happen.
    print("OFFICIAL_BOUNDED_PROBE_COMPLETE=PASS", flush=True)

if __name__ == "__main__":
    main()
