# aPlutoTeam Phase3B v1.2 — Owner Descriptor Trace

v1.1 reproduced the exact 4-row rejection, but direct `.text` xrefs to the
diagnostic strings were zero. That means the compatibility check is likely
data/table driven rather than a simple nearby `cmp ...,3`.

v1.2 traces the embedding descriptor itself:

- locates `unit_type_emb.weight`, `owner_emb.weight`, `order_emb.weight`, etc.;
- searches the complete PE image for absolute-VA, RVA, and file-offset references;
- prints nearby small integer fields so descriptor layout can be inferred;
- finds literal `3` fields near `owner_emb.weight` descriptor references;
- changes each candidate to `4` only in an isolated temporary copy;
- tries the 4-row model;
- for any candidate that reaches handshake, requires full byte-identical seed parity:
  self=old self, ally=old other, enemy=old other, neutral=old neutral.

Patched temporary EXEs are deleted before artifact upload. No official binary is
distributed and no training occurs.
