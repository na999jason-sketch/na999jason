from __future__ import annotations
import argparse, json, re, struct, subprocess, threading, time
from pathlib import Path

import pefile

HS=0x88
RESP=0x28

NAMES = {
    "unit_type_emb.weight": 228,
    "owner_emb.weight": 3,
    "order_emb.weight": 189,
    "last_action_emb.weight": 20,
    "train_type_emb.weight": 229,
    "research_type_emb.weight": 108,
}

def read_exact(pipe,n):
    b=bytearray()
    while len(b)<n:
        c=pipe.read(n-len(b))
        if not c:
            raise EOFError(f"wanted {n}, got {len(b)}")
        b.extend(c)
    return bytes(b)

def request(owner:int):
    n=2; W=H=128; flags=0
    parts=[struct.pack("<iiiIqqqq",n,W,H,flags,0,0,0,0)]
    cats=[[0,0,0,0,0,0],[0,owner,23,0,228,0]]
    cont=[[0.0]*109 for _ in range(n)]
    cont[1][0]=0.5; cont[1][1]=0.5; cont[1][2]=1.0; cont[1][22]=1.0
    for r in cats: parts.append(struct.pack("<"+"q"*6,*r))
    for r in cont: parts.append(struct.pack("<"+"f"*109,*r))
    parts += [bytes([1,1]),bytes([1,1]),bytes([1]*20),bytes([1]*233)]
    parts += [struct.pack("<"+"f"*292,*([0.0]*292))]
    parts += [bytes(128*128*2),bytes(128*128),struct.pack("<qqqq",0,0,0,0)]
    return b"".join(parts)

def parse_hs(raw):
    magic,ver,fps,mu,step,label,build=struct.unpack("<4sIiiq48s64s",raw)
    z=lambda b:b.split(b"\0",1)[0].decode(errors="replace")
    return {"magic":z(magic),"version":ver,"fps":fps,"max_units":mu,
            "step":step,"label":z(label),"build":z(build)}

def parse_resp(raw):
    a,arg,pos,u,f0,f1=struct.unpack("<qqqqff",raw)
    return {"action":a,"arg":arg,"pos":pos,"unit":u,
            "float0":float(f0),"float1":float(f1),"hex":raw.hex()}

def run_engine(exe:Path, blob:Path, owner:int, out:Path, tag:str):
    errp=out/f"{tag}.stderr.log"
    cmd=[str(exe),"--blob",str(blob),"--backend","int8mv","--threads","1",
         "--seed","123456789","--argmax","--verbose"]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
    def drain():
        with errp.open("wb") as f:
            while True:
                c=p.stderr.read(65536)
                if not c:break
                f.write(c);f.flush()
    th=threading.Thread(target=drain,daemon=True);th.start()
    t0=time.monotonic(); hs=resp=err=None
    try:
        hs=parse_hs(read_exact(p.stdout,HS))
        p.stdin.write(request(owner));p.stdin.flush()
        resp=parse_resp(read_exact(p.stdout,RESP))
        try:p.stdin.close()
        except:pass
        p.wait(timeout=15)
    except Exception as e:
        err=f"{type(e).__name__}: {e}"
        try:p.kill();p.wait(timeout=10)
        except:pass
    th.join(timeout=10)
    stderr=errp.read_text(errors="replace") if errp.exists() else ""
    return {"tag":tag,"owner":owner,"elapsed_s":time.monotonic()-t0,
            "returncode":p.returncode,"handshake":hs,"response":resp,
            "error":err,"stderr":stderr}

def section_for(pe, fileoff):
    for s in pe.sections:
        a=s.PointerToRawData; b=a+s.SizeOfRawData
        if a <= fileoff < b:
            return s.Name.rstrip(b"\0").decode(errors="replace")
    return None

def all_occ(data, needle):
    p=0
    while True:
        i=data.find(needle,p)
        if i<0:break
        yield i
        p=i+1

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe",required=True)
    ap.add_argument("--official",required=True)
    ap.add_argument("--team4",required=True)
    ap.add_argument("--out",required=True)
    args=ap.parse_args()
    exe=Path(args.exe).resolve(); official=Path(args.official).resolve()
    team4=Path(args.team4).resolve(); out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    data=exe.read_bytes()
    pe=pefile.PE(str(exe),fast_load=False)
    image_base=int(pe.OPTIONAL_HEADER.ImageBase)

    # Establish exact current rejection.
    baseline=run_engine(exe,team4,1,out,"baseline_team4_ally")
    print("BASELINE",baseline["stderr"].strip(),flush=True)

    # Resolve each categorical embedding name to file offset/RVA/VA.
    strings={}
    for name,expected in NAMES.items():
        hit=data.find(name.encode()+b"\0")
        if hit<0: hit=data.find(name.encode())
        if hit<0:
            strings[name]={"found":False,"expected":expected}
            continue
        rva=int(pe.get_rva_from_offset(hit))
        strings[name]={"found":True,"expected":expected,"file_offset":hit,
                       "rva":rva,"va":image_base+rva,"section":section_for(pe,hit)}

    # Find direct data references to each string in all common encodings.
    refs=[]
    for name,s in strings.items():
        if not s.get("found"):continue
        encs=[
            ("va64",struct.pack("<Q",s["va"])),
            ("rva32",struct.pack("<I",s["rva"])),
            ("fileoff32",struct.pack("<I",s["file_offset"])),
        ]
        for kind,needle in encs:
            for off in all_occ(data,needle):
                if s["file_offset"] <= off < s["file_offset"]+len(name)+1:
                    continue
                refs.append({"name":name,"expected":s["expected"],"kind":kind,
                             "ref_file_offset":off,"ref_section":section_for(pe,off),
                             "distance_to_string":off-s["file_offset"]})

    # Build compact context around every reference so descriptor layout can be inferred.
    contexts=[]
    for r in refs:
        off=r["ref_file_offset"]
        a=max(0,off-96);b=min(len(data),off+160)
        vals32=[]
        for q in range((a+3)//4*4,b-3,4):
            v=struct.unpack_from("<I",data,q)[0]
            if v <= 4096:
                vals32.append({"off":q,"rel":q-off,"value":v})
        contexts.append({**r,"nearby_small_u32":vals32})

    owner_refs=[r for r in refs if r["name"]=="owner_emb.weight"]
    candidates=[]
    seen=set()
    # Descriptor candidate: a literal 3 near a pointer/RVA/file-offset reference to owner_emb.weight.
    # Test both 32-bit and 64-bit fields. Keep the search bounded and rank by distance.
    for r in owner_refs:
        center=r["ref_file_offset"]
        for size in (4,8):
            a=max(0,center-192);b=min(len(data),center+256)
            step=4 if size==4 else 8
            start=((a+step-1)//step)*step
            for off in range(start,b-size+1,step):
                val=int.from_bytes(data[off:off+size],"little")
                if val!=3:continue
                key=(off,size)
                if key in seen:continue
                seen.add(key)
                candidates.append({
                    "file_offset":off,"size":size,"distance":abs(off-center),
                    "relative_to_owner_ref":off-center,
                    "owner_ref_offset":center,"owner_ref_kind":r["kind"],
                    "section":section_for(pe,off),
                })
    candidates.sort(key=lambda x:(x["distance"],x["size"],x["file_offset"]))
    candidates=candidates[:96]

    print("STRINGS",json.dumps(strings,indent=2),flush=True)
    print("OWNER_REFS",json.dumps(owner_refs,indent=2),flush=True)
    print("CANDIDATES",json.dumps(candidates,indent=2),flush=True)

    attempts=[]
    for i,c in enumerate(candidates):
        patched=out/f"candidate_{i:02d}.exe"
        b=bytearray(data)
        b[c["file_offset"]:c["file_offset"]+c["size"]]=(4).to_bytes(c["size"],"little")
        patched.write_bytes(b)
        r=run_engine(patched,team4,1,out,f"candidate_{i:02d}_ally")
        r["candidate_index"]=i
        r["candidate"]=c
        attempts.append(r)
        print("TRY",i,c,"HS",bool(r["handshake"]),"RESP",r["response"],
              "STDERR",r["stderr"].strip(),flush=True)

    accepted=[r for r in attempts if r["handshake"] is not None]
    parity_results=[]
    # A candidate isn't accepted as correct merely because it handshakes.
    # Run full policy-preservation parity for every accepting candidate.
    for j,r in enumerate(accepted):
        cidx=r["candidate_index"]
        patched=out/f"candidate_{cidx:02d}.exe"
        cases={}
        for owner,name in [(0,"self"),(1,"ally"),(2,"enemy"),(3,"neutral")]:
            cases[name]=run_engine(patched,team4,owner,out,f"parity_c{cidx:02d}_{name}")
        refs_off={}
        for owner,name in [(0,"self"),(1,"other"),(2,"neutral")]:
            refs_off[name]=run_engine(exe,official,owner,out,f"official_{name}_for_c{cidx:02d}")
        eq=lambda a,b: bool(a["response"] and b["response"] and a["response"]["hex"]==b["response"]["hex"])
        checks={
            "all_4way_categories_run":all(cases[k]["response"] is not None for k in cases),
            "self_preserved":eq(cases["self"],refs_off["self"]),
            "ally_seed_preserved":eq(cases["ally"],refs_off["other"]),
            "enemy_seed_preserved":eq(cases["enemy"],refs_off["other"]),
            "neutral_preserved":eq(cases["neutral"],refs_off["neutral"]),
            "ally_enemy_identical_seed":eq(cases["ally"],cases["enemy"]),
        }
        parity_results.append({"candidate_index":cidx,"candidate":r["candidate"],
                               "cases":cases,"official_refs":refs_off,
                               "checks":checks,"pass":all(checks.values())})
        print("PARITY",cidx,checks,flush=True)

    winners=[p for p in parity_results if p["pass"]]

    # Save a readable descriptor map.
    with (out/"descriptor_reference_map.txt").open("w",encoding="utf-8") as f:
        for name,s in strings.items():
            f.write(f"{name}: {s}\n")
        f.write("\nREFERENCES\n")
        for c in contexts:
            f.write(json.dumps(c)+"\n")

    report={
        "format":"pluto-team-phase3b-v1.2-owner-descriptor-trace",
        "baseline":baseline,
        "strings":strings,
        "refs":refs,
        "owner_refs":owner_refs,
        "candidate_count":len(candidates),
        "candidates":candidates,
        "attempts":attempts,
        "accepting_handshake_count":len(accepted),
        "parity_results":parity_results,
        "winner_count":len(winners),
        "winner":winners[0] if len(winners)==1 else None,
    }
    (out/"phase3b_v1_2_descriptor_trace.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    with (out/"phase3b_v1_2_summary.txt").open("w",encoding="utf-8") as f:
        f.write(f"known_rejection_reproduced={'owner vocab' in baseline['stderr']}\n")
        f.write(f"owner_string_refs={len(owner_refs)}\n")
        f.write(f"descriptor_candidates={len(candidates)}\n")
        f.write(f"accepting_handshake_candidates={len(accepted)}\n")
        f.write(f"full_parity_winners={len(winners)}\n")
        if len(winners)==1:
            w=winners[0]
            f.write("winner="+json.dumps(w["candidate"])+"\n")
            for k,v in w["checks"].items():f.write(f"{k}={v}\n")
            f.write("PHASE3B_V1_2_OWNER_DESCRIPTOR_TRACE=PASS\n")
        else:
            f.write("PHASE3B_V1_2_OWNER_DESCRIPTOR_TRACE=DIAGNOSTIC_ONLY\n")
    print((out/"phase3b_v1_2_summary.txt").read_text(),flush=True)

    # Diagnostic run should preserve evidence even if no winner.
    if "owner vocab" not in baseline["stderr"]:
        raise SystemExit("baseline owner-vocab rejection not reproduced")

if __name__=="__main__":
    main()
