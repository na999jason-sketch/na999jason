@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v104-launch.log"
>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V104_LAUNCHER=START
echo === aPlutoTeamRuntime v104 - V102 Rollback Baseline + Delayed Recorder ===
for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV104.dll" "%ROOT%\PlutoTeamRuntimePrepV104.exe" "%ROOT%\pluto.dll") do if not exist "%%~F" (
 echo [FAIL] missing %%~F
 pause
 exit /b 1
)
if not exist "%ROOT%\pluto\pluto_infer.exe" exit /b 2
if not exist "%ROOT%\pluto\pluto_weights.bin" exit /b 3
taskkill /IM pluto_infer.exe /F >nul 2>nul
"%ROOT%\PlutoTeamRuntimePrepV104.exe" "%ROOT%" >>"%LAUNCHLOG%" 2>&1
if errorlevel 1 (
 type "%LAUNCHLOG%"
 echo [FAIL] team4 prep failed
 pause
 exit /b 4
)
del /q "%ROOT%\plutoteam-x86-v104.log" 2>nul
echo Enter the SC:R 32-bit team game, then press a key once.
pause >nul
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV104.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
 echo [FAIL] injection failed
 pause
 exit /b %RC%
)
pause
