@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$files=@(); $files += Get-ChildItem -File 'plutoteam-v104-trajectory-g*.ptrj' -ErrorAction SilentlyContinue; if(Test-Path 'plutoteam-x86-v104.log'){$files += Get-Item 'plutoteam-x86-v104.log'}; if(!$files){Write-Host '[FAIL] no v104 training data'; exit 1}; Compress-Archive -Force -Path ($files.FullName) -DestinationPath 'plutoteam-v104-training-data.zip'"
if errorlevel 1 exit /b 1
echo [PASS] plutoteam-v104-training-data.zip
pause
