aPlutoTeamRuntime v104 — v102 rollback baseline + delayed passive recorder
=============================================================================

Reason for this branch
----------------------
v102 was proven in real 3v3 play: original Pluto completed inference and commands.
v103/v103.1/v103.2 all regressed before the first inference completed.

The v103.2 live log proved the original EngineClient was already performing an
orderly shutdown wake (quit=1, req=0, resp=0, N=0) during the first onFrame.
Therefore the req/resp guards were not the root cause.

v104 is rebuilt from the KNOWN-GOOD v102 source, not from v103.2.

Isolation rule
--------------
The first original Pluto onFrame follows the v102 hook/runtime path.
No trajectory file is opened, no recorder buffer is touched, and no recorder
state is armed before that first onFrame returns successfully.

Only AFTER that successful frame:
- a PTRJ103 recorder file is opened;
- a 650 KB request buffer is pre-reserved outside the SetEvent hook;
- later requests are copied after the v102 four-way rewrite;
- disk writes happen only after onFrame returns.

The first inference step is intentionally omitted from the dataset.

Not included
------------
- no req_seq guard;
- no quit-aware SetEvent classification;
- no legacy-shadow row-matching change;
- no bridge strategy or ally-defense logic.

Those changes stay out until the v102 baseline remains stable with recording.

v104 MULTI-MATCH LIFECYCLE FIX
--------------------------------
v103.3 generation 1 completed successfully.
During original Pluto onEnd, EngineClient shutdown called SetEvent while the old
SHM still contained a four-way owner value 3. The v102-style rewrite hook tried
to rewrite that already rewritten payload, logged INVALID_OLD_OWNER, and set
g_team4RewriteFatal=1. Generation 2 then reached before_pluto_onFrame but stopped
immediately because that stale fatal flag survived the restart.

v104 changes only this lifecycle boundary:
- disarm our owner rewrite during original Pluto onEnd;
- always forward the real SetEvent untouched;
- clear the per-match rewrite-fatal state;
- keep rewrite disabled while the new EngineClient starts;
- re-arm only after the new SHM and exactly one pluto_infer process are verified.

No ally-base movement rule or strategic command replacement is added.

v104 OWNER-MATCH FIX
--------------------
The v103.3 trajectory exposed a compatibility bug before training:

- late-game SHM owner rows were matched against MOVING raw SCR CUnits;
- exact x/y/order drift caused many rows to be unmatched;
- unmatched non-self rows were defaulted to ENEMY;
- model input therefore contained dozens of fake enemies.

v104 changes only the relation lookup source:
- model row type/x/y/order is matched against g_legacyCUnits[] (the coherent
  legacy shadow original Pluto actually observed for the same frame);
- ally/enemy relation still comes from real SCR Game alliances;
- no strategy is added;
- original Pluto still chooses actions and commands;
- direct ally target DROP remains only a safety rejection.

Success criterion:
TEAM4_SHM_OWNER_REWRITE unmatched should stay near zero through late game.
