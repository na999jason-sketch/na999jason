@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoteam-x86-v102-launch.log"

>"%LAUNCHLOG%" echo PLUTOTEAMRUNTIME_V102_LAUNCHER=START
>>"%LAUNCHLOG%" echo ROOT=%ROOT%
echo === aPlutoTeamRuntime v102 x86 Four-Way Owner In-Game ===
echo [NOTE] Original Pluto still performs observation processing, inference, decisions and commands.
echo [NOTE] v102 only supplies self/ally/enemy/neutral as separate owner categories to the model.

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV102.dll" "%ROOT%\PlutoTeamRuntimePrepV102.exe" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing: %%~F
  >>"%LAUNCHLOG%" echo FAIL missing: %%~F
  pause
  exit /b 1
)

if exist "%ROOT%\pluto\pluto_infer.exe" if exist "%ROOT%\pluto\pluto_weights.bin" goto runtime_ready
if exist "%ROOT%\pluto_infer.exe" if exist "%ROOT%\pluto_weights.bin" (
  if not exist "%ROOT%\pluto" mkdir "%ROOT%\pluto"
  copy /Y "%ROOT%\pluto_infer.exe" "%ROOT%\pluto\pluto_infer.exe" >nul || goto runtime_fail
  copy /Y "%ROOT%\pluto_weights.bin" "%ROOT%\pluto\pluto_weights.bin" >nul || goto runtime_fail
  goto runtime_ready
)
echo [FAIL] Exact official Pluto inference files are missing.
>>"%LAUNCHLOG%" echo FAIL official runtime missing
pause
exit /b 2

:runtime_fail
echo [FAIL] Could not create Pluto runtime layout.
pause
exit /b 3

:runtime_ready
tasklist /FI "IMAGENAME eq pluto_infer.exe" 2^>nul | find /I "pluto_infer.exe" ^>nul
if not errorlevel 1 (
  echo [FAIL] stale pluto_infer.exe is already running.
  echo Run: taskkill /IM pluto_infer.exe /F
  pause
  exit /b 5
)

echo [INFO] Preparing exact official Pluto engine/weights for four-way owner input...
"%ROOT%\PlutoTeamRuntimePrepV102.exe" "%ROOT%" >>"%LAUNCHLOG%" 2>&1
if errorlevel 1 (
  echo [FAIL] Four-way runtime preparation failed.
  type "%LAUNCHLOG%"
  pause
  exit /b 6
)
echo [PASS] Four-way inference runtime prepared.

del /q "%ROOT%\plutoteam-x86-v102.log" 2>nul
del /q "%ROOT%\plutoteam-x86-v102-inject.log" 2>nul

echo.
echo TEST: 2v2 or 3v3 melee/custom team game.
echo Start SC:R 32-bit and enter the FIRST game.
echo Press any key ONCE to inject v102.
echo Do NOT inject again for later games in the same StarCraft.exe.
pause >nul

echo [INFO] injecting...
>>"%LAUNCHLOG%" echo INJECT_START
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86TeamRuntimeV102.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
>>"%LAUNCHLOG%" echo INJECT_EXIT=%RC%

echo.
echo === INJECT RESULT ===
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
  echo [FAIL] injection stage failed.
  pause
  exit /b %RC%
)

timeout /t 2 /nobreak >nul
if exist "%ROOT%\plutoteam-x86-v102.log" (
  echo [PASS] v102 runtime log created.
  echo Check TEAM4_SHM_OWNER_REWRITE=PASS and ally counts.
) else (
  echo [FAIL] runtime log missing.
)
pause
