@echo off
setlocal
cd /d "%~dp0"
if not exist "pluto\pluto_infer.official.exe" (
  echo [FAIL] official inference backup not found.
  pause
  exit /b 1
)
if not exist "pluto\pluto_weights.official.bin" (
  echo [FAIL] official weights backup not found.
  pause
  exit /b 2
)
taskkill /IM pluto_infer.exe /F >nul 2>nul
copy /Y "pluto\pluto_infer.official.exe" "pluto\pluto_infer.exe" >nul
copy /Y "pluto\pluto_weights.official.bin" "pluto\pluto_weights.bin" >nul
echo [PASS] Exact official Pluto inference files restored.
pause
