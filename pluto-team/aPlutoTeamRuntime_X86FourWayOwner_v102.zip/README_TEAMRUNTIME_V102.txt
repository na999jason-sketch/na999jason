aPlutoTeamRuntime v102 x86 — Four-Way Owner In-Game
=======================================================

WHAT IS NEW
-----------
v101 proved the live SC:R bridge can identify allied units/buildings from:
  CUnit owner +0x4C
  Game::alliances offset 58692

Phase3B v1.3 proved the exact official pluto_infer.exe accepts a four-row
owner embedding after one verified compatibility-gate change:
  file offset 59203: owner vocab 3 -> 4

v102 combines both discoveries in the real game.

MODEL OWNER CATEGORY
--------------------
0 = self
1 = ally
2 = enemy
3 = neutral

The runtime-prep utility derives a four-row owner embedding from the exact
official weights:
  new[0] = old self
  new[1] = old other       (ally seed)
  new[2] = old other       (enemy seed)
  new[3] = old neutral

Therefore ally and enemy are structurally distinct inputs, but their initial
weights are deliberately identical. This preserves the original policy before
team training.

HOW THE LIVE REWRITE WORKS
--------------------------
Original Pluto still builds its normal observation and writes the request to
its own shared-memory transport. Immediately before its request event is
signalled, v102 rewrites ONLY cat[:,1] (owner category).

For original "other player" rows it matches the model row back to the current
real SC:R CUnit using type + exact position, preferring matching order. The
actual CUnit owner plus the verified SCR alliance matrix selects ALLY or ENEMY.
Ambiguous/unmatched rows fail closed to ENEMY/default-other; because ally and
enemy seed rows are initially identical, this does not alter the base policy.

No screen capture. No OCR. No bridge-created strategy. No replacement target.

ALLY TARGET SAFETY
------------------
The v101 drop-only direct-ally-target safety remains enabled. Original Pluto
still generates commands. If its old 1v1 policy directly targets an ally, that
packet is rejected. Position attack-move behavior can still be odd until the
ally embedding is trained.

EXPECTED LOG MARKERS
--------------------
PLUTOTEAMRUNTIME_V102_RESIDENT=LOADED
TEAM_RUNTIME_MODE=FOURWAY_OWNER_INGAME
TEAM4_ENGINE_RUNTIME=PATCH_VERIFIED offset=59203 value=4
TEAM4_WEIGHTS_RUNTIME=OWNER_EMB_4X256_VERIFIED
TEAM4_SET_EVENT_HOOK=INSTALLED
TEAM4_SHM_TRANSPORT=ACTIVE
TEAM4_SHM_OWNER_REWRITE=PASS seq=... N=... self=... ally=... enemy=... neutral=...
TEAM4_OWNER_SAMPLE ... relation=ALLY ...
TEAM_RUNTIME_ALLY_TARGET_BLOCK ...   (if old policy directly targets ally)

TEST
----
1. Put exact official Pluto runtime beside this artifact:
     pluto.dll
     pluto\pluto_infer.exe
     pluto\pluto_weights.bin
2. Start SC:R 32-bit.
3. Enter a 2v2 or 3v3 game.
4. Run RUN_PLUTO_TEAMRUNTIME_X86_V102.cmd once.
5. Let allied units/buildings become visible and play for several minutes.
6. Send back:
     plutoteam-x86-v102.log
     pluto_infer.log   (if present)

The launcher automatically keeps exact-official backups:
  pluto\pluto_infer.official.exe
  pluto\pluto_weights.official.bin

Use RESTORE_PLUTO_OFFICIAL_V102.cmd to restore the pure official runtime.

IMPORTANT
---------
v102 proves live model-boundary four-way input. It does NOT yet mean the model
has learned team cooperation, because ally==enemy at seed. The next stage after
a clean v102 game log is training only the 256-value ally embedding first,
while keeping the original network frozen.
