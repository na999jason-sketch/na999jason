aPlutoSCR v91 x86 Verified Command Translation Dry Run + Exact Bindings

Purpose
- Run the ORIGINAL Pluto binary on 32-bit StarCraft: Remastered.
- Pluto itself still performs observation, inference, decision, and legacy command generation.
- The bridge only supplies the legacy ABI and converts the command packet format.

What v90 proved
- Original Pluto onStart passed and pluto_infer.exe stayed alive.
- Real SC:R CUnit/Game/Players/ActiveTile/Bullet state reached original Pluto.
- Original Pluto generated legacy gameplay command buffers continuously through at least diagnostic frame 901.
- v90 intentionally discarded every command and never sent anything to SC:R.

v91 changes
- Adds the verified public BW 1.16.1 -> SC:R gameplay command translator.
- Selection commands 0x09..0x0B become SC:R 0x63..0x65 with 32-bit unit handles.
- Legacy commands 0x14/0x15 become SC:R 0x60/0x61.
- Legacy unit-target command 0x29 becomes SC:R 0x62.
- Other supported fixed-length gameplay commands retain their packet format exactly.
- Legacy 16-bit unit handles are validated against the 1700 stable legacy slots, then converted back to the current SC:R pool index + source generation format.
- Unsupported commands, truncated packets, null selection handles, expired handles, or unmapped handles fail closed.
- Flushes of Pluto's legacy 512-byte command buffer are captured in order (up to 16 per Pluto callback) and translated too.
- Every translated SCR packet is logged in hex.

IMPORTANT
- v91 is still a DRY RUN. It does NOT call SC:R send_command.
- The verified reference port submits commands on StarCraft's game thread. Our current diagnostic bridge runs Pluto from a resident worker thread, so v91 validates translation first instead of risking a cross-thread send.
- After v91 proves all generated packets/handles translate cleanly, the next step is moving execution onto a verified game-thread hook and submitting the packets with the one-frame retention used by the reference port.

Original Pluto runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Expected v91 milestones
  reloc91.game_operands=PASS_EXACT_BINDINGS
  reloc91.players_operands=PASS_EXACT_BINDINGS
  active_tile=BOUND_REAL_SCR
  profile_bullet=BOUND_VALIDATED
  reloc91.command_abi=PASS_EXACT_BINDINGS
  legacy_command_abi=BOUND_TRANSLATION_VALIDATION_NOT_SENT
  original_pluto.onStart=PASS
  PLUTOSCR_V91_COMMAND_TRANSLATION_VALIDATION_LOOP=START

When Pluto creates commands, expected output is:
  original_pluto.legacy_command_bytes=N frame=F
  scr_command_translation=PASS packets=N frame=F
  scr_command_packet[0]=...
  scr_command_sink=FAIL_CLOSED_TRANSLATION_VALIDATED_NOT_SENT

Any scr_command_translation=FAIL_CLOSED line must be treated as a hard stop before a live sink is enabled.

The original Pluto model/files are not included and are not modified.
