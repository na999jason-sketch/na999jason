aPlutoSCR v79 x86 - complete visible-head + UnitNodeTable relocation

Goal: port the unmodified original Pluto observation/decision/action logic onto live StarCraft: Remastered x86 state.
This overlay is only a compatibility/ABI bridge. It does not implement observation semantics, AI decisions, strategy, or action selection on Pluto's behalf.

v79 changes:
- Keeps v76's global CUnit-vector selection, verified 114-unit dynamic prev/next discovery, semantic visible/hidden/scanner heads, and legacy bullet shadow.
- Patches every currently identified Pluto reference to BW 1.16.1 visible-unit head 0x628430: RVA 0xBD6B, 0x33F7D, and 0x3B787. Each instruction is signature-checked before modification.
- Relocates Pluto's validated UnitNodeTable arithmetic from BW 1.16.1 base 0x59CCA8 to the actual start of the contiguous 336-byte legacy CUnit shadow.
- Relocates the corresponding generation-byte base 0x59CD4D to shadow_base + 0xA5.
- The UnitNodeTable relocation covers validated operands at RVAs 0xAAF4, 0xAB44, 0x3134B, 0x31351, 0x3408D, 0x341B4, 0x343D8, 0x3C2D9, and 0x3C2DE.
- Keeps fail-closed validation: if any expected original Pluto operand differs, v79 refuses to continue rather than inventing or altering Pluto observations.
- Pluto command delivery remains disabled until the original Pluto command output can be mapped to a verified SC:R command sink without changing Pluto's decisions.

Expected log: plutoscr-x86-v79.log
