PlutoSCR v37 - x86 SC:R Direct Pluto Loader
Goal: original Pluto port only. No replacement AI.

Put original pluto.dll, pluto_infer.exe and pluto_weights.bin beside these files.
Launch the 32-bit StarCraft.exe supplied by your own SC:R installation, then run RUN_PLUTO_SCR_X86.cmd.

v37 removes the x64/x86 cross-process PlutoHost route and proves original pluto.dll can be loaded directly inside x86 SC:R.
It intentionally does NOT call gameInit with a fake BWAPI Game pointer. The next integration binds the in-process SC:R BWAPI compatibility facade first.
