@echo off
cd /d "%~dp0"
echo [PlutoSCR v37] x86 SC:R direct Pluto loader
if not exist pluto.dll (
  echo [FAIL] pluto.dll is missing beside this launcher.
  pause
  exit /b 2
)
PlutoSCRX86Inject.exe "%~dp0PlutoSCRX86Resident.dll"
echo.
echo Check plutoscr-x86-direct.log after injection.
pause
