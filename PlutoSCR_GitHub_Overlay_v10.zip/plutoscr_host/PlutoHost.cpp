#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include "PlutoHostIPC.h"
#include <cstdio>
#include <filesystem>
#include <string>

using PFNGameInit = void (*)(BWAPI::Game*);
using PFNCreateAI = BWAPI::AIModule* (*)();

static void dispatchEvent(BWAPI::AIModule* module, const BWAPI::Event& e)
{
  using namespace BWAPI;
  switch (e.getType())
  {
    case EventType::MatchStart:    module->onStart(); break;
    case EventType::MatchEnd:      module->onEnd(e.isWinner()); break;
    case EventType::MatchFrame:    module->onFrame(); break;
    case EventType::SendText:      module->onSendText(e.getText()); break;
    case EventType::ReceiveText:   module->onReceiveText(e.getPlayer(), e.getText()); break;
    case EventType::PlayerLeft:    module->onPlayerLeft(e.getPlayer()); break;
    case EventType::NukeDetect:    module->onNukeDetect(e.getPosition()); break;
    case EventType::UnitDiscover:  module->onUnitDiscover(e.getUnit()); break;
    case EventType::UnitEvade:     module->onUnitEvade(e.getUnit()); break;
    case EventType::UnitCreate:    module->onUnitCreate(e.getUnit()); break;
    case EventType::UnitDestroy:   module->onUnitDestroy(e.getUnit()); break;
    case EventType::UnitMorph:     module->onUnitMorph(e.getUnit()); break;
    case EventType::UnitShow:      module->onUnitShow(e.getUnit()); break;
    case EventType::UnitHide:      module->onUnitHide(e.getUnit()); break;
    case EventType::UnitRenegade:  module->onUnitRenegade(e.getUnit()); break;
    case EventType::SaveGame:      module->onSaveGame(e.getText()); break;
    case EventType::UnitComplete:  module->onUnitComplete(e.getUnit()); break;
    default: break;
  }
}

int wmain(int argc, wchar_t** argv)
{
  std::filesystem::path plutoDll = argc > 1 ? argv[1] : L"pluto.dll";

  HANDLE dataMap = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, PlutoSCR::kMappingName);
  HANDLE ctlMap  = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, PlutoSCR::kControlName);
  if (!dataMap || !ctlMap) {
    std::fwprintf(stderr, L"PlutoHost: SC:R runtime shared mappings are not ready.\n");
    return 2;
  }
  auto* data = static_cast<BWAPI::GameData*>(
    MapViewOfFile(dataMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(BWAPI::GameData)));
  auto* ctl = static_cast<PlutoSCR::Control*>(
    MapViewOfFile(ctlMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(PlutoSCR::Control)));
  if (!data || !ctl || ctl->magic != PlutoSCR::kMagic || ctl->version != PlutoSCR::kVersion)
    return 3;

  HMODULE pluto = LoadLibraryW(plutoDll.c_str());
  if (!pluto) {
    ctl->lastError = GetLastError();
    std::fwprintf(stderr, L"PlutoHost: LoadLibrary failed (%lu): %ls\n", GetLastError(), plutoDll.c_str());
    return 4;
  }
  auto gameInit = reinterpret_cast<PFNGameInit>(GetProcAddress(pluto, "gameInit"));
  auto createAI = reinterpret_cast<PFNCreateAI>(GetProcAddress(pluto, "newAIModule"));
  if (!gameInit || !createAI) {
    ctl->lastError = ERROR_PROC_NOT_FOUND;
    return 5;
  }

  BWAPI::GameImpl game(data);
  gameInit(&game);                         // exact BWAPI 4.4 module contract
  BWAPI::AIModule* module = createAI();
  if (!module) return 6;

  ctl->state = static_cast<std::uint32_t>(PlutoSCR::HostState::HostReady);
  std::uint32_t seen = ctl->runtimeFrameSequence;
  bool wasInGame = false;

  while (ctl->state != static_cast<std::uint32_t>(PlutoSCR::HostState::Stopping))
  {
    const std::uint32_t seq = ctl->runtimeFrameSequence;
    if (seq == seen) { Sleep(1); continue; }
    seen = seq;

    const bool nowInGame = data->isInGame;
    if (nowInGame && !wasInGame) game.onMatchStart();
    else if (!nowInGame && wasInGame) game.onMatchEnd();
    else if (nowInGame) game.onMatchFrame();

    // GameImpl has converted GameData events into ABI-correct BWAPI objects.
    for (const BWAPI::Event& e : game.getEvents())
      dispatchEvent(module, e);

    // Some producers may omit MatchFrame from eventCount; preserve BWAPI's one-frame callback.
    bool hadFrame = false;
    for (const BWAPI::Event& e : game.getEvents())
      if (e.getType() == BWAPI::EventType::MatchFrame) { hadFrame = true; break; }
    if (nowInGame && !hadFrame)
      module->onFrame();

    // Commands/shapes written by Pluto now live in GameData's standard BWAPIClient output arrays.
    MemoryBarrier();
    ctl->commandSequence = seq;
    ctl->hostFrameSequence = seq;
    wasInGame = nowInGame;
  }

  if (wasInGame) game.onMatchEnd();
  delete module;
  FreeLibrary(pluto);
  return 0;
}
