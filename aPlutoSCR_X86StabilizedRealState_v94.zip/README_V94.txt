aPlutoSCR v94 x86 — Stabilized Real State

기준
- v93 실제 작동판을 기준으로 유지한다.
- 원본 Pluto가 관측/추론/판단/legacy command 생성을 담당한다.
- 호환 브리지는 SC:R 실제 상태를 legacy/BWAPI 형태로 연결하고 명령 형식만 변환한다.
- v93의 검증된 게임 메인 스레드 send_command + 1-frame delay 경로는 유지한다.

V94 안정화 변경
1. Coherent CUnit snapshot
   - 같은 worker iteration에서 CUnit pool을 두 번 따로 스캔하지 않는다.
   - SC:R frame_count가 스캔 전/후 동일할 때의 raw CUnit 목록 하나만 채택한다.
   - 동일 raw 목록을 GameData와 legacy CUnit shadow 양쪽에 사용한다.
   - legacy shadow count는 해당 raw snapshot count와 정확히 일치해야 하며 아니면 fail-closed.

2. Full observation frame coherence
   - CUnit snapshot을 잡은 frame과 Game/ActiveTile/Bullet/Players 갱신 완료 후 frame을 다시 비교한다.
   - 중간에 게임 frame이 넘어가면 그 관측은 Pluto에 전달하지 않고 폐기한다.
   - 다음 iteration에서 새 coherent snapshot을 만든다.

3. 실제 SC:R 유닛 가시성
   - 이전의 모든 Unit::isVisible=true 근사를 제거했다.
   - CUnit->Sprite visibility_mask를 직접 읽는다.
   - 자기 유닛은 자기 플레이어에게 visible, 적은 실제 visibility bit가 있을 때만 GameData에 접근 가능하게 한다.
   - 중립 유닛은 접근 가능 상태를 유지한다.

4. 실제 ActiveTile map visibility
   - 실제 SC:R ActiveTileArray 비트에서 GameData isVisible/isExplored/hasCreep/isOccupied를 매 frame 갱신한다.

5. v93 command path 보존
   - legacy command translation/16-bit->32-bit handle 변환 유지
   - GetTickCount game-thread hook의 검증된 두 frame callsite 유지
   - one-frame pending queue 유지
   - SC:R send_command 분석 VA 0x007DA250 유지
   - 변환/handle/hook/send 오류 시 fail-closed

필수 런타임
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

테스트 전 권장
  taskkill /IM pluto_infer.exe /F
  taskkill /IM StarCraft.exe /F

성공 로그 핵심
  stability94=coherent-full-observation+real-sprite-visibility+real-active-tile-map+v93-command-path
  gamedata.map_visibility=BOUND_REAL_SCR
  cunit_snapshot ...
  observation_snapshot=COHERENT ...
  scr_game_thread_hook=ACTIVE ...
  scr_command_translation=PASS ...
  scr_send_command=PASS ...

정상 동작 시 v93처럼 실제 유닛 이동/건설이 계속되어야 하며,
v93의 legacy_cunit_shadow.live_mismatch 로그는 더 이상 발생하지 않아야 한다.
