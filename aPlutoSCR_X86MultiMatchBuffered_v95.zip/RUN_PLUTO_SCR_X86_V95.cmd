@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"

echo === aPlutoSCR v95 x86 Multi-Match Lifecycle + Buffered Logging ===
for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86V95.dll" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing: %%~F
  pause
  exit /b 1
)

if exist "%ROOT%\pluto\pluto_infer.exe" if exist "%ROOT%\pluto\pluto_weights.bin" goto runtime_ready
if exist "%ROOT%\pluto_infer.exe" if exist "%ROOT%\pluto_weights.bin" (
  if not exist "%ROOT%\pluto" mkdir "%ROOT%\pluto"
  copy /Y "%ROOT%\pluto_infer.exe" "%ROOT%\pluto\pluto_infer.exe" >nul || goto runtime_fail
  copy /Y "%ROOT%\pluto_weights.bin" "%ROOT%\pluto\pluto_weights.bin" >nul || goto runtime_fail
  goto runtime_ready
)

echo [FAIL] Original Pluto inference files are missing.
pause
exit /b 2

:runtime_fail
echo [FAIL] Could not create original Pluto runtime layout.
pause
exit /b 3

:runtime_ready
tasklist /FI "IMAGENAME eq pluto_infer.exe" 2^>nul | find /I "pluto_infer.exe" ^>nul
if not errorlevel 1 (
  echo [FAIL] stale pluto_infer.exe is already running.
  echo Run: taskkill /IM pluto_infer.exe /F
  pause
  exit /b 5
)

del /q "%ROOT%\plutoscr-x86-v95.log" 2>nul
echo Start SC:R 32-bit and enter the FIRST local/custom game.
echo Inject ONCE. After that, v95 should handle later games in the SAME StarCraft.exe automatically.
echo Do NOT run this injector again between matches.
pause >nul
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86V95.dll"
if errorlevel 1 (
  echo [FAIL] injection failed
  pause
  exit /b 4
)
echo [PASS] v95 injected. Keep StarCraft.exe running across multiple matches.
echo Log: %ROOT%\plutoscr-x86-v95.log
echo For the Explorer-stall test, do not keep this folder open while the match is running.
pause
