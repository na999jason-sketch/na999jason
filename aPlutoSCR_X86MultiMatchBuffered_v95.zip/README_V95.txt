aPlutoSCR v95 x86 — Multi-Match Lifecycle + Buffered Logging

기준
- v94의 실제 SC:R 상태 관측 + 실제 visibility + 검증된 command translation/send 경로를 그대로 유지한다.
- 원본 Pluto가 관측/추론/판단/legacy command 생성을 담당한다.
- v95는 매치 생명주기와 로그 I/O만 안정화한다.

V95 변경
1. 다판 lifecycle
   - SC:R 1.23.10.13515 x86의 검증된 game-loop active byte(분석 VA 0x121758D)로 경기 종료를 감지한다.
   - 종료 즉시 command sink를 disarm하고 pending turn을 폐기한다.
   - original Pluto onEnd(won) -> BWAPI GameImpl onMatchEnd 순서로 종료한다.
   - 다음 경기에서는 실제 game/local-player/CUnit/Game block이 다시 유효해질 때까지 기다린다.
   - 새 GameData/GameImpl/AIModule을 만들고 gameInit -> onMatchStart -> original Pluto onStart를 다시 수행한다.
   - Pluto binary는 다시 패치하지 않는다. 이미 패치한 대상은 고정 shadow/global cell이며, 각 매치마다 내용만 갱신한다.
   - legacy CUnit 1700-slot 배열은 재할당하지 않아 UnitNodeTable patched base가 2판째에도 유지된다.

2. 매치 간 상태 reset
   - pending commands, command staging buffer, flush capture, handle lookup, bullet shadow, local-player start globals를 초기화한다.
   - stable unit handle generation은 새 매치에서 다시 시작한다.
   - command-send failure state와 per-match submitted counter를 reset한다.
   - pluto_infer.exe는 새 onStart 후 정확히 1개인지 확인하고, 2초 동안 안정화 후 1개가 아니면 fail-closed한다.

3. 탐색기/로그 안정화
   - 로그 파일을 매 줄마다 open/close하지 않는다. DLL 수명 동안 하나의 FILE handle을 유지한다.
   - 64 KiB stdio buffer를 사용한다.
   - 일반 로그는 64줄 단위로 flush하고 FAIL/SEH/MATCH/RESIDENT 로그만 즉시 flush한다.
   - command hex/packet 상세 로그는 처음 12회 + 이후 32회마다 샘플링한다.
   - SC:R game thread에서 발생하는 파일 I/O 횟수를 크게 줄였다.

첫 실행
- StarCraft.exe와 pluto_infer.exe를 모두 종료한 상태에서 시작한다.
- SC:R 32-bit를 켜고 첫 로컬/커스텀 게임에 들어간 뒤 v95를 한 번만 주입한다.

다판 테스트
1) 첫 게임에서 이동/건설 확인
2) 게임 정상 종료
3) StarCraft.exe를 끄지 말고 새 게임 생성
4) injector를 다시 실행하지 않는다
5) 두 번째 게임에서도 자동으로 Pluto가 움직여야 한다

성공 로그
  MATCH_START generation=1 ...
  MATCH_END_DETECTED generation=1 ...
  original_pluto.onEnd=PASS generation=1 ...
  bwapi.onMatchEnd=PASS generation=1
  MATCH_END generation=1 ...
  MATCH_WAIT_NEXT generation=2
  MATCH_START generation=2 ... infer_count=1
  scr_send_command=PASS ...

탐색기 테스트
- 권장 경로: C:\PlutoSCR\v95\
- 테스트 중 해당 폴더를 탐색기로 계속 열어두지 않는다.
- v95는 v94보다 로그 파일 변경 이벤트와 open/close를 크게 줄였다.

Fail-closed
- replay, invalid game state, unit-handle conversion failure, unsupported packet, send_command SEH, duplicate/missing infer process는 실제 command 전송을 중단한다.
