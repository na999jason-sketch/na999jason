PlutoSCR v33 trust-gate build.
The v32 Bottleneck map result was a false positive. v33 removes map proof from the trusted gate and
does not feed heuristic unit/active-match projections to Pluto. Only resident-backed frame/BWGame
evidence is accepted. PlutoHost is intentionally held until unit identity/ownership and command
delivery are proven, preventing false-positive state from driving Pluto.
