#ifndef NOMINMAX
#define NOMINMAX
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <BWAPI/Client/Client.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

static HMODULE g_self=nullptr;
using PFNGameInit=void(*)(BWAPI::Game*);
using PFNCreateAI=BWAPI::AIModule*(*)();
static std::string dirOf(HMODULE m){char p[MAX_PATH]={};GetModuleFileNameA(m,p,MAX_PATH);std::string s(p);auto n=s.find_last_of("\\/");return n==std::string::npos?".":s.substr(0,n);}
static void logLine(const std::string&s){std::ofstream f(dirOf(g_self)+"\\plutoscr-x86-v52.log",std::ios::app);f<<s<<"\r\n";}
static DWORD onStartSeh(BWAPI::AIModule*m){__try{m->onStart();return 0;}__except(EXCEPTION_EXECUTE_HANDLER){return GetExceptionCode();}}
static DWORD onFrameSeh(BWAPI::AIModule*m){__try{m->onFrame();return 0;}__except(EXCEPTION_EXECUTE_HANDLER){return GetExceptionCode();}}

#pragma pack(push,1)
struct LegacyCUnit336{ unsigned char b[336]; };
#pragma pack(pop)
static_assert(sizeof(LegacyCUnit336)==336,"CUnit size");

template<class T> static T rd(const unsigned char*p,size_t o){T v{};std::memcpy(&v,p+o,sizeof(v));return v;}
static bool readable(const void*p,size_t n){
  MEMORY_BASIC_INFORMATION mi{}; if(!VirtualQuery(p,&mi,sizeof(mi)))return false;
  if(mi.State!=MEM_COMMIT || (mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
  uintptr_t a=(uintptr_t)p; uintptr_t e=a+(uintptr_t)n; uintptr_t r=(uintptr_t)mi.BaseAddress+(uintptr_t)mi.RegionSize; return e>=a && e<=r;
}
static bool plausibleUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  auto hp=rd<int32_t>(p,0x08); auto spr=rd<uint32_t>(p,0x0c); auto x=rd<int16_t>(p,0x28); auto y=rd<int16_t>(p,0x2a);
  auto player=rd<uint8_t>(p,0x4c); auto order=rd<uint8_t>(p,0x4d); auto type=rd<uint16_t>(p,0x64);
  return spr!=0 && hp>0 && hp<(5000000*256) && x>=0&&x<=16384&&y>=0&&y<=16384&&player<12&&order<256&&type<234;
}
struct UnitStore{uintptr_t descriptor=0,begin=0,end=0,cap=0;int score=0;};
static UnitStore findLegacyCUnitVector(){
  UnitStore best{}; SYSTEM_INFO si{};GetSystemInfo(&si); uintptr_t a=(uintptr_t)si.lpMinimumApplicationAddress, max=(uintptr_t)si.lpMaximumApplicationAddress;
  MEMORY_BASIC_INFORMATION mi{};
  while(a<max && VirtualQuery((void*)a,&mi,sizeof(mi))){
    bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) && (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && mi.RegionSize>=12){
      uintptr_t s=(uintptr_t)mi.BaseAddress,e=s+mi.RegionSize;
      for(uintptr_t q=s;q+12<=e;q+=4){
        if(!readable((void*)q,12)) continue;
        uint32_t b=0,en=0,c=0;
        std::memcpy(&b,(void*)q,4); std::memcpy(&en,(void*)(q+4),4); std::memcpy(&c,(void*)(q+8),4);
        if(!b||en<b||c<en)continue; uint32_t used=en-b,cap=c-b;
        // SC:R diagnostics report CUnit::sgUnitsMem capacity around 3400; accept active vectors up to that exact engine ceiling.
        if(used==0 || used%336 || cap%336)continue; uint32_t count=used/336, capacity=cap/336;
        if(count<2 || count>3400 || capacity<count || capacity>3400)continue;
        if(!readable((void*)b,std::min<uint32_t>(used,336*64)))continue;
        int score=0; uint32_t step=std::max<uint32_t>(1,count/64);
        for(uint32_t i=0;i<count && i<3400;i+=step) if(plausibleUnit((unsigned char*)(uintptr_t)(b+i*336))) ++score;
        if(score>best.score){best={q,b,en,c,score};}
      }
    }
    uintptr_t next=(uintptr_t)mi.BaseAddress+mi.RegionSize;if(next<=a)break;a=next;
  }
  return best;
}
static int inferRace(int type){if(type<=59||(type>=106&&type<=131))return 1;if((type>=88&&type<=103)||(type>=132&&type<=157))return 0;if((type>=60&&type<=87)||type==97||(type>=159&&type<=173))return 2;return 5;}
static int projectLiveUnits(const UnitStore&s,BWAPI::GameData&d){
  if(!s.begin||s.end<s.begin)return 0; int out=0; std::array<int,12> counts{}; std::array<int,12> race{}; race.fill(5);
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  for(uint32_t i=0;i<count && out<10000;i++){
    auto*p=(unsigned char*)(s.begin+i*336); if(!plausibleUnit(p))continue;
    auto&q=d.units[out]; ZeroMemory(&q,sizeof(q)); q.id=out;q.player=rd<uint8_t>(p,0x4c);q.type=rd<uint16_t>(p,0x64);q.positionX=rd<int16_t>(p,0x28);q.positionY=rd<int16_t>(p,0x2a);
    q.hitPoints=std::max(0,rd<int32_t>(p,0x08)/256);q.shields=rd<uint32_t>(p,0x60)/256;q.energy=rd<uint16_t>(p,0xa2)/256;q.order=rd<uint8_t>(p,0x4d);
    q.targetPositionX=rd<int16_t>(p,0x58);q.targetPositionY=rd<int16_t>(p,0x5a);q.orderTargetPositionX=q.targetPositionX;q.orderTargetPositionY=q.targetPositionY;
    q.exists=true;auto flags=rd<uint32_t>(p,0xdc);q.isCompleted=(flags&1)!=0;q.isCloaked=(flags&0x200)!=0;q.isBurrowed=(flags&0x10)!=0;q.isInvincible=(flags&0x04000000)!=0;
    if(q.player>=0&&q.player<12){counts[q.player]++;race[q.player]=inferRace(q.type);} for(bool&v:q.isVisible)v=true; ++out;
  }
  d.initialUnitCount=out;d.playerCount=0;
  for(int p=0;p<12;p++)if(counts[p]){d.playerCount=std::max(d.playerCount,p+1);d.players[p].race=race[p];d.players[p].isParticipating=true;d.players[p].type=1;d.players[p].isAlly[p]=true;}
  return out;
}
static DWORD WINAPI boot(LPVOID){
  DeleteFileA((dirOf(g_self)+"\\plutoscr-x86-v52.log").c_str()); logLine("PLUTOSCR_V52_RESIDENT=LOADED");logLine("architecture=x86");logLine("policy=original-pluto-observation-untouched");
  UnitStore store=findLegacyCUnitVector();
  logLine("scr_cunit_vector.descriptor=0x"+std::to_string((unsigned long)store.descriptor));logLine("scr_cunit_vector.score="+std::to_string(store.score));
  if(store.score<2){logLine("scr_cunit_vector=UNRESOLVED");return 10;} logLine("scr_cunit_vector=BOUND");
  const std::string d=dirOf(g_self);SetDllDirectoryA(d.c_str());HMODULE pluto=LoadLibraryA((d+"\\pluto.dll").c_str());if(!pluto){logLine("original_pluto.load=FAIL");return 1;}logLine("original_pluto.load=PASS");
  auto gameInit=(PFNGameInit)GetProcAddress(pluto,"gameInit");auto createAI=(PFNCreateAI)GetProcAddress(pluto,"newAIModule");if(!gameInit||!createAI){logLine("original_pluto.exports=FAIL");return 2;}
  auto*data=new BWAPI::GameData();ZeroMemory(data,sizeof(*data));int n=projectLiveUnits(store,*data);logLine("live_units="+std::to_string(n));if(n<2)return 11;
  // Choose the first participating slot only as a compatibility bootstrap; do not fabricate Pluto observations.
  int self=-1,enemy=-1;for(int p=0;p<12;p++)if(data->players[p].isParticipating){if(self<0)self=p;else if(enemy<0)enemy=p;}data->self=self;data->enemy=enemy;data->neutral=11;data->isInGame=true;
  BWAPI::BWAPIClient.data=data;auto*game=new BWAPI::GameImpl(data);BWAPI::BroodwarPtr=game;gameInit(game);auto*module=createAI();if(!module){logLine("original_pluto.newAIModule=FAIL");return 3;}game->onMatchStart();
  DWORD ec=onStartSeh(module);if(ec){logLine("original_pluto.onStart=SEH_EXCEPTION code="+std::to_string(ec));return 4;}logLine("original_pluto.onStart=PASS");
  logLine("PLUTOSCR_V52_LIVE_CUNIT_PLUTO_LOOP=START");int lastCmd=0;
  while(true){Sleep(42);int live=projectLiveUnits(store,*data);if(live<2){logLine("live_units_lost");break;}++data->frameCount;game->onMatchFrame();ec=onFrameSeh(module);if(ec){logLine("original_pluto.onFrame=SEH_EXCEPTION code="+std::to_string(ec));break;}
    if(data->unitCommandCount!=lastCmd){logLine("pluto_bwapi_unit_commands="+std::to_string(data->unitCommandCount));lastCmd=data->unitCommandCount;}
    if(data->unitCommandCount>0){logLine("scr_command_sink=UNRESOLVED_FAIL_CLOSED");data->unitCommandCount=0;lastCmd=0;}
  }
  return 0;
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){if(r==DLL_PROCESS_ATTACH){g_self=h;DisableThreadLibraryCalls(h);HANDLE t=CreateThread(nullptr,0,boot,nullptr,0,nullptr);if(t)CloseHandle(t);}return TRUE;}
