PlutoSCR v74 - x86 dynamic CUnit link discovery for original Pluto

Goal: run the unmodified original Pluto observation/decision/action logic against live StarCraft: Remastered x86 state.
This overlay does not implement AI decisions. It only discovers the live CUnit store and infers the CUnit doubly-linked-list fields from reciprocal in-process pointers.

Fail-closed rules:
- No fixed SC:R global address is trusted for CUnit visible/hidden/scanner heads.
- Candidate prev/next offsets are scored from actual live CUnits.
- A dominant visible chain is required; ambiguous layouts are logged and rejected.
- Scanner Sweep is identified only from a separate linked chain containing unit type 33.
- Pluto command delivery remains disabled until a verified synchronized SC:R command sink is connected.

Expected log: plutoscr-x86-v74.log
