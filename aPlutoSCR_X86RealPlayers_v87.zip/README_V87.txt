aPlutoSCR v87 x86 Real Players + Profile Bullet + Stable CUnit + ActiveTile

Purpose
- Port the original Pluto binary to 32-bit StarCraft: Remastered without replacing Pluto observation, inference, decision, or action generation.
- SC:R real state -> compatibility/legacy view -> original Pluto observation -> original Pluto inference/decision -> original Pluto command output.

v87 changes
- Adds the real SCR Players[12] bridge required by original Pluto onStart.
- Resolves SCR's live players allocation from the verified 1.23.10.13515 x86 profile and validates 12 x 36-byte player records.
- Copies the real player records into a legacy 0x57EEE0 Players[] shadow.
- Relocates every Pluto executable operand that points inside 0x57EEE0..0x57F08F to the real-player shadow, with five known onStart anchors required before patching.
- Refreshes the player shadow every frame.
- Keeps v86 profile bullet shadow, v85 real local-player/start globals, stable 1700 CUnit slots, real SCR Game shadow, and real ActiveTileArray bridge.
- Original Pluto observation/inference/decision/action generation remains untouched.
- Command sink remains disabled until original Pluto command generation is verified.

Original Pluto runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Expected v87 log milestones
  profile_cunit=BOUND_VALIDATED
  reloc87.game_operands=PASS
  legacy_players.select=PROFILE_VALIDATED
  reloc87.players_operands=PASS
  legacy_players=BOUND_REAL_SCR_PLAYERS
  active_tile=BOUND_REAL_SCR
  profile_bullet=BOUND_VALIDATED
  reloc87.start_globals=PASS
  original_pluto.onStart=PASS (or a new later verified legacy reference)

The original Pluto model/files are not included and are not modified.
