@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set "INJECTOR=%ROOT%PlutoSCRX86Inject.exe"
set "RESIDENT=%ROOT%PlutoSCRX86Resident.dll"
set "PLUTO=%ROOT%pluto.dll"
set "INFER=%ROOT%pluto_infer.exe"
set "WEIGHTS=%ROOT%pluto_weights.bin"

echo [PlutoSCR v38] x86 SC:R direct Pluto loader
echo [INFO] package=%ROOT%

if not exist "%INJECTOR%" (
  echo [FAIL] missing: "%INJECTOR%"
  goto :fail
)
if not exist "%RESIDENT%" (
  echo [FAIL] missing: "%RESIDENT%"
  goto :fail
)
if not exist "%PLUTO%" (
  echo [FAIL] missing: "%PLUTO%"
  goto :fail
)
if not exist "%INFER%" (
  echo [FAIL] missing: "%INFER%"
  goto :fail
)
if not exist "%WEIGHTS%" (
  echo [FAIL] missing: "%WEIGHTS%"
  goto :fail
)

echo [PASS] required files present
echo [INFO] injecting resident into running x86 StarCraft.exe...
"%INJECTOR%" "%RESIDENT%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo [FAIL] injector exit=%RC%
  goto :fail
)

echo [PASS] injector exit=0
timeout /t 2 /nobreak >nul
if exist "%ROOT%plutoscr-x86-direct.log" (
  echo.
  type "%ROOT%plutoscr-x86-direct.log"
) else (
  echo [WARN] plutoscr-x86-direct.log was not created.
)
echo.
echo [DONE] v38 direct-load test completed.
pause
exit /b 0

:fail
echo.
echo [STOP] v38 did not continue.
pause
exit /b 1
