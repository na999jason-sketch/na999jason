
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <fstream>
#include <string>

static HMODULE selfModule = nullptr;

static std::string dirOf(HMODULE m) {
  char p[MAX_PATH] = {};
  GetModuleFileNameA(m, p, MAX_PATH);
  std::string s(p);
  size_t n=s.find_last_of("\\/");
  return n==std::string::npos ? "." : s.substr(0,n);
}
static void logLine(const std::string& s) {
  std::ofstream f(dirOf(selfModule)+"\\plutoscr-x86-direct.log",std::ios::app);
  f << s << "\r\n";
}
static DWORD WINAPI boot(LPVOID) {
  logLine("PLUTOSCR_V38_X86_RESIDENT=LOADED");
  logLine("architecture=x86");
  std::string d=dirOf(selfModule);
  SetDllDirectoryA(d.c_str());

  std::string pluto=d+"\\pluto.dll";
  HMODULE p=LoadLibraryA(pluto.c_str());
  if(!p) {
    logLine("PLUTOSCR_ORIGINAL_PLUTO_LOAD=FAIL win32="+std::to_string(GetLastError()));
    return 1;
  }
  logLine("PLUTOSCR_ORIGINAL_PLUTO_LOAD=PASS");

  FARPROC gameInit=GetProcAddress(p,"gameInit");
  FARPROC newAI=GetProcAddress(p,"newAIModule");
  logLine(std::string("export.gameInit=")+(gameInit?"PASS":"FAIL"));
  logLine(std::string("export.newAIModule=")+(newAI?"PASS":"FAIL"));
  if(gameInit && newAI)
    logLine("PLUTOSCR_V38_DIRECT_LOAD_GATE=PASS");
  else
    logLine("PLUTOSCR_V38_DIRECT_LOAD_GATE=FAIL");

  // Do not call gameInit with a fake/null BWAPI::Game. v38 will bind the
  // in-process x86 SC:R BWAPI compatibility facade before invoking Pluto.
  return 0;
}
BOOL APIENTRY DllMain(HMODULE h,DWORD reason,LPVOID) {
  if(reason==DLL_PROCESS_ATTACH) {
    selfModule=h;
    DisableThreadLibraryCalls(h);
    HANDLE t=CreateThread(nullptr,0,boot,nullptr,0,nullptr);
    if(t) CloseHandle(t);
  }
  return TRUE;
}
