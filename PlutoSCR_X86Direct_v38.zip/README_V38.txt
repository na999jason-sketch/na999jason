PlutoSCR v38 - x86 SC:R Direct Loader
Original Pluto only; no replacement AI.

Required beside RUN_PLUTO_SCR_X86_V38.cmd:
  PlutoSCRX86Inject.exe
  PlutoSCRX86Resident.dll
  pluto.dll
  pluto_infer.exe
  pluto_weights.bin

Run the x86 StarCraft.exe first, enter a local/custom game, then run RUN_PLUTO_SCR_X86_V38.cmd.
The launcher uses absolute paths and validates every required file before injection.
v38 is a direct-load gate: it proves the original pluto.dll can be loaded in the x86 SC:R process and its exports resolved.
