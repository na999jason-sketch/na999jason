#ifndef NOMINMAX
#define NOMINMAX
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <fstream>
#include <memory>
#include <string>

static HMODULE g_self = nullptr;
using PFNGameInit = void (*)(BWAPI::Game*);
using PFNCreateAI = BWAPI::AIModule* (*)();

static std::string dirOf(HMODULE m) {
  char p[MAX_PATH] = {};
  GetModuleFileNameA(m,p,MAX_PATH);
  std::string s(p);
  auto n=s.find_last_of("\\/");
  return n==std::string::npos ? "." : s.substr(0,n);
}
static void logLine(const std::string& s) {
  std::ofstream f(dirOf(g_self)+"\\plutoscr-x86-v39.log",std::ios::app);
  f << s << "\r\n";
}

static DWORD WINAPI boot(LPVOID) {
  logLine("PLUTOSCR_V39_RESIDENT=LOADED");
  logLine("architecture=x86");
  const std::string d=dirOf(g_self);
  SetDllDirectoryA(d.c_str());

  HMODULE pluto=LoadLibraryA((d+"\\pluto.dll").c_str());
  if(!pluto){ logLine("original_pluto.load=FAIL"); return 1; }
  logLine("original_pluto.load=PASS");

  auto gameInit=reinterpret_cast<PFNGameInit>(GetProcAddress(pluto,"gameInit"));
  auto createAI=reinterpret_cast<PFNCreateAI>(GetProcAddress(pluto,"newAIModule"));
  if(!gameInit || !createAI){ logLine("original_pluto.exports=FAIL"); return 2; }
  logLine("original_pluto.exports=PASS");

  // Exact upstream BWAPI 4.4 GameImpl contract, now in the same x86 SC:R process.
  // Keep GameData zeroed and DO NOT dispatch match callbacks until real SC:R
  // state is bound in the following integration gate.
  auto* data = new BWAPI::GameData();
  ZeroMemory(data,sizeof(BWAPI::GameData));
  auto* game = new BWAPI::GameImpl(data);

  gameInit(game);
  logLine("original_pluto.gameInit=PASS");

  BWAPI::AIModule* module=createAI();
  if(!module){ logLine("original_pluto.newAIModule=FAIL"); return 3; }
  logLine("original_pluto.newAIModule=PASS");
  logLine("PLUTOSCR_V39_INPROCESS_BWAPI_ABI_GATE=PASS");
  logLine("callbacks.dispatched=false");
  logLine("reason=waiting-for-real-scr-gamedata-binding");

  // Intentionally process-lifetime ownership. Prior Pluto ABI probing showed
  // deleting the module across CRT boundaries can corrupt the heap.
  return 0;
}

BOOL APIENTRY DllMain(HMODULE h,DWORD reason,LPVOID) {
  if(reason==DLL_PROCESS_ATTACH){
    g_self=h;
    DisableThreadLibraryCalls(h);
    HANDLE t=CreateThread(nullptr,0,boot,nullptr,0,nullptr);
    if(t) CloseHandle(t);
  }
  return TRUE;
}
