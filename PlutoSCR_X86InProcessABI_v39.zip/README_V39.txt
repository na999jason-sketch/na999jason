PlutoSCR v39: original Pluto + upstream BWAPI 4.4 GameImpl in the same x86 SC:R process. This gate calls gameInit and newAIModule only; no fake match callbacks are dispatched.
