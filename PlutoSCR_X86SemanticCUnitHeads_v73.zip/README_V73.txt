PlutoSCR v73 - x86 semantic CUnit head relocation for original Pluto
Original pluto.dll observation, inference, decision, and command-generation code is unchanged.
This build validates the installed SC:R 1.23.10.13515 x86 image (SizeOfImage 0x10CE000) and verifies its unit-vector pointer against the independently discovered live CUnit vector before using profile RVAs.
It translates the real SC:R visible, hidden, and scanner-sweep list heads into a legacy CUnit compatibility shadow, preserving source prev/next list relationships instead of inventing one combined list.
Legacy BW heads 0x628430, 0x6283EC, and 0x6283F4 are redirected to those three compatibility slots.
SC:R command delivery remains fail-closed until a real synchronized command sink is resolved; v73 never writes guessed game command addresses.
