#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <cstdio>
#include <memory>
#include <cstring>

using PFNGameInit = void (*)(BWAPI::Game*);
using PFNCreateAI = BWAPI::AIModule* (*)();

static FILE* gTrace=nullptr;
static void mark(const char* s) {
  if(gTrace) { std::fprintf(gTrace,"%s\n",s); std::fflush(gTrace); }
  std::fprintf(stderr,"%s\n",s); std::fflush(stderr);
}
static void markCode(const char* s, unsigned long v) {
  if(gTrace) { std::fprintf(gTrace,"%s=0x%08lx\n",s,v); std::fflush(gTrace); }
  std::fprintf(stderr,"%s=0x%08lx\n",s,v); std::fflush(stderr);
}
static DWORD safeGameInit(PFNGameInit fn, BWAPI::Game* game) {
  __try { fn(game); return 0; }
  __except(EXCEPTION_EXECUTE_HANDLER) { return GetExceptionCode(); }
}
static DWORD safeCreateAI(PFNCreateAI fn, BWAPI::AIModule** out) {
  __try { *out=fn(); return 0; }
  __except(EXCEPTION_EXECUTE_HANDLER) { *out=nullptr; return GetExceptionCode(); }
}

int wmain(int argc, wchar_t** argv) {
  gTrace=_wfopen(L"pluto-module-probe-trace.txt",L"wb");
  mark("probe_start");
  if(argc < 2) { mark("missing_argument"); if(gTrace) fclose(gTrace); return 2; }

  mark("before_LoadLibrary");
  SetLastError(0);
  HMODULE h=LoadLibraryW(argv[1]);
  DWORD loadErr=GetLastError();
  if(!h) {
    markCode("LoadLibrary_GetLastError",loadErr);
    mark("PLUTOSCR_PLUTO_LOAD=FAIL");
    if(gTrace) fclose(gTrace);
    return 3;
  }
  mark("after_LoadLibrary");
  mark("PLUTOSCR_PLUTO_LOAD=PASS");

  auto gameInit=reinterpret_cast<PFNGameInit>(GetProcAddress(h,"gameInit"));
  DWORD e1=GetLastError();
  auto createAI=reinterpret_cast<PFNCreateAI>(GetProcAddress(h,"newAIModule"));
  DWORD e2=GetLastError();
  if(!gameInit || !createAI) {
    markCode("gameInit_GetLastError",e1);
    markCode("newAIModule_GetLastError",e2);
    mark("PLUTOSCR_PLUTO_EXPORTS=FAIL");
    FreeLibrary(h); if(gTrace) fclose(gTrace); return 4;
  }
  mark("after_GetProcAddress");
  mark("PLUTOSCR_PLUTO_EXPORTS=PASS");

  auto data=std::make_unique<BWAPI::GameData>();
  std::memset(data.get(),0,sizeof(BWAPI::GameData));
  BWAPI::GameImpl game(data.get());

  mark("before_gameInit");
  DWORD code=safeGameInit(gameInit,&game);
  if(code) {
    markCode("gameInit_SEH",code);
    mark("PLUTOSCR_PLUTO_GAMEINIT=FAIL");
    FreeLibrary(h); if(gTrace) fclose(gTrace); return 5;
  }
  mark("after_gameInit");
  mark("PLUTOSCR_PLUTO_GAMEINIT=PASS");

  BWAPI::AIModule* module=nullptr;
  mark("before_newAIModule");
  code=safeCreateAI(createAI,&module);
  if(code) {
    markCode("newAIModule_SEH",code);
    mark("PLUTOSCR_PLUTO_CREATE_AI=FAIL");
    FreeLibrary(h); if(gTrace) fclose(gTrace); return 6;
  }
  mark("after_newAIModule");
  if(!module) {
    mark("PLUTOSCR_PLUTO_CREATE_AI=FAIL_NULL");
    FreeLibrary(h); if(gTrace) fclose(gTrace); return 7;
  }
  mark("PLUTOSCR_PLUTO_CREATE_AI=PASS");
  mark("PLUTOSCR_ORIGINAL_MODULE_ABI=PASS");

  // Deliberately no fabricated onStart/onFrame.
  delete module;
  mark("after_delete_module");
  FreeLibrary(h);
  mark("after_FreeLibrary");
  mark("probe_complete");
  if(gTrace) fclose(gTrace);
  return 0;
}
