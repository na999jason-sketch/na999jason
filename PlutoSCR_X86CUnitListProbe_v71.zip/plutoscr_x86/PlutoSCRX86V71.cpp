#ifndef NOMINMAX
#define NOMINMAX
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <BWAPI/Client/Client.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

static HMODULE g_self=nullptr;
using PFNGameInit=void(*)(BWAPI::Game*);
using PFNCreateAI=BWAPI::AIModule*(*)();
static std::string dirOf(HMODULE m){char p[MAX_PATH]={};GetModuleFileNameA(m,p,MAX_PATH);std::string s(p);auto n=s.find_last_of("\\/");return n==std::string::npos?".":s.substr(0,n);}
static void logLine(const std::string&s){std::ofstream f(dirOf(g_self)+"\\plutoscr-x86-v71.log",std::ios::app);f<<s<<"\r\n";}
static volatile DWORD g_sehCode=0;static volatile uintptr_t g_sehAddress=0;static volatile uintptr_t g_sehEip=0;
static volatile uintptr_t g_sehAccessAddress=0;static volatile ULONG_PTR g_sehAccessType=~(ULONG_PTR)0;
static int captureSeh(EXCEPTION_POINTERS*ep){if(ep&&ep->ExceptionRecord){g_sehCode=ep->ExceptionRecord->ExceptionCode;g_sehAddress=(uintptr_t)ep->ExceptionRecord->ExceptionAddress;
if(ep->ExceptionRecord->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && ep->ExceptionRecord->NumberParameters>=2){g_sehAccessType=ep->ExceptionRecord->ExceptionInformation[0];g_sehAccessAddress=(uintptr_t)ep->ExceptionRecord->ExceptionInformation[1];}}
#if defined(_M_IX86)
if(ep&&ep->ContextRecord)g_sehEip=(uintptr_t)ep->ContextRecord->Eip;
#endif
return EXCEPTION_EXECUTE_HANDLER;}
static DWORD onStartSeh(BWAPI::AIModule*m){g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;__try{m->onStart();return 0;}__except(captureSeh(GetExceptionInformation())){return g_sehCode;}}
static DWORD onFrameSeh(BWAPI::AIModule*m){
  g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;
  __try{m->onFrame();return 0;}
  __except(captureSeh(GetExceptionInformation())){return g_sehCode;}
}

#pragma pack(push,1)
struct LegacyCUnit336{ unsigned char b[336]; };
#pragma pack(pop)
static_assert(sizeof(LegacyCUnit336)==336,"CUnit size");

template<class T> static T rd(const unsigned char*p,size_t o){T v{};std::memcpy(&v,p+o,sizeof(v));return v;}
static bool readable(const void*p,size_t n){
  MEMORY_BASIC_INFORMATION mi{}; if(!VirtualQuery(p,&mi,sizeof(mi)))return false;
  if(mi.State!=MEM_COMMIT || (mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
  uintptr_t a=(uintptr_t)p; uintptr_t e=a+(uintptr_t)n; uintptr_t r=(uintptr_t)mi.BaseAddress+(uintptr_t)mi.RegionSize; return e>=a && e<=r;
}
static bool plausibleUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  auto hp=rd<int32_t>(p,0x08); auto spr=rd<uint32_t>(p,0x0c); auto x=rd<int16_t>(p,0x28); auto y=rd<int16_t>(p,0x2a);
  auto player=rd<uint8_t>(p,0x4c); auto order=rd<uint8_t>(p,0x4d); auto type=rd<uint16_t>(p,0x64);
  return spr!=0 && hp>0 && hp<(5000000*256) && x>=0&&x<=16384&&y>=0&&y<=16384&&player<12&&order<256&&type<234;
}
struct UnitStore{uintptr_t descriptor=0,begin=0,end=0,cap=0;int score=0;};
static UnitStore scanDescriptorRange(uintptr_t s,uintptr_t e,const char*tag){
  UnitStore best{}; MEMORY_BASIC_INFORMATION mi{}; uintptr_t a=s; unsigned long regions=0; unsigned long descriptors=0;
  logLine(std::string("checkpoint.scan_range.begin=")+tag);
  while(a<e && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;
    if(re<=a)break;
    uintptr_t lo=std::max(a,rs),hi=std::min(e,re);
    bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) &&
      (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && hi>lo && hi-lo>=12){
      ++regions;
      for(uintptr_t q=(lo+3)&~uintptr_t(3);q+12<=hi;q+=4){
        uint32_t b=0,en=0,c=0;
        std::memcpy(&b,(void*)q,4);std::memcpy(&en,(void*)(q+4),4);std::memcpy(&c,(void*)(q+8),4);
        if(!b||en<b||c<en)continue;uint32_t used=en-b,cap=c-b;
        if(used==0||used%336||cap%336)continue;uint32_t count=used/336,capacity=cap/336;
        if(count<2||count>3400||capacity<count||capacity>3400)continue;
        if(!readable((void*)(uintptr_t)b,std::min<uint32_t>(used,336*64)))continue;
        ++descriptors;int score=0;uint32_t step=std::max<uint32_t>(1,count/64);
        for(uint32_t i=0;i<count&&i<3400;i+=step)if(plausibleUnit((unsigned char*)(uintptr_t)(b+i*336)))++score;
        if(score>best.score){best={q,b,en,c,score};}
      }
    }
    a=re;
  }
  logLine(std::string("checkpoint.scan_range.end=")+tag+" regions="+std::to_string(regions)+" descriptors="+std::to_string(descriptors)+" best_score="+std::to_string(best.score));
  return best;
}
static UnitStore findLegacyCUnitVector(){
  logLine("checkpoint.cunit_scan.enter");
  HMODULE exe=GetModuleHandleA(nullptr);
  if(exe){
    auto base=(uintptr_t)exe;auto dos=(IMAGE_DOS_HEADER*)base;
    if(readable(dos,sizeof(*dos))&&dos->e_magic==IMAGE_DOS_SIGNATURE){
      auto nt=(IMAGE_NT_HEADERS*)(base+dos->e_lfanew);
      if(readable(nt,sizeof(*nt))&&nt->Signature==IMAGE_NT_SIGNATURE){
        uintptr_t end=base+(uintptr_t)nt->OptionalHeader.SizeOfImage;
        logLine("checkpoint.cunit_scan.module_base="+std::to_string((unsigned long)base));
        logLine("checkpoint.cunit_scan.module_size="+std::to_string((unsigned long)nt->OptionalHeader.SizeOfImage));
        UnitStore m=scanDescriptorRange(base,end,"main_module");
        if(m.score>=2){logLine("checkpoint.cunit_scan.module_hit");return m;}
      }
    }
  }
  logLine("checkpoint.cunit_scan.fallback_begin");
  SYSTEM_INFO si{};GetSystemInfo(&si);
  UnitStore f=scanDescriptorRange((uintptr_t)si.lpMinimumApplicationAddress,(uintptr_t)si.lpMaximumApplicationAddress,"process");
  logLine("checkpoint.cunit_scan.fallback_end");
  return f;
}

static uintptr_t g_scrFirstUnitHead=0;

static bool inUnitStore(const UnitStore&s,uintptr_t p){
  return p>=s.begin && p+336<=s.end && ((p-s.begin)%336)==0;
}
static uintptr_t findBestCUnitLinkedHead(const UnitStore&s,int*outLen){
  uintptr_t best=0;int bestLen=0;
  if(!s.begin||s.end<=s.begin)return 0;
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  for(uint32_t i=0;i<count;i++){
    uintptr_t p=s.begin+(uintptr_t)i*336;
    if(!plausibleUnit((unsigned char*)p))continue;
    uintptr_t prev=(uintptr_t)rd<uint32_t>((unsigned char*)p,0x00);
    if(prev && inUnitStore(s,prev))continue;
    uintptr_t cur=p;int n=0;
    while(cur && inUnitStore(s,cur) && n<(int)count){
      if(!plausibleUnit((unsigned char*)cur))break;
      ++n;
      uintptr_t next=(uintptr_t)rd<uint32_t>((unsigned char*)cur,0x04);
      if(!next)break;
      if(!inUnitStore(s,next))break;
      cur=next;
    }
    if(n>bestLen){bestLen=n;best=p;}
  }
  if(outLen)*outLen=bestLen;
  return best;
}


static void logCUnitChainInventory(const UnitStore&s){
  if(!s.begin||s.end<=s.begin){logLine("cunit_lists.inventory=NO_STORE");return;}
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  int heads=0;
  for(uint32_t i=0;i<count;i++){
    uintptr_t p=s.begin+(uintptr_t)i*336;
    if(!plausibleUnit((unsigned char*)p))continue;
    uintptr_t prev=(uintptr_t)rd<uint32_t>((unsigned char*)p,0x00);
    if(prev && inUnitStore(s,prev))continue;
    uintptr_t cur=p;int n=0,scanner=0;
    int owners[12]={0};
    while(cur && inUnitStore(s,cur) && n<(int)count){
      unsigned char*u=(unsigned char*)cur;
      if(!plausibleUnit(u))break;
      int type=(int)rd<uint16_t>(u,0x64);
      int owner=(int)rd<uint8_t>(u,0x4c);
      if(type==33)++scanner;
      if(owner>=0&&owner<12)++owners[owner];
      ++n;
      uintptr_t next=(uintptr_t)rd<uint32_t>(u,0x04);
      if(!next||!inUnitStore(s,next))break;
      cur=next;
    }
    if(n<=0)continue;
    ++heads;
    std::string own;
    for(int o=0;o<12;o++)if(owners[o]){
      if(!own.empty())own+=",";
      own+=std::to_string(o)+":"+std::to_string(owners[o]);
    }
    logLine("cunit_lists.head["+std::to_string(heads-1)+"].address="+std::to_string((unsigned long)p)+
            " len="+std::to_string(n)+" scanner33="+std::to_string(scanner)+" owners="+own);
  }
  logLine("cunit_lists.head_count="+std::to_string(heads));
}

static int inferRace(int type){if(type<=59||(type>=106&&type<=131))return 1;if((type>=88&&type<=103)||(type>=132&&type<=157))return 0;if((type>=60&&type<=87)||type==97||(type>=159&&type<=173))return 2;return 5;}
static int projectLiveUnits(const UnitStore&s,BWAPI::GameData&d){
  if(!s.begin||s.end<s.begin)return 0; int out=0; std::array<int,12> counts{}; std::array<int,12> race{}; race.fill(5);
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  for(uint32_t i=0;i<count && out<10000;i++){
    auto*p=(unsigned char*)(s.begin+i*336); if(!plausibleUnit(p))continue;
    auto&q=d.units[out]; ZeroMemory(&q,sizeof(q)); q.id=out;q.player=rd<uint8_t>(p,0x4c);q.type=rd<uint16_t>(p,0x64);q.positionX=rd<int16_t>(p,0x28);q.positionY=rd<int16_t>(p,0x2a);
    q.hitPoints=std::max(0,rd<int32_t>(p,0x08)/256);q.shields=rd<uint32_t>(p,0x60)/256;q.energy=rd<uint16_t>(p,0xa2)/256;q.order=rd<uint8_t>(p,0x4d);
    q.targetPositionX=rd<int16_t>(p,0x58);q.targetPositionY=rd<int16_t>(p,0x5a);q.orderTargetPositionX=q.targetPositionX;q.orderTargetPositionY=q.targetPositionY;
    q.exists=true;auto flags=rd<uint32_t>(p,0xdc);q.isCompleted=(flags&1)!=0;q.isCloaked=(flags&0x200)!=0;q.isBurrowed=(flags&0x10)!=0;q.isInvincible=(flags&0x04000000)!=0;
    if(q.player>=0&&q.player<12){counts[q.player]++;race[q.player]=inferRace(q.type);} for(bool&v:q.isVisible)v=true; ++out;
  }
  d.initialUnitCount=out;d.playerCount=0;
  for(int p=0;p<12;p++)if(counts[p]){d.playerCount=std::max(d.playerCount,p+1);d.players[p].race=race[p];d.players[p].isParticipating=true;d.players[p].type=1;d.players[p].isAlly[p]=true;}
  return out;
}



#pragma pack(push,1)
struct Legacy57F1Compat {
  unsigned char pad0[0x1D4];
  short value_f1d4;
  short value_f1d6;
  unsigned char pad1[0x64];
  unsigned long value_f23c;
};
#pragma pack(pop)
static Legacy57F1Compat g_legacy57f1{};

static bool patchAbs32(unsigned char* insn,int immOff,const unsigned char* sig,int sigLen,uintptr_t target,const char* tag){
  if(memcmp(insn,sig,sigLen)!=0){logLine(std::string("reloc69.")+tag+".signature=MISMATCH");return false;}
  if(target>0xFFFFFFFFu){logLine(std::string("reloc69.")+tag+".target=OUT_OF_X86_RANGE");return false;}
  DWORD old=0;if(!VirtualProtect(insn,sigLen,PAGE_EXECUTE_READWRITE,&old)){logLine(std::string("reloc69.")+tag+".protect=FAIL");return false;}
  uint32_t v=(uint32_t)target;memcpy(insn+immOff,&v,4);FlushInstructionCache(GetCurrentProcess(),insn,sigLen);
  DWORD tmp=0;VirtualProtect(insn,sigLen,old,&tmp);
  logLine(std::string("reloc69.")+tag+"=PASS");return true;
}
static bool patchPlutoLegacy57F1Block(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char s1[5]={0xA1,0x3C,0xF2,0x57,0x00};
  const unsigned char s2[7]={0x0F,0xBF,0x05,0xD4,0xF1,0x57,0x00};
  const unsigned char s3[7]={0x0F,0xBF,0x15,0xD6,0xF1,0x57,0x00};
  bool a=patchAbs32(b+0xBC1B,1,s1,5,(uintptr_t)&g_legacy57f1.value_f23c,"rva_bc1b_f23c");
  bool c=patchAbs32(b+0xBC26,3,s2,7,(uintptr_t)&g_legacy57f1.value_f1d4,"rva_bc26_f1d4");
  bool d=patchAbs32(b+0xBC33,3,s3,7,(uintptr_t)&g_legacy57f1.value_f1d6,"rva_bc33_f1d6");
  return a&&c&&d;
}

static bool patchPlutoCUnitHead628430(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x1D,0x30,0x84,0x62,0x00};
  return patchAbs32(b+0x33F7D,2,sig,6,(uintptr_t)&g_scrFirstUnitHead,"rva_33f7d_628430");
}

static unsigned char g_reloc57fd3c[0x10000]{};

static bool patchPlutoLegacy57FD3C(HMODULE pluto){
  unsigned char* p=(unsigned char*)pluto+0x7536;
  const unsigned char expect[7]={0x0F,0xB6,0x90,0x3C,0xFD,0x57,0x00};
  if(memcmp(p,expect,7)!=0){
    logLine("reloc_probe.rva_7536_signature=MISMATCH");
    return false;
  }
  // Preserve the exact instruction shape; change only its disp32.
  // movzx edx, byte ptr [eax + disp32]
  uintptr_t compat=(uintptr_t)g_reloc57fd3c;
  if(compat>0xFFFFFFFFu){
    logLine("reloc_probe.compat_ptr=OUT_OF_X86_RANGE");
    return false;
  }
  unsigned char repl[7]={0x0F,0xB6,0x90,0,0,0,0};
  uint32_t disp=(uint32_t)compat;
  memcpy(repl+3,&disp,4);
  DWORD old=0;
  if(!VirtualProtect(p,7,PAGE_EXECUTE_READWRITE,&old)){
    logLine("reloc_probe.virtualprotect=FAIL gle="+std::to_string(GetLastError()));
    return false;
  }
  memcpy(p,repl,7);
  FlushInstructionCache(GetCurrentProcess(),p,7);
  DWORD tmp=0;VirtualProtect(p,7,old,&tmp);
  logLine("reloc_probe.rva_7536_signature=PASS");
  logLine("reloc_probe.rva_7536_patched=PASS");
  logLine("reloc_probe.compat_base="+std::to_string((unsigned long)compat));
  return true;
}

static int mapLegacyPlutoDataPages(){
  // MEM_RESERVE base addresses must honor Windows allocation granularity (normally 64 KiB).
  // These four 64 KiB blocks cover every legacy absolute data page currently observed in Pluto.
  const uintptr_t blocks[]={0x00510000,0x00570000,0x00580000,0x00590000};
  int mapped=0;
  SYSTEM_INFO si{};GetSystemInfo(&si);
  logLine("legacy_probe.allocation_granularity="+std::to_string((unsigned long)si.dwAllocationGranularity));
  for(uintptr_t a:blocks){
    MEMORY_BASIC_INFORMATION mbi{};
    if(!VirtualQuery((LPCVOID)a,&mbi,sizeof(mbi))){
      logLine("legacy_probe.virtualquery_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(GetLastError()));
      continue;
    }
    if(mbi.State==MEM_FREE){
      void*p=VirtualAlloc((LPVOID)a,0x10000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
      if(p==(void*)a){
        ++mapped;
        logLine("legacy_probe.mapped_block="+std::to_string((unsigned long)a));
      }else{
        DWORD gle=GetLastError();
        logLine("legacy_probe.map_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(gle));
        if(p)VirtualFree(p,0,MEM_RELEASE);
      }
    }else{
      logLine("legacy_probe.block_occupied="+std::to_string((unsigned long)a)+
              " state="+std::to_string((unsigned long)mbi.State)+
              " base="+std::to_string((unsigned long)(uintptr_t)mbi.BaseAddress)+
              " size="+std::to_string((unsigned long)mbi.RegionSize));
    }
  }
  return mapped;
}

static DWORD findLegacyCUnitVectorSeh(UnitStore*out){__try{*out=findLegacyCUnitVector();return 0;}__except(EXCEPTION_EXECUTE_HANDLER){return GetExceptionCode();}}
static DWORD WINAPI boot(LPVOID){
  DeleteFileA((dirOf(g_self)+"\\plutoscr-x86-v71.log").c_str());
  logLine("PLUTOSCR_V71_RESIDENT=LOADED");logLine("architecture=x86");logLine("policy=original-pluto-observation-untouched");
  logLine("checkpoint.boot.before_cunit_scan");
  UnitStore store{};
  DWORD scanEc=findLegacyCUnitVectorSeh(&store);
  if(scanEc){logLine("checkpoint.cunit_scan.SEH_EXCEPTION code="+std::to_string(scanEc));return 12;}
  logLine("checkpoint.boot.after_cunit_scan");
  logLine("scr_cunit_vector.descriptor="+std::to_string((unsigned long)store.descriptor));logLine("scr_cunit_vector.score="+std::to_string(store.score));
  if(store.score<2){logLine("scr_cunit_vector=UNRESOLVED");return 10;} logLine("scr_cunit_vector=BOUND");
  const std::string d=dirOf(g_self);SetDllDirectoryA(d.c_str());HMODULE pluto=LoadLibraryA((d+"\\pluto.dll").c_str());if(!pluto){logLine("original_pluto.load=FAIL");return 1;}logLine("original_pluto.load=PASS");
  auto gameInit=(PFNGameInit)GetProcAddress(pluto,"gameInit");auto createAI=(PFNCreateAI)GetProcAddress(pluto,"newAIModule");if(!gameInit||!createAI){logLine("original_pluto.exports=FAIL");return 2;}
  auto*data=new BWAPI::GameData();ZeroMemory(data,sizeof(*data));int n=projectLiveUnits(store,*data);logLine("live_units="+std::to_string(n));if(n<2)return 11;
  // Choose the first participating slot only as a compatibility bootstrap; do not fabricate Pluto observations.
  int self=-1,enemy=-1;for(int p=0;p<12;p++)if(data->players[p].isParticipating){if(self<0)self=p;else if(enemy<0)enemy=p;}data->self=self;data->enemy=enemy;data->neutral=11;data->isInGame=true;
  logLine("gamedata.initialUnitCount="+std::to_string(data->initialUnitCount));
  logLine("gamedata.playerCount="+std::to_string(data->playerCount));
  logLine("gamedata.self="+std::to_string(self)+" enemy="+std::to_string(enemy)+" neutral="+std::to_string(data->neutral));
  for(int p=0;p<12;p++)if(data->players[p].isParticipating){int pc=0;for(int u=0;u<data->initialUnitCount;u++)if(data->units[u].player==p)++pc;logLine("gamedata.player["+std::to_string(p)+"].units="+std::to_string(pc)+" race="+std::to_string(data->players[p].race));}
  logLine("gamedata.mapWidth="+std::to_string(data->mapWidth)+" mapHeight="+std::to_string(data->mapHeight));
  BWAPI::BWAPIClient.data=data;auto*game=new BWAPI::GameImpl(data);BWAPI::BroodwarPtr=game;logLine("checkpoint.gameimpl.constructed");
  gameInit(game);logLine("checkpoint.original_pluto.gameInit.PASS");auto*module=createAI();if(!module){logLine("original_pluto.newAIModule=FAIL");return 3;}logLine("checkpoint.original_pluto.newAIModule.PASS");
  game->onMatchStart();logLine("checkpoint.bwapi.onMatchStart.PASS");
  logLine("reloc_probe.mode=pluto-code-relocation-diagnostic-no-command-sink");
  bool reloc7536=patchPlutoLegacy57FD3C(pluto);
  logLine(std::string("reloc_probe.patch_7536=")+(reloc7536?"PASS":"FAIL"));
  if(!reloc7536)return 13;
  bool reloc57f1=patchPlutoLegacy57F1Block(pluto);
  logLine(std::string("reloc70.patch_57f1_block=")+(reloc57f1?"PASS":"FAIL"));
  if(!reloc57f1)return 14;
  logLine("cunit_lists.legacy_visible=0x628430 hidden=0x6283EC scanner=0x6283F4");
  logCUnitChainInventory(store);
  int headLen=0;g_scrFirstUnitHead=findBestCUnitLinkedHead(store,&headLen);
  logLine("cunit_head.address="+std::to_string((unsigned long)g_scrFirstUnitHead));
  logLine("cunit_head.chain_length="+std::to_string(headLen));
  if(!g_scrFirstUnitHead || headLen<2){logLine("cunit_head=UNRESOLVED");return 15;}
  bool reloc628430=patchPlutoCUnitHead628430(pluto);
  logLine(std::string("reloc70.patch_628430=")+(reloc628430?"PASS":"FAIL"));
  if(!reloc628430)return 16;
  DWORD ec=onStartSeh(module);if(ec){
    logLine("original_pluto.onStart=SEH_EXCEPTION code="+std::to_string(ec));
    logLine("seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
    logLine("seh.eip="+std::to_string((unsigned long)g_sehEip));
    uintptr_t pb=(uintptr_t)pluto;
    if(g_sehAddress>=pb)logLine("seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
    if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)logLine("seh.class=legacy_bw_absolute_address");
    else if(g_sehAddress>=pb)logLine("seh.class=pluto_code");
    else logLine("seh.class=other");
    return 4;
  }logLine("original_pluto.onStart=PASS");
  logLine("reloc_probe.onStart_after_rva7536_patch=PASS");
  logLine("cunit_lists.next_unresolved=legacy_hidden_0x6283EC");
  logLine("PLUTOSCR_V71_LIVE_CUNIT_PLUTO_LOOP=START");int lastCmd=0;
  while(true){Sleep(42);int live=projectLiveUnits(store,*data);if(live<2){logLine("live_units_lost");break;}++data->frameCount;game->onMatchFrame();ec=onFrameSeh(module);if(ec){
      logLine("original_pluto.onFrame=SEH_EXCEPTION code="+std::to_string(ec));
      logLine("onframe.seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
      logLine("onframe.seh.eip="+std::to_string((unsigned long)g_sehEip));
      logLine("onframe.seh.access_type="+std::to_string((unsigned long)g_sehAccessType));
      logLine("onframe.seh.access_address="+std::to_string((unsigned long)g_sehAccessAddress));
      uintptr_t pb=(uintptr_t)pluto;
      if(g_sehAddress>=pb)
        logLine("onframe.seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
      if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)
        logLine("onframe.seh.class=legacy_bw_absolute_address");
      else if(g_sehAddress>=pb)
        logLine("onframe.seh.class=pluto_code");
      else
        logLine("onframe.seh.class=other");
      break;
    }
    if(data->unitCommandCount!=lastCmd){logLine("pluto_bwapi_unit_commands="+std::to_string(data->unitCommandCount));lastCmd=data->unitCommandCount;}
    if(data->unitCommandCount>0){logLine("scr_command_sink=UNRESOLVED_FAIL_CLOSED");data->unitCommandCount=0;lastCmd=0;}
  }
  return 0;
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){if(r==DLL_PROCESS_ATTACH){g_self=h;DisableThreadLibraryCalls(h);HANDLE t=CreateThread(nullptr,0,boot,nullptr,0,nullptr);if(t)CloseHandle(t);}return TRUE;}
