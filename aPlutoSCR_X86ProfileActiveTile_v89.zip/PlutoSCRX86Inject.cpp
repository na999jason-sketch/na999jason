
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <string>

static DWORD findSC() {
  PROCESSENTRY32 pe={sizeof(pe)};
  HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
  if(s==INVALID_HANDLE_VALUE) return 0;
  DWORD pid=0;
  if(Process32First(s,&pe)) do {
    if(_stricmp(pe.szExeFile,"StarCraft.exe")==0) { pid=pe.th32ProcessID; break; }
  } while(Process32Next(s,&pe));
  CloseHandle(s); return pid;
}
int main(int argc,char**argv) {
  std::string dll = argc>1 ? argv[1] : "PlutoSCRX86V89.dll";
  char full[MAX_PATH]={}; GetFullPathNameA(dll.c_str(),MAX_PATH,full,nullptr);
  DWORD pid=findSC();
  if(!pid){ std::cerr<<"StarCraft.exe not found\n"; return 2; }
  HANDLE p=OpenProcess(PROCESS_CREATE_THREAD|PROCESS_QUERY_INFORMATION|PROCESS_VM_OPERATION|PROCESS_VM_WRITE|PROCESS_VM_READ,FALSE,pid);
  if(!p){ std::cerr<<"OpenProcess failed "<<GetLastError()<<"\n"; return 3; }
  SIZE_T n=strlen(full)+1;
  void* r=VirtualAllocEx(p,nullptr,n,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
  if(!r || !WriteProcessMemory(p,r,full,n,nullptr)){ std::cerr<<"remote write failed\n"; return 4; }
  auto load=(LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleA("kernel32.dll"),"LoadLibraryA");
  HANDLE t=CreateRemoteThread(p,nullptr,0,load,r,0,nullptr);
  if(!t){ std::cerr<<"CreateRemoteThread failed "<<GetLastError()<<"\n"; return 5; }
  WaitForSingleObject(t,10000);
  DWORD ec=0; GetExitCodeThread(t,&ec);
  CloseHandle(t); VirtualFreeEx(p,r,0,MEM_RELEASE); CloseHandle(p);
  std::cout<<"PLUTOSCR_V89_X86_INJECT="<<(ec?"PASS":"FAIL")<<" pid="<<pid<<"\n";
  return ec?0:6;
}
