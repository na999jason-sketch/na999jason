#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <cstdio>
#include <memory>
#include <cstring>

using PFNGameInit = void (*)(BWAPI::Game*);
using PFNCreateAI = BWAPI::AIModule* (*)();

// Keep SEH in leaf functions with no C++ objects requiring unwinding.
static DWORD safeGameInit(PFNGameInit fn, BWAPI::Game* game) {
  __try { fn(game); return 0; }
  __except(EXCEPTION_EXECUTE_HANDLER) { return GetExceptionCode(); }
}
static DWORD safeCreateAI(PFNCreateAI fn, BWAPI::AIModule** out) {
  __try { *out=fn(); return 0; }
  __except(EXCEPTION_EXECUTE_HANDLER) { *out=nullptr; return GetExceptionCode(); }
}

int wmain(int argc, wchar_t** argv) {
  if(argc < 2) { std::fwprintf(stderr,L"usage: PlutoModuleProbe.exe pluto.dll\n"); return 2; }

  HMODULE h=LoadLibraryW(argv[1]);
  if(!h) { std::printf("PLUTOSCR_PLUTO_LOAD=FAIL error=%lu\n",GetLastError()); return 3; }

  auto gameInit=reinterpret_cast<PFNGameInit>(GetProcAddress(h,"gameInit"));
  auto createAI=reinterpret_cast<PFNCreateAI>(GetProcAddress(h,"newAIModule"));
  if(!gameInit || !createAI) {
    std::printf("PLUTOSCR_PLUTO_EXPORTS=FAIL gameInit=%p newAIModule=%p\n",(void*)gameInit,(void*)createAI);
    FreeLibrary(h); return 4;
  }
  std::printf("PLUTOSCR_PLUTO_LOAD=PASS\n");
  std::printf("PLUTOSCR_PLUTO_EXPORTS=PASS\n");

  auto data=std::make_unique<BWAPI::GameData>();
  std::memset(data.get(),0,sizeof(BWAPI::GameData));
  BWAPI::GameImpl game(data.get());

  DWORD code=safeGameInit(gameInit,&game);
  if(code) {
    std::printf("PLUTOSCR_PLUTO_GAMEINIT=FAIL seh=0x%08lx\n",code);
    FreeLibrary(h); return 5;
  }
  std::printf("PLUTOSCR_PLUTO_GAMEINIT=PASS\n");

  BWAPI::AIModule* module=nullptr;
  code=safeCreateAI(createAI,&module);
  if(code) {
    std::printf("PLUTOSCR_PLUTO_CREATE_AI=FAIL seh=0x%08lx\n",code);
    FreeLibrary(h); return 6;
  }
  if(!module) {
    std::printf("PLUTOSCR_PLUTO_CREATE_AI=FAIL null\n");
    FreeLibrary(h); return 7;
  }

  std::printf("PLUTOSCR_PLUTO_CREATE_AI=PASS\n");
  std::printf("PLUTOSCR_ORIGINAL_MODULE_ABI=PASS\n");

  // Do not call onStart/onFrame with fabricated game state.
  delete module;
  FreeLibrary(h);
  return 0;
}
