aPlutoSCR v85 x86 Legacy Start Globals + Stable CUnit + ActiveTile

Purpose
- Port the original Pluto binary to 32-bit StarCraft: Remastered without replacing Pluto observation, inference, decision, or action generation.
- SC:R real state -> compatibility/legacy view -> original Pluto observation -> original Pluto inference/decision -> original Pluto command output.

v85 changes
- Keeps the verified v84 SC:R 1.23.10.13515 x86 profile CUnit pool, 1700 stable legacy slots, real SCR Game shadow, real ActiveTileArray bridge, and bullet shadow.
- Reads the actual SC:R local player id from the verified profile slot (analyzed VA 0x00FCACF4).
- Relocates Pluto onStart's legacy BW local-player read at 0x512688 to that real SCR local-player value.
- Relocates the 14 legacy selection/control-group cells at 0x5124D8..0x51250C to a private ABI shadow so Pluto's original onStart writes are preserved without touching unrelated SCR memory.
- Sets BWAPI GameData.self from the real SCR local-player id instead of choosing the first participating slot.
- Keeps fail-closed validation: every patched operand must still contain the expected original Pluto address.
- Adds detailed onStart SEH access/register/code logging for the next unresolved legacy reference.
- Existing pluto_infer.exe processes are rejected fail-closed before onStart.
- Command sink remains disabled until the real Pluto-generated command path is verified.

Original Pluto runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Expected v85 log milestones
  profile_cunit=BOUND_VALIDATED
  reloc85.game_operands=PASS
  active_tile=BOUND_REAL_SCR
  legacy_start.local_player=<actual SCR slot>
  reloc85.rva_14bf_512688=PASS
  reloc85.start_globals=PASS
  legacy_start_globals=BOUND_REAL_LOCAL_PLAYER
  original_pluto.onStart=PASS   (or a new, later legacy reference with detailed SEH data)

The original Pluto model/files are not included and are not modified.
