aPlutoSCR v86 x86 Profile Bullet + Legacy Start Globals + Stable CUnit + ActiveTile

Purpose
- Port the original Pluto binary to 32-bit StarCraft: Remastered without replacing Pluto observation, inference, decision, or action generation.
- SC:R real state -> compatibility/legacy view -> original Pluto observation -> original Pluto inference/decision -> original Pluto command output.

v86 changes
- Replaces the old process-wide bullet scanner with the verified SC:R 1.23.10.13515 x86 profile bullet head at analyzed VA 0x01034A78.
- Traverses the real SCR bullet linked list through next(+4), validates every 112-byte node, and fails closed on cycles, unreadable nodes, or impossible list length.
- Converts each real SCR bullet to the legacy 112-byte BW CBullet view used by original Pluto.
- Converts bullet prev/next links, source/target CUnit pointers, and bullet sprites to the existing stable legacy CUnit/sprite view.
- Refreshes the bullet shadow every frame before original Pluto onFrame, so newly created bullets and psionic storms are observed dynamically.
- Keeps v85 real local-player bridge, 1700 stable CUnit slots, real SCR Game shadow, and real ActiveTileArray bridge.
- Original Pluto observation/inference/decision/action generation remains untouched.
- Command sink remains disabled until original Pluto command generation is verified.

Original Pluto runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Expected v86 log milestones
  profile_cunit=BOUND_VALIDATED
  reloc86.game_operands=PASS
  active_tile=BOUND_REAL_SCR
  profile_bullet.head_slot=<SCR slot>
  profile_bullet.raw_head=<0 or real pointer>
  profile_bullet=BOUND_VALIDATED
  reloc86.patch_64dec4=PASS
  reloc86.start_globals=PASS
  legacy_start_globals=BOUND_REAL_LOCAL_PLAYER
  original_pluto.onStart=PASS (or a new later verified legacy reference)

The original Pluto model/files are not included and are not modified.
