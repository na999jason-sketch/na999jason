aPlutoSCR v80 x86 - Original Pluto Runtime Layout

Goal
----
Port the unmodified original Pluto observation / inference / decision / command path to StarCraft: Remastered x86.
This package is only a compatibility / ABI / runtime-path bridge. It does NOT implement or replace Pluto AI logic.

What v79 proved
---------------
- Live SC:R CUnit vector selected globally: 114 units.
- Real CUnit prev/next chain recovered.
- Visible / hidden / scanner heads relocated.
- UnitNodeTable arithmetic relocated to the 336-byte compatibility shadow.
- Bullet / psionic-storm head relocated.
- Original Pluto onFrame() returned normally for three consecutive frames with SEH=0.

v80 change
----------
The v79 diagnostic showed pluto_infer.exe and pluto_weights.bin size 0 and no pluto_infer.exe process.
The runner had been checking for flat files beside pluto.dll, while original Pluto expects the standard distribution layout:

  pluto.dll
  pluto\
    pluto_infer.exe
    pluto_weights.bin

v80 preserves the original files unchanged. If the two original inference files are supplied flat beside this CMD, the runner copies them into the required pluto\ subdirectory. The resident DLL also verifies the same layout before loading Pluto and refuses to continue if the originals are missing.

v80 also uses Unicode Windows path APIs for runtime discovery/logging so Korean/non-ASCII Windows user paths do not break the bridge's own file checks.

Required original files
-----------------------
Use the UNMODIFIED original Pluto CoG 2026 distribution files:
- pluto.dll
- pluto_infer.exe
- pluto_weights.bin

Do not rename or replace their contents.

Expected v80 log milestones
---------------------------
pluto_runtime.layout=STANDARD
or
pluto_runtime.layout=FLAT_TO_STANDARD
pluto_runtime.ready=YES
pluto_infer.file_size=<nonzero>
pluto_weights.file_size=<nonzero>
original_pluto.onStart=PASS
frame[1].after_pluto_onFrame seh=0
pluto_infer.process_count.after_onStart or after_onFrame >= 1

Command delivery to SC:R remains disabled in this diagnostic stage. Pluto still owns observation, inference, decision and command generation.
