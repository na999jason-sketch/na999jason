aPlutoSCR v96 x86 — Multi-Match Robust Bootstrap + Shared Logging

기준
- v94의 실제 SC:R 상태 관측 + 실제 visibility + 검증된 command translation/send 경로를 그대로 유지한다.
- 원본 Pluto가 관측/추론/판단/legacy command 생성을 담당한다.
- v96는 매치 생명주기와 로그 I/O만 안정화한다.

V96 변경
1. 다판 lifecycle
   - SC:R 1.23.10.13515 x86의 game-loop active 상태를 보되, 시작 직후 순간적인 0을 종료로 오인하지 않도록 연속 inactive를 debounce한다.
   - 종료 즉시 command sink를 disarm하고 pending turn을 폐기한다.
   - original Pluto onEnd(won) -> BWAPI GameImpl onMatchEnd 순서로 종료한다.
   - 다음 경기에서는 실제 game/local-player/CUnit/Game block이 다시 유효해질 때까지 기다린다.
   - 새 GameData/GameImpl/AIModule을 만들고 gameInit -> onMatchStart -> original Pluto onStart를 다시 수행한다.
   - Pluto binary는 다시 패치하지 않는다. 이미 패치한 대상은 고정 shadow/global cell이며, 각 매치마다 내용만 갱신한다.
   - legacy CUnit 1700-slot 배열은 재할당하지 않아 UnitNodeTable patched base가 2판째에도 유지된다.

2. 매치 간 상태 reset
   - pending commands, command staging buffer, flush capture, handle lookup, bullet shadow, local-player start globals를 초기화한다.
   - stable unit handle generation은 새 매치에서 다시 시작한다.
   - command-send failure state와 per-match submitted counter를 reset한다.
   - pluto_infer.exe는 새 onStart 후 정확히 1개인지 확인하고, 2초 동안 안정화 후 1개가 아니면 fail-closed한다.

3. robust bootstrap + 탐색기/로그 안정화
   - v95의 CRT FILE 기반 persistent logger를 제거했다.
   - Win32 CreateFileW/WriteFile 기반의 공유 가능한 로그 HANDLE을 하나 유지한다.
   - FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE로 Explorer/인덱서와의 파일 잠금 충돌을 줄인다.
   - FAIL/SEH/MATCH/RESIDENT/BOOTSTRAP 로그와 64줄 단위만 FlushFileBuffers한다.
   - command hex/packet 상세 로그는 처음 12회 + 이후 32회마다 샘플링한다.
   - injector 자체도 plutoscr-x86-v96-inject.log를 남기고, DLL runtime log 생성 여부를 1.5초 후 확인한다.
   - launcher도 plutoscr-x86-v96-launch.log를 남겨 DLL이 뜨기 전 실패까지 추적 가능하다.

첫 실행
- StarCraft.exe와 pluto_infer.exe를 모두 종료한 상태에서 시작한다.
- SC:R 32-bit를 켜고 첫 로컬/커스텀 게임에 들어간 뒤 v96를 한 번만 주입한다.

다판 테스트
1) 첫 게임에서 이동/건설 확인
2) 게임 정상 종료
3) StarCraft.exe를 끄지 말고 새 게임 생성
4) injector를 다시 실행하지 않는다
5) 두 번째 게임에서도 자동으로 Pluto가 움직여야 한다

성공 로그
  MATCH_START generation=1 ...
  MATCH_END_DETECTED generation=1 ...
  original_pluto.onEnd=PASS generation=1 ...
  bwapi.onMatchEnd=PASS generation=1
  MATCH_END generation=1 ...
  MATCH_WAIT_NEXT generation=2
  MATCH_START generation=2 ... infer_count=1
  scr_send_command=PASS ...

탐색기 테스트
- 권장 경로: C:\PlutoSCR\v96\
- 테스트 중 해당 폴더를 탐색기로 계속 열어두지 않는다.
- v96는 v94보다 로그 파일 변경 이벤트와 open/close를 크게 줄였다.

Fail-closed
- replay, invalid game state, unit-handle conversion failure, unsupported packet, send_command SEH, duplicate/missing infer process는 실제 command 전송을 중단한다.

부팅 진단
- 정상 주입이면 plutoscr-x86-v96.log 첫 줄에 BOOTSTRAP_LOG=PASS_SHARED_WIN32_HANDLE가 찍힌다.
- runtime log가 없으면 plutoscr-x86-v96-launch.log와 plutoscr-x86-v96-inject.log 두 파일만 보내면 주입 단계 원인을 바로 구분할 수 있다.
