aPlutoSCR v83 x86 ActiveTile + Relocated SCR Game Shadow

Goal
- Port the ORIGINAL Pluto observation/inference/action path to 32-bit StarCraft: Remastered.
- Do not replace or imitate Pluto observation, strategy, inference, or command choice.

Changes from v82
- Keeps the validated 96,000-byte live SCR Game shadow and all v82 relocations.
- Resolves SC:R's real ActiveTileArray (map_tile_flags) through the verified x86 profile slot.
- Validates the candidate allocation against the current map size and live-player visibility semantics.
- Relocates all known original-Pluto reads of BW 1.16.1 0x6D1260 (RVA 0x342B5, 0x3B656, 0x3B6FC) to a pointer cell containing the live SCR ActiveTileArray pointer.
- Refreshes that pointer every compatibility frame and fails closed if it changes to an invalid allocation.
- Refuses to start when a stale pluto_infer.exe already exists, preventing duplicate original inference processes.
- Command sink remains fail-closed.

Expected success markers
  pluto_infer.process_count.after_load=0
  active_tile.select=PROFILE_VALIDATED
  reloc83.active_tile=PASS
  active_tile=BOUND_REAL_SCR
  original_pluto.onStart=PASS
  pluto_infer.process_count.after_onStart=1

If RUN reports a stale inference process, run:
  taskkill /IM pluto_infer.exe /F
then launch v83 again.
