@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"

echo === aPlutoSCR v83 x86 ActiveTile + Relocated SCR Game Shadow ===
for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86V83.dll" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing: %%~F
  pause
  exit /b 1
)

if exist "%ROOT%\pluto\pluto_infer.exe" if exist "%ROOT%\pluto\pluto_weights.bin" goto runtime_ready

if exist "%ROOT%\pluto_infer.exe" if exist "%ROOT%\pluto_weights.bin" (
  echo [INFO] Converting flat original Pluto files to the standard runtime layout...
  if not exist "%ROOT%\pluto" mkdir "%ROOT%\pluto"
  copy /Y "%ROOT%\pluto_infer.exe" "%ROOT%\pluto\pluto_infer.exe" >nul || goto runtime_fail
  copy /Y "%ROOT%\pluto_weights.bin" "%ROOT%\pluto\pluto_weights.bin" >nul || goto runtime_fail
  goto runtime_ready
)

echo [FAIL] Original Pluto inference files are missing.
echo Put the UNMODIFIED originals in either:
echo   %ROOT%\pluto\pluto_infer.exe
echo   %ROOT%\pluto\pluto_weights.bin
echo or temporarily beside this CMD as flat files; v83 will copy them into pluto\.
pause
exit /b 2

:runtime_fail
echo [FAIL] Could not create the standard original Pluto runtime layout.
pause
exit /b 3

:runtime_ready
echo [PASS] Original Pluto runtime files found.
tasklist /FI "IMAGENAME eq pluto_infer.exe" 2^>nul | find /I "pluto_infer.exe" ^>nul
if not errorlevel 1 (
  echo [FAIL] A stale pluto_infer.exe is already running.
  echo Close it first, or run: taskkill /IM pluto_infer.exe /F
  pause
  exit /b 5
)
del /q "%ROOT%\plutoscr-x86-v83.log" 2>nul
echo Start the 32-bit SC:R StarCraft.exe and enter a local/custom game first.
echo Then press any key to inject the compatibility bridge.
pause >nul
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86V83.dll"
if errorlevel 1 (
  echo [FAIL] injection failed
  pause
  exit /b 4
)
echo Keep SC:R running for at least 30 seconds.
timeout /t 30 /nobreak >nul
if exist "%ROOT%\plutoscr-x86-v83.log" (
  echo === RUNTIME LOG ===
  type "%ROOT%\plutoscr-x86-v83.log"
) else (
  echo [FAIL] plutoscr-x86-v83.log was not created.
)
pause
