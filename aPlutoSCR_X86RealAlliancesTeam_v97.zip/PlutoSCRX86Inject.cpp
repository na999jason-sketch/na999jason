#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <string>

static FILE* diag=nullptr;
static void say(const char* fmt,...){
  va_list ap;va_start(ap,fmt);vprintf(fmt,ap);va_end(ap);printf("\n");fflush(stdout);
  if(diag){va_start(ap,fmt);vfprintf(diag,fmt,ap);va_end(ap);fprintf(diag,"\n");fflush(diag);}
}
static DWORD findSC(){
  PROCESSENTRY32 pe{};pe.dwSize=sizeof(pe);
  HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(s==INVALID_HANDLE_VALUE)return 0;
  DWORD pid=0;if(Process32First(s,&pe))do{if(_stricmp(pe.szExeFile,"StarCraft.exe")==0){pid=pe.th32ProcessID;break;}}while(Process32Next(s,&pe));
  CloseHandle(s);return pid;
}
static bool existsA(const char*p){DWORD a=GetFileAttributesA(p);return a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY);}
int main(int argc,char**argv){
  fopen_s(&diag,"plutoscr-x86-v97-inject.log","wb");
  say("PLUTOSCR_V97_INJECTOR=START");
  std::string dll=argc>1?argv[1]:"PlutoSCRX86V97.dll";
  char full[32768]={};DWORD fn=GetFullPathNameA(dll.c_str(),(DWORD)sizeof(full),full,nullptr);
  if(!fn||fn>=sizeof(full)){say("FAIL GetFullPathName error=%lu",GetLastError());return 1;}
  say("dll=%s",full);
  if(!existsA(full)){say("FAIL DLL_NOT_FOUND");return 1;}
  DWORD pid=findSC();say("starcraft_pid=%lu",pid);if(!pid){say("FAIL StarCraft.exe not found");return 2;}
  HANDLE p=OpenProcess(PROCESS_CREATE_THREAD|PROCESS_QUERY_INFORMATION|PROCESS_VM_OPERATION|PROCESS_VM_WRITE|PROCESS_VM_READ,FALSE,pid);
  if(!p){say("FAIL OpenProcess error=%lu",GetLastError());return 3;}
  SIZE_T n=strlen(full)+1;void*r=VirtualAllocEx(p,nullptr,n,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
  if(!r){say("FAIL VirtualAllocEx error=%lu",GetLastError());CloseHandle(p);return 4;}
  if(!WriteProcessMemory(p,r,full,n,nullptr)){say("FAIL WriteProcessMemory error=%lu",GetLastError());VirtualFreeEx(p,r,0,MEM_RELEASE);CloseHandle(p);return 4;}
  auto load=(LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleA("kernel32.dll"),"LoadLibraryA");
  if(!load){say("FAIL LoadLibraryA address missing");VirtualFreeEx(p,r,0,MEM_RELEASE);CloseHandle(p);return 5;}
  HANDLE t=CreateRemoteThread(p,nullptr,0,load,r,0,nullptr);
  if(!t){say("FAIL CreateRemoteThread error=%lu",GetLastError());VirtualFreeEx(p,r,0,MEM_RELEASE);CloseHandle(p);return 5;}
  DWORD wait=WaitForSingleObject(t,10000);say("remote_wait=%lu",wait);
  DWORD ec=0;GetExitCodeThread(t,&ec);say("remote_LoadLibrary_result=0x%08lX",ec);
  CloseHandle(t);VirtualFreeEx(p,r,0,MEM_RELEASE);CloseHandle(p);
  if(!ec){say("PLUTOSCR_V97_X86_INJECT=FAIL");return 6;}
  say("PLUTOSCR_V97_X86_INJECT=PASS pid=%lu module=0x%08lX",pid,ec);
  Sleep(1500);
  char dir[32768]={};strcpy_s(dir,sizeof(dir),full);char*slash1=strrchr(dir,'\\');char*slash2=strrchr(dir,'/');char*slash=slash1;if(slash2&&(!slash||slash2>slash))slash=slash2;if(slash)*slash=0;
  std::string runtime=std::string(dir)+"\\plutoscr-x86-v97.log";
  say("runtime_log=%s status=%s",runtime.c_str(),existsA(runtime.c_str())?"FOUND":"MISSING_AFTER_1500MS");
  return 0;
}
