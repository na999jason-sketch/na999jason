#ifndef NOMINMAX
#define NOMINMAX
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <TlHelp32.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <BWAPI/Client/Client.h>
#include "pluto_bindings.h"
#include <MinHook.h>
#include <intrin.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cwchar>
#include <fstream>
#include <string>
#include <vector>
#include <utility>
#include <unordered_set>
#include <unordered_map>
#include <sstream>

static HMODULE g_self=nullptr;
static SRWLOCK g_logLock=SRWLOCK_INIT;
static HANDLE g_logHandle=INVALID_HANDLE_VALUE;
static unsigned g_logLines=0;
using PFNGameInit=void(*)(BWAPI::Game*);
using PFNCreateAI=BWAPI::AIModule*(*)();
static std::wstring dirOfW(HMODULE m){wchar_t p[32768]={};DWORD n=GetModuleFileNameW(m,p,(DWORD)(sizeof(p)/sizeof(p[0])));std::wstring s(p,n);auto cut=s.find_last_of(L"\\/");return cut==std::wstring::npos?L".":s.substr(0,cut);}
static std::string utf8(const std::wstring&w){if(w.empty())return {};int n=WideCharToMultiByte(CP_UTF8,0,w.data(),(int)w.size(),nullptr,0,nullptr,nullptr);std::string s(n,'\0');WideCharToMultiByte(CP_UTF8,0,w.data(),(int)w.size(),s.data(),n,nullptr,nullptr);return s;}
static std::string dirOf(HMODULE m){return utf8(dirOfW(m));}
static HANDLE openSharedLogHandle(bool truncate){
  const auto path=dirOfW(g_self)+L"\\plutoscr-x86-v97.log";
  HANDLE h=CreateFileW(path.c_str(),GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,truncate?CREATE_ALWAYS:OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,nullptr);
  if(h!=INVALID_HANDLE_VALUE && !truncate)SetFilePointer(h,0,nullptr,FILE_END);
  return h;
}
static bool openPersistentLog(){
  AcquireSRWLockExclusive(&g_logLock);
  if(g_logHandle!=INVALID_HANDLE_VALUE){ReleaseSRWLockExclusive(&g_logLock);return true;}
  g_logHandle=openSharedLogHandle(true);
  const bool ok=g_logHandle!=INVALID_HANDLE_VALUE;ReleaseSRWLockExclusive(&g_logLock);return ok;
}
static void logLine(const std::string&s){
  AcquireSRWLockExclusive(&g_logLock);
  if(g_logHandle==INVALID_HANDLE_VALUE)g_logHandle=openSharedLogHandle(false);
  if(g_logHandle!=INVALID_HANDLE_VALUE){
    DWORD wrote=0;WriteFile(g_logHandle,s.data(),(DWORD)s.size(),&wrote,nullptr);
    static const char eol[]="\r\n";WriteFile(g_logHandle,eol,2,&wrote,nullptr);++g_logLines;
    const bool urgent=s.find("FAIL")!=std::string::npos||s.find("SEH")!=std::string::npos||s.find("MATCH_")!=std::string::npos||s.find("RESIDENT")!=std::string::npos||s.find("BOOTSTRAP")!=std::string::npos;
    if(urgent||(g_logLines%64u)==0u)FlushFileBuffers(g_logHandle);
  }
  ReleaseSRWLockExclusive(&g_logLock);
}
static void flushLog(){AcquireSRWLockExclusive(&g_logLock);if(g_logHandle!=INVALID_HANDLE_VALUE)FlushFileBuffers(g_logHandle);ReleaseSRWLockExclusive(&g_logLock);}
static int countProcessByName(const wchar_t* wanted){
  int count=0;HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snap==INVALID_HANDLE_VALUE)return -1;
  PROCESSENTRY32W pe{};pe.dwSize=sizeof(pe);if(Process32FirstW(snap,&pe)){do{if(_wcsicmp(pe.szExeFile,wanted)==0)++count;}while(Process32NextW(snap,&pe));}
  CloseHandle(snap);return count;
}
static unsigned long long fileSizeOrZero(const std::wstring& path){WIN32_FILE_ATTRIBUTE_DATA d{};if(!GetFileAttributesExW(path.c_str(),GetFileExInfoStandard,&d))return 0;ULARGE_INTEGER u{};u.HighPart=d.nFileSizeHigh;u.LowPart=d.nFileSizeLow;return u.QuadPart;}
static bool fileExistsW(const std::wstring& path){DWORD a=GetFileAttributesW(path.c_str());return a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY);}
static bool ensureOriginalPlutoRuntimeLayout(const std::wstring& root){
  const auto sub=root+L"\\pluto";const auto nestedInfer=sub+L"\\pluto_infer.exe";const auto nestedWeights=sub+L"\\pluto_weights.bin";
  if(fileExistsW(nestedInfer)&&fileExistsW(nestedWeights)){logLine("pluto_runtime.layout=STANDARD");return true;}
  const auto flatInfer=root+L"\\pluto_infer.exe";const auto flatWeights=root+L"\\pluto_weights.bin";
  if(fileExistsW(flatInfer)&&fileExistsW(flatWeights)){
    if(!CreateDirectoryW(sub.c_str(),nullptr) && GetLastError()!=ERROR_ALREADY_EXISTS){logLine("pluto_runtime.layout=CREATE_SUBDIR_FAIL error="+std::to_string(GetLastError()));return false;}
    if(!CopyFileW(flatInfer.c_str(),nestedInfer.c_str(),FALSE)){logLine("pluto_runtime.layout=COPY_INFER_FAIL error="+std::to_string(GetLastError()));return false;}
    if(!CopyFileW(flatWeights.c_str(),nestedWeights.c_str(),FALSE)){logLine("pluto_runtime.layout=COPY_WEIGHTS_FAIL error="+std::to_string(GetLastError()));return false;}
    logLine("pluto_runtime.layout=FLAT_TO_STANDARD");return true;
  }
  logLine("pluto_runtime.layout=MISSING");return false;
}
static volatile DWORD g_sehCode=0;static volatile uintptr_t g_sehAddress=0;static volatile uintptr_t g_sehEip=0;
static volatile uintptr_t g_sehAccessAddress=0;static volatile ULONG_PTR g_sehAccessType=~(ULONG_PTR)0;
static volatile uintptr_t g_sehEax=0,g_sehEbx=0,g_sehEcx=0,g_sehEdx=0,g_sehEsi=0,g_sehEdi=0,g_sehEbp=0,g_sehEsp=0;
static int captureSeh(EXCEPTION_POINTERS*ep){if(ep&&ep->ExceptionRecord){g_sehCode=ep->ExceptionRecord->ExceptionCode;g_sehAddress=(uintptr_t)ep->ExceptionRecord->ExceptionAddress;
if(ep->ExceptionRecord->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && ep->ExceptionRecord->NumberParameters>=2){g_sehAccessType=ep->ExceptionRecord->ExceptionInformation[0];g_sehAccessAddress=(uintptr_t)ep->ExceptionRecord->ExceptionInformation[1];}}
#if defined(_M_IX86)
if(ep&&ep->ContextRecord){g_sehEip=(uintptr_t)ep->ContextRecord->Eip;g_sehEax=ep->ContextRecord->Eax;g_sehEbx=ep->ContextRecord->Ebx;g_sehEcx=ep->ContextRecord->Ecx;g_sehEdx=ep->ContextRecord->Edx;g_sehEsi=ep->ContextRecord->Esi;g_sehEdi=ep->ContextRecord->Edi;g_sehEbp=ep->ContextRecord->Ebp;g_sehEsp=ep->ContextRecord->Esp;}
#endif
return EXCEPTION_EXECUTE_HANDLER;}
static DWORD onStartSeh(BWAPI::AIModule*m){g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;__try{m->onStart();return 0;}__except(captureSeh(GetExceptionInformation())){return g_sehCode;}}
static DWORD onEndSeh(BWAPI::AIModule*m,bool won){g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;__try{m->onEnd(won);return 0;}__except(captureSeh(GetExceptionInformation())){return g_sehCode;}}
static DWORD onFrameSeh(BWAPI::AIModule*m){
  g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;
  __try{m->onFrame();return 0;}
  __except(captureSeh(GetExceptionInformation())){return g_sehCode;}
}

#pragma pack(push,1)
struct LegacyCUnit336{ unsigned char b[336]; };
#pragma pack(pop)
static_assert(sizeof(LegacyCUnit336)==336,"CUnit size");

template<class T> static T rd(const unsigned char*p,size_t o){T v{};std::memcpy(&v,p+o,sizeof(v));return v;}
static bool readable(const void*p,size_t n){
  MEMORY_BASIC_INFORMATION mi{}; if(!VirtualQuery(p,&mi,sizeof(mi)))return false;
  if(mi.State!=MEM_COMMIT || (mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
  uintptr_t a=(uintptr_t)p; uintptr_t e=a+(uintptr_t)n; uintptr_t r=(uintptr_t)mi.BaseAddress+(uintptr_t)mi.RegionSize; return e>=a && e<=r;
}
static bool plausibleUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  auto hp=rd<int32_t>(p,0x08); auto spr=rd<uint32_t>(p,0x0c); auto x=rd<int16_t>(p,0x28); auto y=rd<int16_t>(p,0x2a);
  auto player=rd<uint8_t>(p,0x4c); auto order=rd<uint8_t>(p,0x4d); auto type=rd<uint16_t>(p,0x64);
  return spr!=0 && hp>0 && hp<(5000000*256) && x>=0&&x<=16384&&y>=0&&y<=16384&&player<12&&order<256&&type<234;
}
struct UnitStore{uintptr_t descriptor=0,begin=0,end=0,cap=0;int score=0;};
static UnitStore scanDescriptorRange(uintptr_t s,uintptr_t e,const char*tag){
  UnitStore best{}; MEMORY_BASIC_INFORMATION mi{}; uintptr_t a=s; unsigned long regions=0; unsigned long descriptors=0;
  logLine(std::string("checkpoint.scan_range.begin=")+tag);
  while(a<e && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;
    if(re<=a)break;
    uintptr_t lo=std::max(a,rs),hi=std::min(e,re);
    bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) &&
      (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && hi>lo && hi-lo>=12){
      ++regions;
      for(uintptr_t q=(lo+3)&~uintptr_t(3);q+12<=hi;q+=4){
        uint32_t b=0,en=0,c=0;
        std::memcpy(&b,(void*)q,4);std::memcpy(&en,(void*)(q+4),4);std::memcpy(&c,(void*)(q+8),4);
        if(!b||en<b||c<en)continue;uint32_t used=en-b,cap=c-b;
        if(used==0||used%336||cap%336)continue;uint32_t count=used/336,capacity=cap/336;
        if(count<2||count>3400||capacity<count||capacity>3400)continue;
        if(!readable((void*)(uintptr_t)b,std::min<uint32_t>(used,336*64)))continue;
        ++descriptors;int score=0;uint32_t step=std::max<uint32_t>(1,count/64);
        for(uint32_t i=0;i<count&&i<3400;i+=step)if(plausibleUnit((unsigned char*)(uintptr_t)(b+i*336)))++score;
        if(score>best.score){best={q,b,en,c,score};}
      }
    }
    a=re;
  }
  logLine(std::string("checkpoint.scan_range.end=")+tag+" regions="+std::to_string(regions)+" descriptors="+std::to_string(descriptors)+" best_score="+std::to_string(best.score));
  return best;
}
static uintptr_t profileSlotVA(uint32_t analyzedVa){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return 0;
  return (uintptr_t)exe+(uintptr_t)(analyzedVa-0x004A0000u);
}
static bool profileMatchActive(){
  const uintptr_t slot=profileSlotVA(0x0121758Du);
  if(!slot||!readable((void*)slot,1))return false;
  uint8_t v=0;std::memcpy(&v,(void*)slot,1);return v!=0;
}
static bool profileReplayActive(){
  const uintptr_t slot=profileSlotVA(0x01244580u);
  if(!slot||!readable((void*)slot,4))return true;
  uint32_t v=0;std::memcpy(&v,(void*)slot,4);return v!=0;
}
static uint32_t profileReadU32(uint32_t analyzedVa){
  uintptr_t slot=profileSlotVA(analyzedVa);if(!slot||!readable((void*)slot,4))return 0;
  uint32_t v=0;memcpy(&v,(void*)slot,4);return v;
}
static UnitStore findLegacyCUnitVector(){
  logLine("checkpoint.cunit_scan.enter");
  const uintptr_t poolSlot=profileSlotVA(0x010436F0u);
  const uintptr_t lengthSlot=profileSlotVA(0x010436F4u);
  logLine("profile_cunit.pool_slot="+std::to_string((unsigned long)poolSlot));
  logLine("profile_cunit.length_slot="+std::to_string((unsigned long)lengthSlot));
  if(!poolSlot||!lengthSlot||!readable((void*)poolSlot,4)||!readable((void*)lengthSlot,4)){
    logLine("profile_cunit=PROFILE_SLOTS_UNREADABLE");return {};
  }
  uint32_t begin=0,length=0;memcpy(&begin,(void*)poolSlot,4);memcpy(&length,(void*)lengthSlot,4);
  logLine("profile_cunit.pool_begin="+std::to_string((unsigned long)begin));
  logLine("profile_cunit.pool_length="+std::to_string(length));
  if(!begin||length<2||length>8192u){
    logLine("profile_cunit=INVALID_POOL_METADATA");return {};
  }
  const uint64_t bytes64=(uint64_t)length*336ull;
  if(bytes64>0xFFFFFFFFull||!readable((void*)(uintptr_t)begin,(size_t)bytes64)){
    logLine("profile_cunit=POOL_UNREADABLE");return {};
  }
  int present=0,plausible=0;
  for(uint32_t i=0;i<length;i++){
    auto*p=(unsigned char*)(uintptr_t)(begin+(uintptr_t)i*336u);
    if(rd<uint32_t>(p,0x0c)!=0 && rd<uint16_t>(p,0x64)<228){
      ++present;if(plausibleUnit(p))++plausible;
    }
  }
  const uint32_t active=profileReadU32(0x010436A4u);
  const uint32_t hidden=profileReadU32(0x010436B4u);
  const uint32_t scanner=profileReadU32(0x010436B8u);
  logLine("profile_cunit.present="+std::to_string(present)+" plausible="+std::to_string(plausible));
  logLine("profile_cunit.raw_heads.active="+std::to_string((unsigned long)active)+
          " hidden="+std::to_string((unsigned long)hidden)+
          " scanner="+std::to_string((unsigned long)scanner));
  auto inPool=[&](uint32_t p)->bool{
    if(!p)return true;uint64_t b=begin,e=(uint64_t)begin+bytes64;
    return p>=b && p<e && ((p-b)%336u)==0;
  };
  if(present<2||plausible<2||!active||!inPool(active)||!inPool(hidden)||!inPool(scanner)){
    logLine("profile_cunit=VALIDATION_FAIL");return {};
  }
  logLine("checkpoint.cunit_scan.global_select=PROFILE_13515_X86");
  logLine("checkpoint.cunit_scan.global_score="+std::to_string(present));
  logLine("checkpoint.cunit_scan.global_count="+std::to_string(length));
  logLine("profile_cunit=BOUND_VALIDATED");
  const uintptr_t end=(uintptr_t)((uint64_t)begin+bytes64);
  return {poolSlot,(uintptr_t)begin,end,end,present};
}

static uintptr_t g_scrVisibleUnitHead=0;
static uintptr_t g_scrHiddenUnitHead=0;
static uintptr_t g_scrScannerSweepHead=0;
static int g_linkPrevOff=0;
static int g_linkNextOff=4;
static std::vector<LegacyCUnit336> g_legacyCUnits(1700);
static std::vector<uintptr_t> g_legacyRawUnits;

#pragma pack(push,1)
struct LegacyBullet112{ unsigned char b[112]; };
struct LegacySprite36{ unsigned char b[36]; };
#pragma pack(pop)
static_assert(sizeof(LegacyBullet112)==112,"Bullet size");
static_assert(sizeof(LegacySprite36)==36,"Sprite size");

struct StableUnitSlot{
  uintptr_t raw=0;
  uint8_t sourceGeneration=0;
  uint8_t generation=0;
};
static std::array<StableUnitSlot,1700> g_stableUnitSlots{};
static std::array<LegacySprite36,1700> g_legacyUnitSprites{};
static std::unordered_map<uintptr_t,size_t> g_stableUnitLookup;

static uintptr_t g_legacyBulletHead=0;
static std::vector<LegacyBullet112> g_legacyBullets;
static std::vector<LegacySprite36> g_legacyBulletSprites;
static std::vector<uintptr_t> g_legacyRawBullets;
static std::unordered_map<uintptr_t,size_t> g_rawBulletIndex;

static bool presentScrUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  return rd<uint32_t>(p,0x0c)!=0 && rd<uint16_t>(p,0x64)<228;
}
static uintptr_t shadowForRaw(uintptr_t raw){
  if(!raw)return 0;
  auto it=g_stableUnitLookup.find(raw);
  if(it==g_stableUnitLookup.end()||it->second>=g_legacyCUnits.size())return 0;
  return (uintptr_t)&g_legacyCUnits[it->second];
}
static std::vector<uintptr_t> collectPresentRaw(const UnitStore&s){
  std::vector<uintptr_t> out;
  if(!s.begin||s.end<=s.begin)return out;
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  out.reserve(std::min<uint32_t>(count,1700));
  for(uint32_t i=0;i<count;i++){
    uintptr_t raw=s.begin+(uintptr_t)i*336;
    if(presentScrUnit((unsigned char*)raw))out.push_back(raw);
  }
  return out;
}
static uint16_t legacyHandleForRaw(uintptr_t raw){
  auto it=g_stableUnitLookup.find(raw);if(it==g_stableUnitLookup.end())return 0;
  const size_t i=it->second;if(i>=1700)return 0;
  return (uint16_t)((i+1)|((uint16_t)(g_stableUnitSlots[i].generation&31u)<<11));
}

using ScrPacket=std::vector<uint8_t>;
static uint16_t legacyWord(const uint8_t* p){return (uint16_t)(p[0]|((uint16_t)p[1]<<8));}
static void appendDword(ScrPacket& packet,uint32_t v){for(unsigned i=0;i<4;++i)packet.push_back((uint8_t)(v>>(8*i)));}
static unsigned legacyFixedCommandLength(uint8_t id){
  switch(id){
    case 0x0c:return 8;
    case 0x14:return 10;case 0x15:return 11;
    case 0x18:case 0x19:case 0x1b:case 0x1c:case 0x27:case 0x2a:case 0x2e:case 0x31:case 0x33:case 0x34:case 0x36:case 0x5a:return 1;
    case 0x1a:case 0x1e:case 0x21:case 0x22:case 0x25:case 0x26:case 0x28:case 0x2b:case 0x2c:case 0x2d:case 0x30:case 0x32:return 2;
    case 0x1f:case 0x20:case 0x23:case 0x29:case 0x35:return 3;
    case 0x2f:return 5;
    default:return 0;
  }
}
static uint32_t scrHandleForLegacy(uint16_t legacy){
  unsigned index=legacy&0x7ffu;
  if(!index||index>g_stableUnitSlots.size())return 0;--index;
  const auto&slot=g_stableUnitSlots[index];
  if(!slot.raw||slot.generation!=(uint8_t)(legacy>>11))return 0;
  const uint32_t rawStart=profileReadU32(0x010436F0u);
  const uint32_t rawLength=profileReadU32(0x010436F4u);
  if(!rawStart||!rawLength||slot.raw<(uintptr_t)rawStart)return 0;
  const uintptr_t delta=slot.raw-(uintptr_t)rawStart;
  if(delta%336u)return 0;
  const uint32_t rawIndex=(uint32_t)(delta/336u);
  if(rawIndex>=rawLength)return 0;
  const unsigned shift=rawLength>1700u?13u:11u;
  return (rawIndex+1u)|((uint32_t)slot.sourceGeneration<<shift);
}
static bool translateLegacyCommands(const uint8_t* bytes,size_t length,std::vector<ScrPacket>& output,std::string& error){
  output.clear();error.clear();
  auto convert=[&](uint16_t id,uint32_t& result)->bool{
    if(!id){result=0;return true;}
    result=scrHandleForLegacy(id);
    if(!result){error="expired_or_unmapped_unit_handle="+std::to_string((unsigned)id);return false;}
    return true;
  };
  for(size_t offset=0;offset<length;){
    const uint8_t* p=bytes+offset;const uint8_t id=p[0];size_t size=0;
    if(id>=9&&id<=11){
      if(length-offset<2||p[1]>12){error="invalid_legacy_selection";return false;}
      size=2u+(size_t)p[1]*2u;
    }else{
      size=legacyFixedCommandLength(id);
      if(!size){error="unsupported_legacy_command="+std::to_string((unsigned)id);return false;}
    }
    if(size>length-offset){error="truncated_legacy_command";return false;}
    ScrPacket result;
    if(id>=9&&id<=11){
      result.push_back((uint8_t)(0x63+id-9));result.push_back(p[1]);
      for(unsigned i=0;i<p[1];++i){
        const uint16_t old=legacyWord(p+2+i*2);if(!old){error="null_selection_handle";return false;}
        uint32_t mapped=0;if(!convert(old,mapped))return false;appendDword(result,mapped);
      }
    }else if(id==0x14||id==0x15){
      result.push_back((uint8_t)(id==0x14?0x60:0x61));
      result.insert(result.end(),p+1,p+5);
      uint32_t mapped=0;if(!convert(legacyWord(p+5),mapped))return false;appendDword(result,mapped);
      result.insert(result.end(),p+7,p+size);
    }else if(id==0x29){
      result.push_back(0x62);uint32_t mapped=0;if(!convert(legacyWord(p+1),mapped))return false;appendDword(result,mapped);
    }else result.assign(p,p+size);
    output.push_back(std::move(result));offset+=size;
  }
  return true;
}
static void convertLegacyUnitSprite(size_t slot,uintptr_t rawSprite){
  auto&dst=g_legacyUnitSprites[slot];std::memset(dst.b,0,sizeof(dst.b));
  if(!rawSprite||!readable((void*)rawSprite,40))return;
  std::memcpy(dst.b,(void*)rawSprite,20);
  uint32_t zero=0;std::memcpy(dst.b,&zero,4);std::memcpy(dst.b+4,&zero,4);
  uint32_t a=0,b=0;std::memcpy(&a,(void*)(rawSprite+20),4);std::memcpy(&b,(void*)(rawSprite+24),4);
  uint16_t v20=(uint16_t)a,v22=(uint16_t)b;std::memcpy(dst.b+20,&v20,2);std::memcpy(dst.b+22,&v22,2);
  if(readable((void*)(rawSprite+28),12))std::memcpy(dst.b+24,(void*)(rawSprite+28),12);
}
static bool stableSlotSet(const UnitStore&s,const std::vector<uintptr_t>&present,bool logValues){
  if(present.size()>1700u){logLine("stable_cunit_slots=OVERFLOW_GT_1700");return false;}
  std::unordered_set<uintptr_t> now(present.begin(),present.end());
  for(size_t i=0;i<g_stableUnitSlots.size();++i){
    auto&slot=g_stableUnitSlots[i];
    if(slot.raw && !now.count(slot.raw)){
      g_stableUnitLookup.erase(slot.raw);slot.raw=0;slot.sourceGeneration=0;
      std::memset(g_legacyCUnits[i].b,0,sizeof(g_legacyCUnits[i].b));
      std::memset(g_legacyUnitSprites[i].b,0,sizeof(g_legacyUnitSprites[i].b));
    }
  }
  for(uintptr_t raw:present){
    const uint8_t srcGen=rd<uint8_t>((unsigned char*)raw,165);
    auto found=g_stableUnitLookup.find(raw);
    if(found==g_stableUnitLookup.end()){
      size_t empty=g_stableUnitSlots.size();
      for(size_t i=0;i<g_stableUnitSlots.size();++i)if(!g_stableUnitSlots[i].raw){empty=i;break;}
      if(empty==g_stableUnitSlots.size()){logLine("stable_cunit_slots=NO_FREE_SLOT");return false;}
      auto&slot=g_stableUnitSlots[empty];slot.raw=raw;slot.sourceGeneration=srcGen;slot.generation=(uint8_t)((slot.generation+1)&31u);
      g_stableUnitLookup.emplace(raw,empty);
    }else{
      auto&slot=g_stableUnitSlots[found->second];
      if(slot.sourceGeneration!=srcGen){slot.sourceGeneration=srcGen;slot.generation=(uint8_t)((slot.generation+1)&31u);}
    }
  }
  g_legacyRawUnits=present;
  if(logValues){
    logLine("stable_cunit_slots.present="+std::to_string(present.size()));
    logLine("stable_cunit_slots.lookup="+std::to_string(g_stableUnitLookup.size()));
  }
  return true;
}
static bool projectStableLegacyUnitsFromPresent(const UnitStore&s,const std::vector<uintptr_t>&present,bool logValues){
  if(!stableSlotSet(s,present,logValues))return false;
  const uint32_t rawLength=(uint32_t)((s.end-s.begin)/336);
  const unsigned ptrOffsets[]={0,4,20,92,104,108,112,124,128,236,240,244,252,284};
  for(size_t i=0;i<g_stableUnitSlots.size();++i){
    auto&slot=g_stableUnitSlots[i];if(!slot.raw)continue;
    auto*src=(unsigned char*)slot.raw;auto&dst=g_legacyCUnits[i];
    std::memcpy(dst.b,src,336);
    for(unsigned off:ptrOffsets){
      uint32_t rawPtr=rd<uint32_t>(src,off);uint32_t legacy=(uint32_t)shadowForRaw(rawPtr);
      std::memcpy(dst.b+off,&legacy,4);
    }
    for(unsigned off=192;off<=216;off+=4){
      uint32_t rawPtr=rd<uint32_t>(src,off);
      if(g_stableUnitLookup.count(rawPtr)){uint32_t legacy=(uint32_t)shadowForRaw(rawPtr);std::memcpy(dst.b+off,&legacy,4);}
    }
    uint32_t rawSprite=rd<uint32_t>(src,12);convertLegacyUnitSprite(i,rawSprite);
    uint32_t spriteShadow=rawSprite?(uint32_t)(uintptr_t)&g_legacyUnitSprites[i]:0;
    std::memcpy(dst.b+12,&spriteShadow,4);
    std::memcpy(dst.b+165,&slot.generation,1);

    uint16_t high=rawLength>1700?rd<uint16_t>(src,306):0;
    for(unsigned n=0;n<8;++n){
      uint32_t id=(uint32_t)rd<uint16_t>(src,176+n*2)|(((uint32_t)(high>>(n*2))&3u)<<16);
      uint32_t index=id&(rawLength>1700?0x1fffu:0x7ffu);uint16_t legacy=0;
      if(index && index<=rawLength){
        uintptr_t loaded=s.begin+(uintptr_t)(index-1)*336u;
        const unsigned shift=rawLength>1700?13u:11u;
        if(readable((void*)loaded,336) && rd<uint8_t>((unsigned char*)loaded,165)==(uint8_t)(id>>shift))
          legacy=legacyHandleForRaw(loaded);
      }
      std::memcpy(dst.b+176+n*2,&legacy,2);
    }
  }

  const uint32_t rawActive=profileReadU32(0x010436A4u);
  const uint32_t rawHidden=profileReadU32(0x010436B4u);
  const uint32_t rawScanner=profileReadU32(0x010436B8u);
  g_scrVisibleUnitHead=shadowForRaw(rawActive);
  g_scrHiddenUnitHead=shadowForRaw(rawHidden);
  g_scrScannerSweepHead=shadowForRaw(rawScanner);
  if(logValues){
    logLine("profile_heads.raw.visible="+std::to_string((unsigned long)rawActive)+
            " hidden="+std::to_string((unsigned long)rawHidden)+
            " scanner="+std::to_string((unsigned long)rawScanner));
    logLine("profile_heads.shadow.visible="+std::to_string((unsigned long)g_scrVisibleUnitHead)+
            " hidden="+std::to_string((unsigned long)g_scrHiddenUnitHead)+
            " scanner="+std::to_string((unsigned long)g_scrScannerSweepHead));
  }
  if(rawActive && !g_scrVisibleUnitHead){logLine("profile_heads=ACTIVE_NOT_MAPPED");return false;}
  if(rawHidden && !g_scrHiddenUnitHead){logLine("profile_heads=HIDDEN_NOT_MAPPED");return false;}
  if(rawScanner && !g_scrScannerSweepHead){logLine("profile_heads=SCANNER_NOT_MAPPED");return false;}
  return g_scrVisibleUnitHead!=0;
}
static bool projectStableLegacyUnits(const UnitStore&s,bool logValues){
  const auto present=collectPresentRaw(s);
  return projectStableLegacyUnitsFromPresent(s,present,logValues);
}
static int buildLegacyCUnitShadow(const UnitStore&s){
  if(!projectStableLegacyUnits(s,true))return 0;
  return (int)g_legacyRawUnits.size();
}
static int refreshLegacyCUnitShadow(const UnitStore&s){
  if(!projectStableLegacyUnits(s,false))return 0;
  return (int)g_legacyRawUnits.size();
}
static int refreshLegacyCUnitShadowFromPresent(const UnitStore&s,const std::vector<uintptr_t>&present){
  if(!projectStableLegacyUnitsFromPresent(s,present,false))return 0;
  return (int)g_legacyRawUnits.size();
}

static uintptr_t shadowBulletForRaw(uintptr_t raw){
  if(!raw)return 0;
  auto it=g_rawBulletIndex.find(raw);
  if(it==g_rawBulletIndex.end()||it->second>=g_legacyBullets.size())return 0;
  return (uintptr_t)&g_legacyBullets[it->second];
}
static bool projectProfileBulletShadow(bool logValues){
  const uintptr_t headSlot=profileSlotVA(0x01034A78u);
  if(logValues)logLine("profile_bullet.head_slot="+std::to_string((unsigned long)headSlot));
  if(!headSlot||!readable((void*)headSlot,4)){
    logLine("profile_bullet=HEAD_SLOT_UNREADABLE");return false;
  }
  uint32_t rawHead=0;std::memcpy(&rawHead,(void*)headSlot,4);
  if(logValues)logLine("profile_bullet.raw_head="+std::to_string((unsigned long)rawHead));

  std::vector<uintptr_t> rawBullets;
  std::unordered_set<uintptr_t> visited;
  uintptr_t cur=rawHead;
  while(cur){
    if(rawBullets.size()>=8192u){logLine("profile_bullet=OVERFLOW_GT_8192");return false;}
    if(!visited.insert(cur).second){logLine("profile_bullet=CYCLE_DETECTED");return false;}
    if(!readable((void*)cur,112)){logLine("profile_bullet=NODE_UNREADABLE");return false;}
    rawBullets.push_back(cur);
    uint32_t next=rd<uint32_t>((unsigned char*)cur,4);
    if(next && !readable((void*)(uintptr_t)next,112)){logLine("profile_bullet=NEXT_UNREADABLE");return false;}
    cur=next;
  }

  g_legacyBullets.clear();g_legacyBulletSprites.clear();g_legacyRawBullets.clear();g_rawBulletIndex.clear();g_legacyBulletHead=0;
  g_legacyRawBullets=rawBullets;
  g_legacyBullets.resize(rawBullets.size());
  g_legacyBulletSprites.resize(rawBullets.size());
  g_rawBulletIndex.reserve(rawBullets.size()*2+1);
  for(size_t i=0;i<rawBullets.size();++i)g_rawBulletIndex.emplace(rawBullets[i],i);

  for(size_t i=0;i<rawBullets.size();++i){
    auto*src=(unsigned char*)rawBullets[i];
    std::memcpy(g_legacyBullets[i].b,src,112);
  }
  for(size_t i=0;i<rawBullets.size();++i){
    uintptr_t raw=rawBullets[i];auto*src=(unsigned char*)raw;auto&dst=g_legacyBullets[i];
    uint32_t prev=(uint32_t)shadowBulletForRaw(rd<uint32_t>(src,0));
    uint32_t next=(uint32_t)shadowBulletForRaw(rd<uint32_t>(src,4));
    std::memcpy(dst.b+0,&prev,4);std::memcpy(dst.b+4,&next,4);
    for(int off:{0x14,0x5c,0x64,0x68}){
      uint32_t u=(uint32_t)shadowForRaw(rd<uint32_t>(src,(size_t)off));
      std::memcpy(dst.b+off,&u,4);
    }
    uint32_t rawSprite=rd<uint32_t>(src,0x0c);uint32_t spriteShadow=0;
    if(rawSprite){
      if(!readable((void*)(uintptr_t)rawSprite,40)){logLine("profile_bullet=SPRITE_UNREADABLE");return false;}
      auto&s=g_legacyBulletSprites[i];std::memset(s.b,0,sizeof(s.b));std::memcpy(s.b,(void*)(uintptr_t)rawSprite,20);
      uint32_t z=0;std::memcpy(s.b,&z,4);std::memcpy(s.b+4,&z,4);
      uint16_t v20=(uint16_t)rd<uint32_t>((unsigned char*)(uintptr_t)rawSprite,20);
      uint16_t v22=(uint16_t)rd<uint32_t>((unsigned char*)(uintptr_t)rawSprite,24);
      std::memcpy(s.b+20,&v20,2);std::memcpy(s.b+22,&v22,2);
      if(readable((void*)(uintptr_t)(rawSprite+28),12))std::memcpy(s.b+24,(void*)(uintptr_t)(rawSprite+28),12);
      spriteShadow=(uint32_t)(uintptr_t)&s;
    }
    std::memcpy(dst.b+0x0c,&spriteShadow,4);
  }
  g_legacyBulletHead=rawBullets.empty()?0:shadowBulletForRaw(rawBullets[0]);
  if(logValues){
    logLine("profile_bullet.active="+std::to_string(rawBullets.size()));
    logLine("profile_bullet.shadow_head="+std::to_string((unsigned long)g_legacyBulletHead));
    logLine("profile_bullet=BOUND_VALIDATED");
  }
  return rawHead==0 || g_legacyBulletHead!=0;
}
static bool buildLegacyBulletShadow(){return projectProfileBulletShadow(true);}
static bool refreshLegacyBulletShadow(){return projectProfileBulletShadow(false);}

static int profileLocalPlayerCandidate();
static int inferRace(int type){if(type<=59||(type>=106&&type<=131))return 1;if((type>=88&&type<=103)||(type>=132&&type<=157))return 0;if((type>=60&&type<=87)||type==97||(type>=159&&type<=173))return 2;return 5;}
static int projectLiveUnitsFromPresent(const std::vector<uintptr_t>&present,BWAPI::GameData&d){
  int out=0;std::array<int,12> counts{};std::array<int,12> race{};race.fill(5);
  const int previous=d.initialUnitCount;const int self=d.self;
  for(uintptr_t raw:present){
    auto*p=(unsigned char*)raw;if(!presentScrUnit(p))continue;
    const int owner=rd<uint8_t>(p,0x4c);const int type=rd<uint16_t>(p,0x64);
    if(owner>=0&&owner<12){counts[owner]++;race[owner]=inferRace(type);}
    const uint32_t sprite=rd<uint32_t>(p,0x0c);uint8_t visibility=0;
    if(sprite&&readable((void*)(uintptr_t)(sprite+12),1))std::memcpy(&visibility,(void*)(uintptr_t)(sprite+12),1);
    if(self>=0&&self<8 && owner!=self && owner!=11 && !(visibility&(1u<<self)))continue;
    if(out>=10000)break;
    auto&q=d.units[out];ZeroMemory(&q,sizeof(q));q.id=out;q.player=owner;q.type=type;q.positionX=rd<int16_t>(p,0x28);q.positionY=rd<int16_t>(p,0x2a);
    q.hitPoints=std::max(0,rd<int32_t>(p,0x08)/256);q.shields=rd<uint32_t>(p,0x60)/256;q.energy=rd<uint16_t>(p,0xa2)/256;q.order=rd<uint8_t>(p,0x4d);
    q.targetPositionX=rd<int16_t>(p,0x58);q.targetPositionY=rd<int16_t>(p,0x5a);q.orderTargetPositionX=q.targetPositionX;q.orderTargetPositionY=q.targetPositionY;
    q.exists=true;auto flags=rd<uint32_t>(p,0xdc);q.isCompleted=(flags&1)!=0;q.isCloaked=(flags&0x200)!=0;q.isBurrowed=(flags&0x10)!=0;q.isInvincible=(flags&0x04000000)!=0;
    for(bool&v:q.isVisible)v=false;
    const int visCount=(int)(sizeof(q.isVisible)/sizeof(q.isVisible[0]));
    for(int i=0;i<8&&i<visCount;++i)q.isVisible[i]=(owner==i)||((visibility&(1u<<i))!=0);
    ++out;
  }
  for(int i=out;i<previous&&i<10000;++i)ZeroMemory(&d.units[i],sizeof(d.units[i]));
  d.initialUnitCount=out;d.playerCount=0;
  for(int pl=0;pl<12;pl++)if(counts[pl]){d.playerCount=std::max(d.playerCount,pl+1);d.players[pl].race=race[pl];d.players[pl].isParticipating=true;d.players[pl].type=1;d.players[pl].isAlly[pl]=true;}
  return out;
}
static int projectLiveUnits(const UnitStore&s,BWAPI::GameData&d){
  return projectLiveUnitsFromPresent(collectPresentRaw(s),d);
}


static constexpr uintptr_t kLegacyGameBase=0x0057F0F0u;
static constexpr size_t kScrGameSize=96000u;
static uintptr_t g_scrGame=0;
static unsigned char* g_legacyGameShadow=nullptr;

static bool collectCoherentPresentRaw(const UnitStore&s,std::vector<uintptr_t>&out,uint32_t&frameOut){
  out.clear();frameOut=0;
  if(!g_scrGame||!readable((void*)(g_scrGame+332),4))return false;
  for(int attempt=0;attempt<4;++attempt){
    const uint32_t before=rd<uint32_t>((unsigned char*)g_scrGame,332);
    auto candidate=collectPresentRaw(s);
    const uint32_t after=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(before==after){out.swap(candidate);frameOut=after;return true;}
    Sleep(0);
  }
  return false;
}

static int scoreScrGameCandidate(uintptr_t g,int expectedLive,uint64_t* unitTotalOut=nullptr){
  if(!g || !readable((void*)g,kScrGameSize))return -1;
  const auto*p=(const unsigned char*)g;
  const uint16_t w=rd<uint16_t>(p,228),h=rd<uint16_t>(p,230);
  const uint32_t frame=rd<uint32_t>(p,332);
  if(w<32||w>256||h<32||h>256||frame==0||frame>50000000u)return -1;
  int score=200;
  int smallUp=0,totalUp=0;
  for(size_t i=0;i<12u*46u;i++){++totalUp;if(rd<uint8_t>(p,57792+i)<=3)++smallUp;}
  for(size_t i=0;i<12u*15u;i++){++totalUp;if(rd<uint8_t>(p,66108+i)<=3)++smallUp;}
  if(smallUp<totalUp*98/100)return -1;score+=smallUp;
  int smallTech=0,totalTech=0;
  for(size_t i=0;i<12u*24u;i++){++totalTech;if(rd<uint8_t>(p,56916+i)<=1)++smallTech;}
  for(size_t i=0;i<12u*20u;i++){++totalTech;if(rd<uint8_t>(p,65616+i)<=1)++smallTech;}
  if(smallTech<totalTech*95/100)return -1;score+=smallTech;
  uint64_t unitTotal=0;int badCounts=0;
  for(size_t i=0;i<228u*12u;i++){uint32_t v=rd<uint32_t>(p,12852+i*4);if(v>5000u)++badCounts;unitTotal+=v;}
  if(badCounts>4 || unitTotal<2 || unitTotal>20000)return -1;
  if(unitTotalOut)*unitTotalOut=unitTotal;
  score+=400;
  if(expectedLive>0){uint64_t diff=unitTotal>(uint64_t)expectedLive?unitTotal-expectedLive:(uint64_t)expectedLive-unitTotal;if(diff<=16)score+=500;else if(diff<=64)score+=250;}
  int goodSupply=0,totalSupply=0;
  for(int race=0;race<3;race++)for(int block=0;block<3;block++)for(int pl=0;pl<12;pl++){
    ++totalSupply;uint32_t v=rd<uint32_t>(p,12372+race*144+block*48+pl*4);if(v<5000u)++goodSupply;
  }
  if(goodSupply<totalSupply*95/100)return -1;score+=goodSupply;
  return score;
}

static uintptr_t profileScrGameCandidate(){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return 0;
  const uintptr_t base=(uintptr_t)exe;
  const uintptr_t slot=base+(0x00FA63CCu-0x004A0000u);
  if(!readable((void*)slot,4))return 0;
  uint32_t encoded=0;memcpy(&encoded,(void*)slot,4);
  return (uintptr_t)(encoded^0x10FAE560u);
}

static uintptr_t findScrGameBlock(int expectedLive){
  uintptr_t prof=profileScrGameCandidate();uint64_t total=0;int ps=scoreScrGameCandidate(prof,expectedLive,&total);
  logLine("scr_game.profile_candidate="+std::to_string((unsigned long)prof)+" score="+std::to_string(ps)+" unit_total="+std::to_string(total));
  if(ps>=1500){logLine("scr_game.select=PROFILE_VALIDATED");return prof;}
  SYSTEM_INFO si{};GetSystemInfo(&si);MEMORY_BASIC_INFORMATION mi{};uintptr_t a=(uintptr_t)si.lpMinimumApplicationAddress;
  uintptr_t best=0;int bestScore=-1;uint64_t bestTotal=0;unsigned long regions=0,candidates=0;
  while(a<(uintptr_t)si.lpMaximumApplicationAddress && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;if(re<=a)break;
    const bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) && (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && mi.RegionSize>=kScrGameSize){++regions;uintptr_t lo=(rs+15u)&~uintptr_t(15u),hi=re-kScrGameSize;
      for(uintptr_t q=lo;q<=hi;q+=16u){
        uint16_t w=0,h=0;uint32_t frame=0;memcpy(&w,(void*)(q+228),2);memcpy(&h,(void*)(q+230),2);if(w<32||w>256||h<32||h>256)continue;memcpy(&frame,(void*)(q+332),4);if(!frame||frame>50000000u)continue;
        uint64_t ut=0;int sc=scoreScrGameCandidate(q,expectedLive,&ut);if(sc<0)continue;++candidates;if(sc>bestScore){bestScore=sc;best=q;bestTotal=ut;}
      }
    }
    a=re;
  }
  logLine("scr_game.scan.regions="+std::to_string(regions)+" candidates="+std::to_string(candidates)+" best_score="+std::to_string(bestScore));
  logLine("scr_game.scan.best="+std::to_string((unsigned long)best)+" unit_total="+std::to_string(bestTotal));
  if(bestScore<1500){logLine("scr_game.select=UNRESOLVED");return 0;}
  logLine("scr_game.select=DYNAMIC_SCAN");return best;
}

static bool allocateLegacyGameShadow(){
  if(g_legacyGameShadow)return true;
  void* p=VirtualAlloc(nullptr,kScrGameSize,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
  if(!p){logLine("legacy_game.alloc=FAIL gle="+std::to_string(GetLastError()));return false;}
  if((uintptr_t)p>0xFFFFFFFFu){VirtualFree(p,0,MEM_RELEASE);logLine("legacy_game.alloc=OUT_OF_X86_RANGE");return false;}
  g_legacyGameShadow=(unsigned char*)p;
  logLine("legacy_game.allocated_shadow="+std::to_string((unsigned long)(uintptr_t)g_legacyGameShadow));
  return true;
}

static bool syncLegacyGameShadow(uintptr_t g){
  if(!g_legacyGameShadow||!g||!readable((void*)g,kScrGameSize))return false;
  memcpy(g_legacyGameShadow,(void*)g,kScrGameSize);
  return true;
}



// SC:R ActiveTileArray bridge. The original Pluto reads the BW 1.16.1
// pointer at 0x6D1260. We do not synthesize tile state: we validate and expose
// SC:R's live map_tile_flags() allocation through a pointer cell and relocate
// only Pluto's known absolute operands that load 0x6D1260.
static uint32_t g_scrActiveTileArray=0;
static uint32_t g_legacyActiveTilePtr=0;
static uintptr_t g_activeTileProfileSlot=0;

// Legacy BW 1.16.1 onStart globals. The original Pluto reads the local player
// id from 0x512688 and clears the selection/control-group cells at
// 0x5124D8..0x51250C. These are ABI cells only: the local player value comes
// directly from SCR, while Pluto's legacy writes stay isolated in this shadow.
static uint32_t g_legacyLocalPlayerId=0;
alignas(4) static unsigned char g_legacyStartSelection[0x38]{};

// Legacy BW Players[12] block. SCR keeps the same 36-byte player records but
// at a relocated runtime allocation. Pluto onStart reads these records directly
// for slot type/race/team/name. Preserve Pluto's reads by copying the real SCR
// records into a 12*36 shadow and relocating only operands that point inside
// 0x57EEE0..0x57F08F.
static constexpr uint32_t kLegacyPlayersBase=0x0057EEE0u;
static constexpr size_t kLegacyPlayersBytes=12u*36u;
alignas(4) static unsigned char g_legacyPlayersShadow[kLegacyPlayersBytes]{};
static uint32_t g_scrPlayers=0;

// Legacy BWAPI command-staging ABI used directly by the pinned Pluto binary.
// v97 keeps Pluto observation/inference/decision on the proven resident worker,
// translates its original 1.16.1 gameplay packets using the verified rules,
// then queues those SC:R packets for submission ONLY from SC:R's verified game
// thread frame callsites. A one-frame pending turn preserves the reference
// bridge's measured observation-to-effect delay. Any mismatch fails closed.
alignas(16) static unsigned char g_legacyCommandBuffer[512]{};
static volatile uint32_t g_legacyCommandSize=0;
static uint32_t g_legacyMultiplayerFlag=0;
static uint16_t g_legacyGameModeWord=2;
static constexpr LONG kMaxCapturedFlushes=16;
static volatile LONG g_legacyFlushCount=0;
static volatile LONG g_legacyFlushOverflow=0;
static uint32_t g_legacyFlushSizes[kMaxCapturedFlushes]{};
alignas(16) static unsigned char g_legacyFlushBuffers[kMaxCapturedFlushes][512]{};

static std::string packetHex(const ScrPacket& p);
struct PendingScrTurn{uint32_t frame=0;std::vector<ScrPacket> packets;};
static SRWLOCK g_pendingTurnLock=SRWLOCK_INIT;
static std::vector<PendingScrTurn> g_pendingTurns;
static volatile LONG g_commandSendFailed=0;
static volatile LONG g_gameThreadHookReady=0;
static volatile LONG g_gameThreadHookSeen=0;
static volatile LONG g_submittedPackets=0;
static volatile LONG g_matchCommandsArmed=0;
static volatile LONG g_translateLogSequence=0;
static volatile LONG g_sendLogSequence=0;
static DWORD g_gameThreadId=0;
static uint32_t g_lastHookFrame=0;
using PFNGetTickCount=DWORD (WINAPI*)();
static PFNGetTickCount g_originalGetTickCount=nullptr;
static thread_local bool g_insideGameTickHook=false;
static volatile DWORD g_sendSehCode=0;

static bool executableAddress(uintptr_t p){
  MEMORY_BASIC_INFORMATION mi{};if(!p||!VirtualQuery((void*)p,&mi,sizeof(mi)))return false;
  if(mi.State!=MEM_COMMIT || (mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
  const DWORD x=mi.Protect&0xffu;
  return x==PAGE_EXECUTE||x==PAGE_EXECUTE_READ||x==PAGE_EXECUTE_READWRITE||x==PAGE_EXECUTE_WRITECOPY;
}
static bool sendPacketSeh(void (__cdecl*send)(const uint8_t*,size_t),const ScrPacket&packet){
  g_sendSehCode=0;
  __try{send(packet.data(),packet.size());return true;}
  __except((g_sendSehCode=GetExceptionCode(),EXCEPTION_EXECUTE_HANDLER)){return false;}
}
static void clearPendingTurns(){AcquireSRWLockExclusive(&g_pendingTurnLock);g_pendingTurns.clear();ReleaseSRWLockExclusive(&g_pendingTurnLock);}
static bool queueTranslatedTurn(uint32_t frame,std::vector<ScrPacket>&&packets){
  if(packets.empty())return true;
  if(InterlockedCompareExchange(&g_commandSendFailed,0,0))return false;
  bool ok=true;AcquireSRWLockExclusive(&g_pendingTurnLock);
  if(g_pendingTurns.size()>=128u)ok=false;
  else g_pendingTurns.push_back(PendingScrTurn{frame,std::move(packets)});
  ReleaseSRWLockExclusive(&g_pendingTurnLock);
  if(!ok){InterlockedExchange(&g_commandSendFailed,1);logLine("scr_command_pending=OVERFLOW_FAIL_CLOSED");}
  return ok;
}
static void drainPendingTurnsOnGameThread(uint32_t frame){
  if(InterlockedCompareExchange(&g_commandSendFailed,0,0))return;
  if(profileReadU32(0x01244580u)){InterlockedExchange(&g_commandSendFailed,1);clearPendingTurns();logLine("scr_send_command=REPLAY_REJECTED_FAIL_CLOSED");return;}
  if(g_lastHookFrame && frame<g_lastHookFrame){clearPendingTurns();logLine("scr_game_thread.frame_reset pending=DISCARDED");}
  g_lastHookFrame=frame;
  std::vector<PendingScrTurn> due;
  AcquireSRWLockExclusive(&g_pendingTurnLock);
  for(auto it=g_pendingTurns.begin();it!=g_pendingTurns.end();){
    if(it->frame>=frame){++it;continue;}
    due.push_back(std::move(*it));it=g_pendingTurns.erase(it);
  }
  ReleaseSRWLockExclusive(&g_pendingTurnLock);
  if(due.empty())return;
  const uintptr_t sendVa=profileSlotVA(0x007DA250u);
  if(!executableAddress(sendVa)){
    InterlockedExchange(&g_commandSendFailed,1);clearPendingTurns();logLine("scr_send_command=ADDRESS_NOT_EXECUTABLE_FAIL_CLOSED");return;
  }
  auto send=reinterpret_cast<void (__cdecl*)(const uint8_t*,size_t)>(sendVa);
  for(auto&turn:due){
    unsigned sent=0;
    for(auto&packet:turn.packets){
      if(packet.empty()||packet.size()>512u||!sendPacketSeh(send,packet)){
        InterlockedExchange(&g_commandSendFailed,1);clearPendingTurns();
        logLine("scr_send_command=SEH_OR_PACKET_FAIL_CLOSED code="+std::to_string((unsigned long)g_sendSehCode));return;
      }
      ++sent;InterlockedIncrement(&g_submittedPackets);
    }
    const LONG sendSeq=InterlockedIncrement(&g_sendLogSequence);
    if(sendSeq<=12 || (sendSeq%32)==0)logLine("scr_send_command=PASS seq="+std::to_string((long)sendSeq)+" game_frame="+std::to_string(frame)+" queued_frame="+std::to_string(turn.frame)+" packets="+std::to_string(sent)+" first="+(turn.packets.empty()?std::string():packetHex(turn.packets.front())));
  }
}
static DWORD WINAPI gameTickHook(){
  const uintptr_t caller=(uintptr_t)_ReturnAddress();
  const bool frameCall=caller==profileSlotVA(0x0076E02Fu)||caller==profileSlotVA(0x0077D112u);
  if(frameCall && InterlockedCompareExchange(&g_gameThreadHookReady,0,0) && !g_insideGameTickHook){
    g_insideGameTickHook=true;g_gameThreadId=GetCurrentThreadId();
    if(InterlockedCompareExchange(&g_gameThreadHookSeen,1,0)==0)
      logLine("scr_game_thread_hook=ACTIVE thread="+std::to_string((unsigned long)g_gameThreadId)+" caller="+std::to_string((unsigned long)caller));
    if(InterlockedCompareExchange(&g_matchCommandsArmed,0,0) && g_scrGame && readable((void*)(g_scrGame+332),4))drainPendingTurnsOnGameThread(rd<uint32_t>((unsigned char*)g_scrGame,332));
    g_insideGameTickHook=false;
  }
  return g_originalGetTickCount?g_originalGetTickCount():0;
}
static bool installGameThreadCommandHook(){
  const uintptr_t importSlot=profileSlotVA(0x00DD01C4u);
  if(!importSlot||!readable((void*)importSlot,4)){logLine("scr_game_thread_hook=IMPORT_SLOT_UNREADABLE");return false;}
  uintptr_t target=0;memcpy(&target,(void*)importSlot,4);
  auto kernel=GetModuleHandleW(L"kernel32.dll");
  const uintptr_t expected=(uintptr_t)(kernel?GetProcAddress(kernel,"GetTickCount"):nullptr);
  const uintptr_t sendVa=profileSlotVA(0x007DA250u);
  logLine("scr_game_thread_hook.import="+std::to_string((unsigned long)target)+" winapi="+std::to_string((unsigned long)expected));
  logLine("scr_send_command.addr="+std::to_string((unsigned long)sendVa));
  if(!expected||!executableAddress(expected)){logLine("scr_game_thread_hook=GETTICKCOUNT_NOT_EXECUTABLE_FAIL_CLOSED");return false;}
  if(target!=expected)logLine("scr_game_thread_hook.import_note=IAT_TARGET_DIFFERS_FROM_WINAPI_ACCEPTED_REFERENCE_BEHAVIOR");
  if(!executableAddress(sendVa)){logLine("scr_send_command=PROFILE_ADDRESS_REJECTED_FAIL_CLOSED");return false;}
  MH_STATUS st=MH_Initialize();
  if(st==MH_OK)st=MH_CreateHook((LPVOID)expected,(LPVOID)&gameTickHook,reinterpret_cast<LPVOID*>(&g_originalGetTickCount));
  if(st==MH_OK)st=MH_EnableHook((LPVOID)expected);
  if(st!=MH_OK){logLine("scr_game_thread_hook=MINHOOK_FAIL code="+std::to_string((int)st));return false;}
  InterlockedExchange(&g_gameThreadHookReady,1);
  logLine("scr_game_thread_hook=INSTALLED callsite_a="+std::to_string((unsigned long)profileSlotVA(0x0076E02Fu))+" callsite_b="+std::to_string((unsigned long)profileSlotVA(0x0077D112u)));
  return true;
}

static void __cdecl legacyCommandFlushStub(){
  uint32_t n=g_legacyCommandSize;if(n>sizeof(g_legacyCommandBuffer))n=(uint32_t)sizeof(g_legacyCommandBuffer);
  LONG index=InterlockedIncrement(&g_legacyFlushCount)-1;
  if(index>=0&&index<kMaxCapturedFlushes){g_legacyFlushSizes[index]=n;if(n)memcpy(g_legacyFlushBuffers[index],g_legacyCommandBuffer,n);}
  else InterlockedExchange(&g_legacyFlushOverflow,1);
  g_legacyCommandSize=0;
}

static uint32_t profilePlayersCandidate(){
  const uint32_t a=profileReadU32(0x0101F0E4u);
  const uint32_t b=profileReadU32(0x01240E38u);
  if(!a&&!b)return 0;
  return (0xFB5969C2u-a)^b;
}

static int scorePlayersCandidate(uint32_t p){
  if(!p||!readable((void*)(uintptr_t)p,kLegacyPlayersBytes))return -1;
  int score=0;
  for(int i=0;i<12;i++){
    auto*r=(unsigned char*)(uintptr_t)(p+i*36u);
    uint32_t id=rd<uint32_t>(r,0);
    uint8_t type=rd<uint8_t>(r,8),race=rd<uint8_t>(r,9),team=rd<uint8_t>(r,10);
    if(id<16)score+=2;
    if(type<16)score+=3;
    if(race<8)score+=3;
    if(team<16)score+=2;
  }
  return score;
}

static bool resolveLegacyPlayers(){
  const uint32_t cand=profilePlayersCandidate();
  const int score=scorePlayersCandidate(cand);
  logLine("legacy_players.profile_candidate="+std::to_string((unsigned long)cand)+" score="+std::to_string(score));
  if(score<80){logLine("legacy_players.select=REJECTED");return false;}
  g_scrPlayers=cand;
  memcpy(g_legacyPlayersShadow,(void*)(uintptr_t)g_scrPlayers,kLegacyPlayersBytes);
  logLine("legacy_players.select=PROFILE_VALIDATED");
  logLine("legacy_players.scr_base="+std::to_string((unsigned long)g_scrPlayers));
  for(int i=0;i<8;i++){
    auto*r=g_legacyPlayersShadow+i*36u;
    logLine("legacy_players.slot["+std::to_string(i)+"].type="+std::to_string((int)rd<uint8_t>(r,8))+
            " race="+std::to_string((int)rd<uint8_t>(r,9))+" team="+std::to_string((int)rd<uint8_t>(r,10)));
  }
  return true;
}

static bool refreshLegacyPlayers(){
  const uint32_t now=profilePlayersCandidate();
  if(!now||scorePlayersCandidate(now)<80)return false;
  if(now!=g_scrPlayers){logLine("legacy_players.pointer_changed="+std::to_string((unsigned long)g_scrPlayers)+"->"+std::to_string((unsigned long)now));g_scrPlayers=now;}
  memcpy(g_legacyPlayersShadow,(void*)(uintptr_t)g_scrPlayers,kLegacyPlayersBytes);
  return true;
}

// v97: mirror SCR's real participant/team/alliance state into BWAPI GameData.
// This is observation compatibility only: Pluto still performs all strategy/decision making.
static bool projectRealPlayerRelations(BWAPI::GameData& d,bool logValues){
  if(!g_scrGame||!g_scrPlayers||!readable((void*)g_scrGame,kScrGameSize)||!readable((void*)(uintptr_t)g_scrPlayers,kLegacyPlayersBytes))return false;
  const uintptr_t gameTypeBase=profileSlotVA(0x01240E58u);
  if(!gameTypeBase||!readable((void*)(gameTypeBase+40u),2))return false;
  uint16_t gameType=0;memcpy(&gameType,(void*)(gameTypeBase+40u),2);
  d.gameType=gameType;d.playerCount=12;d.forceCount=(d.gameType==BWAPI::GameTypes::Top_vs_Bottom)?3:1;d.enemy=-1;d.neutral=11;
  if(d.forceCount==3){std::strcpy(d.forces[1].name,"Top");std::strcpy(d.forces[2].name,"Bottom");}
  for(unsigned i=0;i<12;++i){
    auto& p=d.players[i];auto*raw=(unsigned char*)(uintptr_t)(g_scrPlayers+i*36u);
    p.race=rd<uint8_t>(raw,9);p.type=rd<uint8_t>(raw,8);p.isNeutral=(i==11);
    p.isParticipating=i<8 && (p.type==BWAPI::PlayerTypes::Player || p.type==BWAPI::PlayerTypes::Computer);
    const uint8_t team=rd<uint8_t>(raw,10);p.force=(p.isParticipating&&d.forceCount==3&&team<=2)?team:0;
    p.startLocationX=p.startLocationY=-1;
    for(unsigned j=0;j<12;++j){
      auto*other=(unsigned char*)(uintptr_t)(g_scrPlayers+j*36u);
      const uint8_t ot=rd<uint8_t>(other,8);
      const bool otherParticipates=j<8 && (ot==BWAPI::PlayerTypes::Player || ot==BWAPI::PlayerTypes::Computer);
      const uint8_t alliance=rd<uint8_t>((unsigned char*)g_scrGame,58692u+i*12u+j);
      p.isAlly[j]=(i==j)||(p.isParticipating&&otherParticipates&&alliance!=0);
      p.isEnemy[j]=p.isParticipating&&otherParticipates&&!p.isAlly[j];
    }
    if(i<8){
      const uint16_t sx=rd<uint16_t>((unsigned char*)g_scrGame,58928u+i*4u);
      const uint16_t sy=rd<uint16_t>((unsigned char*)g_scrGame,58928u+i*4u+2u);
      if(i==(unsigned)d.self&&sx&&sy){p.startLocationX=(int)sx/32-2;p.startLocationY=(int)sy/32-1;}
    }
    if(d.enemy<0&&p.isParticipating&&i!=(unsigned)d.self&&p.isEnemy[d.self])d.enemy=(int)i;
  }
  if(logValues){
    logLine("gamedata.relations=BOUND_REAL_SCR gameType="+std::to_string((int)gameType)+" forceCount="+std::to_string(d.forceCount)+" self="+std::to_string(d.self)+" enemy="+std::to_string(d.enemy));
    for(unsigned i=0;i<8;++i)if(d.players[i].isParticipating){
      auto*raw=(unsigned char*)(uintptr_t)(g_scrPlayers+i*36u);
      logLine("gamedata.relation.player["+std::to_string(i)+"].type="+std::to_string((int)d.players[i].type)+" race="+std::to_string((int)d.players[i].race)+" team="+std::to_string((int)rd<uint8_t>(raw,10))+" force="+std::to_string((int)d.players[i].force)+" ally_to_self="+std::to_string((int)d.players[i].isAlly[d.self])+" enemy_to_self="+std::to_string((int)d.players[i].isEnemy[d.self]));
    }
  }
  return d.self>=0&&d.self<8&&d.players[d.self].isParticipating;
}

static bool patchPlutoLegacyPlayersOperands(HMODULE pluto){
  if(!g_legacyPlayersShadow){logLine("reloc97.players_exact=NO_SHADOW");return false;}
  auto*base=(unsigned char*)pluto;size_t found=0,patched=0;uint32_t minRva=0xffffffffu,maxRva=0;
  for(const auto& b:pluto_bindings){
    if(b.expected<kLegacyPlayersBase || b.expected>=kLegacyPlayersBase+kLegacyPlayersBytes)continue;
    ++found;minRva=std::min(minRva,b.rva);maxRva=std::max(maxRva,b.rva);
    if(!readable(base+b.rva,4)){logLine("reloc97.players_exact=RVA_UNREADABLE rva="+std::to_string(b.rva));return false;}
    uint32_t cur=0;memcpy(&cur,base+b.rva,4);
    if(cur!=b.expected){logLine("reloc97.players_exact=MISMATCH rva="+std::to_string(b.rva)+" expected="+std::to_string(b.expected)+" got="+std::to_string(cur));return false;}
    const uint32_t nv=(uint32_t)((uintptr_t)g_legacyPlayersShadow+(uintptr_t)(b.expected-kLegacyPlayersBase));
    DWORD old=0;if(!VirtualProtect(base+b.rva,4,PAGE_EXECUTE_READWRITE,&old)){logLine("reloc97.players_exact=PROTECT_FAIL");return false;}
    memcpy(base+b.rva,&nv,4);FlushInstructionCache(GetCurrentProcess(),base+b.rva,4);DWORD tmp=0;VirtualProtect(base+b.rva,4,old,&tmp);++patched;
  }
  logLine("reloc97.players_exact.found="+std::to_string(found));
  logLine("reloc97.players_exact.rva_min="+std::to_string(minRva)+" rva_max="+std::to_string(maxRva));
  logLine("reloc97.players_exact.patched="+std::to_string(patched));
  if(found!=25 || patched!=found){logLine("reloc97.players_exact=VALIDATION_FAIL");return false;}
  logLine("reloc97.players_operands=PASS_EXACT_BINDINGS");return true;
}

static bool refreshLegacyCommandEnvironment(){
  // SCR profile: is_multiplayer is a byte at analyzed VA 0x123F7BC.
  uintptr_t mpSlot=profileSlotVA(0x0123F7BCu);
  if(!mpSlot||!readable((void*)mpSlot,1))return false;
  uint8_t mp=0;memcpy(&mp,(void*)mpSlot,1);
  g_legacyMultiplayerFlag=mp?1u:0u;
  g_legacyGameModeWord=2; // matches BWAPI/legacy-view game type used by the pinned Pluto port
  return true;
}

static bool patchPlutoLegacyCommandAbi(HMODULE pluto){
  if(!refreshLegacyCommandEnvironment()){logLine("reloc97.command_abi=SCR_ENV_UNREADABLE");return false;}
  auto*base=(unsigned char*)pluto;
  size_t found=0,patched=0,c59688c=0,c596904=0,c654880=0,c654aa0=0,c485a40=0;
  for(const auto& b:pluto_bindings){
    uint32_t nv=0;bool use=true;
    switch(b.expected){
      case 0x0059688cu:nv=(uint32_t)(uintptr_t)&g_legacyMultiplayerFlag;++c59688c;break;
      case 0x00596904u:nv=(uint32_t)(uintptr_t)&g_legacyGameModeWord;++c596904;break;
      case 0x00654880u:nv=(uint32_t)(uintptr_t)g_legacyCommandBuffer;++c654880;break;
      case 0x00654aa0u:nv=(uint32_t)(uintptr_t)&g_legacyCommandSize;++c654aa0;break;
      case 0x00485a40u:nv=(uint32_t)(uintptr_t)&legacyCommandFlushStub;++c485a40;break;
      default:use=false;break;
    }
    if(!use)continue;++found;
    if(!readable(base+b.rva,4)){logLine("reloc97.command_abi=RVA_UNREADABLE rva="+std::to_string(b.rva));return false;}
    uint32_t cur=0;memcpy(&cur,base+b.rva,4);
    if(cur!=b.expected){logLine("reloc97.command_abi=MISMATCH rva="+std::to_string(b.rva)+" expected="+std::to_string(b.expected)+" got="+std::to_string(cur));return false;}
    DWORD old=0;if(!VirtualProtect(base+b.rva,4,PAGE_EXECUTE_READWRITE,&old)){logLine("reloc97.command_abi=PROTECT_FAIL");return false;}
    memcpy(base+b.rva,&nv,4);FlushInstructionCache(GetCurrentProcess(),base+b.rva,4);DWORD tmp=0;VirtualProtect(base+b.rva,4,old,&tmp);++patched;
  }
  logLine("reloc97.command_abi.found="+std::to_string(found)+" patched="+std::to_string(patched));
  logLine("reloc97.command_abi.counts.59688c="+std::to_string(c59688c)+" 596904="+std::to_string(c596904)+" 654880="+std::to_string(c654880)+" 654aa0="+std::to_string(c654aa0)+" 485a40="+std::to_string(c485a40));
  logLine("legacy_command.multiplayer="+std::to_string(g_legacyMultiplayerFlag)+" game_mode_word="+std::to_string((unsigned)g_legacyGameModeWord));
  if(c59688c!=2||c596904!=2||c654880!=4||c654aa0!=8||c485a40!=2||patched!=found){logLine("reloc97.command_abi=VALIDATION_FAIL");return false;}
  g_legacyCommandSize=0;g_legacyFlushCount=0;g_legacyFlushOverflow=0;
  memset(g_legacyCommandBuffer,0,sizeof(g_legacyCommandBuffer));memset(g_legacyFlushSizes,0,sizeof(g_legacyFlushSizes));memset(g_legacyFlushBuffers,0,sizeof(g_legacyFlushBuffers));
  logLine("reloc97.command_abi=PASS_EXACT_BINDINGS");
  return true;
}

static std::string hexPrefix(const unsigned char* p,size_t n,size_t cap=96){
  std::ostringstream ss;const char*hex="0123456789ABCDEF";size_t m=std::min(n,cap);
  for(size_t i=0;i<m;i++){ss<<hex[p[i]>>4]<<hex[p[i]&15];}
  if(n>m)ss<<"...";return ss.str();
}

static std::string packetHex(const ScrPacket& p){return hexPrefix(p.data(),p.size(),256);}
static bool translateAndValidateLegacyCommands(uint32_t frame){
  if(g_legacyFlushOverflow){logLine("legacy_command_flush=CAPTURE_OVERFLOW_FAIL_CLOSED");return false;}
  std::vector<ScrPacket> all;LONG flushes=g_legacyFlushCount;
  if(flushes<0||flushes>kMaxCapturedFlushes){logLine("legacy_command_flush=COUNT_INVALID_FAIL_CLOSED");return false;}
  for(LONG i=0;i<flushes;++i){
    const uint32_t n=g_legacyFlushSizes[i];if(n>512u){logLine("legacy_command_flush=OVERFLOW_FAIL_CLOSED");return false;}
    if(!n)continue;
    const LONG detailSeq=InterlockedCompareExchange(&g_translateLogSequence,0,0)+1;
    if(detailSeq<=12 || (detailSeq%32)==0){logLine("legacy_command_flush.legacy_bytes="+std::to_string(n)+" frame="+std::to_string(frame));logLine("legacy_command_flush.legacy_hex="+hexPrefix(g_legacyFlushBuffers[i],n));}
    std::vector<ScrPacket> packets;std::string error;
    if(!translateLegacyCommands(g_legacyFlushBuffers[i],n,packets,error)){logLine("legacy_command_flush.translate=FAIL_CLOSED "+error);return false;}
    for(auto& p:packets)all.push_back(std::move(p));
  }
  const uint32_t n=g_legacyCommandSize;
  if(n>512u){logLine("legacy_command_queue=OVERFLOW_FAIL_CLOSED bytes="+std::to_string(n));return false;}
  if(n){
    const LONG detailSeq=InterlockedCompareExchange(&g_translateLogSequence,0,0)+1;
    if(detailSeq<=12 || (detailSeq%32)==0){logLine("original_pluto.legacy_command_bytes="+std::to_string(n)+" frame="+std::to_string(frame));logLine("original_pluto.legacy_command_hex="+hexPrefix(g_legacyCommandBuffer,n));}
    std::vector<ScrPacket> packets;std::string error;
    if(!translateLegacyCommands(g_legacyCommandBuffer,n,packets,error)){logLine("scr_command_translation=FAIL_CLOSED "+error);return false;}
    for(auto& p:packets)all.push_back(std::move(p));
  }
  if(!all.empty()){
    const LONG seq=InterlockedIncrement(&g_translateLogSequence);
    const bool verbose=seq<=12 || (seq%32)==0;
    if(verbose){
      logLine("scr_command_translation=PASS seq="+std::to_string((long)seq)+" packets="+std::to_string(all.size())+" frame="+std::to_string(frame));
      for(size_t i=0;i<all.size();++i)logLine("scr_command_packet["+std::to_string(i)+"]="+packetHex(all[i]));
    }
    const size_t queued=all.size();
    if(!queueTranslatedTurn(frame,std::move(all))){logLine("scr_command_sink=QUEUE_FAIL_CLOSED");return false;}
    if(verbose)logLine("scr_command_sink=QUEUED_FOR_GAME_THREAD packets="+std::to_string(queued)+" frame="+std::to_string(frame));
  }
  g_legacyCommandSize=0;g_legacyFlushCount=0;g_legacyFlushOverflow=0;
  memset(g_legacyCommandBuffer,0,sizeof(g_legacyCommandBuffer));memset(g_legacyFlushSizes,0,sizeof(g_legacyFlushSizes));memset(g_legacyFlushBuffers,0,sizeof(g_legacyFlushBuffers));
  return true;
}

static int profileLocalPlayerCandidate(){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return -1;
  uintptr_t slot=(uintptr_t)exe+(0x00FCACF4u-0x004A0000u);
  if(!readable((void*)slot,4))return -1;
  uint32_t v=0;memcpy(&v,(void*)slot,4);return v<8?(int)v:-1;
}

static uint32_t profileActiveTileCandidate(){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return 0;
  g_activeTileProfileSlot=(uintptr_t)exe+(0x01049478u-0x004A0000u);
  if(!readable((void*)g_activeTileProfileSlot,4))return 0;
  uint32_t p=0;memcpy(&p,(void*)g_activeTileProfileSlot,4);return p;
}

static bool readableNonExecSpan(uintptr_t begin,size_t bytes,unsigned*regionsOut=nullptr){
  if(regionsOut)*regionsOut=0;if(!begin||!bytes)return false;
  const uintptr_t end=begin+(uintptr_t)bytes;if(end<begin)return false;
  uintptr_t cur=begin;unsigned regions=0;
  while(cur<end){
    MEMORY_BASIC_INFORMATION mi{};if(!VirtualQuery((void*)cur,&mi,sizeof(mi)))return false;
    if(mi.State!=MEM_COMMIT||(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
    if(mi.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY))return false;
    const uintptr_t re=(uintptr_t)mi.BaseAddress+(uintptr_t)mi.RegionSize;if(re<=cur)return false;
    cur=std::min(end,re);++regions;if(regions>64)return false;
  }
  if(regionsOut)*regionsOut=regions;return true;
}

static int scoreActiveTileCandidate(uint32_t p,int w,int h,const UnitStore& store,int local,int* checkedOut=nullptr,int* visibleOut=nullptr){
  if(checkedOut)*checkedOut=0;if(visibleOut)*visibleOut=0;
  if(!p||w<=0||h<=0||w>256||h>256)return -1;
  const size_t count=(size_t)w*(size_t)h,bytes=count*4u;unsigned regions=0;
  // The profile slot is the authoritative source. Validate the complete map-tile
  // buffer as committed, non-executable data even if it crosses VM regions.
  if(!readableNonExecSpan((uintptr_t)p,bytes,&regions))return -1;
  std::unordered_set<uint32_t> distinct;
  const size_t step=std::max<size_t>(1,count/1024u);
  for(size_t i=0;i<count;i+=step){
    uint32_t v=0;memcpy(&v,(void*)((uintptr_t)p+i*4u),4);distinct.insert(v);
    if(distinct.size()>256)break;
  }
  if(distinct.size()<2)return -1;
  int score=300+(int)std::min<size_t>(distinct.size(),128u)+(int)std::min<unsigned>(regions,8u)*4;
  // Own-unit visibility is only a diagnostic cross-check. It must not reject
  // the verified profile pointer because unit ownership/list membership can
  // legitimately differ during setup, observers, team games, and transitions.
  int checked=0,visible=0;
  if(local>=0&&local<8){
    auto raws=collectPresentRaw(store);
    for(uintptr_t raw:raws){
      auto*u=(unsigned char*)raw;if(rd<uint8_t>(u,0x4c)!=(uint8_t)local)continue;
      int x=rd<int16_t>(u,0x28),y=rd<int16_t>(u,0x2a),tx=x/32,ty=y/32;
      if(tx<0||tx>=w||ty<0||ty>=h)continue;
      uint32_t f=0;memcpy(&f,(void*)((uintptr_t)p+4u*((size_t)ty*(size_t)w+(size_t)tx)),4);
      ++checked;if((f&(1u<<local))==0)++visible;if(checked>=64)break;
    }
    if(checked>=2 && visible*100>=checked*70)score+=visible*4;
  }
  if(checkedOut)*checkedOut=checked;if(visibleOut)*visibleOut=visible;
  return score;
}

static bool resolveActiveTileArray(const UnitStore& store,int w,int h){
  const int local=profileLocalPlayerCandidate();
  const uint32_t cand=profileActiveTileCandidate();int checked=0,visible=0;
  const int score=scoreActiveTileCandidate(cand,w,h,store,local,&checked,&visible);
  logLine("active_tile.profile_slot="+std::to_string((unsigned long)g_activeTileProfileSlot));
  logLine("active_tile.profile_candidate="+std::to_string((unsigned long)cand)+" score="+std::to_string(score));
  logLine("active_tile.validation_mode=PROFILE_STRUCTURAL_NONEXEC_SPAN");
  logLine("active_tile.local_player="+std::to_string(local)+" own_checked="+std::to_string(checked)+" visible_hits="+std::to_string(visible));
  if(score<300){logLine("active_tile.select=REJECTED");return false;}
  g_scrActiveTileArray=cand;g_legacyActiveTilePtr=cand;
  logLine("active_tile.select=PROFILE_VALIDATED");
  logLine("active_tile.ptr="+std::to_string((unsigned long)g_scrActiveTileArray));
  return true;
}

static bool refreshActiveTileArray(int w,int h,const UnitStore& store){
  if(!g_activeTileProfileSlot||!readable((void*)g_activeTileProfileSlot,4))return false;
  uint32_t now=0;memcpy(&now,(void*)g_activeTileProfileSlot,4);
  if(now!=g_scrActiveTileArray){
    int checked=0,visible=0;int local=profileLocalPlayerCandidate();
    int score=scoreActiveTileCandidate(now,w,h,store,local,&checked,&visible);
    logLine("active_tile.pointer_changed="+std::to_string((unsigned long)g_scrActiveTileArray)+"->"+std::to_string((unsigned long)now)+" score="+std::to_string(score));
    if(score<300)return false;g_scrActiveTileArray=now;
  }
  g_legacyActiveTilePtr=g_scrActiveTileArray;return true;
}


#pragma pack(push,1)
struct Legacy57F1Compat {
  unsigned char pad0[0x1D4];
  short value_f1d4;
  short value_f1d6;
  unsigned char pad1[0x64];
  unsigned long value_f23c;
};
#pragma pack(pop)
static Legacy57F1Compat g_legacy57f1{};

static bool patchAbs32(unsigned char* insn,int immOff,const unsigned char* sig,int sigLen,uintptr_t target,const char* tag){
  if(memcmp(insn,sig,sigLen)!=0){logLine(std::string("reloc97.")+tag+".signature=MISMATCH");return false;}
  if(target>0xFFFFFFFFu){logLine(std::string("reloc97.")+tag+".target=OUT_OF_X86_RANGE");return false;}
  DWORD old=0;if(!VirtualProtect(insn,sigLen,PAGE_EXECUTE_READWRITE,&old)){logLine(std::string("reloc97.")+tag+".protect=FAIL");return false;}
  uint32_t v=(uint32_t)target;memcpy(insn+immOff,&v,4);FlushInstructionCache(GetCurrentProcess(),insn,sigLen);
  DWORD tmp=0;VirtualProtect(insn,sigLen,old,&tmp);
  logLine(std::string("reloc97.")+tag+"=PASS");return true;
}
static bool patchPlutoLegacy57F1Block(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char s1[5]={0xA1,0x3C,0xF2,0x57,0x00};
  const unsigned char s2[7]={0x0F,0xBF,0x05,0xD4,0xF1,0x57,0x00};
  const unsigned char s3[7]={0x0F,0xBF,0x15,0xD6,0xF1,0x57,0x00};
  bool a=patchAbs32(b+0xBC1B,1,s1,5,(uintptr_t)&g_legacy57f1.value_f23c,"rva_bc1b_f23c");
  bool c=patchAbs32(b+0xBC26,3,s2,7,(uintptr_t)&g_legacy57f1.value_f1d4,"rva_bc26_f1d4");
  bool d=patchAbs32(b+0xBC33,3,s3,7,(uintptr_t)&g_legacy57f1.value_f1d6,"rva_bc33_f1d6");
  return a&&c&&d;
}

static bool patchOperand32(HMODULE pluto,uint32_t rva,uint32_t expected,uint32_t value,const char* tag){
  unsigned char* p=(unsigned char*)pluto+rva;
  uint32_t cur=0;memcpy(&cur,p,4);
  if(cur!=expected){
    std::ostringstream os;os<<"reloc97."<<tag<<".expected="<<expected<<" actual="<<cur;logLine(os.str());
    return false;
  }
  DWORD old=0;if(!VirtualProtect(p,4,PAGE_EXECUTE_READWRITE,&old)){logLine(std::string("reloc97.")+tag+".protect=FAIL");return false;}
  memcpy(p,&value,4);FlushInstructionCache(GetCurrentProcess(),p,4);
  DWORD tmp=0;VirtualProtect(p,4,old,&tmp);
  logLine(std::string("reloc97.")+tag+"=PASS");return true;
}

static bool patchPlutoLegacyStartGlobals(HMODULE pluto){
  const int local=profileLocalPlayerCandidate();
  if(local<0||local>=8){logLine("legacy_start.local_player=UNRESOLVED");return false;}
  g_legacyLocalPlayerId=(uint32_t)local;
  memset(g_legacyStartSelection,0,sizeof(g_legacyStartSelection));
  logLine("legacy_start.local_player="+std::to_string(local));
  bool ok=true;
  uintptr_t lp=(uintptr_t)&g_legacyLocalPlayerId;
  if(lp>0xFFFFFFFFu){logLine("reloc97.start_globals=OUT_OF_X86_RANGE");return false;}
  ok=patchOperand32(pluto,0x14BF,0x00512688u,(uint32_t)lp,"rva_14bf_512688")&&ok;
  struct StartCell{uint32_t rva;uint32_t old;};
  static const StartCell cells[]={
    {0x1542,0x005124D8u},{0x154C,0x005124F4u},{0x1556,0x005124DCu},{0x1560,0x005124F8u},
    {0x156A,0x005124E0u},{0x1574,0x005124FCu},{0x157E,0x005124E4u},{0x1588,0x00512500u},
    {0x1592,0x005124E8u},{0x159C,0x00512504u},{0x15A6,0x005124ECu},{0x15B0,0x00512508u},
    {0x15BA,0x005124F0u},{0x15C4,0x0051250Cu}
  };
  for(const auto& c:cells){
    const uint32_t off=c.old-0x005124D8u;
    uintptr_t target=(uintptr_t)g_legacyStartSelection+off;
    if(target>0xFFFFFFFFu){logLine("reloc97.start_globals.cell=OUT_OF_X86_RANGE");return false;}
    std::ostringstream tag;tag<<"rva_"<<std::hex<<c.rva<<"_start_"<<c.old;
    ok=patchOperand32(pluto,c.rva,c.old,(uint32_t)target,tag.str().c_str())&&ok;
  }
  logLine(std::string("reloc97.start_globals=")+(ok?"PASS":"FAIL"));
  return ok;
}

static bool patchPlutoLegacyGameOperands(HMODULE pluto){
  if(!g_legacyGameShadow){logLine("reloc97.game_exact=NO_SHADOW");return false;}
  auto*base=(unsigned char*)pluto;size_t found=0,patched=0;uint32_t minRva=0xffffffffu,maxRva=0;size_t early=0;
  bool aFrame=false,aMapW=false,aMapH=false,aUpgrade=false,aLegacy7536=false;
  for(const auto& b:pluto_bindings){
    if(b.expected<kLegacyGameBase || b.expected>=kLegacyGameBase+kScrGameSize)continue;
    ++found;minRva=std::min(minRva,b.rva);maxRva=std::max(maxRva,b.rva);if(b.rva<0x30000u)++early;
    if(b.expected==0x0057F23Cu)aFrame=true;if(b.expected==0x0057F1D4u)aMapW=true;if(b.expected==0x0057F1D6u)aMapH=true;
    if(b.expected==0x0058D2B0u)aUpgrade=true;if(b.expected==0x0057FD3Cu)aLegacy7536=true;
    if(!readable(base+b.rva,4)){logLine("reloc97.game_exact=RVA_UNREADABLE rva="+std::to_string(b.rva));return false;}
    uint32_t cur=0;memcpy(&cur,base+b.rva,4);
    if(cur!=b.expected){logLine("reloc97.game_exact=MISMATCH rva="+std::to_string(b.rva)+" expected="+std::to_string(b.expected)+" got="+std::to_string(cur));return false;}
    const uint32_t nv=(uint32_t)((uintptr_t)g_legacyGameShadow+(uintptr_t)(b.expected-kLegacyGameBase));
    DWORD old=0;if(!VirtualProtect(base+b.rva,4,PAGE_EXECUTE_READWRITE,&old)){logLine("reloc97.game_exact=PROTECT_FAIL");return false;}
    memcpy(base+b.rva,&nv,4);FlushInstructionCache(GetCurrentProcess(),base+b.rva,4);DWORD tmp=0;VirtualProtect(base+b.rva,4,old,&tmp);++patched;
  }
  logLine("reloc97.game_exact.found="+std::to_string(found));
  logLine("reloc97.game_exact.rva_min="+std::to_string(minRva)+" rva_max="+std::to_string(maxRva)+" early_lt_30000="+std::to_string(early));
  logLine("reloc97.game_exact.anchor.frame="+std::string(aFrame?"YES":"NO")+" mapw="+(aMapW?std::string("YES"):std::string("NO"))+" maph="+(aMapH?std::string("YES"):std::string("NO"))+" upgrade="+(aUpgrade?std::string("YES"):std::string("NO"))+" legacy7536="+(aLegacy7536?std::string("YES"):std::string("NO")));
  logLine("reloc97.game_exact.patched="+std::to_string(patched));
  if(found<100 || patched!=found || !aFrame||!aMapW||!aMapH||!aUpgrade||!aLegacy7536){logLine("reloc97.game_exact=VALIDATION_FAIL");return false;}
  logLine("reloc97.game_operands=PASS_EXACT_BINDINGS");return true;
}

static bool patchPlutoCUnitHead628430(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sigEbx[6]={0x8B,0x1D,0x30,0x84,0x62,0x00};
  const unsigned char sigEdi[6]={0x8B,0x3D,0x30,0x84,0x62,0x00};
  const uintptr_t target=(uintptr_t)&g_scrVisibleUnitHead;
  bool a=patchAbs32(b+0x33F7D,2,sigEbx,6,target,"rva_33f7d_628430");
  bool c=patchAbs32(b+0xBD6B,2,sigEbx,6,target,"rva_bd6b_628430");
  bool d=patchAbs32(b+0x3B787,2,sigEdi,6,target,"rva_3b787_628430");
  return a&&c&&d;
}

static bool patchPlutoUnitNodeTableBase(HMODULE pluto){
  if(g_legacyCUnits.empty()){logLine("reloc97.unit_table=NO_SHADOW_UNITS");return false;}
  uintptr_t basePtr=(uintptr_t)&g_legacyCUnits[0];
  if(basePtr>0xFFFFFFFFu || basePtr+0xA5u>0xFFFFFFFFu){logLine("reloc97.unit_table=OUT_OF_X86_RANGE");return false;}
  uint32_t base=(uint32_t)basePtr;
  uint32_t negBase=0u-base;
  uint32_t generationBase=base+0xA5u;
  logLine("reloc97.unit_table.shadow_base="+std::to_string((unsigned long)base));
  bool ok=true;
  // Pluto computes unit slot indices by adding/subtracting BW 1.16.1's
  // UnitNodeTable base (0x59CCA8). Redirect only those validated operands
  // to the start of our contiguous 336-byte legacy CUnit shadow.
  ok=patchOperand32(pluto,0xAAF4,0xFFA63358u,negBase,"rva_aaf4_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0xAB44,0xFFA63358u,negBase,"rva_ab44_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3134B,0x0059CD4Du,generationBase,"rva_3134b_59cd4d")&&ok;
  ok=patchOperand32(pluto,0x31351,0x0059CCA8u,base,"rva_31351_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3408D,0xFFA63358u,negBase,"rva_3408d_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x341B4,0xFFA63358u,negBase,"rva_341b4_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x343D8,0xFFA63358u,negBase,"rva_343d8_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3C2D9,0x0059CD4Du,generationBase,"rva_3c2d9_59cd4d")&&ok;
  ok=patchOperand32(pluto,0x3C2DE,0x0059CCA8u,base,"rva_3c2de_59cca8")&&ok;
  logLine(std::string("reloc97.unit_table=")+(ok?"PASS":"FAIL"));
  return ok;
}

static bool patchPlutoCUnitHead6283EC(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x2D,0xEC,0x83,0x62,0x00};
  return patchAbs32(b+0x34149,2,sig,6,(uintptr_t)&g_scrHiddenUnitHead,"rva_34149_6283ec");
}

static bool patchPlutoCUnitHead6283F4(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x2D,0xF4,0x83,0x62,0x00};
  return patchAbs32(b+0x34250,2,sig,6,(uintptr_t)&g_scrScannerSweepHead,"rva_34250_6283f4");
}


static bool projectRealMapVisibility(BWAPI::GameData&d){
  if(!g_scrActiveTileArray||d.self<0||d.self>=8||d.mapWidth<=0||d.mapWidth>256||d.mapHeight<=0||d.mapHeight>256)return false;
  const size_t count=(size_t)d.mapWidth*(size_t)d.mapHeight;
  if(!readableNonExecSpan(g_scrActiveTileArray,count*4u,nullptr))return false;
  for(int y=0;y<d.mapHeight;++y)for(int x=0;x<d.mapWidth;++x){
    uint32_t f=0;std::memcpy(&f,(void*)(g_scrActiveTileArray+4u*((size_t)y*(size_t)d.mapWidth+(size_t)x)),4);
    d.isVisible[x][y]=(f&(1u<<d.self))==0;
    d.isExplored[x][y]=(f&(1u<<(d.self+8)))==0;
    d.hasCreep[x][y]=d.isVisible[x][y]&&(f&0x40400000u)!=0;
    d.isOccupied[x][y]=d.isVisible[x][y]&&(f&0x08000000u)!=0;
  }
  return true;
}

static bool patchPlutoActiveTileArray6D1260(HMODULE pluto){
  if(!g_scrActiveTileArray){logLine("reloc97.active_tile=NO_SCR_POINTER");return false;}
  uintptr_t cell=(uintptr_t)&g_legacyActiveTilePtr;
  if(cell>0xFFFFFFFFu){logLine("reloc97.active_tile=CELL_OUT_OF_X86_RANGE");return false;}
  bool ok=true;uint32_t target=(uint32_t)cell;
  ok=patchOperand32(pluto,0x342B7,0x006D1260u,target,"rva_342b7_6d1260")&&ok;
  ok=patchOperand32(pluto,0x3B657,0x006D1260u,target,"rva_3b657_6d1260")&&ok;
  ok=patchOperand32(pluto,0x3B6FD,0x006D1260u,target,"rva_3b6fd_6d1260")&&ok;
  logLine(std::string("reloc97.active_tile=")+(ok?"PASS":"FAIL"));return ok;
}

static bool patchPlutoBulletHead64DEC4(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x1D,0xC4,0xDE,0x64,0x00};
  return patchAbs32(b+0xBC75,2,sig,6,(uintptr_t)&g_legacyBulletHead,"rva_bc75_64dec4");
}

static unsigned char g_reloc57fd3c[0x10000]{};

static bool patchPlutoLegacy57FD3C(HMODULE pluto){
  unsigned char* p=(unsigned char*)pluto+0x7536;
  const unsigned char expect[7]={0x0F,0xB6,0x90,0x3C,0xFD,0x57,0x00};
  if(memcmp(p,expect,7)!=0){
    logLine("reloc_probe.rva_7536_signature=MISMATCH");
    return false;
  }
  // Preserve the exact instruction shape; change only its disp32.
  // movzx edx, byte ptr [eax + disp32]
  uintptr_t compat=(uintptr_t)g_reloc57fd3c;
  if(compat>0xFFFFFFFFu){
    logLine("reloc_probe.compat_ptr=OUT_OF_X86_RANGE");
    return false;
  }
  unsigned char repl[7]={0x0F,0xB6,0x90,0,0,0,0};
  uint32_t disp=(uint32_t)compat;
  memcpy(repl+3,&disp,4);
  DWORD old=0;
  if(!VirtualProtect(p,7,PAGE_EXECUTE_READWRITE,&old)){
    logLine("reloc_probe.virtualprotect=FAIL gle="+std::to_string(GetLastError()));
    return false;
  }
  memcpy(p,repl,7);
  FlushInstructionCache(GetCurrentProcess(),p,7);
  DWORD tmp=0;VirtualProtect(p,7,old,&tmp);
  logLine("reloc_probe.rva_7536_signature=PASS");
  logLine("reloc_probe.rva_7536_patched=PASS");
  logLine("reloc_probe.compat_base="+std::to_string((unsigned long)compat));
  return true;
}

static int mapLegacyPlutoDataPages(){
  // MEM_RESERVE base addresses must honor Windows allocation granularity (normally 64 KiB).
  // These four 64 KiB blocks cover every legacy absolute data page currently observed in Pluto.
  const uintptr_t blocks[]={0x00510000,0x00570000,0x00580000,0x00590000};
  int mapped=0;
  SYSTEM_INFO si{};GetSystemInfo(&si);
  logLine("legacy_probe.allocation_granularity="+std::to_string((unsigned long)si.dwAllocationGranularity));
  for(uintptr_t a:blocks){
    MEMORY_BASIC_INFORMATION mbi{};
    if(!VirtualQuery((LPCVOID)a,&mbi,sizeof(mbi))){
      logLine("legacy_probe.virtualquery_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(GetLastError()));
      continue;
    }
    if(mbi.State==MEM_FREE){
      void*p=VirtualAlloc((LPVOID)a,0x10000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
      if(p==(void*)a){
        ++mapped;
        logLine("legacy_probe.mapped_block="+std::to_string((unsigned long)a));
      }else{
        DWORD gle=GetLastError();
        logLine("legacy_probe.map_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(gle));
        if(p)VirtualFree(p,0,MEM_RELEASE);
      }
    }else{
      logLine("legacy_probe.block_occupied="+std::to_string((unsigned long)a)+
              " state="+std::to_string((unsigned long)mbi.State)+
              " base="+std::to_string((unsigned long)(uintptr_t)mbi.BaseAddress)+
              " size="+std::to_string((unsigned long)mbi.RegionSize));
    }
  }
  return mapped;
}

static DWORD findLegacyCUnitVectorSeh(UnitStore*out){__try{*out=findLegacyCUnitVector();return 0;}__except(EXCEPTION_EXECUTE_HANDLER){return GetExceptionCode();}}
static DWORD WINAPI boot(LPVOID){
  if(!openPersistentLog())return 90;
  logLine("BOOTSTRAP_LOG=PASS_SHARED_WIN32_HANDLE");
  logLine("PLUTOSCR_V97_RESIDENT=LOADED");logLine("architecture=x86");logLine("policy=original-pluto-observation-untouched");logLine("stability97=v96-multi-match+real-scr-player-relations+alliance-matrix+team-force-state");
  logLine("checkpoint.boot.before_cunit_scan");
  UnitStore store{};
  DWORD scanEc=findLegacyCUnitVectorSeh(&store);
  if(scanEc){logLine("checkpoint.cunit_scan.SEH_EXCEPTION code="+std::to_string(scanEc));return 12;}
  logLine("checkpoint.boot.after_cunit_scan");
  logLine("scr_cunit_vector.descriptor="+std::to_string((unsigned long)store.descriptor));logLine("scr_cunit_vector.score="+std::to_string(store.score));
  if(store.score<2){logLine("scr_cunit_vector=UNRESOLVED");return 10;} logLine("scr_cunit_vector=BOUND");
  logLine("cunit_store.begin="+std::to_string((unsigned long)store.begin)+" end="+std::to_string((unsigned long)store.end)+" cap="+std::to_string((unsigned long)store.cap));
  const std::wstring d=dirOfW(g_self);
  SetCurrentDirectoryW(d.c_str());SetDllDirectoryW(d.c_str());
  const bool runtimeReady=ensureOriginalPlutoRuntimeLayout(d);
  const std::wstring plutoDll=d+L"\\pluto.dll";
  HMODULE pluto=LoadLibraryW(plutoDll.c_str());if(!pluto){logLine("original_pluto.load=FAIL error="+std::to_string(GetLastError()));return 1;}logLine("original_pluto.load=PASS");
  wchar_t plutoPath[32768]={};DWORD plutoPathLen=GetModuleFileNameW(pluto,plutoPath,(DWORD)(sizeof(plutoPath)/sizeof(plutoPath[0])));std::wstring plutoDir(plutoPath,plutoPathLen);auto ps=plutoDir.find_last_of(L"\\/");if(ps!=std::wstring::npos)plutoDir=plutoDir.substr(0,ps);
  std::wstring inferPath=plutoDir+L"\\pluto\\pluto_infer.exe";std::wstring weightsPath=plutoDir+L"\\pluto\\pluto_weights.bin";
  logLine("pluto.module_path_utf8="+utf8(std::wstring(plutoPath,plutoPathLen)));
  logLine("pluto_runtime.ready="+std::string(runtimeReady?"YES":"NO"));
  logLine("pluto_infer.file_size="+std::to_string(fileSizeOrZero(inferPath)));
  logLine("pluto_weights.file_size="+std::to_string(fileSizeOrZero(weightsPath)));
  if(!runtimeReady || fileSizeOrZero(inferPath)==0 || fileSizeOrZero(weightsPath)==0){logLine("pluto_runtime=REJECTED_MISSING_ORIGINAL_INFERENCE_FILES");return 1;}
  int inferBeforeStart=countProcessByName(L"pluto_infer.exe");logLine("pluto_infer.process_count.after_load="+std::to_string(inferBeforeStart));if(inferBeforeStart>0){logLine("pluto_infer.stale_process=REJECTED_FAIL_CLOSED");return 25;}
  auto gameInit=(PFNGameInit)GetProcAddress(pluto,"gameInit");auto createAI=(PFNCreateAI)GetProcAddress(pluto,"newAIModule");if(!gameInit||!createAI){logLine("original_pluto.exports=FAIL");return 2;}
  auto*data=new BWAPI::GameData();ZeroMemory(data,sizeof(*data));
  const int bootstrapSelf=profileLocalPlayerCandidate();if(bootstrapSelf<0||bootstrapSelf>=8){logLine("gamedata.bootstrap_self=UNRESOLVED_FAIL_CLOSED");return 26;}
  data->self=bootstrapSelf;data->neutral=11;
  int n=projectLiveUnits(store,*data);logLine("live_units="+std::to_string(n));if(n<2)return 11;
  g_scrGame=findScrGameBlock(n);
  if(!g_scrGame){logLine("legacy_game=UNRESOLVED_FAIL_CLOSED");return 13;}
  data->mapWidth=rd<uint16_t>((unsigned char*)g_scrGame,228);data->mapHeight=rd<uint16_t>((unsigned char*)g_scrGame,230);data->frameCount=rd<uint32_t>((unsigned char*)g_scrGame,332);
  logLine("scr_game.ptr="+std::to_string((unsigned long)g_scrGame));
  logLine("scr_game.mapWidth="+std::to_string(data->mapWidth)+" mapHeight="+std::to_string(data->mapHeight)+" frame="+std::to_string(data->frameCount));
  if(!allocateLegacyGameShadow()){logLine("legacy_game.alloc=FAIL_CLOSED");return 14;}
  if(!syncLegacyGameShadow(g_scrGame)){logLine("legacy_game.sync=FAIL_CLOSED");return 14;}
  logLine("legacy_game.shadow_base="+std::to_string((unsigned long)(uintptr_t)g_legacyGameShadow));
  logLine("legacy_game.shadow_size="+std::to_string((unsigned long)kScrGameSize));
  if(!patchPlutoLegacyGameOperands(pluto)){logLine("legacy_game.reloc=FAIL_CLOSED");return 22;}
  logLine("legacy_game=BOUND_RELOCATED_REAL_SCR_GAME");
  if(!resolveLegacyPlayers()){logLine("legacy_players=UNRESOLVED_FAIL_CLOSED");return 28;}
  if(!patchPlutoLegacyPlayersOperands(pluto)){logLine("legacy_players.reloc=FAIL_CLOSED");return 29;}
  logLine("legacy_players=BOUND_REAL_SCR_PLAYERS");
  // v97: use SCR's real participant/team/alliance matrix instead of guessing the first non-self slot.
  int self=profileLocalPlayerCandidate();
  if(self<0||self>=8){logLine("gamedata.self=UNRESOLVED_FAIL_CLOSED");return 26;}
  data->self=self;data->neutral=11;
  if(!projectRealPlayerRelations(*data,true)){logLine("gamedata.relations=UNRESOLVED_FAIL_CLOSED");return 30;}
  int enemy=data->enemy;data->isInGame=true;
  logLine("gamedata.initialUnitCount="+std::to_string(data->initialUnitCount));
  logLine("gamedata.playerCount="+std::to_string(data->playerCount));
  logLine("gamedata.self="+std::to_string(self)+" enemy="+std::to_string(enemy)+" neutral="+std::to_string(data->neutral));
  for(int p=0;p<12;p++)if(data->players[p].isParticipating){int pc=0;for(int u=0;u<data->initialUnitCount;u++)if(data->units[u].player==p)++pc;logLine("gamedata.player["+std::to_string(p)+"].units="+std::to_string(pc)+" race="+std::to_string(data->players[p].race));}
  logLine("gamedata.mapWidth="+std::to_string(data->mapWidth)+" mapHeight="+std::to_string(data->mapHeight));
  BWAPI::BWAPIClient.data=data;auto*game=new BWAPI::GameImpl(data);BWAPI::BroodwarPtr=game;logLine("checkpoint.gameimpl.constructed");
  gameInit(game);logLine("checkpoint.original_pluto.gameInit.PASS");auto*module=createAI();if(!module){logLine("original_pluto.newAIModule=FAIL");return 3;}logLine("checkpoint.original_pluto.newAIModule.PASS");
  game->onMatchStart();logLine("checkpoint.bwapi.onMatchStart.PASS");
  logLine("reloc_probe.mode=pluto-original-observation-real-scr-alliance-team-force-coherent-state-game-thread-send");
  // Do not patch 0x57F1xx/0x57FD3C to zero-filled compatibility buffers anymore.
  // Original Pluto now reads the actual SCR Game state through relocated legacy Game operands.
  int headLen=buildLegacyCUnitShadow(store);
  logLine("legacy_cunit_shadow.count="+std::to_string(headLen));
  if(!g_scrVisibleUnitHead || headLen<2){logLine("legacy_cunit_shadow=UNRESOLVED");return 15;}
  logLine("legacy_cunit_shadow=BOUND");
  bool reloc628430=patchPlutoCUnitHead628430(pluto);
  logLine(std::string("reloc97.patch_all_628430=")+(reloc628430?"PASS":"FAIL"));
  if(!reloc628430)return 16;
  bool relocUnitTable=patchPlutoUnitNodeTableBase(pluto);
  logLine(std::string("reloc97.patch_unit_table=")+(relocUnitTable?"PASS":"FAIL"));
  if(!relocUnitTable)return 21;
  bool reloc6283ec=patchPlutoCUnitHead6283EC(pluto);
  logLine(std::string("reloc97.patch_6283ec=")+(reloc6283ec?"PASS":"FAIL"));
  if(!reloc6283ec)return 17;
  bool reloc6283f4=patchPlutoCUnitHead6283F4(pluto);
  logLine(std::string("reloc97.patch_6283f4=")+(reloc6283f4?"PASS":"FAIL"));
  if(!reloc6283f4)return 18;
  if(!resolveActiveTileArray(store,data->mapWidth,data->mapHeight)){logLine("active_tile=UNRESOLVED_FAIL_CLOSED");return 23;}
  if(!patchPlutoActiveTileArray6D1260(pluto)){logLine("active_tile.reloc=FAIL_CLOSED");return 24;}
  logLine("active_tile=BOUND_REAL_SCR");
  if(!projectRealMapVisibility(*data)){logLine("gamedata.map_visibility=FAIL_CLOSED");return 30;}
  logLine("gamedata.map_visibility=BOUND_REAL_SCR");
  if(!buildLegacyBulletShadow()){logLine("profile_bullet=UNRESOLVED_FAIL_CLOSED");return 19;}
  logLine("profile_bullet_shadow=BOUND");
  bool reloc64dec4=patchPlutoBulletHead64DEC4(pluto);
  logLine(std::string("reloc97.patch_64dec4=")+(reloc64dec4?"PASS":"FAIL"));
  if(!reloc64dec4)return 20;
  if(!patchPlutoLegacyStartGlobals(pluto)){logLine("legacy_start_globals=FAIL_CLOSED");return 27;}
  logLine("legacy_start_globals=BOUND_REAL_LOCAL_PLAYER");
  if(!patchPlutoLegacyCommandAbi(pluto)){logLine("legacy_command_abi=FAIL_CLOSED");return 28;}
  logLine("legacy_command_abi=BOUND_TRANSLATION_GAME_THREAD_SEND");
  DWORD ec=onStartSeh(module);if(ec){
    logLine("original_pluto.onStart=SEH_EXCEPTION code="+std::to_string(ec));
    logLine("seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
    logLine("seh.eip="+std::to_string((unsigned long)g_sehEip));
    logLine("seh.access_type="+std::to_string((unsigned long)g_sehAccessType));
    logLine("seh.access_address="+std::to_string((unsigned long)g_sehAccessAddress));
    logLine("seh.regs.eax="+std::to_string((unsigned long)g_sehEax)+" ebx="+std::to_string((unsigned long)g_sehEbx)+" ecx="+std::to_string((unsigned long)g_sehEcx)+" edx="+std::to_string((unsigned long)g_sehEdx)+" esi="+std::to_string((unsigned long)g_sehEsi)+" edi="+std::to_string((unsigned long)g_sehEdi)+" ebp="+std::to_string((unsigned long)g_sehEbp)+" esp="+std::to_string((unsigned long)g_sehEsp));
    if(readable((void*)g_sehEip,16)){std::ostringstream hs;hs<<"seh.code16=";auto*q=(unsigned char*)g_sehEip;const char*hex="0123456789ABCDEF";for(int i=0;i<16;i++){hs<<hex[q[i]>>4]<<hex[q[i]&15];}logLine(hs.str());}
    uintptr_t pb=(uintptr_t)pluto;
    if(g_sehAddress>=pb)logLine("seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
    if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)logLine("seh.class=legacy_bw_absolute_address");
    else if(g_sehAddress>=pb)logLine("seh.class=pluto_code");
    else logLine("seh.class=other");
    return 4;
  }logLine("original_pluto.onStart=PASS");
  if(!installGameThreadCommandHook()){logLine("scr_command_sink=GAME_THREAD_HOOK_FAIL_CLOSED");return 29;}
  logLine("scr_command_sink=ARMED_GAME_THREAD_ONE_FRAME_DELAY");
  InterlockedExchange(&g_matchCommandsArmed,1);
  logLine("pluto_infer.process_count.after_onStart="+std::to_string(countProcessByName(L"pluto_infer.exe")));
  logLine("reloc_probe.onStart_with_real_local_player_and_relocated_game=PASS");
  unsigned matchGeneration=1;
  logLine("MATCH_START generation=1 frame="+std::to_string(data->frameCount));
  logLine("PLUTOSCR_V97_MULTI_MATCH_STABLE_LOOP=START");
  for(;;){
    int lastCmd=0;unsigned diagFrame=0;bool matchEndedNormally=false;unsigned inactiveStreak=0;
    while(true){
      const bool matchActiveNow=profileMatchActive();
      if(!matchActiveNow){
        ++inactiveStreak;
        if(diagFrame>=3 && inactiveStreak>=8){matchEndedNormally=true;logLine("MATCH_END_DETECTED generation="+std::to_string(matchGeneration)+" reason=game_loop_inactive_debounced streak="+std::to_string(inactiveStreak));break;}
        Sleep(42);continue;
      }
      inactiveStreak=0;
    ++diagFrame; if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_sleep");
    Sleep(42);if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_sleep");
    std::vector<uintptr_t> framePresent;uint32_t coherentFrame=0;
    if(!collectCoherentPresentRaw(store,framePresent,coherentFrame)){
      if(!profileMatchActive()){matchEndedNormally=true;logLine("MATCH_END_DETECTED generation="+std::to_string(matchGeneration)+" reason=state_unavailable");break;}
      if(diagFrame<=3||diagFrame%120==0)logLine("cunit_snapshot=FRAME_CHANGED_RETRY_SKIP");
      continue;
    }
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].cunit_snapshot frame="+std::to_string(coherentFrame)+" present="+std::to_string(framePresent.size()));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_projectLiveUnits");
    data->self=profileLocalPlayerCandidate();if(data->self<0||data->self>=8){logLine("gamedata.self.live=UNRESOLVED_FAIL_CLOSED");break;}
    int live=projectLiveUnitsFromPresent(framePresent,*data);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_projectLiveUnits live="+std::to_string(live));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_shadow_refresh");
    int shadowLive=refreshLegacyCUnitShadowFromPresent(store,framePresent);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_shadow_refresh live="+std::to_string(shadowLive));
    if(shadowLive!=(int)framePresent.size()){logLine("cunit_snapshot=SHADOW_COUNT_MISMATCH_FAIL_CLOSED "+std::to_string(shadowLive)+"/"+std::to_string(framePresent.size()));break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].gamedata_accessible="+std::to_string(live)+" legacy_present="+std::to_string(shadowLive));
    if(live<2){if(!profileMatchActive()){matchEndedNormally=true;logLine("MATCH_END_DETECTED generation="+std::to_string(matchGeneration)+" reason=units_gone");break;}logLine("live_units_transient_lt2=SKIP");continue;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_game_shadow_refresh");
    if(!syncLegacyGameShadow(g_scrGame)){logLine("legacy_game.live_refresh=FAIL_CLOSED");break;}
    data->mapWidth=rd<uint16_t>((unsigned char*)g_scrGame,228);data->mapHeight=rd<uint16_t>((unsigned char*)g_scrGame,230);data->frameCount=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_game_shadow_refresh frame="+std::to_string(data->frameCount));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_active_tile_refresh");
    if(!refreshActiveTileArray(data->mapWidth,data->mapHeight,store)){logLine("active_tile.live_refresh=FAIL_CLOSED");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_active_tile_refresh ptr="+std::to_string((unsigned long)g_scrActiveTileArray));
    if(!projectRealMapVisibility(*data)){logLine("gamedata.map_visibility.live_refresh=FAIL_CLOSED");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].map_visibility=REAL_SCR");
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_bullet_refresh");
    if(!refreshLegacyBulletShadow()){logLine("profile_bullet.live_refresh=FAIL_CLOSED");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_bullet_refresh active="+std::to_string(g_legacyRawBullets.size()));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_players_refresh");
    if(!refreshLegacyPlayers()){logLine("legacy_players.live_refresh=FAIL_CLOSED");break;}
    if(!projectRealPlayerRelations(*data,false)){logLine("gamedata.relations.live_refresh=FAIL_CLOSED");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_players_refresh enemy="+std::to_string(data->enemy));
    const uint32_t finalObservationFrame=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(finalObservationFrame!=coherentFrame){
      if(diagFrame<=3||diagFrame%120==0)logLine("observation_snapshot=FRAME_DRIFT_DISCARDED start="+std::to_string(coherentFrame)+" end="+std::to_string(finalObservationFrame));
      continue;
    }
    data->frameCount=coherentFrame;
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].observation_snapshot=COHERENT frame="+std::to_string(coherentFrame));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_bwapi_onMatchFrame");
    game->onMatchFrame();
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_bwapi_onMatchFrame");
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].pluto_infer.process_count.before_onFrame="+std::to_string(countProcessByName(L"pluto_infer.exe")));
    if(InterlockedCompareExchange(&g_commandSendFailed,0,0)){logLine("scr_command_sink.live=SEND_FAILED_FAIL_CLOSED");break;}
    if(!refreshLegacyCommandEnvironment()){logLine("legacy_command_env.live_refresh=FAIL_CLOSED");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_pluto_onFrame");
    ec=onFrameSeh(module);
    if(!translateAndValidateLegacyCommands(data->frameCount)){logLine("scr_command_translation.live=FAIL_CLOSED");break;}
    if(InterlockedCompareExchange(&g_commandSendFailed,0,0)){logLine("scr_command_sink.live=POST_TRANSLATE_SEND_FAILED_FAIL_CLOSED");break;}
    if(diagFrame<=3||diagFrame%120==0)logLine("scr_command_submitted.total="+std::to_string((long)InterlockedCompareExchange(&g_submittedPackets,0,0))+" hook_seen="+std::to_string((long)InterlockedCompareExchange(&g_gameThreadHookSeen,0,0)));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_pluto_onFrame seh="+std::to_string(ec));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].pluto_infer.process_count.after_onFrame="+std::to_string(countProcessByName(L"pluto_infer.exe")));
    if(ec){
      logLine("original_pluto.onFrame=SEH_EXCEPTION code="+std::to_string(ec));
      logLine("onframe.seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
      logLine("onframe.seh.eip="+std::to_string((unsigned long)g_sehEip));
      logLine("onframe.seh.access_type="+std::to_string((unsigned long)g_sehAccessType));
      logLine("onframe.seh.access_address="+std::to_string((unsigned long)g_sehAccessAddress));
      logLine("onframe.seh.regs.eax="+std::to_string((unsigned long)g_sehEax)+" ebx="+std::to_string((unsigned long)g_sehEbx)+" ecx="+std::to_string((unsigned long)g_sehEcx)+" edx="+std::to_string((unsigned long)g_sehEdx)+" esi="+std::to_string((unsigned long)g_sehEsi)+" edi="+std::to_string((unsigned long)g_sehEdi)+" ebp="+std::to_string((unsigned long)g_sehEbp)+" esp="+std::to_string((unsigned long)g_sehEsp));
      if(readable((void*)g_sehEip,16)){std::ostringstream hs;hs<<"onframe.seh.code16=";auto*q=(unsigned char*)g_sehEip;const char*hex="0123456789ABCDEF";for(int i=0;i<16;i++){hs<<hex[q[i]>>4]<<hex[q[i]&15];}logLine(hs.str());}
      if(g_sehEip>=16 && readable((void*)(g_sehEip-16),48)){std::ostringstream hs;hs<<"onframe.seh.code_window_m16_p32=";auto*q=(unsigned char*)(g_sehEip-16);const char*hex="0123456789ABCDEF";for(int i=0;i<48;i++){hs<<hex[q[i]>>4]<<hex[q[i]&15];}logLine(hs.str());}
      if(readable((void*)g_sehEsp,64)){std::ostringstream ss;ss<<"onframe.seh.stack16=";auto*q=(uint32_t*)g_sehEsp;for(int i=0;i<16;i++){if(i)ss<<",";ss<<q[i];}logLine(ss.str());}
      uintptr_t pb=(uintptr_t)pluto;
      if(g_sehAddress>=pb)
        logLine("onframe.seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
      if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)
        logLine("onframe.seh.class=legacy_bw_absolute_address");
      else if(g_sehAddress>=pb)
        logLine("onframe.seh.class=pluto_code");
      else
        logLine("onframe.seh.class=other");
      break;
    }
    if(data->unitCommandCount!=lastCmd){logLine("pluto_bwapi_unit_commands="+std::to_string(data->unitCommandCount));lastCmd=data->unitCommandCount;}
    if(data->unitCommandCount>0){logLine("scr_command_sink=UNRESOLVED_FAIL_CLOSED");data->unitCommandCount=0;lastCmd=0;}
    }
    if(!matchEndedNormally){logLine("MATCH_LOOP_STOPPED_FATAL generation="+std::to_string(matchGeneration));break;}

    // End the just-finished match while commands are disarmed. This follows the
    // reference bridge lifecycle: AIModule::onEnd first, then GameImpl::onMatchEnd.
    InterlockedExchange(&g_matchCommandsArmed,0);clearPendingTurns();g_lastHookFrame=0;
    g_legacyCommandSize=0;g_legacyFlushCount=0;g_legacyFlushOverflow=0;
    std::memset(g_legacyCommandBuffer,0,sizeof(g_legacyCommandBuffer));
    const int endedSelf=data?data->self:-1;bool won=false;
    if(data&&g_scrGame&&endedSelf>=0&&endedSelf<8&&readable((void*)(g_scrGame+58896u+(unsigned)endedSelf),1))won=rd<uint8_t>((unsigned char*)g_scrGame,58896u+(unsigned)endedSelf)==3;
    if(module){DWORD endEc=onEndSeh(module,won);logLine(std::string("original_pluto.onEnd=")+(endEc?"SEH_EXCEPTION":"PASS")+" generation="+std::to_string(matchGeneration)+" won="+(won?"1":"0")+(endEc?" code="+std::to_string(endEc):std::string()));}
    if(game){game->onMatchEnd();logLine("bwapi.onMatchEnd=PASS generation="+std::to_string(matchGeneration));}
    BWAPI::BroodwarPtr=nullptr;BWAPI::BWAPIClient.data=nullptr;
    if(game){delete game;game=nullptr;}if(data){delete data;data=nullptr;}module=nullptr;
    logLine("MATCH_END generation="+std::to_string(matchGeneration)+" submitted_total="+std::to_string((long)InterlockedCompareExchange(&g_submittedPackets,0,0)));
    flushLog();

    // Clear per-match identities without reallocating the fixed legacy CUnit table,
    // so Pluto's one-time patched UnitNodeTable base remains valid across matches.
    g_stableUnitLookup.clear();g_legacyRawUnits.clear();
    for(auto&slot:g_stableUnitSlots)slot={};
    std::memset(g_legacyCUnits.data(),0,g_legacyCUnits.size()*sizeof(LegacyCUnit336));
    std::memset(g_legacyUnitSprites.data(),0,g_legacyUnitSprites.size()*sizeof(LegacySprite36));
    g_scrVisibleUnitHead=g_scrHiddenUnitHead=g_scrScannerSweepHead=0;
    g_legacyBullets.clear();g_legacyBulletSprites.clear();g_legacyRawBullets.clear();g_rawBulletIndex.clear();g_legacyBulletHead=0;
    g_legacyLocalPlayerId=0;std::memset(g_legacyStartSelection,0,sizeof(g_legacyStartSelection));
    InterlockedExchange(&g_commandSendFailed,0);InterlockedExchange(&g_submittedPackets,0);InterlockedExchange(&g_translateLogSequence,0);InterlockedExchange(&g_sendLogSequence,0);

    logLine("MATCH_WAIT_NEXT generation="+std::to_string(matchGeneration+1));
    UnitStore nextStore{};uintptr_t nextGame=0;int nextSelf=-1;int nextLive=0;
    for(;;){
      Sleep(100);
      if(profileReplayActive()||!profileMatchActive())continue;
      nextSelf=profileLocalPlayerCandidate();if(nextSelf<0||nextSelf>=8)continue;
      DWORD nextScan=findLegacyCUnitVectorSeh(&nextStore);if(nextScan||nextStore.score<2){Sleep(150);continue;}
      auto nextPresent=collectPresentRaw(nextStore);if(nextPresent.size()<2){Sleep(150);continue;}
      nextGame=findScrGameBlock((int)nextPresent.size());if(!nextGame){Sleep(150);continue;}
      const uint16_t nw=rd<uint16_t>((unsigned char*)nextGame,228),nh=rd<uint16_t>((unsigned char*)nextGame,230);
      const uint32_t nf=rd<uint32_t>((unsigned char*)nextGame,332);if(nw<32||nh<32||!nf){Sleep(150);continue;}
      nextLive=(int)nextPresent.size();break;
    }

    store=nextStore;g_scrGame=nextGame;
    data=new BWAPI::GameData();ZeroMemory(data,sizeof(*data));data->self=nextSelf;data->neutral=11;
    int projected=projectLiveUnits(store,*data);if(projected<2){logLine("MATCH_RESTART=PROJECT_UNITS_FAIL_CLOSED");break;}
    data->mapWidth=rd<uint16_t>((unsigned char*)g_scrGame,228);data->mapHeight=rd<uint16_t>((unsigned char*)g_scrGame,230);data->frameCount=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(!syncLegacyGameShadow(g_scrGame)){logLine("MATCH_RESTART=GAME_SHADOW_FAIL_CLOSED");break;}
    if(!resolveLegacyPlayers()||!refreshLegacyPlayers()){logLine("MATCH_RESTART=PLAYERS_FAIL_CLOSED");break;}
    data->self=nextSelf;data->neutral=11;
    if(!projectRealPlayerRelations(*data,true)){logLine("MATCH_RESTART=RELATIONS_FAIL_CLOSED");break;}
    int newEnemy=data->enemy;data->isInGame=true;
    BWAPI::BWAPIClient.data=data;game=new BWAPI::GameImpl(data);BWAPI::BroodwarPtr=game;gameInit(game);module=createAI();
    if(!module){logLine("MATCH_RESTART=NEW_AI_NULL_FAIL_CLOSED");break;}
    game->onMatchStart();
    int restartShadow=buildLegacyCUnitShadow(store);if(!g_scrVisibleUnitHead||restartShadow<2){logLine("MATCH_RESTART=CUNIT_SHADOW_FAIL_CLOSED");break;}
    if(!resolveActiveTileArray(store,data->mapWidth,data->mapHeight)||!projectRealMapVisibility(*data)){logLine("MATCH_RESTART=ACTIVE_TILE_FAIL_CLOSED");break;}
    if(!buildLegacyBulletShadow()){logLine("MATCH_RESTART=BULLET_FAIL_CLOSED");break;}
    g_legacyLocalPlayerId=(uint32_t)nextSelf;std::memset(g_legacyStartSelection,0,sizeof(g_legacyStartSelection));
    if(!refreshLegacyCommandEnvironment()){logLine("MATCH_RESTART=COMMAND_ENV_FAIL_CLOSED");break;}
    g_legacyCommandSize=0;g_legacyFlushCount=0;g_legacyFlushOverflow=0;std::memset(g_legacyCommandBuffer,0,sizeof(g_legacyCommandBuffer));std::memset(g_legacyFlushSizes,0,sizeof(g_legacyFlushSizes));std::memset(g_legacyFlushBuffers,0,sizeof(g_legacyFlushBuffers));
    DWORD restartEc=onStartSeh(module);if(restartEc){logLine("MATCH_RESTART=ONSTART_SEH_FAIL_CLOSED code="+std::to_string(restartEc));break;}
    int inferCount=countProcessByName(L"pluto_infer.exe");
    for(int settle=0;settle<20 && inferCount!=1;++settle){Sleep(100);inferCount=countProcessByName(L"pluto_infer.exe");}
    if(inferCount!=1){logLine("MATCH_RESTART=INFER_PROCESS_FAIL_CLOSED count="+std::to_string(inferCount));break;}
    ++matchGeneration;InterlockedExchange(&g_matchCommandsArmed,1);
    logLine("MATCH_START generation="+std::to_string(matchGeneration)+" frame="+std::to_string(data->frameCount)+" self="+std::to_string(nextSelf)+" live="+std::to_string(nextLive)+" infer_count="+std::to_string(inferCount));
    flushLog();
  }
  InterlockedExchange(&g_matchCommandsArmed,0);clearPendingTurns();flushLog();
  return 0;
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){if(r==DLL_PROCESS_ATTACH){g_self=h;DisableThreadLibraryCalls(h);HANDLE t=CreateThread(nullptr,0,boot,nullptr,0,nullptr);if(t)CloseHandle(t);}return TRUE;}
