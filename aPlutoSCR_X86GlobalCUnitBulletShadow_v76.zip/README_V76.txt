aPlutoSCR v76 x86 - original Pluto bullet-list compatibility probe

Goal: run the unmodified original Pluto observation/decision/action logic against live StarCraft: Remastered x86 state.
This overlay does not implement AI decisions. It fixes v75's CUnit-vector selection so a plausible in-module false positive cannot short-circuit the verified full-process search, then keeps the fail-closed legacy bullet-list bridge for Pluto's BW 1.16.1 address 0x64DEC4.

v76 behavior:
- Always completes both main-module and full-process CUnit descriptor scans, then selects the globally strongest candidate (score first, live-count tie-break).
- Keeps v74's dynamically discovered CUnit prev/next links and semantic visible/hidden/scanner heads.
- Verifies Pluto RVA 0xBC75 is exactly `mov ebx, dword ptr [0x64DEC4]` before patching.
- Scans live process memory for plausible 112-byte CBullet objects by cross-checking their unit references against the already verified live CUnit set.
- If active bullets are found, builds a legacy 112-byte bullet shadow list and remaps bullet->unit pointers into the legacy CUnit shadow.
- If no plausible active bullets exist at snapshot time, exposes a null legacy bullet head (the correct BW 1.16.1 representation for an empty bullet list).
- Ambiguous bullet candidates fail closed rather than fabricating an observation.
- Pluto command delivery remains disabled until a verified synchronized SC:R command sink is connected.
- SEH logging now records x86 registers and 16 instruction bytes for the next unported legacy reference.

Expected log: plutoscr-x86-v76.log
