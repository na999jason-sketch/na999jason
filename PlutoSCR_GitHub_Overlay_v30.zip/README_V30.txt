PlutoSCR v30 Live Integration Candidate

This package combines the already compiled x64 SC:R runtime/resident path and
the v29 x86 original-Pluto Host path.

Required original Pluto files beside RUN_PLUTO_SCR.cmd:
  pluto.dll
  pluto_infer.exe
  pluto_weights.bin

The launcher detects StarCraft.exe, starts the original inference executable,
injects the x64 resident DLL, then starts the x86 PlutoHost.

IMPORTANT:
v30 is a live integration candidate, not a claim that SC:R state publication
and command delivery are already proven end-to-end. The launcher is fail-closed
and logs to plutoscr-live.log.
