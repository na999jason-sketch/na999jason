$ErrorActionPreference="Stop"
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$log=Join-Path $root "plutoscr-live.log"
"[$(Get-Date -Format o)] PlutoSCR live launcher start" | Set-Content $log

function Log($s) {
  $s | Tee-Object -FilePath $log -Append
}

$sc=Get-Process StarCraft -ErrorAction SilentlyContinue | Select-Object -First 1
if(-not $sc) {
  Log "[FAIL] StarCraft.exe is not running."
  exit 20
}
Log "[PASS] StarCraft PID=$($sc.Id)"

# Start original inference side first. Pluto may also launch/connect according to its own behavior;
# avoid spawning a duplicate if it is already resident.
$infer=Get-Process pluto_infer -ErrorAction SilentlyContinue | Select-Object -First 1
if(-not $infer) {
  Log "[INFO] Starting original pluto_infer.exe"
  Start-Process -FilePath (Join-Path $root "pluto_infer.exe") -WorkingDirectory $root
  Start-Sleep -Milliseconds 750
} else {
  Log "[PASS] pluto_infer already running PID=$($infer.Id)"
}

Log "[INFO] Injecting x64 resident runtime"
& (Join-Path $root "runtime-inject-resident-win.exe") $sc.Id (Join-Path $root "starcraft-api-resident.dll") 2>&1 |
  Tee-Object -FilePath $log -Append
if($LASTEXITCODE -ne 0) {
  Log "[FAIL] resident injection exit=$LASTEXITCODE"
  exit 21
}

Start-Sleep -Milliseconds 500

Log "[INFO] Starting x86 PlutoHost with original pluto.dll"
$host=Start-Process -FilePath (Join-Path $root "PlutoHost.exe") `
  -ArgumentList ('"{0}"' -f (Join-Path $root "pluto.dll")) `
  -WorkingDirectory $root -PassThru

Log "[PASS] PlutoHost PID=$($host.Id)"
Log "[INFO] Enter/start a local or custom SC:R match."
Log "[INFO] Live success still requires runtime state publication and command delivery proof."
exit 0
