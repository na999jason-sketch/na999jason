PlutoSCR v30 live transport integration
Start SC:R and leave it at menu. Run RUN_PLUTO_SCR.cmd, then enter a LOCAL/CUSTOM match when prompted.
The launcher waits for resident validated live snapshots, starts the upstream command-queue proof/receiver,
starts the continuous PlutoSCR GameData bridge, then starts original Pluto through PlutoHost.
After 30-60 seconds send all *.log files.

Important: this package is still a live validation build. It does not claim Pluto gameplay success until
logs prove frame publication, original Pluto callbacks, command production, receiver application, and SC:R behavior.
