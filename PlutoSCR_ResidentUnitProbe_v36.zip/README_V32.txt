PlutoSCR v32 proof-first live transport
Flow: inject resident -> external Windows live proof (state+units+players+map) -> active match gate ->
command queue proof/receiver -> continuous GameData bridge -> original PlutoHost.
On failure, diagnostic logs and bridge-ready.txt/resident-adapter.log are copied beside the launcher.
