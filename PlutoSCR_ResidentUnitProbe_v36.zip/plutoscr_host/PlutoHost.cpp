#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include "PlutoHostIPC.h"
#include "../plutoscr_bridge/FrameHandshake.h"
#include <cstdio>
#include <filesystem>
#include <string>

using PFNGameInit = void (*)(BWAPI::Game*);
using PFNCreateAI = BWAPI::AIModule* (*)();

static void dispatchEvent(BWAPI::AIModule* module, const BWAPI::Event& e)
{
  using namespace BWAPI;
  switch (e.getType())
  {
    case EventType::MatchStart:    module->onStart(); break;
    case EventType::MatchEnd:      module->onEnd(e.isWinner()); break;
    case EventType::MatchFrame:    module->onFrame(); break;
    case EventType::SendText:      module->onSendText(e.getText()); break;
    case EventType::ReceiveText:   module->onReceiveText(e.getPlayer(), e.getText()); break;
    case EventType::PlayerLeft:    module->onPlayerLeft(e.getPlayer()); break;
    case EventType::NukeDetect:    module->onNukeDetect(e.getPosition()); break;
    case EventType::UnitDiscover:  module->onUnitDiscover(e.getUnit()); break;
    case EventType::UnitEvade:     module->onUnitEvade(e.getUnit()); break;
    case EventType::UnitCreate:    module->onUnitCreate(e.getUnit()); break;
    case EventType::UnitDestroy:   module->onUnitDestroy(e.getUnit()); break;
    case EventType::UnitMorph:     module->onUnitMorph(e.getUnit()); break;
    case EventType::UnitShow:      module->onUnitShow(e.getUnit()); break;
    case EventType::UnitHide:      module->onUnitHide(e.getUnit()); break;
    case EventType::UnitRenegade:  module->onUnitRenegade(e.getUnit()); break;
    case EventType::SaveGame:      module->onSaveGame(e.getText()); break;
    case EventType::UnitComplete:  module->onUnitComplete(e.getUnit()); break;
    default: break;
  }
}

int wmain(int argc, wchar_t** argv)
{
  std::filesystem::path plutoDll = argc > 1 ? argv[1] : L"pluto.dll";

  HANDLE dataMap = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, PlutoSCR::kMappingName);
  HANDLE ctlMap  = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, PlutoSCR::kControlName);
  if (!dataMap || !ctlMap) {
    std::fwprintf(stderr, L"PlutoHost: SC:R runtime shared mappings are not ready.\n");
    return 2;
  }
  auto* data = static_cast<BWAPI::GameData*>(
    MapViewOfFile(dataMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(BWAPI::GameData)));
  auto* ctl = static_cast<PlutoSCR::Control*>(
    MapViewOfFile(ctlMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(PlutoSCR::Control)));
  if (!data || !ctl || ctl->magic != PlutoSCR::kMagic || ctl->version != PlutoSCR::kVersion)
    return 3;

  HMODULE pluto = LoadLibraryW(plutoDll.c_str());
  if (!pluto) {
    ctl->lastError = GetLastError();
    std::fwprintf(stderr, L"PlutoHost: LoadLibrary failed (%lu): %ls\n", GetLastError(), plutoDll.c_str());
    return 4;
  }
  auto gameInit = reinterpret_cast<PFNGameInit>(GetProcAddress(pluto, "gameInit"));
  auto createAI = reinterpret_cast<PFNCreateAI>(GetProcAddress(pluto, "newAIModule"));
  if (!gameInit || !createAI) {
    ctl->lastError = ERROR_PROC_NOT_FOUND;
    return 5;
  }

  BWAPI::GameImpl game(data);
  gameInit(&game);                         // exact BWAPI 4.4 module contract
  BWAPI::AIModule* module = createAI();
  if (!module) return 6;

  InterlockedExchange(reinterpret_cast<volatile LONG*>(&ctl->state), static_cast<LONG>(PlutoSCR::HostState::HostReady));
  std::int32_t seenFrame = ctl->consumedFrame;
  bool wasInGame = false;

  while (ctl->state != static_cast<std::int32_t>(PlutoSCR::HostState::Stopping))
  {
    // Stable state snapshot only: odd stateSequence means x64 is still writing.
    const std::int32_t seq0 = ctl->stateSequence;
    if ((seq0 & 1) != 0) { Sleep(0); continue; }

    const std::int32_t frame = ctl->publishedFrame;
    if (frame == seenFrame || frame == ctl->consumedFrame) { Sleep(1); continue; }

    MemoryBarrier();
    if (seq0 != ctl->stateSequence || (ctl->stateSequence & 1) != 0) continue;

    const bool nowInGame = data->isInGame;
    if (nowInGame && !wasInGame) game.onMatchStart();
    else if (nowInGame) game.onMatchFrame();

    // Dispatch ABI-correct producer events before onMatchEnd(), because
    // GameImpl::onMatchEnd() clears per-frame event state.
    bool hadMatchEnd = false;
    for (const BWAPI::Event& e : game.getEvents()) {
      if (e.getType() == BWAPI::EventType::MatchEnd) hadMatchEnd = true;
      dispatchEvent(module, e);
    }
    if (!nowInGame && wasInGame) {
      if (!hadMatchEnd) module->onEnd(false);
      game.onMatchEnd();
    }

    // Some producers may omit MatchFrame from eventCount; preserve BWAPI's one-frame callback.
    bool hadFrame = false;
    for (const BWAPI::Event& e : game.getEvents())
      if (e.getType() == BWAPI::EventType::MatchFrame) { hadFrame = true; break; }
    if (nowInGame && !hadFrame)
      module->onFrame();

    // Pluto has returned from all callbacks for this exact published frame.
    // Commit only after its GameData command arrays are stable.
    MemoryBarrier();
    InterlockedExchange(reinterpret_cast<volatile LONG*>(&ctl->consumedFrame), static_cast<LONG>(frame));
    InterlockedIncrement(reinterpret_cast<volatile LONG*>(&ctl->commandSequence));
    seenFrame = frame;
    wasInGame = nowInGame;
  }

  if (wasInGame) {
    module->onEnd(false);
    game.onMatchEnd();
  }

  // Original Pluto owns the concrete AIModule allocation. v25/v26 proved that
  // deleting it from the host CRT corrupts the heap. Keep the DLL/module alive
  // for the lifetime of this process, exactly as required by the ABI boundary.
  ExitProcess(0);
  return 0;
}
