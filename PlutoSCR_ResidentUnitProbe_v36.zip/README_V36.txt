PlutoSCR v36 Resident Unit Identity Probe
Purpose: port original Pluto only. No replacement AI and no synthesized policy.
This build keeps PlutoHost blocked. It records the strongest resident-side SC:R unit candidate,
including address, position, owner/player, type hint, HP evidence, secondary object and sprite.
External heuristic map/unit matches are not accepted as truth.
