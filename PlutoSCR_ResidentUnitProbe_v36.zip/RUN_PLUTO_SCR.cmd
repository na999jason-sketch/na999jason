@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo PlutoSCR Live Launcher
echo ============================================================

if not exist "pluto.dll" (
  echo [FAIL] pluto.dll missing
  pause
  exit /b 10
)
if not exist "pluto_infer.exe" (
  echo [FAIL] pluto_infer.exe missing
  echo Copy it from the original Pluto package into this folder.
  pause
  exit /b 11
)
if not exist "pluto_weights.bin" (
  echo [FAIL] pluto_weights.bin missing
  echo Copy it from the original Pluto package into this folder.
  pause
  exit /b 12
)
if not exist "PlutoHost.exe" (
  echo [FAIL] PlutoHost.exe missing
  pause
  exit /b 13
)
if not exist "starcraft-api-resident.dll" (
  echo [FAIL] starcraft-api-resident.dll missing
  pause
  exit /b 14
)
if not exist "runtime-inject-resident-win.exe" (
  echo [FAIL] runtime-inject-resident-win.exe missing
  pause
  exit /b 15
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_PLUTO_SCR.ps1"
set EC=%ERRORLEVEL%
echo.
echo Launcher exit code: %EC%
pause
exit /b %EC%
