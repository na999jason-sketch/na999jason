#include "RuntimeCommandPump.h"
#include <fstream>
namespace PlutoSCR {
PumpResult pumpCommandsToValidatedBridge(BWAPI::GameData& data,const std::filesystem::path& bridge){
 PumpResult result;
 auto drained=drainBWAPIClientCommands(data);
 result.rejected+=(int)drained.rejected.size();
 std::ofstream queue(bridge/"commands.log",std::ios::app);
 if(!queue){result.reason="commands.log unavailable";return result;}
 for(const auto& request:drained.requests){
   auto encoded=BWAPI::Runtime::encodeRuntimeCommandRequest(request);
   if(!encoded.encoded){++result.rejected;continue;}
   queue<<(request.kind==BWAPI::Runtime::RuntimeCommandKind::GameAction?"game-action":"unit-command")
        <<'|'<<request.name<<'|'<<request.targetUnitId<<'|';
   for(std::size_t i=0;i<request.arguments.size();++i){
     if(i) queue<<',';
     queue<<request.arguments[i];
   }
   queue<<'\n'; ++result.accepted;
 }
 queue.flush();
 result.reason="ok"; return result;
}
}
