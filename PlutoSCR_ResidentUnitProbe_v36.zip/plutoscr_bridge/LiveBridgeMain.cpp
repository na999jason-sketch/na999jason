#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include "PlutoSCRShared.h"
#include "ValidatedSnapshotReader.h"
#include "SCRStateProjection.h"
#include "RuntimeCommandPump.h"
#include <BWAPI/Client/GameData.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <cstring>
#include <chrono>
#include <thread>

static void logLine(const std::filesystem::path& p,const std::string& s){
 std::ofstream f(p,std::ios::app); if(f) f<<s<<"\n";
}

int wmain(int argc,wchar_t**argv){
 if(argc<2){std::cerr<<"usage: plutoscr-live-bridge <resident-bridge-dir>\n";return 64;}
 const std::filesystem::path bridge=argv[1];
 const auto log=std::filesystem::current_path()/"plutoscr-bridge.log";
 logLine(log,"live_bridge.start bridge="+bridge.string());

 HANDLE cm=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(PlutoSCR::Control),PlutoSCR::ControlMapping);
 HANDLE dm=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(BWAPI::GameData),PlutoSCR::GameDataMapping);
 if(!cm||!dm){logLine(log,"live_bridge.mapping_create_failed");return 2;}
 auto* ctl=(PlutoSCR::Control*)MapViewOfFile(cm,FILE_MAP_ALL_ACCESS,0,0,sizeof(PlutoSCR::Control));
 auto* data=(BWAPI::GameData*)MapViewOfFile(dm,FILE_MAP_ALL_ACCESS,0,0,sizeof(BWAPI::GameData));
 if(!ctl||!data){logLine(log,"live_bridge.mapping_view_failed");return 3;}
 std::memset(ctl,0,sizeof(*ctl)); std::memset(data,0,sizeof(*data));
 ctl->magic=PlutoSCR::Magic; ctl->version=PlutoSCR::Version;
 InterlockedExchange(reinterpret_cast<volatile LONG*>(&ctl->state),(LONG)PlutoSCR::State::RuntimeReady);
 logLine(log,"live_bridge.mapping_ready");

 int lastPublished=-1; LONG lastDrained=0; unsigned rejectTicks=0;
 for(;;){
   if(ctl->state==(LONG)PlutoSCR::State::Stopping) break;

   // Drain only after PlutoHost has committed commands for the published frame.
   LONG cs=ctl->commandSequence;
   if(cs!=lastDrained && ctl->consumedFrame==lastPublished){
     auto pr=PlutoSCR::pumpCommandsToValidatedBridge(*data,bridge);
     logLine(log,"live_bridge.commands frame="+std::to_string(lastPublished)+
       " accepted="+std::to_string(pr.accepted)+" rejected="+std::to_string(pr.rejected)+
       " reason="+pr.reason);
     InterlockedExchange(reinterpret_cast<volatile LONG*>(&ctl->drainedCommandSequence),cs);
     lastDrained=cs;
   }

   // Never overwrite GameData until Host consumed the previous frame and commands were drained.
   if(lastPublished>=0 && (ctl->consumedFrame!=lastPublished || ctl->drainedCommandSequence!=ctl->commandSequence)){
     Sleep(1); continue;
   }

   auto snap=PlutoSCR::readValidatedBridgeSnapshot(bridge);
   if(!snap.ok){
     if((++rejectTicks%200)==1) logLine(log,"live_bridge.snapshot_wait reason="+snap.reason);
     Sleep(10); continue;
   }
   rejectTicks=0;
   if(snap.frame.frame==lastPublished){Sleep(2);continue;}

   LONG seq=InterlockedIncrement(reinterpret_cast<volatile LONG*>(&ctl->stateSequence));
   if((seq&1)==0) InterlockedIncrement(reinterpret_cast<volatile LONG*>(&ctl->stateSequence));
   MemoryBarrier();
   PlutoSCR::projectValidatedSnapshot(snap.frame,*data);
   MemoryBarrier();
   InterlockedExchange(reinterpret_cast<volatile LONG*>(&ctl->publishedFrame),snap.frame.frame);
   seq=InterlockedIncrement(reinterpret_cast<volatile LONG*>(&ctl->stateSequence));
   if((seq&1)!=0) InterlockedIncrement(reinterpret_cast<volatile LONG*>(&ctl->stateSequence));
   lastPublished=snap.frame.frame;
   logLine(log,"live_bridge.publish frame="+std::to_string(lastPublished)+
     " units="+std::to_string(snap.frame.units.size())+
     " players="+std::to_string(snap.frame.players.size())+
     " self="+std::to_string(snap.frame.self));
 }
 return 0;
}
