aPlutoSCR v90 x86 Legacy Command Staging + Exact Bindings

Purpose
- Run the original Pluto binary on 32-bit StarCraft: Remastered.
- Do not replace Pluto observation, inference, policy, decision, or command generation.
- Flow remains: SC:R real state -> compatibility/legacy ABI -> original Pluto -> original Pluto command bytes.

Why v90 exists
- v89 passed exact Game/Players bindings, stable CUnit shadow, real ActiveTileArray, real Players, real local player, and profile bullet bridge.
- Original Pluto onStart passed, pluto_infer.exe stayed alive, and onFrame returned normally for three consecutive calls.
- The next access violation was at Pluto RVA 0xAD20 reading legacy address 0x596904.
- The exact pinned binding table shows RVA 0xAD20 belongs to Pluto's legacy command serialization path. The same path directly uses 0x59688C, 0x596904, command buffer 0x654880, command size 0x654AA0, and flush target 0x485A40.

v90 changes
- Adds an exact-binding legacy command-staging ABI for the pinned Pluto binary.
- 0x59688C receives the real SCR multiplayer flag.
- 0x596904 receives the legacy game-mode word used by the verified compatibility view.
- 0x654880 is redirected to a 512-byte shadow command buffer.
- 0x654AA0 is redirected to a shadow command-size cell.
- 0x485A40 is redirected to a fail-closed flush stub.
- Every patched command operand must match both the exact Pluto RVA and exact expected legacy value from the pinned pluto_bindings.h table.
- Original Pluto command bytes are logged (size + hex prefix) and then discarded.
- NO command packet is sent to SC:R in v90. This is intentionally fail-closed.
- Keeps v89 exact Game/Players bindings, real Players, real local player, stable 1700 CUnit slots, CUnit pointer/sprite/handle conversion, real SCR Game shadow, real ActiveTileArray, and profile bullet shadow.

Original Pluto runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Expected v90 milestones
  reloc90.game_operands=PASS_EXACT_BINDINGS
  reloc90.players_operands=PASS_EXACT_BINDINGS
  active_tile=BOUND_REAL_SCR
  profile_bullet=BOUND_VALIDATED
  reloc90.command_abi=PASS_EXACT_BINDINGS_FAIL_CLOSED
  legacy_command_abi=BOUND_SHADOW_NOT_SENT
  original_pluto.onStart=PASS
  frame[1].after_pluto_onFrame seh=0

Command-generation milestone (if Pluto issues a command)
  original_pluto.legacy_command_bytes=N
  original_pluto.legacy_command_hex=...
  scr_command_sink=FAIL_CLOSED_NOT_SENT

If a flush is requested by Pluto before frame return, v90 records:
  legacy_command_flush.count=N last_bytes=M
  legacy_command_flush.hex=...

The original Pluto model/files are not included and are not modified.
