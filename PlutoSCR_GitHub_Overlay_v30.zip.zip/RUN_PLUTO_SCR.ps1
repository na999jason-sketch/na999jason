﻿$ErrorActionPreference="Stop"
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$log=Join-Path $root "plutoscr-live.log"
"[$(Get-Date -Format o)] PlutoSCR live diagnostic launcher start" | Set-Content $log
function Log($s) { $s | Tee-Object -FilePath $log -Append }
function Need($n) { $p=Join-Path $root $n; if(-not(Test-Path $p)){Log "[FAIL] missing file: $n";exit 10}; Log "[PASS] file=$n bytes=$((Get-Item $p).Length)"; return $p }
try {
 $injector=Need "runtime-inject-resident-win.exe"; $resident=Need "starcraft-api-resident.dll"
 $hostExe=Need "PlutoHost.exe"; $plutoDll=Need "pluto.dll"; $inferExe=Need "pluto_infer.exe"; $null=Need "pluto_weights.bin"
 $sc=Get-Process StarCraft -ErrorAction SilentlyContinue|Select-Object -First 1
 if(-not $sc){Log "[FAIL] StarCraft.exe is not running.";exit 20}; Log "[PASS] StarCraft PID=$($sc.Id)"
 $infer=Get-Process pluto_infer -ErrorAction SilentlyContinue|Select-Object -First 1
 if(-not $infer){Log "[INFO] Starting original pluto_infer.exe";$infer=Start-Process $inferExe -WorkingDirectory $root -PassThru;Start-Sleep -Milliseconds 750;$infer.Refresh();if($infer.HasExited){Log "[FAIL] pluto_infer exited early code=$($infer.ExitCode)";exit 22};Log "[PASS] pluto_infer PID=$($infer.Id)"}else{Log "[PASS] pluto_infer already running PID=$($infer.Id)"}
 $io=Join-Path $root "injector.stdout.log";$ie=Join-Path $root "injector.stderr.log";Remove-Item $io,$ie -Force -ErrorAction SilentlyContinue
 Log "[INFO] Injecting x64 resident runtime"
 $inj=Start-Process $injector -ArgumentList @("$($sc.Id)","`"$resident`"") -WorkingDirectory $root -PassThru -RedirectStandardOutput $io -RedirectStandardError $ie
 $limit=(Get-Date).AddSeconds(15);while(-not $inj.HasExited -and (Get-Date)-lt $limit){Start-Sleep -Milliseconds 250;$inj.Refresh()}
 if(-not $inj.HasExited){Log "[FAIL] injector timeout after 15s PID=$($inj.Id)";Stop-Process -Id $inj.Id -Force -ErrorAction SilentlyContinue;if(Test-Path $io){Get-Content $io|%{Log "[INJECT-OUT] $_"}};if(Test-Path $ie){Get-Content $ie|%{Log "[INJECT-ERR] $_"}};exit 23}
 if(Test-Path $io){Get-Content $io|%{Log "[INJECT-OUT] $_"}};if(Test-Path $ie){Get-Content $ie|%{Log "[INJECT-ERR] $_"}}
 Log "[INFO] injector exit=$($inj.ExitCode)";if($inj.ExitCode-ne 0){Log "[FAIL] resident injection failed";exit 21};Log "[PASS] resident injector returned success"
 Start-Sleep -Milliseconds 750
 try{$sc.Refresh();$mods=@($sc.Modules|%{$_.ModuleName});if($mods-contains "starcraft-api-resident.dll"){Log "[PASS] resident module visible in StarCraft.exe"}else{Log "[WARN] resident module not visible via Process.Modules"}}catch{Log "[WARN] resident module enumeration unavailable: $($_.Exception.Message)"}
 Log "[INFO] Starting x86 PlutoHost with original pluto.dll"
 $ho=Join-Path $root "PlutoHost.stdout.log";$he=Join-Path $root "PlutoHost.stderr.log";Remove-Item $ho,$he -Force -ErrorAction SilentlyContinue
 $ph=Start-Process $hostExe -ArgumentList ('"{0}"'-f $plutoDll) -WorkingDirectory $root -PassThru -RedirectStandardOutput $ho -RedirectStandardError $he
 Start-Sleep -Seconds 2;$ph.Refresh()
 if($ph.HasExited){if(Test-Path $ho){Get-Content $ho|%{Log "[HOST-OUT] $_"}};if(Test-Path $he){Get-Content $he|%{Log "[HOST-ERR] $_"}};Log "[FAIL] PlutoHost exited early code=$($ph.ExitCode)";exit 24}
 Log "[PASS] PlutoHost PID=$($ph.Id) still_running_after_2s=true";Log "[PASS] DIAGNOSTIC_LAUNCH_CHAIN=PASS"
 Log "[INFO] Enter a local/custom match, play 20-30 seconds, then send all *.log files.";exit 0
}catch{Log "[FAIL] launcher exception: $($_.Exception.GetType().FullName): $($_.Exception.Message)";Log "[FAIL] at=$($_.InvocationInfo.PositionMessage)";exit 99}
