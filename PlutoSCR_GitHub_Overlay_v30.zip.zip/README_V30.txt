PlutoSCR v30 diagnostic launcher. Start SC:R at menu, run RUN_PLUTO_SCR.cmd, enter local/custom match, play 20-30 seconds, then send plutoscr-live.log and all injector/PlutoHost *.log files.
