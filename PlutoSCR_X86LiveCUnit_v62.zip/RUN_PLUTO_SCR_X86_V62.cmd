@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
for %%F in ("%ROOT%PlutoSCRX86Inject.exe" "%ROOT%PlutoSCRX86V62.dll" "%ROOT%pluto.dll" "%ROOT%pluto_infer.exe" "%ROOT%pluto_weights.bin") do if not exist "%%~F" (echo [FAIL] missing: %%~F&pause&exit /b 1)
echo [PlutoSCR v62] Live x86 CUnit -> original Pluto runner
"%ROOT%PlutoSCRX86Inject.exe" "%ROOT%PlutoSCRX86V62.dll"
if errorlevel 1 (echo [FAIL] injection failed&pause&exit /b 2)
timeout /t 8 /nobreak >nul
if exist "%ROOT%plutoscr-x86-v62.log" type "%ROOT%plutoscr-x86-v62.log"
pause
