PlutoSCR v62 x86 live runtime gate

1. Put these original Pluto files beside the artifact files:
   pluto.dll
   pluto_infer.exe
   pluto_weights.bin
2. Start the verified 32-bit StarCraft Remastered client.
3. Enter a local/custom game and leave the game running.
4. Run RUN_PLUTO_SCR_X86_V62.cmd.
5. After at least 15 seconds, send plutoscr-x86-v62.log back.

Success is NOT claimed merely because injection succeeds.
The next proof target is live SC:R state -> BWAPI GameData/GameImpl -> original Pluto callbacks.
Command delivery remains fail-closed until a real synchronized SC:R command path is proven.
