v42 executes original Pluto onStart/onFrame inside x86 SC:R. It does not claim zeroed GameData is live SC:R state and adds no replacement AI logic.
