aPlutoSCR v81 x86 Real SCR Game Shadow

Purpose
- Port the original Pluto CoG 2026 binary to 32-bit StarCraft: Remastered.
- Observation, inference, decision-making, and command selection remain inside the unmodified original Pluto.
- This build only supplies a memory/BWAPI compatibility layer.

What changed from v80
- v80 proved the original pluto_infer.exe launches and remains alive.
- The next Pluto read fault was 0x58D2B0 (per-player current upgrade levels).
- v81 no longer redirects the 0x57F1xx/0x57FD3C reads to zero-filled compatibility buffers.
- v81 locates and validates the real live SCR Game structure, maps the old BW 0x57F0F0 Game range, and refreshes a 96,000-byte shadow from the actual SCR Game state every frame.
- This preserves original Pluto reads for map size/frame, resources, supplies, upgrades, tech state, availability, and related Game fields.
- CUnit, UnitNodeTable and bullet compatibility from v80 are retained.
- Command sink remains fail-closed.

Original runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Run
1. Put the unmodified original Pluto files beside this package in the layout above.
2. Start 32-bit StarCraft: Remastered and enter a local/custom match.
3. Run RUN_PLUTO_SCR_X86_V81.cmd.
4. Upload plutoscr-x86-v81.log.

Success indicators
- pluto_runtime.ready=YES
- scr_game.select=PROFILE_VALIDATED or DYNAMIC_SCAN
- legacy_game=BOUND_REAL_SCR_GAME
- gamedata.mapWidth/mapHeight are non-zero
- pluto_infer.process_count.after_onStart=1
- original_pluto.onFrame advances beyond the prior 0x58D2B0 fault
