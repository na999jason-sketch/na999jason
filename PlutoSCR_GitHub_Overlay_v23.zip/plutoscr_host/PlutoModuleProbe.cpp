#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <cstdio>
#include <filesystem>
#include <memory>
#include <cstring>

using PFNGameInit = void (*)(BWAPI::Game*);
using PFNCreateAI = BWAPI::AIModule* (*)();

int wmain(int argc, wchar_t** argv) {
  if(argc < 2) { std::fwprintf(stderr,L"usage: PlutoModuleProbe.exe pluto.dll\n"); return 2; }
  std::filesystem::path dll=argv[1];

  HMODULE h=LoadLibraryW(dll.c_str());
  if(!h) { std::printf("PLUTOSCR_PLUTO_LOAD=FAIL error=%lu\n",GetLastError()); return 3; }
  auto gameInit=reinterpret_cast<PFNGameInit>(GetProcAddress(h,"gameInit"));
  auto createAI=reinterpret_cast<PFNCreateAI>(GetProcAddress(h,"newAIModule"));
  if(!gameInit || !createAI) {
    std::printf("PLUTOSCR_PLUTO_EXPORTS=FAIL gameInit=%p newAIModule=%p\n",(void*)gameInit,(void*)createAI);
    FreeLibrary(h); return 4;
  }
  std::printf("PLUTOSCR_PLUTO_LOAD=PASS\n");
  std::printf("PLUTOSCR_PLUTO_EXPORTS=PASS\n");

  auto data=std::make_unique<BWAPI::GameData>();
  std::memset(data.get(),0,sizeof(BWAPI::GameData));
  BWAPI::GameImpl game(data.get());

  __try {
    gameInit(&game);
  } __except(EXCEPTION_EXECUTE_HANDLER) {
    std::printf("PLUTOSCR_PLUTO_GAMEINIT=FAIL seh=0x%08lx\n",GetExceptionCode());
    FreeLibrary(h); return 5;
  }
  std::printf("PLUTOSCR_PLUTO_GAMEINIT=PASS\n");

  BWAPI::AIModule* module=nullptr;
  __try {
    module=createAI();
  } __except(EXCEPTION_EXECUTE_HANDLER) {
    std::printf("PLUTOSCR_PLUTO_CREATE_AI=FAIL seh=0x%08lx\n",GetExceptionCode());
    FreeLibrary(h); return 6;
  }
  if(!module) { std::printf("PLUTOSCR_PLUTO_CREATE_AI=FAIL null\n"); FreeLibrary(h); return 7; }

  std::printf("PLUTOSCR_PLUTO_CREATE_AI=PASS\n");
  std::printf("PLUTOSCR_ORIGINAL_MODULE_ABI=PASS\n");
  delete module;
  FreeLibrary(h);
  return 0;
}
