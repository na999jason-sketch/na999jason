#pragma once
// Single canonical IPC ABI shared with the x64 runtime.
#include "../plutoscr_bridge/PlutoSCRShared.h"

namespace PlutoSCR {
static constexpr const wchar_t* kMappingName = GameDataMapping;
static constexpr const wchar_t* kControlName = ControlMapping;
static constexpr std::uint32_t kMagic = Magic;
static constexpr std::uint32_t kVersion = Version;
using HostState = State;
}
