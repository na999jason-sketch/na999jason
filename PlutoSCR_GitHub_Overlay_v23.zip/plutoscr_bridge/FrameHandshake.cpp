#include "FrameHandshake.h"
#include <atomic>

namespace plutoscr {

static void fence() { std::atomic_thread_fence(std::memory_order_seq_cst); }

void initializeFrameHandshake(FrameHandshake& h) {
  h.owner = static_cast<std::uint32_t>(FrameOwner::Runtime);
  h.stateSequence = 0;
  h.commandSequence = 0;
  h.reserved = 0;
  h.publishedFrame = -1;
  h.consumedFrame = -1;
  h.drainedFrame = -1;
  h.lastError = 0;
  fence();
}

bool runtimeCanPublish(const FrameHandshake& h) {
  return h.owner == static_cast<std::uint32_t>(FrameOwner::Runtime) &&
         (h.stateSequence & 1u) == 0 &&
         h.consumedFrame == h.drainedFrame;
}

bool runtimeBeginPublish(FrameHandshake& h, std::int32_t frame) {
  if (!runtimeCanPublish(h)) return false;
  ++h.stateSequence; // odd = writer active
  fence();
  h.publishedFrame = frame;
  return true;
}

void runtimeFinishPublish(FrameHandshake& h) {
  fence();
  ++h.stateSequence; // even = stable snapshot
  h.owner = static_cast<std::uint32_t>(FrameOwner::Host);
  fence();
}

bool hostCanConsume(const FrameHandshake& h) {
  return h.owner == static_cast<std::uint32_t>(FrameOwner::Host) &&
         (h.stateSequence & 1u) == 0 &&
         h.publishedFrame != h.consumedFrame;
}

bool hostBeginConsume(FrameHandshake& h, std::int32_t& frame) {
  if (!hostCanConsume(h)) return false;
  fence();
  frame = h.publishedFrame;
  return true;
}

bool hostCommitCommands(FrameHandshake& h, std::int32_t frame) {
  if (h.owner != static_cast<std::uint32_t>(FrameOwner::Host) ||
      h.publishedFrame != frame ||
      h.consumedFrame == frame) return false;
  fence();
  h.consumedFrame = frame;
  ++h.commandSequence;
  h.owner = static_cast<std::uint32_t>(FrameOwner::Runtime);
  fence();
  return true;
}

bool runtimeCanDrain(const FrameHandshake& h) {
  return h.owner == static_cast<std::uint32_t>(FrameOwner::Runtime) &&
         h.consumedFrame == h.publishedFrame &&
         h.drainedFrame != h.consumedFrame;
}

bool runtimeFinishDrain(FrameHandshake& h) {
  if (!runtimeCanDrain(h)) return false;
  h.drainedFrame = h.consumedFrame;
  fence();
  return true;
}

} // namespace plutoscr
