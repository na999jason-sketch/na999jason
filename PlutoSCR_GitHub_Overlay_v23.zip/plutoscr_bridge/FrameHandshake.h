#pragma once
#include <cstdint>

namespace plutoscr {

enum class FrameOwner : std::uint32_t {
  Runtime = 0,
  Host = 1
};

struct FrameHandshake {
  volatile std::uint32_t owner;
  volatile std::uint32_t stateSequence;
  volatile std::uint32_t commandSequence;
  volatile std::uint32_t reserved;
  volatile std::int32_t publishedFrame;
  volatile std::int32_t consumedFrame;
  volatile std::int32_t drainedFrame;
  volatile std::int32_t lastError;
};

static_assert(sizeof(FrameHandshake) == 32, "FrameHandshake ABI changed");

void initializeFrameHandshake(FrameHandshake& h);

// x64 runtime side
bool runtimeCanPublish(const FrameHandshake& h);
bool runtimeBeginPublish(FrameHandshake& h, std::int32_t frame);
void runtimeFinishPublish(FrameHandshake& h);
bool runtimeCanDrain(const FrameHandshake& h);
bool runtimeFinishDrain(FrameHandshake& h);

// x86 PlutoHost side
bool hostCanConsume(const FrameHandshake& h);
bool hostBeginConsume(FrameHandshake& h, std::int32_t& frame);
bool hostCommitCommands(FrameHandshake& h, std::int32_t frame);

} // namespace plutoscr
