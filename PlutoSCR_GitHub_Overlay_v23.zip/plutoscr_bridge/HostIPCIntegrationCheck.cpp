#include "../plutoscr_host/PlutoHostIPC.h"
#include "PlutoSCRShared.h"
#include <cwchar>
#include <iostream>

int main() {
  if (PlutoSCR::kMagic != PlutoSCR::Magic) return 10;
  if (PlutoSCR::kVersion != PlutoSCR::Version) return 11;
  if (std::wcscmp(PlutoSCR::kMappingName, PlutoSCR::GameDataMapping) != 0) return 12;
  if (std::wcscmp(PlutoSCR::kControlName, PlutoSCR::ControlMapping) != 0) return 13;
  if (sizeof(PlutoSCR::Control) != sizeof(PlutoSCR::Control)) return 14;
  std::cout << "PLUTOSCR_IPC_UNIFIED=PASS\n";
  std::wcout << L"game=" << PlutoSCR::kMappingName << L"\n";
  std::wcout << L"control=" << PlutoSCR::kControlName << L"\n";
  std::cout << "version=" << PlutoSCR::kVersion << "\n";
  return 0;
}
