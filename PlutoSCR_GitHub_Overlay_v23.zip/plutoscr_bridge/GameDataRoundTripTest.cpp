#include "PlutoSCRShared.h"
#include "SCRStateProjection.h"
#include "BWAPICommandDrain.h"
#include <BWAPI/UnitCommandType.h>
#include <cstring>
#include <iostream>
#include <memory>

#define CHECK(x) do { if(!(x)) { std::cerr<<"FAIL line "<<__LINE__<<": "<<#x<<"\n"; return __LINE__; } } while(0)

int main() {
  auto data = std::make_unique<BWAPI::GameData>();
  std::memset(data.get(),0,sizeof(BWAPI::GameData));

  PlutoSCR::Control ctl{};
  ctl.magic=PlutoSCR::Magic; ctl.version=PlutoSCR::Version;
  ctl.state=(std::int32_t)PlutoSCR::State::RuntimeReady;
  ctl.stateSequence=0; ctl.publishedFrame=-1; ctl.consumedFrame=-1;
  ctl.commandSequence=0; ctl.drainedCommandSequence=0;

  PlutoSCR::SCRFrameSnapshot snap;
  snap.frame=4242; snap.activeMatch=true; snap.self=0; snap.enemy=1;
  snap.mapWidth=128; snap.mapHeight=128; snap.mapName="roundtrip";
  PlutoSCR::SCRUnitSnapshot u;
  u.bwapiId=7; u.player=0; u.type=0; u.x=111; u.y=222; u.hp=40;
  u.exists=true; u.completed=true; u.visible=true;
  snap.units.push_back(u);

  // x64 runtime publish phase, same seqlock protocol used by SharedGameData.
  ++ctl.stateSequence; CHECK((ctl.stateSequence&1)==1);
  PlutoSCR::projectValidatedSnapshot(snap,*data);
  ctl.publishedFrame=snap.frame;
  ++ctl.stateSequence; CHECK((ctl.stateSequence&1)==0);

  // x86 host-visible assertions: exact GameData memory, no conversion copy.
  CHECK(data->frameCount==4242);
  CHECK(data->isInGame);
  CHECK(data->units[7].exists);
  CHECK(data->units[7].positionX==111);
  CHECK(data->units[7].positionY==222);

  // Stand in for one standard BWAPIClient output written by Pluto/GameImpl.
  data->unitCommandCount=1;
  auto &c=data->unitCommands[0];
  c.type=BWAPI::UnitCommandTypes::Move;
  c.unitIndex=7;
  c.x=333; c.y=444;
  ctl.consumedFrame=ctl.publishedFrame;
  ++ctl.commandSequence;

  // x64 runtime drain phase.
  CHECK(ctl.commandSequence!=ctl.drainedCommandSequence);
  auto drained=PlutoSCR::drainBWAPIClientCommands(*data);
  CHECK(drained.rejected.empty());
  CHECK(drained.requests.size()==1);
  CHECK(drained.requests[0].name=="Move");
  CHECK(drained.requests[0].arguments.size()==2);
  CHECK(drained.requests[0].arguments[0]==333);
  CHECK(drained.requests[0].arguments[1]==444);
  CHECK(data->unitCommandCount==0);
  ctl.lastUnitCommandCount=(std::int32_t)drained.requests.size();
  ctl.drainedCommandSequence=ctl.commandSequence;

  CHECK(ctl.consumedFrame==ctl.publishedFrame);
  CHECK(ctl.drainedCommandSequence==ctl.commandSequence);
  std::cout<<"PLUTOSCR_GAMEDATA_ROUNDTRIP=PASS\n";
  std::cout<<"frame="<<ctl.publishedFrame<<" unit=7 state_xy=111,222 command=Move command_xy=333,444\n";
  return 0;
}
