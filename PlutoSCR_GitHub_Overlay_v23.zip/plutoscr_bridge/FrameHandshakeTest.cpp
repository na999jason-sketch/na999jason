#include "FrameHandshake.h"
#include <iostream>

#define CHECK(x) do { if(!(x)) { std::cerr << "FAIL line " << __LINE__ << ": " #x "\n"; return 1; } } while(0)

int main() {
  plutoscr::FrameHandshake h{};
  plutoscr::initializeFrameHandshake(h);

  CHECK(plutoscr::runtimeCanPublish(h));
  CHECK(plutoscr::runtimeBeginPublish(h, 100));
  CHECK(!plutoscr::runtimeCanPublish(h));
  plutoscr::runtimeFinishPublish(h);

  std::int32_t frame=-1;
  CHECK(plutoscr::hostBeginConsume(h, frame));
  CHECK(frame == 100);
  CHECK(plutoscr::hostCommitCommands(h, frame));
  CHECK(!plutoscr::hostCommitCommands(h, frame));

  CHECK(plutoscr::runtimeCanDrain(h));
  CHECK(plutoscr::runtimeFinishDrain(h));
  CHECK(!plutoscr::runtimeCanDrain(h));
  CHECK(plutoscr::runtimeCanPublish(h));

  CHECK(plutoscr::runtimeBeginPublish(h, 101));
  plutoscr::runtimeFinishPublish(h);
  CHECK(plutoscr::hostBeginConsume(h, frame));
  CHECK(frame == 101);
  CHECK(plutoscr::hostCommitCommands(h, frame));
  CHECK(plutoscr::runtimeFinishDrain(h));

  std::cout << "PLUTOSCR_FRAME_HANDSHAKE=PASS\n";
  std::cout << "published=" << h.publishedFrame
            << " consumed=" << h.consumedFrame
            << " drained=" << h.drainedFrame
            << " stateSequence=" << h.stateSequence
            << " commandSequence=" << h.commandSequence << "\n";
  return 0;
}
