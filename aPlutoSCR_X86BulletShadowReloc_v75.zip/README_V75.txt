aPlutoSCR v75 x86 - original Pluto bullet-list compatibility probe

Goal: run the unmodified original Pluto observation/decision/action logic against live StarCraft: Remastered x86 state.
This overlay does not implement AI decisions. It extends v74's verified dynamic CUnit bridge with a fail-closed legacy bullet-list bridge for Pluto's BW 1.16.1 address 0x64DEC4.

v75 behavior:
- Keeps v74's dynamically discovered CUnit prev/next links and semantic visible/hidden/scanner heads.
- Verifies Pluto RVA 0xBC75 is exactly `mov ebx, dword ptr [0x64DEC4]` before patching.
- Scans live process memory for plausible 112-byte CBullet objects by cross-checking their unit references against the already verified live CUnit set.
- If active bullets are found, builds a legacy 112-byte bullet shadow list and remaps bullet->unit pointers into the legacy CUnit shadow.
- If no plausible active bullets exist at snapshot time, exposes a null legacy bullet head (the correct BW 1.16.1 representation for an empty bullet list).
- Ambiguous bullet candidates fail closed rather than fabricating an observation.
- Pluto command delivery remains disabled until a verified synchronized SC:R command sink is connected.
- SEH logging now records x86 registers and 16 instruction bytes for the next unported legacy reference.

Expected log: plutoscr-x86-v75.log
