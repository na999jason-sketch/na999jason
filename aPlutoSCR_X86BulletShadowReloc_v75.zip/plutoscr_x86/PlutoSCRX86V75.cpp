#ifndef NOMINMAX
#define NOMINMAX
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <BWAPI/Client/Client.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <sstream>

static HMODULE g_self=nullptr;
using PFNGameInit=void(*)(BWAPI::Game*);
using PFNCreateAI=BWAPI::AIModule*(*)();
static std::string dirOf(HMODULE m){char p[MAX_PATH]={};GetModuleFileNameA(m,p,MAX_PATH);std::string s(p);auto n=s.find_last_of("\\/");return n==std::string::npos?".":s.substr(0,n);}
static void logLine(const std::string&s){std::ofstream f(dirOf(g_self)+"\\plutoscr-x86-v75.log",std::ios::app);f<<s<<"\r\n";}
static volatile DWORD g_sehCode=0;static volatile uintptr_t g_sehAddress=0;static volatile uintptr_t g_sehEip=0;
static volatile uintptr_t g_sehAccessAddress=0;static volatile ULONG_PTR g_sehAccessType=~(ULONG_PTR)0;
static volatile uintptr_t g_sehEax=0,g_sehEbx=0,g_sehEcx=0,g_sehEdx=0,g_sehEsi=0,g_sehEdi=0,g_sehEbp=0,g_sehEsp=0;
static int captureSeh(EXCEPTION_POINTERS*ep){if(ep&&ep->ExceptionRecord){g_sehCode=ep->ExceptionRecord->ExceptionCode;g_sehAddress=(uintptr_t)ep->ExceptionRecord->ExceptionAddress;
if(ep->ExceptionRecord->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && ep->ExceptionRecord->NumberParameters>=2){g_sehAccessType=ep->ExceptionRecord->ExceptionInformation[0];g_sehAccessAddress=(uintptr_t)ep->ExceptionRecord->ExceptionInformation[1];}}
#if defined(_M_IX86)
if(ep&&ep->ContextRecord){g_sehEip=(uintptr_t)ep->ContextRecord->Eip;g_sehEax=ep->ContextRecord->Eax;g_sehEbx=ep->ContextRecord->Ebx;g_sehEcx=ep->ContextRecord->Ecx;g_sehEdx=ep->ContextRecord->Edx;g_sehEsi=ep->ContextRecord->Esi;g_sehEdi=ep->ContextRecord->Edi;g_sehEbp=ep->ContextRecord->Ebp;g_sehEsp=ep->ContextRecord->Esp;}
#endif
return EXCEPTION_EXECUTE_HANDLER;}
static DWORD onStartSeh(BWAPI::AIModule*m){g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;__try{m->onStart();return 0;}__except(captureSeh(GetExceptionInformation())){return g_sehCode;}}
static DWORD onFrameSeh(BWAPI::AIModule*m){
  g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;
  __try{m->onFrame();return 0;}
  __except(captureSeh(GetExceptionInformation())){return g_sehCode;}
}

#pragma pack(push,1)
struct LegacyCUnit336{ unsigned char b[336]; };
#pragma pack(pop)
static_assert(sizeof(LegacyCUnit336)==336,"CUnit size");

template<class T> static T rd(const unsigned char*p,size_t o){T v{};std::memcpy(&v,p+o,sizeof(v));return v;}
static bool readable(const void*p,size_t n){
  MEMORY_BASIC_INFORMATION mi{}; if(!VirtualQuery(p,&mi,sizeof(mi)))return false;
  if(mi.State!=MEM_COMMIT || (mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
  uintptr_t a=(uintptr_t)p; uintptr_t e=a+(uintptr_t)n; uintptr_t r=(uintptr_t)mi.BaseAddress+(uintptr_t)mi.RegionSize; return e>=a && e<=r;
}
static bool plausibleUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  auto hp=rd<int32_t>(p,0x08); auto spr=rd<uint32_t>(p,0x0c); auto x=rd<int16_t>(p,0x28); auto y=rd<int16_t>(p,0x2a);
  auto player=rd<uint8_t>(p,0x4c); auto order=rd<uint8_t>(p,0x4d); auto type=rd<uint16_t>(p,0x64);
  return spr!=0 && hp>0 && hp<(5000000*256) && x>=0&&x<=16384&&y>=0&&y<=16384&&player<12&&order<256&&type<234;
}
struct UnitStore{uintptr_t descriptor=0,begin=0,end=0,cap=0;int score=0;};
static UnitStore scanDescriptorRange(uintptr_t s,uintptr_t e,const char*tag){
  UnitStore best{}; MEMORY_BASIC_INFORMATION mi{}; uintptr_t a=s; unsigned long regions=0; unsigned long descriptors=0;
  logLine(std::string("checkpoint.scan_range.begin=")+tag);
  while(a<e && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;
    if(re<=a)break;
    uintptr_t lo=std::max(a,rs),hi=std::min(e,re);
    bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) &&
      (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && hi>lo && hi-lo>=12){
      ++regions;
      for(uintptr_t q=(lo+3)&~uintptr_t(3);q+12<=hi;q+=4){
        uint32_t b=0,en=0,c=0;
        std::memcpy(&b,(void*)q,4);std::memcpy(&en,(void*)(q+4),4);std::memcpy(&c,(void*)(q+8),4);
        if(!b||en<b||c<en)continue;uint32_t used=en-b,cap=c-b;
        if(used==0||used%336||cap%336)continue;uint32_t count=used/336,capacity=cap/336;
        if(count<2||count>3400||capacity<count||capacity>3400)continue;
        if(!readable((void*)(uintptr_t)b,std::min<uint32_t>(used,336*64)))continue;
        ++descriptors;int score=0;uint32_t step=std::max<uint32_t>(1,count/64);
        for(uint32_t i=0;i<count&&i<3400;i+=step)if(plausibleUnit((unsigned char*)(uintptr_t)(b+i*336)))++score;
        if(score>best.score){best={q,b,en,c,score};}
      }
    }
    a=re;
  }
  logLine(std::string("checkpoint.scan_range.end=")+tag+" regions="+std::to_string(regions)+" descriptors="+std::to_string(descriptors)+" best_score="+std::to_string(best.score));
  return best;
}
static UnitStore findLegacyCUnitVector(){
  logLine("checkpoint.cunit_scan.enter");
  HMODULE exe=GetModuleHandleA(nullptr);
  if(exe){
    auto base=(uintptr_t)exe;auto dos=(IMAGE_DOS_HEADER*)base;
    if(readable(dos,sizeof(*dos))&&dos->e_magic==IMAGE_DOS_SIGNATURE){
      auto nt=(IMAGE_NT_HEADERS*)(base+dos->e_lfanew);
      if(readable(nt,sizeof(*nt))&&nt->Signature==IMAGE_NT_SIGNATURE){
        uintptr_t end=base+(uintptr_t)nt->OptionalHeader.SizeOfImage;
        logLine("checkpoint.cunit_scan.module_base="+std::to_string((unsigned long)base));
        logLine("checkpoint.cunit_scan.module_size="+std::to_string((unsigned long)nt->OptionalHeader.SizeOfImage));
        UnitStore m=scanDescriptorRange(base,end,"main_module");
        if(m.score>=2){logLine("checkpoint.cunit_scan.module_hit");return m;}
      }
    }
  }
  logLine("checkpoint.cunit_scan.fallback_begin");
  SYSTEM_INFO si{};GetSystemInfo(&si);
  UnitStore f=scanDescriptorRange((uintptr_t)si.lpMinimumApplicationAddress,(uintptr_t)si.lpMaximumApplicationAddress,"process");
  logLine("checkpoint.cunit_scan.fallback_end");
  return f;
}

static uintptr_t g_scrVisibleUnitHead=0;
static uintptr_t g_scrHiddenUnitHead=0;
static uintptr_t g_scrScannerSweepHead=0;
static int g_linkPrevOff=-1;
static int g_linkNextOff=-1;
static std::vector<LegacyCUnit336> g_legacyCUnits;
static std::vector<uintptr_t> g_legacyRawUnits;

#pragma pack(push,1)
struct LegacyBullet112{ unsigned char b[112]; };
struct LegacySprite36{ unsigned char b[36]; };
#pragma pack(pop)
static_assert(sizeof(LegacyBullet112)==112,"Bullet size");
static_assert(sizeof(LegacySprite36)==36,"Sprite size");
static uintptr_t g_legacyBulletHead=0;
static std::vector<LegacyBullet112> g_legacyBullets;
static std::vector<LegacySprite36> g_legacyBulletSprites;
static std::vector<uintptr_t> g_legacyRawBullets;
static std::unordered_map<uintptr_t,size_t> g_rawBulletIndex;

static bool presentScrUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  return rd<uint32_t>(p,0x0c)!=0 && rd<uint16_t>(p,0x64)<228;
}
static bool rawMember(const std::vector<uintptr_t>&raws,uintptr_t p){
  return p && std::binary_search(raws.begin(),raws.end(),p);
}
static uintptr_t shadowForRaw(uintptr_t raw){
  if(!raw)return 0;
  auto it=std::lower_bound(g_legacyRawUnits.begin(),g_legacyRawUnits.end(),raw);
  if(it==g_legacyRawUnits.end()||*it!=raw)return 0;
  size_t i=(size_t)(it-g_legacyRawUnits.begin());
  return (uintptr_t)&g_legacyCUnits[i];
}
static std::vector<uintptr_t> collectPresentRaw(const UnitStore&s){
  std::vector<uintptr_t> out;
  if(!s.begin||s.end<=s.begin)return out;
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  out.reserve(count);
  for(uint32_t i=0;i<count;i++){
    uintptr_t raw=s.begin+(uintptr_t)i*336;
    if(presentScrUnit((unsigned char*)raw))out.push_back(raw);
  }
  return out;
}
struct ChainInfo{uintptr_t head=0;std::vector<uintptr_t> nodes;int scanner33=0;};
struct LinkCandidate{int prevOff=-1,nextOff=-1,valid=0,reciprocal=0,coverage=0,longest=0,chains=0,score=0;};
static std::vector<ChainInfo> chainsFor(const std::vector<uintptr_t>&raws,int prevOff,int nextOff,int*coverageOut=nullptr){
  std::vector<ChainInfo> chains;std::unordered_set<uintptr_t> visited;
  for(uintptr_t raw:raws){
    uint32_t prev=rd<uint32_t>((unsigned char*)raw,(size_t)prevOff);
    uint32_t next=rd<uint32_t>((unsigned char*)raw,(size_t)nextOff);
    if(prev!=0 || (next!=0 && !rawMember(raws,next)))continue;
    ChainInfo c{};c.head=raw;std::unordered_set<uintptr_t> local;uintptr_t cur=raw;
    while(cur && rawMember(raws,cur) && !local.count(cur) && c.nodes.size()<=raws.size()){
      local.insert(cur);visited.insert(cur);c.nodes.push_back(cur);
      if(rd<uint16_t>((unsigned char*)cur,0x64)==33)++c.scanner33;
      uint32_t n=rd<uint32_t>((unsigned char*)cur,(size_t)nextOff);
      if(!n)break;
      if(!rawMember(raws,n))break;
      uint32_t back=rd<uint32_t>((unsigned char*)(uintptr_t)n,(size_t)prevOff);
      if(back!=(uint32_t)cur)break;
      cur=n;
    }
    if(!c.nodes.empty())chains.push_back(std::move(c));
  }
  std::sort(chains.begin(),chains.end(),[](const ChainInfo&a,const ChainInfo&b){return a.nodes.size()>b.nodes.size();});
  if(coverageOut)*coverageOut=(int)visited.size();
  return chains;
}
static LinkCandidate evaluateLinkPair(const std::vector<uintptr_t>&raws,int prevOff){
  LinkCandidate c{};c.prevOff=prevOff;c.nextOff=prevOff+4;
  for(uintptr_t raw:raws){
    uint32_t prev=rd<uint32_t>((unsigned char*)raw,(size_t)c.prevOff);
    uint32_t next=rd<uint32_t>((unsigned char*)raw,(size_t)c.nextOff);
    bool pv=(prev==0)||rawMember(raws,prev),nv=(next==0)||rawMember(raws,next);
    if(pv&&nv)++c.valid;
    if(next && rawMember(raws,next)){
      uint32_t back=rd<uint32_t>((unsigned char*)(uintptr_t)next,(size_t)c.prevOff);
      if(back==(uint32_t)raw)++c.reciprocal;
    }
    if(prev && rawMember(raws,prev)){
      uint32_t fwd=rd<uint32_t>((unsigned char*)(uintptr_t)prev,(size_t)c.nextOff);
      if(fwd==(uint32_t)raw)++c.reciprocal;
    }
  }
  auto chains=chainsFor(raws,c.prevOff,c.nextOff,&c.coverage);c.chains=(int)chains.size();
  for(const auto&x:chains)c.longest=std::max(c.longest,(int)x.nodes.size());
  // Master CUnit list fields should be valid for almost every allocated unit,
  // reciprocal in both directions, and produce one dominant chain rather than
  // per-player/per-order sublists.  Favor those properties heavily.
  c.score=c.valid*2+c.reciprocal*4+c.coverage*5+c.longest*8-c.chains*2;
  return c;
}
static bool discoverDynamicCUnitLinks(const UnitStore&s){
  auto raws=collectPresentRaw(s);
  logLine("dynamic_links.present="+std::to_string(raws.size()));
  if(raws.size()<2)return false;
  std::vector<LinkCandidate> cs;
  for(int off=0;off<=328;off+=4){
    auto c=evaluateLinkPair(raws,off);
    if(c.valid>=(int)(raws.size()*9/10))cs.push_back(c);
  }
  std::sort(cs.begin(),cs.end(),[](const LinkCandidate&a,const LinkCandidate&b){return a.score>b.score;});
  for(size_t i=0;i<cs.size()&&i<12;i++){
    const auto&c=cs[i];
    logLine("dynamic_links.candidate["+std::to_string(i)+"] prev="+std::to_string(c.prevOff)+" next="+std::to_string(c.nextOff)+
      " valid="+std::to_string(c.valid)+" reciprocal="+std::to_string(c.reciprocal)+" coverage="+std::to_string(c.coverage)+
      " longest="+std::to_string(c.longest)+" chains="+std::to_string(c.chains)+" score="+std::to_string(c.score));
  }
  if(cs.empty()){logLine("dynamic_links=NO_CANDIDATE");return false;}
  const auto&b=cs.front();
  const int n=(int)raws.size();
  if(b.valid<n*9/10 || b.coverage<n*8/10 || b.longest<n*6/10){logLine("dynamic_links=LOW_CONFIDENCE");return false;}
  if(cs.size()>1 && b.score==cs[1].score){logLine("dynamic_links=AMBIGUOUS_TIE");return false;}
  g_linkPrevOff=b.prevOff;g_linkNextOff=b.nextOff;
  logLine("dynamic_links.selected.prev="+std::to_string(g_linkPrevOff)+" next="+std::to_string(g_linkNextOff));
  return true;
}
static bool classifySemanticHeads(const std::vector<uintptr_t>&raws,bool logValues,uintptr_t*outVisible,uintptr_t*outHidden,uintptr_t*outScanner){
  if(g_linkPrevOff<0||g_linkNextOff<0)return false;
  int coverage=0;auto chains=chainsFor(raws,g_linkPrevOff,g_linkNextOff,&coverage);
  if(logValues)logLine("semantic_chains.count="+std::to_string(chains.size())+" coverage="+std::to_string(coverage));
  for(size_t i=0;i<chains.size()&&i<12;i++)if(logValues){
    logLine("semantic_chain["+std::to_string(i)+"].head="+std::to_string((unsigned long)chains[i].head)+
      " len="+std::to_string(chains[i].nodes.size())+" scanner33="+std::to_string(chains[i].scanner33));
  }
  uintptr_t scanner=0,visible=0,hidden=0;size_t visibleLen=0,hiddenLen=0;int nonScanner=0;
  for(const auto&c:chains){
    if(c.scanner33>0){
      if(scanner){logLine("semantic_heads=MULTIPLE_SCANNER_CHAINS");return false;}
      scanner=c.head;continue;
    }
    ++nonScanner;
    if(c.nodes.size()>visibleLen){hidden=visible;hiddenLen=visibleLen;visible=c.head;visibleLen=c.nodes.size();}
    else if(c.nodes.size()>hiddenLen){hidden=c.head;hiddenLen=c.nodes.size();}
  }
  if(!visible || visibleLen<raws.size()*6/10){logLine("semantic_heads=VISIBLE_NOT_DOMINANT");return false;}
  // A second non-scanner chain is accepted as the hidden-unit list only when
  // it is small compared with the visible list. Multiple large partitions are
  // characteristic of another CUnit linkage (e.g. per-player), not visibility.
  if(nonScanner>2){logLine("semantic_heads=TOO_MANY_NONSCANNER_CHAINS");return false;}
  if(hidden && hiddenLen>std::max<size_t>(32,visibleLen/4)){logLine("semantic_heads=SECOND_CHAIN_TOO_LARGE");return false;}
  if(outVisible)*outVisible=visible;if(outHidden)*outHidden=hidden;if(outScanner)*outScanner=scanner;
  if(logValues)logLine("semantic_heads.raw.visible="+std::to_string((unsigned long)visible)+" hidden="+std::to_string((unsigned long)hidden)+" scanner="+std::to_string((unsigned long)scanner));
  return true;
}
static bool refreshSemanticHeads(bool logValues){
  uintptr_t visible=0,hidden=0,scanner=0;
  if(!classifySemanticHeads(g_legacyRawUnits,logValues,&visible,&hidden,&scanner))return false;
  g_scrVisibleUnitHead=shadowForRaw(visible);
  g_scrHiddenUnitHead=shadowForRaw(hidden);
  g_scrScannerSweepHead=shadowForRaw(scanner);
  if(logValues)logLine("semantic_heads.shadow.visible="+std::to_string((unsigned long)g_scrVisibleUnitHead)+" hidden="+std::to_string((unsigned long)g_scrHiddenUnitHead)+" scanner="+std::to_string((unsigned long)g_scrScannerSweepHead));
  return g_scrVisibleUnitHead!=0;
}
static void translateShadowListLinks(){
  for(size_t i=0;i<g_legacyCUnits.size();++i){
    auto*src=(unsigned char*)g_legacyRawUnits[i];
    uint32_t rawPrev=rd<uint32_t>(src,(size_t)g_linkPrevOff),rawNext=rd<uint32_t>(src,(size_t)g_linkNextOff);
    uint32_t prev=(uint32_t)shadowForRaw(rawPrev),next=(uint32_t)shadowForRaw(rawNext);
    std::memcpy(g_legacyCUnits[i].b+0x00,&prev,4);std::memcpy(g_legacyCUnits[i].b+0x04,&next,4);
  }
}
static int buildLegacyCUnitShadow(const UnitStore&s){
  if(g_linkPrevOff<0 && !discoverDynamicCUnitLinks(s))return 0;
  if(g_legacyCUnits.capacity()<3400)g_legacyCUnits.reserve(3400);
  if(g_legacyRawUnits.capacity()<3400)g_legacyRawUnits.reserve(3400);
  g_legacyCUnits.clear();g_legacyRawUnits=collectPresentRaw(s);
  for(uintptr_t raw:g_legacyRawUnits){LegacyCUnit336 u{};std::memcpy(u.b,(void*)raw,336);g_legacyCUnits.push_back(u);}
  translateShadowListLinks();
  if(!refreshSemanticHeads(true)){g_scrVisibleUnitHead=g_scrHiddenUnitHead=g_scrScannerSweepHead=0;return 0;}
  return (int)g_legacyCUnits.size();
}
static int refreshLegacyCUnitShadow(const UnitStore&s){
  auto now=collectPresentRaw(s);
  if(now!=g_legacyRawUnits)return buildLegacyCUnitShadow(s);
  for(size_t i=0;i<g_legacyCUnits.size();++i)std::memcpy(g_legacyCUnits[i].b,(void*)g_legacyRawUnits[i],336);
  translateShadowListLinks();
  if(!refreshSemanticHeads(false))return 0;
  return (int)g_legacyCUnits.size();
}


static bool plausibleBullet(const unsigned char*p,const std::unordered_set<uint32_t>&unitSet){
  if(!readable(p,112))return false;
  if(unitSet.count((uint32_t)(uintptr_t)p))return false;
  uint32_t exists=rd<uint32_t>(p,0x08),spr=rd<uint32_t>(p,0x0c);
  int16_t x=rd<int16_t>(p,0x28),y=rd<int16_t>(p,0x2a);
  uint8_t player=rd<uint8_t>(p,0x4c),beh=rd<uint8_t>(p,0x4d),weapon=rd<uint8_t>(p,0x60);
  uint32_t u0=rd<uint32_t>(p,0x14),u1=rd<uint32_t>(p,0x5c),u2=rd<uint32_t>(p,0x64),u3=rd<uint32_t>(p,0x68);
  auto unitOk=[&](uint32_t u){return u==0 || unitSet.count(u)!=0;};
  int linked=(unitSet.count(u0)?1:0)+(unitSet.count(u1)?1:0)+(unitSet.count(u2)?1:0)+(unitSet.count(u3)?1:0);
  return exists>=1 && exists<=4 && spr!=0 && readable((void*)(uintptr_t)spr,36) &&
         x>=0&&x<=16384&&y>=0&&y<=16384 && player<12 && beh<=8 && weapon<200 &&
         unitOk(u0)&&unitOk(u1)&&unitOk(u2)&&unitOk(u3) && linked>0;
}
static std::vector<uintptr_t> scanBulletCandidates(){
  std::vector<uintptr_t> out;
  std::unordered_set<uint32_t> unitSet;unitSet.reserve(g_legacyRawUnits.size()*2+1);
  for(uintptr_t u:g_legacyRawUnits)unitSet.insert((uint32_t)u);
  std::unordered_set<uintptr_t> seen;
  SYSTEM_INFO si{};GetSystemInfo(&si);MEMORY_BASIC_INFORMATION mi{};
  uintptr_t a=(uintptr_t)si.lpMinimumApplicationAddress,e=(uintptr_t)si.lpMaximumApplicationAddress;
  unsigned long regions=0;unsigned long unitRefs=0;
  while(a<e && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;if(re<=a)break;
    bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) &&
      (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && re>rs+4){
      ++regions;
      uintptr_t lo=(rs+3)&~uintptr_t(3),hi=re-4;
      for(uintptr_t q=lo;q<=hi;q+=4){
        uint32_t v=0;std::memcpy(&v,(void*)q,4);if(!unitSet.count(v))continue;++unitRefs;
        const int offs[]={0x14,0x5c,0x64,0x68};
        for(int off:offs){
          if(q<(uintptr_t)off)continue;uintptr_t b=q-(uintptr_t)off;
          if(seen.count(b))continue;
          if((b&3)!=0)continue;
          if(plausibleBullet((unsigned char*)b,unitSet)){seen.insert(b);out.push_back(b);}
        }
      }
    }
    a=re;
  }
  std::sort(out.begin(),out.end());
  logLine("bullet_scan.regions="+std::to_string(regions)+" unit_refs="+std::to_string(unitRefs)+" candidates="+std::to_string(out.size()));
  return out;
}
static uintptr_t shadowBulletForRaw(uintptr_t raw){
  if(!raw)return 0;auto it=g_rawBulletIndex.find(raw);if(it==g_rawBulletIndex.end())return 0;
  return (uintptr_t)&g_legacyBullets[it->second];
}
static bool buildLegacyBulletShadow(){
  auto candidates=scanBulletCandidates();
  g_legacyBullets.clear();g_legacyBulletSprites.clear();g_legacyRawBullets.clear();g_rawBulletIndex.clear();g_legacyBulletHead=0;
  if(candidates.empty()){
    logLine("legacy_bullet_shadow.active=0");
    logLine("legacy_bullet_shadow.head=0");
    return true;
  }
  std::unordered_set<uintptr_t> set(candidates.begin(),candidates.end());
  struct BChain{uintptr_t head=0;std::vector<uintptr_t> nodes;};
  std::vector<BChain> chains;
  for(uintptr_t b:candidates){
    uint32_t prev=rd<uint32_t>((unsigned char*)b,0),next=rd<uint32_t>((unsigned char*)b,4);
    if(prev && set.count(prev))continue;
    BChain c{};c.head=b;std::unordered_set<uintptr_t> local;uintptr_t cur=b;
    while(cur && set.count(cur) && !local.count(cur) && c.nodes.size()<=candidates.size()){
      local.insert(cur);c.nodes.push_back(cur);uint32_t n=rd<uint32_t>((unsigned char*)cur,4);
      if(!n)break;if(!set.count(n))break;
      uint32_t back=rd<uint32_t>((unsigned char*)(uintptr_t)n,0);if(back!=(uint32_t)cur)break;cur=n;
    }
    if(!c.nodes.empty())chains.push_back(std::move(c));
  }
  std::sort(chains.begin(),chains.end(),[](const BChain&a,const BChain&b){return a.nodes.size()>b.nodes.size();});
  if(chains.empty()){logLine("legacy_bullet_shadow=NO_CHAIN");return false;}
  if(chains.size()>1 && chains[0].nodes.size()==chains[1].nodes.size()){logLine("legacy_bullet_shadow=AMBIGUOUS_CHAIN");return false;}
  const auto&best=chains[0];
  if(best.nodes.size()<candidates.size()/2 && candidates.size()>2){logLine("legacy_bullet_shadow=LOW_COVERAGE");return false;}
  g_legacyRawBullets=best.nodes;
  g_legacyBullets.resize(best.nodes.size());g_legacyBulletSprites.resize(best.nodes.size());
  g_rawBulletIndex.reserve(best.nodes.size()*2+1);
  for(size_t i=0;i<best.nodes.size();++i)g_rawBulletIndex.emplace(best.nodes[i],i);
  for(size_t i=0;i<best.nodes.size();++i){
    uintptr_t raw=best.nodes[i];auto*src=(unsigned char*)raw;std::memcpy(g_legacyBullets[i].b,src,112);
  }
  for(size_t i=0;i<best.nodes.size();++i){
    uintptr_t raw=best.nodes[i];auto*src=(unsigned char*)raw;auto&dst=g_legacyBullets[i];
    uint32_t prev=(uint32_t)shadowBulletForRaw(rd<uint32_t>(src,0)),next=(uint32_t)shadowBulletForRaw(rd<uint32_t>(src,4));
    std::memcpy(dst.b+0,&prev,4);std::memcpy(dst.b+4,&next,4);
    for(int off:{0x14,0x5c,0x64,0x68}){
      uint32_t u=(uint32_t)shadowForRaw(rd<uint32_t>(src,(size_t)off));std::memcpy(dst.b+off,&u,4);
    }
    uint32_t rawSprite=rd<uint32_t>(src,0x0c);uint32_t spriteShadow=0;
    if(rawSprite && readable((void*)(uintptr_t)rawSprite,40)){
      auto&s=g_legacyBulletSprites[i];std::memset(s.b,0,sizeof(s.b));std::memcpy(s.b,(void*)(uintptr_t)rawSprite,20);
      uint32_t z=0;std::memcpy(s.b,&z,4);std::memcpy(s.b+4,&z,4);
      uint16_t v20=(uint16_t)rd<uint32_t>((unsigned char*)(uintptr_t)rawSprite,20);
      uint16_t v22=(uint16_t)rd<uint32_t>((unsigned char*)(uintptr_t)rawSprite,24);
      std::memcpy(s.b+20,&v20,2);std::memcpy(s.b+22,&v22,2);
      if(readable((void*)(uintptr_t)(rawSprite+28),12))std::memcpy(s.b+24,(void*)(uintptr_t)(rawSprite+28),12);
      spriteShadow=(uint32_t)(uintptr_t)&s;
    }
    std::memcpy(dst.b+0x0c,&spriteShadow,4);
  }
  g_legacyBulletHead=shadowBulletForRaw(best.head);
  logLine("legacy_bullet_shadow.active="+std::to_string(g_legacyRawBullets.size()));
  logLine("legacy_bullet_shadow.raw_head="+std::to_string((unsigned long)best.head));
  logLine("legacy_bullet_shadow.head="+std::to_string((unsigned long)g_legacyBulletHead));
  return g_legacyBulletHead!=0;
}

static int inferRace(int type){if(type<=59||(type>=106&&type<=131))return 1;if((type>=88&&type<=103)||(type>=132&&type<=157))return 0;if((type>=60&&type<=87)||type==97||(type>=159&&type<=173))return 2;return 5;}
static int projectLiveUnits(const UnitStore&s,BWAPI::GameData&d){
  if(!s.begin||s.end<s.begin)return 0; int out=0; std::array<int,12> counts{}; std::array<int,12> race{}; race.fill(5);
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  for(uint32_t i=0;i<count && out<10000;i++){
    auto*p=(unsigned char*)(s.begin+i*336); if(!plausibleUnit(p))continue;
    auto&q=d.units[out]; ZeroMemory(&q,sizeof(q)); q.id=out;q.player=rd<uint8_t>(p,0x4c);q.type=rd<uint16_t>(p,0x64);q.positionX=rd<int16_t>(p,0x28);q.positionY=rd<int16_t>(p,0x2a);
    q.hitPoints=std::max(0,rd<int32_t>(p,0x08)/256);q.shields=rd<uint32_t>(p,0x60)/256;q.energy=rd<uint16_t>(p,0xa2)/256;q.order=rd<uint8_t>(p,0x4d);
    q.targetPositionX=rd<int16_t>(p,0x58);q.targetPositionY=rd<int16_t>(p,0x5a);q.orderTargetPositionX=q.targetPositionX;q.orderTargetPositionY=q.targetPositionY;
    q.exists=true;auto flags=rd<uint32_t>(p,0xdc);q.isCompleted=(flags&1)!=0;q.isCloaked=(flags&0x200)!=0;q.isBurrowed=(flags&0x10)!=0;q.isInvincible=(flags&0x04000000)!=0;
    if(q.player>=0&&q.player<12){counts[q.player]++;race[q.player]=inferRace(q.type);} for(bool&v:q.isVisible)v=true; ++out;
  }
  d.initialUnitCount=out;d.playerCount=0;
  for(int p=0;p<12;p++)if(counts[p]){d.playerCount=std::max(d.playerCount,p+1);d.players[p].race=race[p];d.players[p].isParticipating=true;d.players[p].type=1;d.players[p].isAlly[p]=true;}
  return out;
}



#pragma pack(push,1)
struct Legacy57F1Compat {
  unsigned char pad0[0x1D4];
  short value_f1d4;
  short value_f1d6;
  unsigned char pad1[0x64];
  unsigned long value_f23c;
};
#pragma pack(pop)
static Legacy57F1Compat g_legacy57f1{};

static bool patchAbs32(unsigned char* insn,int immOff,const unsigned char* sig,int sigLen,uintptr_t target,const char* tag){
  if(memcmp(insn,sig,sigLen)!=0){logLine(std::string("reloc69.")+tag+".signature=MISMATCH");return false;}
  if(target>0xFFFFFFFFu){logLine(std::string("reloc69.")+tag+".target=OUT_OF_X86_RANGE");return false;}
  DWORD old=0;if(!VirtualProtect(insn,sigLen,PAGE_EXECUTE_READWRITE,&old)){logLine(std::string("reloc69.")+tag+".protect=FAIL");return false;}
  uint32_t v=(uint32_t)target;memcpy(insn+immOff,&v,4);FlushInstructionCache(GetCurrentProcess(),insn,sigLen);
  DWORD tmp=0;VirtualProtect(insn,sigLen,old,&tmp);
  logLine(std::string("reloc69.")+tag+"=PASS");return true;
}
static bool patchPlutoLegacy57F1Block(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char s1[5]={0xA1,0x3C,0xF2,0x57,0x00};
  const unsigned char s2[7]={0x0F,0xBF,0x05,0xD4,0xF1,0x57,0x00};
  const unsigned char s3[7]={0x0F,0xBF,0x15,0xD6,0xF1,0x57,0x00};
  bool a=patchAbs32(b+0xBC1B,1,s1,5,(uintptr_t)&g_legacy57f1.value_f23c,"rva_bc1b_f23c");
  bool c=patchAbs32(b+0xBC26,3,s2,7,(uintptr_t)&g_legacy57f1.value_f1d4,"rva_bc26_f1d4");
  bool d=patchAbs32(b+0xBC33,3,s3,7,(uintptr_t)&g_legacy57f1.value_f1d6,"rva_bc33_f1d6");
  return a&&c&&d;
}

static bool patchPlutoCUnitHead628430(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x1D,0x30,0x84,0x62,0x00};
  return patchAbs32(b+0x33F7D,2,sig,6,(uintptr_t)&g_scrVisibleUnitHead,"rva_33f7d_628430");
}

static bool patchPlutoCUnitHead6283EC(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x2D,0xEC,0x83,0x62,0x00};
  return patchAbs32(b+0x34149,2,sig,6,(uintptr_t)&g_scrHiddenUnitHead,"rva_34149_6283ec");
}

static bool patchPlutoCUnitHead6283F4(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x2D,0xF4,0x83,0x62,0x00};
  return patchAbs32(b+0x34250,2,sig,6,(uintptr_t)&g_scrScannerSweepHead,"rva_34250_6283f4");
}

static bool patchPlutoBulletHead64DEC4(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x1D,0xC4,0xDE,0x64,0x00};
  return patchAbs32(b+0xBC75,2,sig,6,(uintptr_t)&g_legacyBulletHead,"rva_bc75_64dec4");
}

static unsigned char g_reloc57fd3c[0x10000]{};

static bool patchPlutoLegacy57FD3C(HMODULE pluto){
  unsigned char* p=(unsigned char*)pluto+0x7536;
  const unsigned char expect[7]={0x0F,0xB6,0x90,0x3C,0xFD,0x57,0x00};
  if(memcmp(p,expect,7)!=0){
    logLine("reloc_probe.rva_7536_signature=MISMATCH");
    return false;
  }
  // Preserve the exact instruction shape; change only its disp32.
  // movzx edx, byte ptr [eax + disp32]
  uintptr_t compat=(uintptr_t)g_reloc57fd3c;
  if(compat>0xFFFFFFFFu){
    logLine("reloc_probe.compat_ptr=OUT_OF_X86_RANGE");
    return false;
  }
  unsigned char repl[7]={0x0F,0xB6,0x90,0,0,0,0};
  uint32_t disp=(uint32_t)compat;
  memcpy(repl+3,&disp,4);
  DWORD old=0;
  if(!VirtualProtect(p,7,PAGE_EXECUTE_READWRITE,&old)){
    logLine("reloc_probe.virtualprotect=FAIL gle="+std::to_string(GetLastError()));
    return false;
  }
  memcpy(p,repl,7);
  FlushInstructionCache(GetCurrentProcess(),p,7);
  DWORD tmp=0;VirtualProtect(p,7,old,&tmp);
  logLine("reloc_probe.rva_7536_signature=PASS");
  logLine("reloc_probe.rva_7536_patched=PASS");
  logLine("reloc_probe.compat_base="+std::to_string((unsigned long)compat));
  return true;
}

static int mapLegacyPlutoDataPages(){
  // MEM_RESERVE base addresses must honor Windows allocation granularity (normally 64 KiB).
  // These four 64 KiB blocks cover every legacy absolute data page currently observed in Pluto.
  const uintptr_t blocks[]={0x00510000,0x00570000,0x00580000,0x00590000};
  int mapped=0;
  SYSTEM_INFO si{};GetSystemInfo(&si);
  logLine("legacy_probe.allocation_granularity="+std::to_string((unsigned long)si.dwAllocationGranularity));
  for(uintptr_t a:blocks){
    MEMORY_BASIC_INFORMATION mbi{};
    if(!VirtualQuery((LPCVOID)a,&mbi,sizeof(mbi))){
      logLine("legacy_probe.virtualquery_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(GetLastError()));
      continue;
    }
    if(mbi.State==MEM_FREE){
      void*p=VirtualAlloc((LPVOID)a,0x10000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
      if(p==(void*)a){
        ++mapped;
        logLine("legacy_probe.mapped_block="+std::to_string((unsigned long)a));
      }else{
        DWORD gle=GetLastError();
        logLine("legacy_probe.map_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(gle));
        if(p)VirtualFree(p,0,MEM_RELEASE);
      }
    }else{
      logLine("legacy_probe.block_occupied="+std::to_string((unsigned long)a)+
              " state="+std::to_string((unsigned long)mbi.State)+
              " base="+std::to_string((unsigned long)(uintptr_t)mbi.BaseAddress)+
              " size="+std::to_string((unsigned long)mbi.RegionSize));
    }
  }
  return mapped;
}

static DWORD findLegacyCUnitVectorSeh(UnitStore*out){__try{*out=findLegacyCUnitVector();return 0;}__except(EXCEPTION_EXECUTE_HANDLER){return GetExceptionCode();}}
static DWORD WINAPI boot(LPVOID){
  DeleteFileA((dirOf(g_self)+"\\plutoscr-x86-v75.log").c_str());
  logLine("PLUTOSCR_V75_RESIDENT=LOADED");logLine("architecture=x86");logLine("policy=original-pluto-observation-untouched");
  logLine("checkpoint.boot.before_cunit_scan");
  UnitStore store{};
  DWORD scanEc=findLegacyCUnitVectorSeh(&store);
  if(scanEc){logLine("checkpoint.cunit_scan.SEH_EXCEPTION code="+std::to_string(scanEc));return 12;}
  logLine("checkpoint.boot.after_cunit_scan");
  logLine("scr_cunit_vector.descriptor="+std::to_string((unsigned long)store.descriptor));logLine("scr_cunit_vector.score="+std::to_string(store.score));
  if(store.score<2){logLine("scr_cunit_vector=UNRESOLVED");return 10;} logLine("scr_cunit_vector=BOUND");
  logLine("cunit_store.begin="+std::to_string((unsigned long)store.begin)+" end="+std::to_string((unsigned long)store.end)+" cap="+std::to_string((unsigned long)store.cap));
  const std::string d=dirOf(g_self);SetDllDirectoryA(d.c_str());HMODULE pluto=LoadLibraryA((d+"\\pluto.dll").c_str());if(!pluto){logLine("original_pluto.load=FAIL");return 1;}logLine("original_pluto.load=PASS");
  auto gameInit=(PFNGameInit)GetProcAddress(pluto,"gameInit");auto createAI=(PFNCreateAI)GetProcAddress(pluto,"newAIModule");if(!gameInit||!createAI){logLine("original_pluto.exports=FAIL");return 2;}
  auto*data=new BWAPI::GameData();ZeroMemory(data,sizeof(*data));int n=projectLiveUnits(store,*data);logLine("live_units="+std::to_string(n));if(n<2)return 11;
  // Choose the first participating slot only as a compatibility bootstrap; do not fabricate Pluto observations.
  int self=-1,enemy=-1;for(int p=0;p<12;p++)if(data->players[p].isParticipating){if(self<0)self=p;else if(enemy<0)enemy=p;}data->self=self;data->enemy=enemy;data->neutral=11;data->isInGame=true;
  logLine("gamedata.initialUnitCount="+std::to_string(data->initialUnitCount));
  logLine("gamedata.playerCount="+std::to_string(data->playerCount));
  logLine("gamedata.self="+std::to_string(self)+" enemy="+std::to_string(enemy)+" neutral="+std::to_string(data->neutral));
  for(int p=0;p<12;p++)if(data->players[p].isParticipating){int pc=0;for(int u=0;u<data->initialUnitCount;u++)if(data->units[u].player==p)++pc;logLine("gamedata.player["+std::to_string(p)+"].units="+std::to_string(pc)+" race="+std::to_string(data->players[p].race));}
  logLine("gamedata.mapWidth="+std::to_string(data->mapWidth)+" mapHeight="+std::to_string(data->mapHeight));
  BWAPI::BWAPIClient.data=data;auto*game=new BWAPI::GameImpl(data);BWAPI::BroodwarPtr=game;logLine("checkpoint.gameimpl.constructed");
  gameInit(game);logLine("checkpoint.original_pluto.gameInit.PASS");auto*module=createAI();if(!module){logLine("original_pluto.newAIModule=FAIL");return 3;}logLine("checkpoint.original_pluto.newAIModule.PASS");
  game->onMatchStart();logLine("checkpoint.bwapi.onMatchStart.PASS");
  logLine("reloc_probe.mode=pluto-original-observation-dynamic-cunit-links-bullet-shadow-no-command-sink");
  bool reloc7536=patchPlutoLegacy57FD3C(pluto);
  logLine(std::string("reloc_probe.patch_7536=")+(reloc7536?"PASS":"FAIL"));
  if(!reloc7536)return 13;
  bool reloc57f1=patchPlutoLegacy57F1Block(pluto);
  logLine(std::string("reloc70.patch_57f1_block=")+(reloc57f1?"PASS":"FAIL"));
  if(!reloc57f1)return 14;
  int headLen=buildLegacyCUnitShadow(store);
  logLine("legacy_cunit_shadow.count="+std::to_string(headLen));
  if(!g_scrVisibleUnitHead || headLen<2){logLine("legacy_cunit_shadow=UNRESOLVED");return 15;}
  logLine("legacy_cunit_shadow=BOUND");
  bool reloc628430=patchPlutoCUnitHead628430(pluto);
  logLine(std::string("reloc75.patch_628430=")+(reloc628430?"PASS":"FAIL"));
  if(!reloc628430)return 16;
  bool reloc6283ec=patchPlutoCUnitHead6283EC(pluto);
  logLine(std::string("reloc75.patch_6283ec=")+(reloc6283ec?"PASS":"FAIL"));
  if(!reloc6283ec)return 17;
  bool reloc6283f4=patchPlutoCUnitHead6283F4(pluto);
  logLine(std::string("reloc75.patch_6283f4=")+(reloc6283f4?"PASS":"FAIL"));
  if(!reloc6283f4)return 18;
  if(!buildLegacyBulletShadow()){logLine("legacy_bullet_shadow=UNRESOLVED_FAIL_CLOSED");return 19;}
  logLine("legacy_bullet_shadow=BOUND");
  bool reloc64dec4=patchPlutoBulletHead64DEC4(pluto);
  logLine(std::string("reloc75.patch_64dec4=")+(reloc64dec4?"PASS":"FAIL"));
  if(!reloc64dec4)return 20;
  DWORD ec=onStartSeh(module);if(ec){
    logLine("original_pluto.onStart=SEH_EXCEPTION code="+std::to_string(ec));
    logLine("seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
    logLine("seh.eip="+std::to_string((unsigned long)g_sehEip));
    uintptr_t pb=(uintptr_t)pluto;
    if(g_sehAddress>=pb)logLine("seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
    if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)logLine("seh.class=legacy_bw_absolute_address");
    else if(g_sehAddress>=pb)logLine("seh.class=pluto_code");
    else logLine("seh.class=other");
    return 4;
  }logLine("original_pluto.onStart=PASS");
  logLine("reloc_probe.onStart_after_rva7536_patch=PASS");
  logLine("PLUTOSCR_V75_LIVE_CUNIT_PLUTO_LOOP=START");int lastCmd=0;
  while(true){Sleep(42);int live=projectLiveUnits(store,*data);int shadowLive=refreshLegacyCUnitShadow(store);if(shadowLive!=live)logLine("legacy_cunit_shadow.live_mismatch="+std::to_string(shadowLive)+"/"+std::to_string(live));if(live<2){logLine("live_units_lost");break;}++data->frameCount;game->onMatchFrame();ec=onFrameSeh(module);if(ec){
      logLine("original_pluto.onFrame=SEH_EXCEPTION code="+std::to_string(ec));
      logLine("onframe.seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
      logLine("onframe.seh.eip="+std::to_string((unsigned long)g_sehEip));
      logLine("onframe.seh.access_type="+std::to_string((unsigned long)g_sehAccessType));
      logLine("onframe.seh.access_address="+std::to_string((unsigned long)g_sehAccessAddress));
      logLine("onframe.seh.regs.eax="+std::to_string((unsigned long)g_sehEax)+" ebx="+std::to_string((unsigned long)g_sehEbx)+" ecx="+std::to_string((unsigned long)g_sehEcx)+" edx="+std::to_string((unsigned long)g_sehEdx)+" esi="+std::to_string((unsigned long)g_sehEsi)+" edi="+std::to_string((unsigned long)g_sehEdi)+" ebp="+std::to_string((unsigned long)g_sehEbp)+" esp="+std::to_string((unsigned long)g_sehEsp));
      if(readable((void*)g_sehEip,16)){std::ostringstream hs;hs<<"onframe.seh.code16=";auto*q=(unsigned char*)g_sehEip;const char*hex="0123456789ABCDEF";for(int i=0;i<16;i++){hs<<hex[q[i]>>4]<<hex[q[i]&15];}logLine(hs.str());}
      uintptr_t pb=(uintptr_t)pluto;
      if(g_sehAddress>=pb)
        logLine("onframe.seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
      if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)
        logLine("onframe.seh.class=legacy_bw_absolute_address");
      else if(g_sehAddress>=pb)
        logLine("onframe.seh.class=pluto_code");
      else
        logLine("onframe.seh.class=other");
      break;
    }
    if(data->unitCommandCount!=lastCmd){logLine("pluto_bwapi_unit_commands="+std::to_string(data->unitCommandCount));lastCmd=data->unitCommandCount;}
    if(data->unitCommandCount>0){logLine("scr_command_sink=UNRESOLVED_FAIL_CLOSED");data->unitCommandCount=0;lastCmd=0;}
  }
  return 0;
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){if(r==DLL_PROCESS_ATTACH){g_self=h;DisableThreadLibraryCalls(h);HANDLE t=CreateThread(nullptr,0,boot,nullptr,0,nullptr);if(t)CloseHandle(t);}return TRUE;}
