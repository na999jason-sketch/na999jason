﻿$ErrorActionPreference="Stop"
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$log=Join-Path $root "plutoscr-live.log"
"[$(Get-Date -Format o)] PlutoSCR live transport launcher start" | Set-Content $log
function Log($s){$s|Tee-Object -FilePath $log -Append|Out-Null}
function Need($n){$p=Join-Path $root $n;if(-not(Test-Path $p)){Log "[FAIL] missing file: $n";exit 10};Log "[PASS] file=$n bytes=$((Get-Item $p).Length)";return [string]$p}

try{
 $injector=Need "runtime-inject-resident-win.exe";$resident=Need "starcraft-api-resident.dll"
 $hostExe=Need "PlutoHost.exe";$liveBridge=Need "plutoscr-live-bridge.exe"
 $receiver=Need "starcraft-runtime-adapter-proof.exe";$plutoDll=Need "pluto.dll"
 $inferExe=Need "pluto_infer.exe";$null=Need "pluto_weights.bin"

 $sc=Get-Process StarCraft -ErrorAction SilentlyContinue|Select-Object -First 1
 if(-not $sc){Log "[FAIL] StarCraft.exe is not running";exit 20}
 Log "[PASS] StarCraft PID=$($sc.Id)"

 $infer=Get-Process pluto_infer -ErrorAction SilentlyContinue|Select-Object -First 1
 if(-not $infer){$infer=Start-Process -FilePath $inferExe -WorkingDirectory $root -PassThru;Start-Sleep -Milliseconds 700;$infer.Refresh()}
 if($infer.HasExited){Log "[FAIL] pluto_infer exited early code=$($infer.ExitCode)";exit 21}
 Log "[PASS] pluto_infer PID=$($infer.Id)"

 $io=Join-Path $root "injector.stdout.log";$ie=Join-Path $root "injector.stderr.log"
 Remove-Item $io,$ie -Force -ErrorAction SilentlyContinue
 $inj=Start-Process -FilePath $injector -ArgumentList @("--process-id","$($sc.Id)","--adapter","`"$resident`"") -WorkingDirectory $root -PassThru -Wait -RedirectStandardOutput $io -RedirectStandardError $ie
 if(Test-Path $io){Get-Content $io|%{Log "[INJECT-OUT] $_"}}
 if(Test-Path $ie){Get-Content $ie|%{Log "[INJECT-ERR] $_"}}
 Log "[INFO] injector exit=$($inj.ExitCode)"
 if($inj.ExitCode-ne 0){Log "[FAIL] resident injection failed";exit 22}
 Log "[PASS] resident injection request completed"

 $bridge=Join-Path $env:TEMP "starcraft-api-live-bridge"
 $ready=Join-Path $bridge "ready"
 Log "[INFO] bridge=$bridge"
 Log "[INFO] Waiting for resident active-match snapshots. Enter a local/custom match now."
 $deadline=(Get-Date).AddSeconds(120)
 $active=$false
 while((Get-Date)-lt $deadline){
   if(Test-Path $ready){
     $r=Get-Content $ready -ErrorAction SilentlyContinue
     if(($r -contains "mode=validated-runtime-adapter") -and
        ($r -contains "proof.read_game_state=passed") -and
        ($r -contains "proof.read_units=passed") -and
        ($r -contains "proof.active_match_state=passed")){
       $active=$true;break
     }
   }
   Start-Sleep -Milliseconds 500
 }
 if(-not $active){
   Log "[FAIL] resident did not produce active-match validated snapshots within 120s"
   $rl=Join-Path $bridge "resident-adapter.log"
   if(Test-Path $rl){Get-Content $rl -Tail 80|%{Log "[RESIDENT] $_"}}
   exit 23
 }
 Log "[PASS] resident active-match snapshot gate passed"

 # Upstream proven command receiver. It discovers/proves the live SC:R command queue
 # and then tails commands.log produced by the PlutoSCR live bridge.
 $ro=Join-Path $root "command-receiver.stdout.log";$re=Join-Path $root "command-receiver.stderr.log"
 Remove-Item $ro,$re -Force -ErrorAction SilentlyContinue
 $recvArgs=@("--process-id","$($sc.Id)","--executable","`"$($sc.Path)`"","--bridge","`"$bridge`"",
             "--prove-read-game-state","--prove-issue-commands","--serve-command-bridge")
 $rp=Start-Process -FilePath $receiver -ArgumentList $recvArgs -WorkingDirectory $root -PassThru -RedirectStandardOutput $ro -RedirectStandardError $re
 Log "[INFO] command receiver PID=$($rp.Id) proof/discovery started"

 # Let receiver perform initial proof/discovery before Pluto begins issuing commands.
 Start-Sleep -Seconds 5
 $rp.Refresh()
 if($rp.HasExited){
   if(Test-Path $ro){Get-Content $ro|%{Log "[RECEIVER-OUT] $_"}}
   if(Test-Path $re){Get-Content $re|%{Log "[RECEIVER-ERR] $_"}}
   Log "[FAIL] command receiver exited early code=$($rp.ExitCode)"
   exit 24
 }

 $bo=Join-Path $root "live-bridge.stdout.log";$be=Join-Path $root "live-bridge.stderr.log"
 Remove-Item $bo,$be -Force -ErrorAction SilentlyContinue
 $bp=Start-Process -FilePath $liveBridge -ArgumentList @("`"$bridge`"") -WorkingDirectory $root -PassThru -RedirectStandardOutput $bo -RedirectStandardError $be
 Start-Sleep -Seconds 1;$bp.Refresh()
 if($bp.HasExited){Log "[FAIL] live bridge exited early code=$($bp.ExitCode)";exit 25}
 Log "[PASS] live bridge PID=$($bp.Id)"

 $ho=Join-Path $root "PlutoHost.stdout.log";$he=Join-Path $root "PlutoHost.stderr.log"
 Remove-Item $ho,$he -Force -ErrorAction SilentlyContinue
 $hp=Start-Process -FilePath $hostExe -ArgumentList @("`"$plutoDll`"") -WorkingDirectory $root -PassThru -RedirectStandardOutput $ho -RedirectStandardError $he
 Start-Sleep -Seconds 2;$hp.Refresh()
 if($hp.HasExited){
   if(Test-Path $ho){Get-Content $ho|%{Log "[HOST-OUT] $_"}}
   if(Test-Path $he){Get-Content $he|%{Log "[HOST-ERR] $_"}}
   Log "[FAIL] PlutoHost exited early code=$($hp.ExitCode)";exit 26
 }
 Log "[PASS] PlutoHost PID=$($hp.Id)"
 Log "[PASS] LIVE_TRANSPORT_CHAIN_STARTED=true"
 Log "[INFO] Play 30-60 seconds, then send every *.log file plus plutoscr-bridge.log."
}catch{
 Log "[FAIL] launcher exception: $($_.Exception.GetType().FullName): $($_.Exception.Message)"
 Log "[FAIL] at=$($_.InvocationInfo.PositionMessage)";exit 99
}
