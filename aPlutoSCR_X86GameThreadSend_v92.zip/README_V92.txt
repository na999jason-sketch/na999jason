aPlutoSCR v92 x86 — Game Thread Send + One Frame Delay

목표
- SC:R 실제 게임 상태 -> 원본 Pluto 관측/추론/판단 -> 원본 Pluto legacy command 생성
- 검증된 BW 1.16.1 -> SC:R command packet 변환
- SC:R 게임 메인 스레드의 검증된 frame callsite에서만 send_command 실행
- 공개 검증 포트와 동일하게 명령을 1프레임 보류한 뒤 적용

안전 조건
- SC:R 1.23.10.13515 x86 프로필 전용
- GetTickCount import가 프로필과 정확히 일치해야 hook 설치
- send_command 분석 VA 0x007DA250이 executable memory여야 함
- legacy handle/packet 변환 실패 시 fail-closed
- replay/세션 검증은 아직 최종 정리 전이므로 테스트용 로컬 게임에서만 사용 권장

필수 런타임
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

테스트 전 반드시 기존 프로세스를 종료:
  taskkill /IM pluto_infer.exe /F
  taskkill /IM StarCraft.exe /F

성공 로그 핵심
  scr_game_thread_hook=INSTALLED ...
  scr_game_thread_hook=ACTIVE ...
  scr_command_sink=ARMED_GAME_THREAD_ONE_FRAME_DELAY
  scr_command_translation=PASS ...
  scr_command_sink=QUEUED_FOR_GAME_THREAD ...
  scr_send_command=PASS game_frame=... queued_frame=... packets=...
  scr_command_submitted.total=...

성공 시 SC:R 유닛이 원본 Pluto가 생성한 명령대로 실제 움직여야 한다.
