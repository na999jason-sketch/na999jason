#ifndef NOMINMAX
#define NOMINMAX
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <TlHelp32.h>
#include <BWAPI.h>
#include <BWAPI/Client/GameImpl.h>
#include <BWAPI/Client/GameData.h>
#include <BWAPI/Client/Client.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cwchar>
#include <fstream>
#include <string>
#include <vector>
#include <utility>
#include <unordered_set>
#include <unordered_map>
#include <sstream>

static HMODULE g_self=nullptr;
using PFNGameInit=void(*)(BWAPI::Game*);
using PFNCreateAI=BWAPI::AIModule*(*)();
static std::wstring dirOfW(HMODULE m){wchar_t p[32768]={};DWORD n=GetModuleFileNameW(m,p,(DWORD)(sizeof(p)/sizeof(p[0])));std::wstring s(p,n);auto cut=s.find_last_of(L"\\/");return cut==std::wstring::npos?L".":s.substr(0,cut);}
static std::string utf8(const std::wstring&w){if(w.empty())return {};int n=WideCharToMultiByte(CP_UTF8,0,w.data(),(int)w.size(),nullptr,0,nullptr,nullptr);std::string s(n,'\0');WideCharToMultiByte(CP_UTF8,0,w.data(),(int)w.size(),s.data(),n,nullptr,nullptr);return s;}
static std::string dirOf(HMODULE m){return utf8(dirOfW(m));}
static void logLine(const std::string&s){const auto path=dirOfW(g_self)+L"\\plutoscr-x86-v82.log";FILE*f=nullptr;_wfopen_s(&f,path.c_str(),L"ab");if(!f)return;fwrite(s.data(),1,s.size(),f);fwrite("\r\n",1,2,f);fclose(f);}
static int countProcessByName(const wchar_t* wanted){
  int count=0;HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snap==INVALID_HANDLE_VALUE)return -1;
  PROCESSENTRY32W pe{};pe.dwSize=sizeof(pe);if(Process32FirstW(snap,&pe)){do{if(_wcsicmp(pe.szExeFile,wanted)==0)++count;}while(Process32NextW(snap,&pe));}
  CloseHandle(snap);return count;
}
static unsigned long long fileSizeOrZero(const std::wstring& path){WIN32_FILE_ATTRIBUTE_DATA d{};if(!GetFileAttributesExW(path.c_str(),GetFileExInfoStandard,&d))return 0;ULARGE_INTEGER u{};u.HighPart=d.nFileSizeHigh;u.LowPart=d.nFileSizeLow;return u.QuadPart;}
static bool fileExistsW(const std::wstring& path){DWORD a=GetFileAttributesW(path.c_str());return a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY);}
static bool ensureOriginalPlutoRuntimeLayout(const std::wstring& root){
  const auto sub=root+L"\\pluto";const auto nestedInfer=sub+L"\\pluto_infer.exe";const auto nestedWeights=sub+L"\\pluto_weights.bin";
  if(fileExistsW(nestedInfer)&&fileExistsW(nestedWeights)){logLine("pluto_runtime.layout=STANDARD");return true;}
  const auto flatInfer=root+L"\\pluto_infer.exe";const auto flatWeights=root+L"\\pluto_weights.bin";
  if(fileExistsW(flatInfer)&&fileExistsW(flatWeights)){
    if(!CreateDirectoryW(sub.c_str(),nullptr) && GetLastError()!=ERROR_ALREADY_EXISTS){logLine("pluto_runtime.layout=CREATE_SUBDIR_FAIL error="+std::to_string(GetLastError()));return false;}
    if(!CopyFileW(flatInfer.c_str(),nestedInfer.c_str(),FALSE)){logLine("pluto_runtime.layout=COPY_INFER_FAIL error="+std::to_string(GetLastError()));return false;}
    if(!CopyFileW(flatWeights.c_str(),nestedWeights.c_str(),FALSE)){logLine("pluto_runtime.layout=COPY_WEIGHTS_FAIL error="+std::to_string(GetLastError()));return false;}
    logLine("pluto_runtime.layout=FLAT_TO_STANDARD");return true;
  }
  logLine("pluto_runtime.layout=MISSING");return false;
}
static volatile DWORD g_sehCode=0;static volatile uintptr_t g_sehAddress=0;static volatile uintptr_t g_sehEip=0;
static volatile uintptr_t g_sehAccessAddress=0;static volatile ULONG_PTR g_sehAccessType=~(ULONG_PTR)0;
static volatile uintptr_t g_sehEax=0,g_sehEbx=0,g_sehEcx=0,g_sehEdx=0,g_sehEsi=0,g_sehEdi=0,g_sehEbp=0,g_sehEsp=0;
static int captureSeh(EXCEPTION_POINTERS*ep){if(ep&&ep->ExceptionRecord){g_sehCode=ep->ExceptionRecord->ExceptionCode;g_sehAddress=(uintptr_t)ep->ExceptionRecord->ExceptionAddress;
if(ep->ExceptionRecord->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && ep->ExceptionRecord->NumberParameters>=2){g_sehAccessType=ep->ExceptionRecord->ExceptionInformation[0];g_sehAccessAddress=(uintptr_t)ep->ExceptionRecord->ExceptionInformation[1];}}
#if defined(_M_IX86)
if(ep&&ep->ContextRecord){g_sehEip=(uintptr_t)ep->ContextRecord->Eip;g_sehEax=ep->ContextRecord->Eax;g_sehEbx=ep->ContextRecord->Ebx;g_sehEcx=ep->ContextRecord->Ecx;g_sehEdx=ep->ContextRecord->Edx;g_sehEsi=ep->ContextRecord->Esi;g_sehEdi=ep->ContextRecord->Edi;g_sehEbp=ep->ContextRecord->Ebp;g_sehEsp=ep->ContextRecord->Esp;}
#endif
return EXCEPTION_EXECUTE_HANDLER;}
static DWORD onStartSeh(BWAPI::AIModule*m){g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;__try{m->onStart();return 0;}__except(captureSeh(GetExceptionInformation())){return g_sehCode;}}
static DWORD onFrameSeh(BWAPI::AIModule*m){
  g_sehCode=0;g_sehAddress=0;g_sehEip=0;g_sehAccessAddress=0;g_sehAccessType=~(ULONG_PTR)0;g_sehEax=g_sehEbx=g_sehEcx=g_sehEdx=g_sehEsi=g_sehEdi=g_sehEbp=g_sehEsp=0;
  __try{m->onFrame();return 0;}
  __except(captureSeh(GetExceptionInformation())){return g_sehCode;}
}

#pragma pack(push,1)
struct LegacyCUnit336{ unsigned char b[336]; };
#pragma pack(pop)
static_assert(sizeof(LegacyCUnit336)==336,"CUnit size");

template<class T> static T rd(const unsigned char*p,size_t o){T v{};std::memcpy(&v,p+o,sizeof(v));return v;}
static bool readable(const void*p,size_t n){
  MEMORY_BASIC_INFORMATION mi{}; if(!VirtualQuery(p,&mi,sizeof(mi)))return false;
  if(mi.State!=MEM_COMMIT || (mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
  uintptr_t a=(uintptr_t)p; uintptr_t e=a+(uintptr_t)n; uintptr_t r=(uintptr_t)mi.BaseAddress+(uintptr_t)mi.RegionSize; return e>=a && e<=r;
}
static bool plausibleUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  auto hp=rd<int32_t>(p,0x08); auto spr=rd<uint32_t>(p,0x0c); auto x=rd<int16_t>(p,0x28); auto y=rd<int16_t>(p,0x2a);
  auto player=rd<uint8_t>(p,0x4c); auto order=rd<uint8_t>(p,0x4d); auto type=rd<uint16_t>(p,0x64);
  return spr!=0 && hp>0 && hp<(5000000*256) && x>=0&&x<=16384&&y>=0&&y<=16384&&player<12&&order<256&&type<234;
}
struct UnitStore{uintptr_t descriptor=0,begin=0,end=0,cap=0;int score=0;};
static UnitStore scanDescriptorRange(uintptr_t s,uintptr_t e,const char*tag){
  UnitStore best{}; MEMORY_BASIC_INFORMATION mi{}; uintptr_t a=s; unsigned long regions=0; unsigned long descriptors=0;
  logLine(std::string("checkpoint.scan_range.begin=")+tag);
  while(a<e && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;
    if(re<=a)break;
    uintptr_t lo=std::max(a,rs),hi=std::min(e,re);
    bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) &&
      (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && hi>lo && hi-lo>=12){
      ++regions;
      for(uintptr_t q=(lo+3)&~uintptr_t(3);q+12<=hi;q+=4){
        uint32_t b=0,en=0,c=0;
        std::memcpy(&b,(void*)q,4);std::memcpy(&en,(void*)(q+4),4);std::memcpy(&c,(void*)(q+8),4);
        if(!b||en<b||c<en)continue;uint32_t used=en-b,cap=c-b;
        if(used==0||used%336||cap%336)continue;uint32_t count=used/336,capacity=cap/336;
        if(count<2||count>3400||capacity<count||capacity>3400)continue;
        if(!readable((void*)(uintptr_t)b,std::min<uint32_t>(used,336*64)))continue;
        ++descriptors;int score=0;uint32_t step=std::max<uint32_t>(1,count/64);
        for(uint32_t i=0;i<count&&i<3400;i+=step)if(plausibleUnit((unsigned char*)(uintptr_t)(b+i*336)))++score;
        if(score>best.score){best={q,b,en,c,score};}
      }
    }
    a=re;
  }
  logLine(std::string("checkpoint.scan_range.end=")+tag+" regions="+std::to_string(regions)+" descriptors="+std::to_string(descriptors)+" best_score="+std::to_string(best.score));
  return best;
}
static UnitStore findLegacyCUnitVector(){
  logLine("checkpoint.cunit_scan.enter");
  UnitStore moduleBest{};
  HMODULE exe=GetModuleHandleA(nullptr);
  if(exe){
    auto base=(uintptr_t)exe;auto dos=(IMAGE_DOS_HEADER*)base;
    if(readable(dos,sizeof(*dos))&&dos->e_magic==IMAGE_DOS_SIGNATURE){
      auto nt=(IMAGE_NT_HEADERS*)(base+dos->e_lfanew);
      if(readable(nt,sizeof(*nt))&&nt->Signature==IMAGE_NT_SIGNATURE){
        uintptr_t end=base+(uintptr_t)nt->OptionalHeader.SizeOfImage;
        logLine("checkpoint.cunit_scan.module_base="+std::to_string((unsigned long)base));
        logLine("checkpoint.cunit_scan.module_size="+std::to_string((unsigned long)nt->OptionalHeader.SizeOfImage));
        moduleBest=scanDescriptorRange(base,end,"main_module");
        logLine("checkpoint.cunit_scan.module_best_score="+std::to_string(moduleBest.score));
      }
    }
  }

  // Never short-circuit on an in-module descriptor.  SC:R can contain a
  // plausible vector-shaped object in the image while the live CUnit vector
  // lives in another committed region.  Scan the entire x86 process and pick
  // the globally strongest candidate.  This changes only bridge discovery;
  // Pluto's observation/decision code remains untouched.
  logLine("checkpoint.cunit_scan.process_begin");
  SYSTEM_INFO si{};GetSystemInfo(&si);
  UnitStore processBest=scanDescriptorRange((uintptr_t)si.lpMinimumApplicationAddress,(uintptr_t)si.lpMaximumApplicationAddress,"process");
  logLine("checkpoint.cunit_scan.process_end");

  auto countOf=[](const UnitStore&u)->uint32_t{return (u.begin && u.end>=u.begin)?(uint32_t)((u.end-u.begin)/336):0;};
  UnitStore best=moduleBest;
  const bool chooseProcess=(processBest.score>best.score) ||
    (processBest.score==best.score && countOf(processBest)>countOf(best));
  if(chooseProcess)best=processBest;
  logLine(std::string("checkpoint.cunit_scan.global_select=")+(chooseProcess?"process":"main_module"));
  logLine("checkpoint.cunit_scan.global_score="+std::to_string(best.score));
  logLine("checkpoint.cunit_scan.global_count="+std::to_string(countOf(best)));
  return best;
}

static uintptr_t g_scrVisibleUnitHead=0;
static uintptr_t g_scrHiddenUnitHead=0;
static uintptr_t g_scrScannerSweepHead=0;
static int g_linkPrevOff=-1;
static int g_linkNextOff=-1;
static std::vector<LegacyCUnit336> g_legacyCUnits;
static std::vector<uintptr_t> g_legacyRawUnits;

#pragma pack(push,1)
struct LegacyBullet112{ unsigned char b[112]; };
struct LegacySprite36{ unsigned char b[36]; };
#pragma pack(pop)
static_assert(sizeof(LegacyBullet112)==112,"Bullet size");
static_assert(sizeof(LegacySprite36)==36,"Sprite size");
static uintptr_t g_legacyBulletHead=0;
static std::vector<LegacyBullet112> g_legacyBullets;
static std::vector<LegacySprite36> g_legacyBulletSprites;
static std::vector<uintptr_t> g_legacyRawBullets;
static std::unordered_map<uintptr_t,size_t> g_rawBulletIndex;

static bool presentScrUnit(const unsigned char*p){
  if(!readable(p,336))return false;
  return rd<uint32_t>(p,0x0c)!=0 && rd<uint16_t>(p,0x64)<228;
}
static bool rawMember(const std::vector<uintptr_t>&raws,uintptr_t p){
  return p && std::binary_search(raws.begin(),raws.end(),p);
}
static uintptr_t shadowForRaw(uintptr_t raw){
  if(!raw)return 0;
  auto it=std::lower_bound(g_legacyRawUnits.begin(),g_legacyRawUnits.end(),raw);
  if(it==g_legacyRawUnits.end()||*it!=raw)return 0;
  size_t i=(size_t)(it-g_legacyRawUnits.begin());
  return (uintptr_t)&g_legacyCUnits[i];
}
static std::vector<uintptr_t> collectPresentRaw(const UnitStore&s){
  std::vector<uintptr_t> out;
  if(!s.begin||s.end<=s.begin)return out;
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  out.reserve(count);
  for(uint32_t i=0;i<count;i++){
    uintptr_t raw=s.begin+(uintptr_t)i*336;
    if(presentScrUnit((unsigned char*)raw))out.push_back(raw);
  }
  return out;
}
struct ChainInfo{uintptr_t head=0;std::vector<uintptr_t> nodes;int scanner33=0;};
struct LinkCandidate{int prevOff=-1,nextOff=-1,valid=0,reciprocal=0,coverage=0,longest=0,chains=0,score=0;};
static std::vector<ChainInfo> chainsFor(const std::vector<uintptr_t>&raws,int prevOff,int nextOff,int*coverageOut=nullptr){
  std::vector<ChainInfo> chains;std::unordered_set<uintptr_t> visited;
  for(uintptr_t raw:raws){
    uint32_t prev=rd<uint32_t>((unsigned char*)raw,(size_t)prevOff);
    uint32_t next=rd<uint32_t>((unsigned char*)raw,(size_t)nextOff);
    if(prev!=0 || (next!=0 && !rawMember(raws,next)))continue;
    ChainInfo c{};c.head=raw;std::unordered_set<uintptr_t> local;uintptr_t cur=raw;
    while(cur && rawMember(raws,cur) && !local.count(cur) && c.nodes.size()<=raws.size()){
      local.insert(cur);visited.insert(cur);c.nodes.push_back(cur);
      if(rd<uint16_t>((unsigned char*)cur,0x64)==33)++c.scanner33;
      uint32_t n=rd<uint32_t>((unsigned char*)cur,(size_t)nextOff);
      if(!n)break;
      if(!rawMember(raws,n))break;
      uint32_t back=rd<uint32_t>((unsigned char*)(uintptr_t)n,(size_t)prevOff);
      if(back!=(uint32_t)cur)break;
      cur=n;
    }
    if(!c.nodes.empty())chains.push_back(std::move(c));
  }
  std::sort(chains.begin(),chains.end(),[](const ChainInfo&a,const ChainInfo&b){return a.nodes.size()>b.nodes.size();});
  if(coverageOut)*coverageOut=(int)visited.size();
  return chains;
}
static LinkCandidate evaluateLinkPair(const std::vector<uintptr_t>&raws,int prevOff){
  LinkCandidate c{};c.prevOff=prevOff;c.nextOff=prevOff+4;
  for(uintptr_t raw:raws){
    uint32_t prev=rd<uint32_t>((unsigned char*)raw,(size_t)c.prevOff);
    uint32_t next=rd<uint32_t>((unsigned char*)raw,(size_t)c.nextOff);
    bool pv=(prev==0)||rawMember(raws,prev),nv=(next==0)||rawMember(raws,next);
    if(pv&&nv)++c.valid;
    if(next && rawMember(raws,next)){
      uint32_t back=rd<uint32_t>((unsigned char*)(uintptr_t)next,(size_t)c.prevOff);
      if(back==(uint32_t)raw)++c.reciprocal;
    }
    if(prev && rawMember(raws,prev)){
      uint32_t fwd=rd<uint32_t>((unsigned char*)(uintptr_t)prev,(size_t)c.nextOff);
      if(fwd==(uint32_t)raw)++c.reciprocal;
    }
  }
  auto chains=chainsFor(raws,c.prevOff,c.nextOff,&c.coverage);c.chains=(int)chains.size();
  for(const auto&x:chains)c.longest=std::max(c.longest,(int)x.nodes.size());
  // Master CUnit list fields should be valid for almost every allocated unit,
  // reciprocal in both directions, and produce one dominant chain rather than
  // per-player/per-order sublists.  Favor those properties heavily.
  c.score=c.valid*2+c.reciprocal*4+c.coverage*5+c.longest*8-c.chains*2;
  return c;
}
static bool discoverDynamicCUnitLinks(const UnitStore&s){
  auto raws=collectPresentRaw(s);
  logLine("dynamic_links.present="+std::to_string(raws.size()));
  if(raws.size()<2)return false;
  std::vector<LinkCandidate> cs;
  for(int off=0;off<=328;off+=4){
    auto c=evaluateLinkPair(raws,off);
    if(c.valid>=(int)(raws.size()*9/10))cs.push_back(c);
  }
  std::sort(cs.begin(),cs.end(),[](const LinkCandidate&a,const LinkCandidate&b){return a.score>b.score;});
  for(size_t i=0;i<cs.size()&&i<12;i++){
    const auto&c=cs[i];
    logLine("dynamic_links.candidate["+std::to_string(i)+"] prev="+std::to_string(c.prevOff)+" next="+std::to_string(c.nextOff)+
      " valid="+std::to_string(c.valid)+" reciprocal="+std::to_string(c.reciprocal)+" coverage="+std::to_string(c.coverage)+
      " longest="+std::to_string(c.longest)+" chains="+std::to_string(c.chains)+" score="+std::to_string(c.score));
  }
  if(cs.empty()){logLine("dynamic_links=NO_CANDIDATE");return false;}
  const auto&b=cs.front();
  const int n=(int)raws.size();
  if(b.valid<n*9/10 || b.coverage<n*8/10 || b.longest<n*6/10){logLine("dynamic_links=LOW_CONFIDENCE");return false;}
  if(cs.size()>1 && b.score==cs[1].score){logLine("dynamic_links=AMBIGUOUS_TIE");return false;}
  g_linkPrevOff=b.prevOff;g_linkNextOff=b.nextOff;
  logLine("dynamic_links.selected.prev="+std::to_string(g_linkPrevOff)+" next="+std::to_string(g_linkNextOff));
  return true;
}
static bool classifySemanticHeads(const std::vector<uintptr_t>&raws,bool logValues,uintptr_t*outVisible,uintptr_t*outHidden,uintptr_t*outScanner){
  if(g_linkPrevOff<0||g_linkNextOff<0)return false;
  int coverage=0;auto chains=chainsFor(raws,g_linkPrevOff,g_linkNextOff,&coverage);
  if(logValues)logLine("semantic_chains.count="+std::to_string(chains.size())+" coverage="+std::to_string(coverage));
  for(size_t i=0;i<chains.size()&&i<12;i++)if(logValues){
    logLine("semantic_chain["+std::to_string(i)+"].head="+std::to_string((unsigned long)chains[i].head)+
      " len="+std::to_string(chains[i].nodes.size())+" scanner33="+std::to_string(chains[i].scanner33));
  }
  uintptr_t scanner=0,visible=0,hidden=0;size_t visibleLen=0,hiddenLen=0;int nonScanner=0;
  for(const auto&c:chains){
    if(c.scanner33>0){
      if(scanner){logLine("semantic_heads=MULTIPLE_SCANNER_CHAINS");return false;}
      scanner=c.head;continue;
    }
    ++nonScanner;
    if(c.nodes.size()>visibleLen){hidden=visible;hiddenLen=visibleLen;visible=c.head;visibleLen=c.nodes.size();}
    else if(c.nodes.size()>hiddenLen){hidden=c.head;hiddenLen=c.nodes.size();}
  }
  if(!visible || visibleLen<raws.size()*6/10){logLine("semantic_heads=VISIBLE_NOT_DOMINANT");return false;}
  // A second non-scanner chain is accepted as the hidden-unit list only when
  // it is small compared with the visible list. Multiple large partitions are
  // characteristic of another CUnit linkage (e.g. per-player), not visibility.
  if(nonScanner>2){logLine("semantic_heads=TOO_MANY_NONSCANNER_CHAINS");return false;}
  if(hidden && hiddenLen>std::max<size_t>(32,visibleLen/4)){logLine("semantic_heads=SECOND_CHAIN_TOO_LARGE");return false;}
  if(outVisible)*outVisible=visible;if(outHidden)*outHidden=hidden;if(outScanner)*outScanner=scanner;
  if(logValues)logLine("semantic_heads.raw.visible="+std::to_string((unsigned long)visible)+" hidden="+std::to_string((unsigned long)hidden)+" scanner="+std::to_string((unsigned long)scanner));
  return true;
}
static bool refreshSemanticHeads(bool logValues){
  uintptr_t visible=0,hidden=0,scanner=0;
  if(!classifySemanticHeads(g_legacyRawUnits,logValues,&visible,&hidden,&scanner))return false;
  g_scrVisibleUnitHead=shadowForRaw(visible);
  g_scrHiddenUnitHead=shadowForRaw(hidden);
  g_scrScannerSweepHead=shadowForRaw(scanner);
  if(logValues)logLine("semantic_heads.shadow.visible="+std::to_string((unsigned long)g_scrVisibleUnitHead)+" hidden="+std::to_string((unsigned long)g_scrHiddenUnitHead)+" scanner="+std::to_string((unsigned long)g_scrScannerSweepHead));
  return g_scrVisibleUnitHead!=0;
}
static void translateShadowListLinks(){
  for(size_t i=0;i<g_legacyCUnits.size();++i){
    auto*src=(unsigned char*)g_legacyRawUnits[i];
    uint32_t rawPrev=rd<uint32_t>(src,(size_t)g_linkPrevOff),rawNext=rd<uint32_t>(src,(size_t)g_linkNextOff);
    uint32_t prev=(uint32_t)shadowForRaw(rawPrev),next=(uint32_t)shadowForRaw(rawNext);
    std::memcpy(g_legacyCUnits[i].b+0x00,&prev,4);std::memcpy(g_legacyCUnits[i].b+0x04,&next,4);
  }
}
static int buildLegacyCUnitShadow(const UnitStore&s){
  if(g_linkPrevOff<0 && !discoverDynamicCUnitLinks(s))return 0;
  if(g_legacyCUnits.capacity()<3400)g_legacyCUnits.reserve(3400);
  if(g_legacyRawUnits.capacity()<3400)g_legacyRawUnits.reserve(3400);
  g_legacyCUnits.clear();g_legacyRawUnits=collectPresentRaw(s);
  for(uintptr_t raw:g_legacyRawUnits){LegacyCUnit336 u{};std::memcpy(u.b,(void*)raw,336);g_legacyCUnits.push_back(u);}
  translateShadowListLinks();
  if(!refreshSemanticHeads(true)){g_scrVisibleUnitHead=g_scrHiddenUnitHead=g_scrScannerSweepHead=0;return 0;}
  return (int)g_legacyCUnits.size();
}
static int refreshLegacyCUnitShadow(const UnitStore&s){
  auto now=collectPresentRaw(s);
  if(now!=g_legacyRawUnits)return buildLegacyCUnitShadow(s);
  for(size_t i=0;i<g_legacyCUnits.size();++i)std::memcpy(g_legacyCUnits[i].b,(void*)g_legacyRawUnits[i],336);
  translateShadowListLinks();
  if(!refreshSemanticHeads(false))return 0;
  return (int)g_legacyCUnits.size();
}


static bool plausibleBullet(const unsigned char*p,const std::unordered_set<uint32_t>&unitSet){
  if(!readable(p,112))return false;
  if(unitSet.count((uint32_t)(uintptr_t)p))return false;
  uint32_t exists=rd<uint32_t>(p,0x08),spr=rd<uint32_t>(p,0x0c);
  int16_t x=rd<int16_t>(p,0x28),y=rd<int16_t>(p,0x2a);
  uint8_t player=rd<uint8_t>(p,0x4c),beh=rd<uint8_t>(p,0x4d),weapon=rd<uint8_t>(p,0x60);
  uint32_t u0=rd<uint32_t>(p,0x14),u1=rd<uint32_t>(p,0x5c),u2=rd<uint32_t>(p,0x64),u3=rd<uint32_t>(p,0x68);
  auto unitOk=[&](uint32_t u){return u==0 || unitSet.count(u)!=0;};
  int linked=(unitSet.count(u0)?1:0)+(unitSet.count(u1)?1:0)+(unitSet.count(u2)?1:0)+(unitSet.count(u3)?1:0);
  return exists>=1 && exists<=4 && spr!=0 && readable((void*)(uintptr_t)spr,36) &&
         x>=0&&x<=16384&&y>=0&&y<=16384 && player<12 && beh<=8 && weapon<200 &&
         unitOk(u0)&&unitOk(u1)&&unitOk(u2)&&unitOk(u3) && linked>0;
}
static std::vector<uintptr_t> scanBulletCandidates(){
  std::vector<uintptr_t> out;
  std::unordered_set<uint32_t> unitSet;unitSet.reserve(g_legacyRawUnits.size()*2+1);
  for(uintptr_t u:g_legacyRawUnits)unitSet.insert((uint32_t)u);
  std::unordered_set<uintptr_t> seen;
  SYSTEM_INFO si{};GetSystemInfo(&si);MEMORY_BASIC_INFORMATION mi{};
  uintptr_t a=(uintptr_t)si.lpMinimumApplicationAddress,e=(uintptr_t)si.lpMaximumApplicationAddress;
  unsigned long regions=0;unsigned long unitRefs=0;
  while(a<e && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;if(re<=a)break;
    bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) &&
      (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && re>rs+4){
      ++regions;
      uintptr_t lo=(rs+3)&~uintptr_t(3),hi=re-4;
      for(uintptr_t q=lo;q<=hi;q+=4){
        uint32_t v=0;std::memcpy(&v,(void*)q,4);if(!unitSet.count(v))continue;++unitRefs;
        const int offs[]={0x14,0x5c,0x64,0x68};
        for(int off:offs){
          if(q<(uintptr_t)off)continue;uintptr_t b=q-(uintptr_t)off;
          if(seen.count(b))continue;
          if((b&3)!=0)continue;
          if(plausibleBullet((unsigned char*)b,unitSet)){seen.insert(b);out.push_back(b);}
        }
      }
    }
    a=re;
  }
  std::sort(out.begin(),out.end());
  logLine("bullet_scan.regions="+std::to_string(regions)+" unit_refs="+std::to_string(unitRefs)+" candidates="+std::to_string(out.size()));
  return out;
}
static uintptr_t shadowBulletForRaw(uintptr_t raw){
  if(!raw)return 0;auto it=g_rawBulletIndex.find(raw);if(it==g_rawBulletIndex.end())return 0;
  return (uintptr_t)&g_legacyBullets[it->second];
}
static bool buildLegacyBulletShadow(){
  auto candidates=scanBulletCandidates();
  g_legacyBullets.clear();g_legacyBulletSprites.clear();g_legacyRawBullets.clear();g_rawBulletIndex.clear();g_legacyBulletHead=0;
  if(candidates.empty()){
    logLine("legacy_bullet_shadow.active=0");
    logLine("legacy_bullet_shadow.head=0");
    return true;
  }
  std::unordered_set<uintptr_t> set(candidates.begin(),candidates.end());
  struct BChain{uintptr_t head=0;std::vector<uintptr_t> nodes;};
  std::vector<BChain> chains;
  for(uintptr_t b:candidates){
    uint32_t prev=rd<uint32_t>((unsigned char*)b,0),next=rd<uint32_t>((unsigned char*)b,4);
    if(prev && set.count(prev))continue;
    BChain c{};c.head=b;std::unordered_set<uintptr_t> local;uintptr_t cur=b;
    while(cur && set.count(cur) && !local.count(cur) && c.nodes.size()<=candidates.size()){
      local.insert(cur);c.nodes.push_back(cur);uint32_t n=rd<uint32_t>((unsigned char*)cur,4);
      if(!n)break;if(!set.count(n))break;
      uint32_t back=rd<uint32_t>((unsigned char*)(uintptr_t)n,0);if(back!=(uint32_t)cur)break;cur=n;
    }
    if(!c.nodes.empty())chains.push_back(std::move(c));
  }
  std::sort(chains.begin(),chains.end(),[](const BChain&a,const BChain&b){return a.nodes.size()>b.nodes.size();});
  if(chains.empty()){logLine("legacy_bullet_shadow=NO_CHAIN");return false;}
  if(chains.size()>1 && chains[0].nodes.size()==chains[1].nodes.size()){logLine("legacy_bullet_shadow=AMBIGUOUS_CHAIN");return false;}
  const auto&best=chains[0];
  if(best.nodes.size()<candidates.size()/2 && candidates.size()>2){logLine("legacy_bullet_shadow=LOW_COVERAGE");return false;}
  g_legacyRawBullets=best.nodes;
  g_legacyBullets.resize(best.nodes.size());g_legacyBulletSprites.resize(best.nodes.size());
  g_rawBulletIndex.reserve(best.nodes.size()*2+1);
  for(size_t i=0;i<best.nodes.size();++i)g_rawBulletIndex.emplace(best.nodes[i],i);
  for(size_t i=0;i<best.nodes.size();++i){
    uintptr_t raw=best.nodes[i];auto*src=(unsigned char*)raw;std::memcpy(g_legacyBullets[i].b,src,112);
  }
  for(size_t i=0;i<best.nodes.size();++i){
    uintptr_t raw=best.nodes[i];auto*src=(unsigned char*)raw;auto&dst=g_legacyBullets[i];
    uint32_t prev=(uint32_t)shadowBulletForRaw(rd<uint32_t>(src,0)),next=(uint32_t)shadowBulletForRaw(rd<uint32_t>(src,4));
    std::memcpy(dst.b+0,&prev,4);std::memcpy(dst.b+4,&next,4);
    for(int off:{0x14,0x5c,0x64,0x68}){
      uint32_t u=(uint32_t)shadowForRaw(rd<uint32_t>(src,(size_t)off));std::memcpy(dst.b+off,&u,4);
    }
    uint32_t rawSprite=rd<uint32_t>(src,0x0c);uint32_t spriteShadow=0;
    if(rawSprite && readable((void*)(uintptr_t)rawSprite,40)){
      auto&s=g_legacyBulletSprites[i];std::memset(s.b,0,sizeof(s.b));std::memcpy(s.b,(void*)(uintptr_t)rawSprite,20);
      uint32_t z=0;std::memcpy(s.b,&z,4);std::memcpy(s.b+4,&z,4);
      uint16_t v20=(uint16_t)rd<uint32_t>((unsigned char*)(uintptr_t)rawSprite,20);
      uint16_t v22=(uint16_t)rd<uint32_t>((unsigned char*)(uintptr_t)rawSprite,24);
      std::memcpy(s.b+20,&v20,2);std::memcpy(s.b+22,&v22,2);
      if(readable((void*)(uintptr_t)(rawSprite+28),12))std::memcpy(s.b+24,(void*)(uintptr_t)(rawSprite+28),12);
      spriteShadow=(uint32_t)(uintptr_t)&s;
    }
    std::memcpy(dst.b+0x0c,&spriteShadow,4);
  }
  g_legacyBulletHead=shadowBulletForRaw(best.head);
  logLine("legacy_bullet_shadow.active="+std::to_string(g_legacyRawBullets.size()));
  logLine("legacy_bullet_shadow.raw_head="+std::to_string((unsigned long)best.head));
  logLine("legacy_bullet_shadow.head="+std::to_string((unsigned long)g_legacyBulletHead));
  return g_legacyBulletHead!=0;
}

static int inferRace(int type){if(type<=59||(type>=106&&type<=131))return 1;if((type>=88&&type<=103)||(type>=132&&type<=157))return 0;if((type>=60&&type<=87)||type==97||(type>=159&&type<=173))return 2;return 5;}
static int projectLiveUnits(const UnitStore&s,BWAPI::GameData&d){
  if(!s.begin||s.end<s.begin)return 0; int out=0; std::array<int,12> counts{}; std::array<int,12> race{}; race.fill(5);
  const uint32_t count=(uint32_t)((s.end-s.begin)/336);
  for(uint32_t i=0;i<count && out<10000;i++){
    auto*p=(unsigned char*)(s.begin+i*336); if(!plausibleUnit(p))continue;
    auto&q=d.units[out]; ZeroMemory(&q,sizeof(q)); q.id=out;q.player=rd<uint8_t>(p,0x4c);q.type=rd<uint16_t>(p,0x64);q.positionX=rd<int16_t>(p,0x28);q.positionY=rd<int16_t>(p,0x2a);
    q.hitPoints=std::max(0,rd<int32_t>(p,0x08)/256);q.shields=rd<uint32_t>(p,0x60)/256;q.energy=rd<uint16_t>(p,0xa2)/256;q.order=rd<uint8_t>(p,0x4d);
    q.targetPositionX=rd<int16_t>(p,0x58);q.targetPositionY=rd<int16_t>(p,0x5a);q.orderTargetPositionX=q.targetPositionX;q.orderTargetPositionY=q.targetPositionY;
    q.exists=true;auto flags=rd<uint32_t>(p,0xdc);q.isCompleted=(flags&1)!=0;q.isCloaked=(flags&0x200)!=0;q.isBurrowed=(flags&0x10)!=0;q.isInvincible=(flags&0x04000000)!=0;
    if(q.player>=0&&q.player<12){counts[q.player]++;race[q.player]=inferRace(q.type);} for(bool&v:q.isVisible)v=true; ++out;
  }
  d.initialUnitCount=out;d.playerCount=0;
  for(int p=0;p<12;p++)if(counts[p]){d.playerCount=std::max(d.playerCount,p+1);d.players[p].race=race[p];d.players[p].isParticipating=true;d.players[p].type=1;d.players[p].isAlly[p]=true;}
  return out;
}


static constexpr uintptr_t kLegacyGameBase=0x0057F0F0u;
static constexpr size_t kScrGameSize=96000u;
static uintptr_t g_scrGame=0;
static unsigned char* g_legacyGameShadow=nullptr;

static int scoreScrGameCandidate(uintptr_t g,int expectedLive,uint64_t* unitTotalOut=nullptr){
  if(!g || !readable((void*)g,kScrGameSize))return -1;
  const auto*p=(const unsigned char*)g;
  const uint16_t w=rd<uint16_t>(p,228),h=rd<uint16_t>(p,230);
  const uint32_t frame=rd<uint32_t>(p,332);
  if(w<32||w>256||h<32||h>256||frame==0||frame>50000000u)return -1;
  int score=200;
  int smallUp=0,totalUp=0;
  for(size_t i=0;i<12u*46u;i++){++totalUp;if(rd<uint8_t>(p,57792+i)<=3)++smallUp;}
  for(size_t i=0;i<12u*15u;i++){++totalUp;if(rd<uint8_t>(p,66108+i)<=3)++smallUp;}
  if(smallUp<totalUp*98/100)return -1;score+=smallUp;
  int smallTech=0,totalTech=0;
  for(size_t i=0;i<12u*24u;i++){++totalTech;if(rd<uint8_t>(p,56916+i)<=1)++smallTech;}
  for(size_t i=0;i<12u*20u;i++){++totalTech;if(rd<uint8_t>(p,65616+i)<=1)++smallTech;}
  if(smallTech<totalTech*95/100)return -1;score+=smallTech;
  uint64_t unitTotal=0;int badCounts=0;
  for(size_t i=0;i<228u*12u;i++){uint32_t v=rd<uint32_t>(p,12852+i*4);if(v>5000u)++badCounts;unitTotal+=v;}
  if(badCounts>4 || unitTotal<2 || unitTotal>20000)return -1;
  if(unitTotalOut)*unitTotalOut=unitTotal;
  score+=400;
  if(expectedLive>0){uint64_t diff=unitTotal>(uint64_t)expectedLive?unitTotal-expectedLive:(uint64_t)expectedLive-unitTotal;if(diff<=16)score+=500;else if(diff<=64)score+=250;}
  int goodSupply=0,totalSupply=0;
  for(int race=0;race<3;race++)for(int block=0;block<3;block++)for(int pl=0;pl<12;pl++){
    ++totalSupply;uint32_t v=rd<uint32_t>(p,12372+race*144+block*48+pl*4);if(v<5000u)++goodSupply;
  }
  if(goodSupply<totalSupply*95/100)return -1;score+=goodSupply;
  return score;
}

static uintptr_t profileScrGameCandidate(){
  HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return 0;
  const uintptr_t base=(uintptr_t)exe;
  const uintptr_t slot=base+(0x00FA63CCu-0x004A0000u);
  if(!readable((void*)slot,4))return 0;
  uint32_t encoded=0;memcpy(&encoded,(void*)slot,4);
  return (uintptr_t)(encoded^0x10FAE560u);
}

static uintptr_t findScrGameBlock(int expectedLive){
  uintptr_t prof=profileScrGameCandidate();uint64_t total=0;int ps=scoreScrGameCandidate(prof,expectedLive,&total);
  logLine("scr_game.profile_candidate="+std::to_string((unsigned long)prof)+" score="+std::to_string(ps)+" unit_total="+std::to_string(total));
  if(ps>=1500){logLine("scr_game.select=PROFILE_VALIDATED");return prof;}
  SYSTEM_INFO si{};GetSystemInfo(&si);MEMORY_BASIC_INFORMATION mi{};uintptr_t a=(uintptr_t)si.lpMinimumApplicationAddress;
  uintptr_t best=0;int bestScore=-1;uint64_t bestTotal=0;unsigned long regions=0,candidates=0;
  while(a<(uintptr_t)si.lpMaximumApplicationAddress && VirtualQuery((void*)a,&mi,sizeof(mi))){
    uintptr_t rs=(uintptr_t)mi.BaseAddress,re=rs+(uintptr_t)mi.RegionSize;if(re<=a)break;
    const bool rw=mi.State==MEM_COMMIT && !(mi.Protect&(PAGE_NOACCESS|PAGE_GUARD)) && (mi.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
    if(rw && mi.RegionSize>=kScrGameSize){++regions;uintptr_t lo=(rs+15u)&~uintptr_t(15u),hi=re-kScrGameSize;
      for(uintptr_t q=lo;q<=hi;q+=16u){
        uint16_t w=0,h=0;uint32_t frame=0;memcpy(&w,(void*)(q+228),2);memcpy(&h,(void*)(q+230),2);if(w<32||w>256||h<32||h>256)continue;memcpy(&frame,(void*)(q+332),4);if(!frame||frame>50000000u)continue;
        uint64_t ut=0;int sc=scoreScrGameCandidate(q,expectedLive,&ut);if(sc<0)continue;++candidates;if(sc>bestScore){bestScore=sc;best=q;bestTotal=ut;}
      }
    }
    a=re;
  }
  logLine("scr_game.scan.regions="+std::to_string(regions)+" candidates="+std::to_string(candidates)+" best_score="+std::to_string(bestScore));
  logLine("scr_game.scan.best="+std::to_string((unsigned long)best)+" unit_total="+std::to_string(bestTotal));
  if(bestScore<1500){logLine("scr_game.select=UNRESOLVED");return 0;}
  logLine("scr_game.select=DYNAMIC_SCAN");return best;
}

static bool allocateLegacyGameShadow(){
  if(g_legacyGameShadow)return true;
  void* p=VirtualAlloc(nullptr,kScrGameSize,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
  if(!p){logLine("legacy_game.alloc=FAIL gle="+std::to_string(GetLastError()));return false;}
  if((uintptr_t)p>0xFFFFFFFFu){VirtualFree(p,0,MEM_RELEASE);logLine("legacy_game.alloc=OUT_OF_X86_RANGE");return false;}
  g_legacyGameShadow=(unsigned char*)p;
  logLine("legacy_game.allocated_shadow="+std::to_string((unsigned long)(uintptr_t)g_legacyGameShadow));
  return true;
}

static bool syncLegacyGameShadow(uintptr_t g){
  if(!g_legacyGameShadow||!g||!readable((void*)g,kScrGameSize))return false;
  memcpy(g_legacyGameShadow,(void*)g,kScrGameSize);
  return true;
}



#pragma pack(push,1)
struct Legacy57F1Compat {
  unsigned char pad0[0x1D4];
  short value_f1d4;
  short value_f1d6;
  unsigned char pad1[0x64];
  unsigned long value_f23c;
};
#pragma pack(pop)
static Legacy57F1Compat g_legacy57f1{};

static bool patchAbs32(unsigned char* insn,int immOff,const unsigned char* sig,int sigLen,uintptr_t target,const char* tag){
  if(memcmp(insn,sig,sigLen)!=0){logLine(std::string("reloc69.")+tag+".signature=MISMATCH");return false;}
  if(target>0xFFFFFFFFu){logLine(std::string("reloc69.")+tag+".target=OUT_OF_X86_RANGE");return false;}
  DWORD old=0;if(!VirtualProtect(insn,sigLen,PAGE_EXECUTE_READWRITE,&old)){logLine(std::string("reloc69.")+tag+".protect=FAIL");return false;}
  uint32_t v=(uint32_t)target;memcpy(insn+immOff,&v,4);FlushInstructionCache(GetCurrentProcess(),insn,sigLen);
  DWORD tmp=0;VirtualProtect(insn,sigLen,old,&tmp);
  logLine(std::string("reloc69.")+tag+"=PASS");return true;
}
static bool patchPlutoLegacy57F1Block(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char s1[5]={0xA1,0x3C,0xF2,0x57,0x00};
  const unsigned char s2[7]={0x0F,0xBF,0x05,0xD4,0xF1,0x57,0x00};
  const unsigned char s3[7]={0x0F,0xBF,0x15,0xD6,0xF1,0x57,0x00};
  bool a=patchAbs32(b+0xBC1B,1,s1,5,(uintptr_t)&g_legacy57f1.value_f23c,"rva_bc1b_f23c");
  bool c=patchAbs32(b+0xBC26,3,s2,7,(uintptr_t)&g_legacy57f1.value_f1d4,"rva_bc26_f1d4");
  bool d=patchAbs32(b+0xBC33,3,s3,7,(uintptr_t)&g_legacy57f1.value_f1d6,"rva_bc33_f1d6");
  return a&&c&&d;
}

static bool patchOperand32(HMODULE pluto,uint32_t rva,uint32_t expected,uint32_t value,const char* tag){
  unsigned char* p=(unsigned char*)pluto+rva;
  uint32_t cur=0;memcpy(&cur,p,4);
  if(cur!=expected){
    std::ostringstream os;os<<"reloc82."<<tag<<".expected="<<expected<<" actual="<<cur;logLine(os.str());
    return false;
  }
  DWORD old=0;if(!VirtualProtect(p,4,PAGE_EXECUTE_READWRITE,&old)){logLine(std::string("reloc82.")+tag+".protect=FAIL");return false;}
  memcpy(p,&value,4);FlushInstructionCache(GetCurrentProcess(),p,4);
  DWORD tmp=0;VirtualProtect(p,4,old,&tmp);
  logLine(std::string("reloc82.")+tag+"=PASS");return true;
}

static bool patchPlutoLegacyGameOperands(HMODULE pluto){
  if(!g_legacyGameShadow){logLine("reloc82.game_block=NO_SHADOW");return false;}
  auto* base=(unsigned char*)pluto;
  auto* dos=(IMAGE_DOS_HEADER*)base;
  if(!readable(dos,sizeof(*dos))||dos->e_magic!=IMAGE_DOS_SIGNATURE){logLine("reloc82.game_block=BAD_DOS");return false;}
  auto* nt=(IMAGE_NT_HEADERS*)(base+dos->e_lfanew);
  if(!readable(nt,sizeof(*nt))||nt->Signature!=IMAGE_NT_SIGNATURE){logLine("reloc82.game_block=BAD_NT");return false;}
  struct Hit{unsigned char* p;uint32_t oldv;};
  std::vector<Hit> hits;
  bool aFrame=false,aMapW=false,aMapH=false,aUpgrade=false,aLegacy7536=false;
  auto* sec=IMAGE_FIRST_SECTION(nt);
  for(unsigned si=0;si<nt->FileHeader.NumberOfSections;++si){
    if(!(sec[si].Characteristics&IMAGE_SCN_MEM_EXECUTE))continue;
    size_t n=sec[si].Misc.VirtualSize?sec[si].Misc.VirtualSize:sec[si].SizeOfRawData;
    if(sec[si].VirtualAddress>=nt->OptionalHeader.SizeOfImage)continue;
    n=std::min<size_t>(n,nt->OptionalHeader.SizeOfImage-sec[si].VirtualAddress);
    auto* p=base+sec[si].VirtualAddress;
    for(size_t i=0;i+4<=n;++i){
      uint32_t v=0;memcpy(&v,p+i,4);
      if(v<kLegacyGameBase||v>=kLegacyGameBase+kScrGameSize)continue;
      hits.push_back({p+i,v});
      if(v==0x0057F23Cu)aFrame=true;
      if(v==0x0057F1D4u)aMapW=true;
      if(v==0x0057F1D6u)aMapH=true;
      if(v==0x0058D2B0u)aUpgrade=true;
      if(v==0x0057FD3Cu)aLegacy7536=true;
      i+=3;
    }
  }
  logLine("reloc82.game_operands.found="+std::to_string(hits.size()));
  logLine("reloc82.game_operands.anchor.frame="+std::string(aFrame?"YES":"NO")+
          " mapw="+(aMapW?std::string("YES"):std::string("NO"))+
          " maph="+(aMapH?std::string("YES"):std::string("NO"))+
          " upgrade="+(aUpgrade?std::string("YES"):std::string("NO"))+
          " legacy7536="+(aLegacy7536?std::string("YES"):std::string("NO")));
  // Exact Pluto release is expected to contain many direct references into the
  // contiguous BW Game block. Refuse to patch if the anchors do not match.
  if(hits.size()<20||!aFrame||!aMapW||!aMapH||!aUpgrade||!aLegacy7536){logLine("reloc82.game_operands=VALIDATION_FAIL");return false;}
  uintptr_t sb=(uintptr_t)g_legacyGameShadow;
  if(sb>0xFFFFFFFFu||sb+kScrGameSize>0x100000000ull){logLine("reloc82.game_operands=SHADOW_RANGE_FAIL");return false;}
  for(const auto& h:hits){
    uint32_t nv=(uint32_t)(sb+(uintptr_t)(h.oldv-kLegacyGameBase));
    DWORD old=0;if(!VirtualProtect(h.p,4,PAGE_EXECUTE_READWRITE,&old)){logLine("reloc82.game_operands=PROTECT_FAIL");return false;}
    memcpy(h.p,&nv,4);FlushInstructionCache(GetCurrentProcess(),h.p,4);DWORD tmp=0;VirtualProtect(h.p,4,old,&tmp);
  }
  logLine("reloc82.game_operands.shadow_base="+std::to_string((unsigned long)sb));
  logLine("reloc82.game_operands.patched="+std::to_string(hits.size()));
  logLine("reloc82.game_operands=PASS");
  return true;
}

static bool patchPlutoCUnitHead628430(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sigEbx[6]={0x8B,0x1D,0x30,0x84,0x62,0x00};
  const unsigned char sigEdi[6]={0x8B,0x3D,0x30,0x84,0x62,0x00};
  const uintptr_t target=(uintptr_t)&g_scrVisibleUnitHead;
  bool a=patchAbs32(b+0x33F7D,2,sigEbx,6,target,"rva_33f7d_628430");
  bool c=patchAbs32(b+0xBD6B,2,sigEbx,6,target,"rva_bd6b_628430");
  bool d=patchAbs32(b+0x3B787,2,sigEdi,6,target,"rva_3b787_628430");
  return a&&c&&d;
}

static bool patchPlutoUnitNodeTableBase(HMODULE pluto){
  if(g_legacyCUnits.empty()){logLine("reloc82.unit_table=NO_SHADOW_UNITS");return false;}
  uintptr_t basePtr=(uintptr_t)&g_legacyCUnits[0];
  if(basePtr>0xFFFFFFFFu || basePtr+0xA5u>0xFFFFFFFFu){logLine("reloc82.unit_table=OUT_OF_X86_RANGE");return false;}
  uint32_t base=(uint32_t)basePtr;
  uint32_t negBase=0u-base;
  uint32_t generationBase=base+0xA5u;
  logLine("reloc82.unit_table.shadow_base="+std::to_string((unsigned long)base));
  bool ok=true;
  // Pluto computes unit slot indices by adding/subtracting BW 1.16.1's
  // UnitNodeTable base (0x59CCA8). Redirect only those validated operands
  // to the start of our contiguous 336-byte legacy CUnit shadow.
  ok=patchOperand32(pluto,0xAAF4,0xFFA63358u,negBase,"rva_aaf4_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0xAB44,0xFFA63358u,negBase,"rva_ab44_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3134B,0x0059CD4Du,generationBase,"rva_3134b_59cd4d")&&ok;
  ok=patchOperand32(pluto,0x31351,0x0059CCA8u,base,"rva_31351_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3408D,0xFFA63358u,negBase,"rva_3408d_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x341B4,0xFFA63358u,negBase,"rva_341b4_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x343D8,0xFFA63358u,negBase,"rva_343d8_neg_59cca8")&&ok;
  ok=patchOperand32(pluto,0x3C2D9,0x0059CD4Du,generationBase,"rva_3c2d9_59cd4d")&&ok;
  ok=patchOperand32(pluto,0x3C2DE,0x0059CCA8u,base,"rva_3c2de_59cca8")&&ok;
  logLine(std::string("reloc82.unit_table=")+(ok?"PASS":"FAIL"));
  return ok;
}

static bool patchPlutoCUnitHead6283EC(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x2D,0xEC,0x83,0x62,0x00};
  return patchAbs32(b+0x34149,2,sig,6,(uintptr_t)&g_scrHiddenUnitHead,"rva_34149_6283ec");
}

static bool patchPlutoCUnitHead6283F4(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x2D,0xF4,0x83,0x62,0x00};
  return patchAbs32(b+0x34250,2,sig,6,(uintptr_t)&g_scrScannerSweepHead,"rva_34250_6283f4");
}

static bool patchPlutoBulletHead64DEC4(HMODULE pluto){
  unsigned char* b=(unsigned char*)pluto;
  const unsigned char sig[6]={0x8B,0x1D,0xC4,0xDE,0x64,0x00};
  return patchAbs32(b+0xBC75,2,sig,6,(uintptr_t)&g_legacyBulletHead,"rva_bc75_64dec4");
}

static unsigned char g_reloc57fd3c[0x10000]{};

static bool patchPlutoLegacy57FD3C(HMODULE pluto){
  unsigned char* p=(unsigned char*)pluto+0x7536;
  const unsigned char expect[7]={0x0F,0xB6,0x90,0x3C,0xFD,0x57,0x00};
  if(memcmp(p,expect,7)!=0){
    logLine("reloc_probe.rva_7536_signature=MISMATCH");
    return false;
  }
  // Preserve the exact instruction shape; change only its disp32.
  // movzx edx, byte ptr [eax + disp32]
  uintptr_t compat=(uintptr_t)g_reloc57fd3c;
  if(compat>0xFFFFFFFFu){
    logLine("reloc_probe.compat_ptr=OUT_OF_X86_RANGE");
    return false;
  }
  unsigned char repl[7]={0x0F,0xB6,0x90,0,0,0,0};
  uint32_t disp=(uint32_t)compat;
  memcpy(repl+3,&disp,4);
  DWORD old=0;
  if(!VirtualProtect(p,7,PAGE_EXECUTE_READWRITE,&old)){
    logLine("reloc_probe.virtualprotect=FAIL gle="+std::to_string(GetLastError()));
    return false;
  }
  memcpy(p,repl,7);
  FlushInstructionCache(GetCurrentProcess(),p,7);
  DWORD tmp=0;VirtualProtect(p,7,old,&tmp);
  logLine("reloc_probe.rva_7536_signature=PASS");
  logLine("reloc_probe.rva_7536_patched=PASS");
  logLine("reloc_probe.compat_base="+std::to_string((unsigned long)compat));
  return true;
}

static int mapLegacyPlutoDataPages(){
  // MEM_RESERVE base addresses must honor Windows allocation granularity (normally 64 KiB).
  // These four 64 KiB blocks cover every legacy absolute data page currently observed in Pluto.
  const uintptr_t blocks[]={0x00510000,0x00570000,0x00580000,0x00590000};
  int mapped=0;
  SYSTEM_INFO si{};GetSystemInfo(&si);
  logLine("legacy_probe.allocation_granularity="+std::to_string((unsigned long)si.dwAllocationGranularity));
  for(uintptr_t a:blocks){
    MEMORY_BASIC_INFORMATION mbi{};
    if(!VirtualQuery((LPCVOID)a,&mbi,sizeof(mbi))){
      logLine("legacy_probe.virtualquery_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(GetLastError()));
      continue;
    }
    if(mbi.State==MEM_FREE){
      void*p=VirtualAlloc((LPVOID)a,0x10000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
      if(p==(void*)a){
        ++mapped;
        logLine("legacy_probe.mapped_block="+std::to_string((unsigned long)a));
      }else{
        DWORD gle=GetLastError();
        logLine("legacy_probe.map_fail="+std::to_string((unsigned long)a)+" gle="+std::to_string(gle));
        if(p)VirtualFree(p,0,MEM_RELEASE);
      }
    }else{
      logLine("legacy_probe.block_occupied="+std::to_string((unsigned long)a)+
              " state="+std::to_string((unsigned long)mbi.State)+
              " base="+std::to_string((unsigned long)(uintptr_t)mbi.BaseAddress)+
              " size="+std::to_string((unsigned long)mbi.RegionSize));
    }
  }
  return mapped;
}

static DWORD findLegacyCUnitVectorSeh(UnitStore*out){__try{*out=findLegacyCUnitVector();return 0;}__except(EXCEPTION_EXECUTE_HANDLER){return GetExceptionCode();}}
static DWORD WINAPI boot(LPVOID){
  DeleteFileW((dirOfW(g_self)+L"\\plutoscr-x86-v82.log").c_str());
  logLine("PLUTOSCR_V82_RESIDENT=LOADED");logLine("architecture=x86");logLine("policy=original-pluto-observation-untouched");
  logLine("checkpoint.boot.before_cunit_scan");
  UnitStore store{};
  DWORD scanEc=findLegacyCUnitVectorSeh(&store);
  if(scanEc){logLine("checkpoint.cunit_scan.SEH_EXCEPTION code="+std::to_string(scanEc));return 12;}
  logLine("checkpoint.boot.after_cunit_scan");
  logLine("scr_cunit_vector.descriptor="+std::to_string((unsigned long)store.descriptor));logLine("scr_cunit_vector.score="+std::to_string(store.score));
  if(store.score<2){logLine("scr_cunit_vector=UNRESOLVED");return 10;} logLine("scr_cunit_vector=BOUND");
  logLine("cunit_store.begin="+std::to_string((unsigned long)store.begin)+" end="+std::to_string((unsigned long)store.end)+" cap="+std::to_string((unsigned long)store.cap));
  const std::wstring d=dirOfW(g_self);
  SetCurrentDirectoryW(d.c_str());SetDllDirectoryW(d.c_str());
  const bool runtimeReady=ensureOriginalPlutoRuntimeLayout(d);
  const std::wstring plutoDll=d+L"\\pluto.dll";
  HMODULE pluto=LoadLibraryW(plutoDll.c_str());if(!pluto){logLine("original_pluto.load=FAIL error="+std::to_string(GetLastError()));return 1;}logLine("original_pluto.load=PASS");
  wchar_t plutoPath[32768]={};DWORD plutoPathLen=GetModuleFileNameW(pluto,plutoPath,(DWORD)(sizeof(plutoPath)/sizeof(plutoPath[0])));std::wstring plutoDir(plutoPath,plutoPathLen);auto ps=plutoDir.find_last_of(L"\\/");if(ps!=std::wstring::npos)plutoDir=plutoDir.substr(0,ps);
  std::wstring inferPath=plutoDir+L"\\pluto\\pluto_infer.exe";std::wstring weightsPath=plutoDir+L"\\pluto\\pluto_weights.bin";
  logLine("pluto.module_path_utf8="+utf8(std::wstring(plutoPath,plutoPathLen)));
  logLine("pluto_runtime.ready="+std::string(runtimeReady?"YES":"NO"));
  logLine("pluto_infer.file_size="+std::to_string(fileSizeOrZero(inferPath)));
  logLine("pluto_weights.file_size="+std::to_string(fileSizeOrZero(weightsPath)));
  if(!runtimeReady || fileSizeOrZero(inferPath)==0 || fileSizeOrZero(weightsPath)==0){logLine("pluto_runtime=REJECTED_MISSING_ORIGINAL_INFERENCE_FILES");return 1;}
  logLine("pluto_infer.process_count.after_load="+std::to_string(countProcessByName(L"pluto_infer.exe")));
  auto gameInit=(PFNGameInit)GetProcAddress(pluto,"gameInit");auto createAI=(PFNCreateAI)GetProcAddress(pluto,"newAIModule");if(!gameInit||!createAI){logLine("original_pluto.exports=FAIL");return 2;}
  auto*data=new BWAPI::GameData();ZeroMemory(data,sizeof(*data));int n=projectLiveUnits(store,*data);logLine("live_units="+std::to_string(n));if(n<2)return 11;
  g_scrGame=findScrGameBlock(n);
  if(!g_scrGame){logLine("legacy_game=UNRESOLVED_FAIL_CLOSED");return 13;}
  data->mapWidth=rd<uint16_t>((unsigned char*)g_scrGame,228);data->mapHeight=rd<uint16_t>((unsigned char*)g_scrGame,230);data->frameCount=rd<uint32_t>((unsigned char*)g_scrGame,332);
  logLine("scr_game.ptr="+std::to_string((unsigned long)g_scrGame));
  logLine("scr_game.mapWidth="+std::to_string(data->mapWidth)+" mapHeight="+std::to_string(data->mapHeight)+" frame="+std::to_string(data->frameCount));
  if(!allocateLegacyGameShadow()){logLine("legacy_game.alloc=FAIL_CLOSED");return 14;}
  if(!syncLegacyGameShadow(g_scrGame)){logLine("legacy_game.sync=FAIL_CLOSED");return 14;}
  logLine("legacy_game.shadow_base="+std::to_string((unsigned long)(uintptr_t)g_legacyGameShadow));
  logLine("legacy_game.shadow_size="+std::to_string((unsigned long)kScrGameSize));
  if(!patchPlutoLegacyGameOperands(pluto)){logLine("legacy_game.reloc=FAIL_CLOSED");return 22;}
  logLine("legacy_game=BOUND_RELOCATED_REAL_SCR_GAME");
  // Choose the first participating slot only as a compatibility bootstrap; do not fabricate Pluto observations.
  int self=-1,enemy=-1;for(int p=0;p<12;p++)if(data->players[p].isParticipating){if(self<0)self=p;else if(enemy<0)enemy=p;}data->self=self;data->enemy=enemy;data->neutral=11;data->isInGame=true;
  logLine("gamedata.initialUnitCount="+std::to_string(data->initialUnitCount));
  logLine("gamedata.playerCount="+std::to_string(data->playerCount));
  logLine("gamedata.self="+std::to_string(self)+" enemy="+std::to_string(enemy)+" neutral="+std::to_string(data->neutral));
  for(int p=0;p<12;p++)if(data->players[p].isParticipating){int pc=0;for(int u=0;u<data->initialUnitCount;u++)if(data->units[u].player==p)++pc;logLine("gamedata.player["+std::to_string(p)+"].units="+std::to_string(pc)+" race="+std::to_string(data->players[p].race));}
  logLine("gamedata.mapWidth="+std::to_string(data->mapWidth)+" mapHeight="+std::to_string(data->mapHeight));
  BWAPI::BWAPIClient.data=data;auto*game=new BWAPI::GameImpl(data);BWAPI::BroodwarPtr=game;logLine("checkpoint.gameimpl.constructed");
  gameInit(game);logLine("checkpoint.original_pluto.gameInit.PASS");auto*module=createAI();if(!module){logLine("original_pluto.newAIModule=FAIL");return 3;}logLine("checkpoint.original_pluto.newAIModule.PASS");
  game->onMatchStart();logLine("checkpoint.bwapi.onMatchStart.PASS");
  logLine("reloc_probe.mode=pluto-original-observation-relocated-real-scr-game-shadow-cunit-unit-table-bullet-no-command-sink");
  // Do not patch 0x57F1xx/0x57FD3C to zero-filled compatibility buffers anymore.
  // Original Pluto now reads the actual SCR Game state through relocated legacy Game operands.
  int headLen=buildLegacyCUnitShadow(store);
  logLine("legacy_cunit_shadow.count="+std::to_string(headLen));
  if(!g_scrVisibleUnitHead || headLen<2){logLine("legacy_cunit_shadow=UNRESOLVED");return 15;}
  logLine("legacy_cunit_shadow=BOUND");
  bool reloc628430=patchPlutoCUnitHead628430(pluto);
  logLine(std::string("reloc82.patch_all_628430=")+(reloc628430?"PASS":"FAIL"));
  if(!reloc628430)return 16;
  bool relocUnitTable=patchPlutoUnitNodeTableBase(pluto);
  logLine(std::string("reloc82.patch_unit_table=")+(relocUnitTable?"PASS":"FAIL"));
  if(!relocUnitTable)return 21;
  bool reloc6283ec=patchPlutoCUnitHead6283EC(pluto);
  logLine(std::string("reloc82.patch_6283ec=")+(reloc6283ec?"PASS":"FAIL"));
  if(!reloc6283ec)return 17;
  bool reloc6283f4=patchPlutoCUnitHead6283F4(pluto);
  logLine(std::string("reloc82.patch_6283f4=")+(reloc6283f4?"PASS":"FAIL"));
  if(!reloc6283f4)return 18;
  if(!buildLegacyBulletShadow()){logLine("legacy_bullet_shadow=UNRESOLVED_FAIL_CLOSED");return 19;}
  logLine("legacy_bullet_shadow=BOUND");
  bool reloc64dec4=patchPlutoBulletHead64DEC4(pluto);
  logLine(std::string("reloc82.patch_64dec4=")+(reloc64dec4?"PASS":"FAIL"));
  if(!reloc64dec4)return 20;
  DWORD ec=onStartSeh(module);if(ec){
    logLine("original_pluto.onStart=SEH_EXCEPTION code="+std::to_string(ec));
    logLine("seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
    logLine("seh.eip="+std::to_string((unsigned long)g_sehEip));
    uintptr_t pb=(uintptr_t)pluto;
    if(g_sehAddress>=pb)logLine("seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
    if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)logLine("seh.class=legacy_bw_absolute_address");
    else if(g_sehAddress>=pb)logLine("seh.class=pluto_code");
    else logLine("seh.class=other");
    return 4;
  }logLine("original_pluto.onStart=PASS");
  logLine("pluto_infer.process_count.after_onStart="+std::to_string(countProcessByName(L"pluto_infer.exe")));
  logLine("reloc_probe.onStart_with_relocated_real_game_shadow=PASS");
  logLine("PLUTOSCR_V82_LIVE_CUNIT_PLUTO_LOOP=START");int lastCmd=0;unsigned diagFrame=0;
  while(true){
    ++diagFrame; if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_sleep");
    Sleep(42);if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_sleep");
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_projectLiveUnits");
    int live=projectLiveUnits(store,*data);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_projectLiveUnits live="+std::to_string(live));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_shadow_refresh");
    int shadowLive=refreshLegacyCUnitShadow(store);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_shadow_refresh live="+std::to_string(shadowLive));
    if(shadowLive!=live)logLine("legacy_cunit_shadow.live_mismatch="+std::to_string(shadowLive)+"/"+std::to_string(live));if(live<2){logLine("live_units_lost");break;}
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_game_shadow_refresh");
    if(!syncLegacyGameShadow(g_scrGame)){logLine("legacy_game.live_refresh=FAIL_CLOSED");break;}
    data->mapWidth=rd<uint16_t>((unsigned char*)g_scrGame,228);data->mapHeight=rd<uint16_t>((unsigned char*)g_scrGame,230);data->frameCount=rd<uint32_t>((unsigned char*)g_scrGame,332);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_game_shadow_refresh frame="+std::to_string(data->frameCount));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_bwapi_onMatchFrame");
    game->onMatchFrame();
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_bwapi_onMatchFrame");
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].pluto_infer.process_count.before_onFrame="+std::to_string(countProcessByName(L"pluto_infer.exe")));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].before_pluto_onFrame");
    ec=onFrameSeh(module);
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].after_pluto_onFrame seh="+std::to_string(ec));
    if(diagFrame<=3)logLine("frame["+std::to_string(diagFrame)+"].pluto_infer.process_count.after_onFrame="+std::to_string(countProcessByName(L"pluto_infer.exe")));
    if(ec){
      logLine("original_pluto.onFrame=SEH_EXCEPTION code="+std::to_string(ec));
      logLine("onframe.seh.exception_address="+std::to_string((unsigned long)g_sehAddress));
      logLine("onframe.seh.eip="+std::to_string((unsigned long)g_sehEip));
      logLine("onframe.seh.access_type="+std::to_string((unsigned long)g_sehAccessType));
      logLine("onframe.seh.access_address="+std::to_string((unsigned long)g_sehAccessAddress));
      logLine("onframe.seh.regs.eax="+std::to_string((unsigned long)g_sehEax)+" ebx="+std::to_string((unsigned long)g_sehEbx)+" ecx="+std::to_string((unsigned long)g_sehEcx)+" edx="+std::to_string((unsigned long)g_sehEdx)+" esi="+std::to_string((unsigned long)g_sehEsi)+" edi="+std::to_string((unsigned long)g_sehEdi)+" ebp="+std::to_string((unsigned long)g_sehEbp)+" esp="+std::to_string((unsigned long)g_sehEsp));
      if(readable((void*)g_sehEip,16)){std::ostringstream hs;hs<<"onframe.seh.code16=";auto*q=(unsigned char*)g_sehEip;const char*hex="0123456789ABCDEF";for(int i=0;i<16;i++){hs<<hex[q[i]>>4]<<hex[q[i]&15];}logLine(hs.str());}
      uintptr_t pb=(uintptr_t)pluto;
      if(g_sehAddress>=pb)
        logLine("onframe.seh.pluto_rva="+std::to_string((unsigned long)(g_sehAddress-pb)));
      if(g_sehAddress>=0x00400000 && g_sehAddress<0x00600000)
        logLine("onframe.seh.class=legacy_bw_absolute_address");
      else if(g_sehAddress>=pb)
        logLine("onframe.seh.class=pluto_code");
      else
        logLine("onframe.seh.class=other");
      break;
    }
    if(data->unitCommandCount!=lastCmd){logLine("pluto_bwapi_unit_commands="+std::to_string(data->unitCommandCount));lastCmd=data->unitCommandCount;}
    if(data->unitCommandCount>0){logLine("scr_command_sink=UNRESOLVED_FAIL_CLOSED");data->unitCommandCount=0;lastCmd=0;}
  }
  return 0;
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){if(r==DLL_PROCESS_ATTACH){g_self=h;DisableThreadLibraryCalls(h);HANDLE t=CreateThread(nullptr,0,boot,nullptr,0,nullptr);if(t)CloseHandle(t);}return TRUE;}
