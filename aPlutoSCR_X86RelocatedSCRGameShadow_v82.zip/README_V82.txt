aPlutoSCR v82 x86 Relocated SCR Game Shadow

Purpose
- Port the unmodified original Pluto CoG 2026 binary to 32-bit StarCraft: Remastered.
- Observation, inference, decision-making, and command selection remain inside the original Pluto.
- This build only supplies the memory/BWAPI compatibility layer.

What changed from v81
- v81 successfully located the real live SCR Game structure (96x128 map, frame 260) but failed closed because the old fixed BW virtual-address blocks at 0x570000/0x580000/0x590000 were already occupied.
- v82 allocates the 96,000-byte Game shadow at a normal free x86 address instead of trying to reserve old BW addresses.
- It validates the known Pluto Game-memory anchors, then relocates Pluto's direct operands that point into the contiguous legacy Game range 0x57F0F0..0x5967EF.
- The target for each operand is shadow_base + (legacy_address - 0x57F0F0).
- The shadow is refreshed every frame from the actual SCR Game structure.
- This preserves original Pluto reads of map size/frame, resources, supplies, upgrades, tech state, availability, research/upgrade state, and other Game fields.
- CUnit, UnitNodeTable and bullet compatibility from v80/v81 are retained.
- Command sink remains fail-closed; this build does not invent actions.

Original runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Run
1. Put the unmodified original Pluto files beside this package in the layout above.
2. Start 32-bit StarCraft: Remastered and enter a local/custom match.
3. Run RUN_PLUTO_SCR_X86_V82.cmd.
4. Upload plutoscr-x86-v82.log.

Success indicators
- pluto_runtime.ready=YES
- scr_game.select=PROFILE_VALIDATED or DYNAMIC_SCAN
- reloc82.game_operands=PASS
- legacy_game=BOUND_RELOCATED_REAL_SCR_GAME
- gamedata.mapWidth/mapHeight are non-zero
- pluto_infer.process_count.after_onStart=1
- original_pluto.onFrame advances beyond the prior 0x58D2B0 fault
