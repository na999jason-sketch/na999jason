aPlutoSCR v99 x86 — Coherent State Retry + Multi-Match

기준
- v97의 실제 SC:R Game/Players/CUnit/ActiveTile/Bullet 관측, 실제 visibility/alliance, original Pluto inference/decision, command translation, game-thread send, multi-match lifecycle을 그대로 유지한다.
- 원본 Pluto가 관측/추론/판단/legacy command 생성을 담당한다. v99은 판단 로직을 추가하지 않는다.

v99 변경 — 장시간 multi-match CUnit/head race + bullet race 수정
추가 수정 — CUnit/head transient race
- v96 soak test에서 generation=5 중 `profile_heads=HIDDEN_NOT_MAPPED` 뒤 `SHADOW_COUNT_MISMATCH_FAIL_CLOSED`로 멈춘 실제 로그를 반영했다.
- 공개 reference의 `unit(raw)` semantics와 맞춰 hidden/scanner head가 현재 legacy-accessible unit 집합에 없으면 null로 투영하며 즉시 fatal로 보지 않는다.
- active-head/legacy shadow mismatch는 전체 관측을 폐기하고 최대 7회 재시도한다. 8회 연속 실패만 실제 구조 이상으로 보고 fail-closed한다.
- 원본 Pluto의 관측/추론/판단/명령 생성은 변경하지 않는다.

- v97 두 번째 경기에서 `profile_bullet=CYCLE_DETECTED` 직후 `MATCH_LOOP_STOPPED_FATAL`로 멈춘 로그를 기준으로 수정했다.
- 원인은 resident worker가 SC:R bullet linked list를 비동기 순회하는 순간 game thread가 링크를 갱신하면, 정상 리스트도 일시적으로 cycle/unreadable처럼 보일 수 있다는 점이다.
- 그런 torn bullet snapshot은 Pluto에 절대 전달하지 않는다.
- bullet snapshot이 한 번 실패하면 그 observation 전체를 버리고 다음 poll에서 다시 읽는다.
- 성공하면 `profile_bullet.live_refresh=RECOVERED retries=N ...`를 기록하고 정상 진행한다.
- 동일 문제가 연속 8회 발생하면 실제 구조 손상 가능성으로 보고 기존처럼 fail-closed한다.
- 경기 종료 도중 bullet 상태가 사라진 경우에는 fatal로 보지 않고 정상 match-end lifecycle로 넘긴다.

보존 사항
- v97 real SCR alliances / team / force 상태
- coherent CUnit snapshot
- real ActiveTile visibility
- legacy Game/Players exact bindings
- exact legacy command translation
- one-frame delayed game-thread send_command
- same-process multi-match lifecycle
- shared Win32 logging

권장 테스트
1) StarCraft.exe와 pluto_infer.exe를 완전히 종료한다.
2) SC:R 32-bit를 새로 실행한다.
3) 1:1 melee 첫 판에 들어간 뒤 v99을 한 번만 주입한다.
4) injector를 다시 실행하지 않고 5판 이상 연속 진행한다.
5) `profile_bullet=CYCLE_DETECTED`가 나와도 바로 뒤에 TRANSIENT_RETRY_SKIP / RECOVERED가 나오며 게임이 계속 돌아가야 한다.

정상 회복 예시
  profile_bullet=CYCLE_DETECTED
  profile_bullet.live_refresh=TRANSIENT_RETRY_SKIP streak=1 frame=...
  profile_bullet.live_refresh=RECOVERED retries=1 frame=...

진짜 fail-closed
- bullet snapshot이 연속 8회 실패
- unsupported command / invalid handle
- send_command failure/SEH
- invalid persistent game state
- inference process count invalid

로그
- plutoscr-x86-v99.log
- plutoscr-x86-v99-inject.log
- plutoscr-x86-v99-launch.log
