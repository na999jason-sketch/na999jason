@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "LAUNCHLOG=%ROOT%\plutoscr-x86-v99-launch.log"

>"%LAUNCHLOG%" echo PLUTOSCR_V99_LAUNCHER=START
>>"%LAUNCHLOG%" echo ROOT=%ROOT%
echo === aPlutoSCR v99 x86 Coherent State Retry + Multi-Match ===

for %%F in ("%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86V99.dll" "%ROOT%\pluto.dll") do if not exist "%%~F" (
  echo [FAIL] missing: %%~F
  >>"%LAUNCHLOG%" echo FAIL missing: %%~F
  echo Copy the original pluto.dll beside this CMD.
  pause
  exit /b 1
)

if exist "%ROOT%\pluto\pluto_infer.exe" if exist "%ROOT%\pluto\pluto_weights.bin" goto runtime_ready
if exist "%ROOT%\pluto_infer.exe" if exist "%ROOT%\pluto_weights.bin" (
  if not exist "%ROOT%\pluto" mkdir "%ROOT%\pluto"
  copy /Y "%ROOT%\pluto_infer.exe" "%ROOT%\pluto\pluto_infer.exe" >nul || goto runtime_fail
  copy /Y "%ROOT%\pluto_weights.bin" "%ROOT%\pluto\pluto_weights.bin" >nul || goto runtime_fail
  goto runtime_ready
)

echo [FAIL] Original Pluto inference files are missing.
>>"%LAUNCHLOG%" echo FAIL inference files missing
pause
exit /b 2

:runtime_fail
echo [FAIL] Could not create original Pluto runtime layout.
>>"%LAUNCHLOG%" echo FAIL runtime layout
pause
exit /b 3

:runtime_ready
tasklist /FI "IMAGENAME eq pluto_infer.exe" 2^>nul | find /I "pluto_infer.exe" ^>nul
if not errorlevel 1 (
  echo [FAIL] stale pluto_infer.exe is already running.
  echo Run: taskkill /IM pluto_infer.exe /F
  >>"%LAUNCHLOG%" echo FAIL stale pluto_infer.exe
  pause
  exit /b 5
)

del /q "%ROOT%\plutoscr-x86-v99.log" 2>nul
del /q "%ROOT%\plutoscr-x86-v99-inject.log" 2>nul

echo Start SC:R 32-bit and enter the FIRST local/custom game.
echo Press any key ONCE to inject v99.
echo After match 1, do NOT inject again. Make match 2 in the same StarCraft.exe.
pause >nul

echo [INFO] injecting...
>>"%LAUNCHLOG%" echo INJECT_START
"%ROOT%\PlutoSCRX86Inject.exe" "%ROOT%\PlutoSCRX86V99.dll" >>"%LAUNCHLOG%" 2>&1
set "RC=%ERRORLEVEL%"
>>"%LAUNCHLOG%" echo INJECT_EXIT=%RC%

echo.
echo === INJECT RESULT ===
type "%LAUNCHLOG%"
if not "%RC%"=="0" (
  echo [FAIL] injection stage failed. Send plutoscr-x86-v99-launch.log and plutoscr-x86-v99-inject.log.
  pause
  exit /b %RC%
)

timeout /t 2 /nobreak >nul
if exist "%ROOT%\plutoscr-x86-v99.log" (
  echo [PASS] DLL bootstrap log created.
  echo Keep StarCraft.exe running. Test repeated 1v1 melee games without rerunning v99.
) else (
  echo [FAIL] DLL injection returned PASS but runtime log is still missing.
  echo Send these two files:
  echo   plutoscr-x86-v99-launch.log
  echo   plutoscr-x86-v99-inject.log
)
pause
