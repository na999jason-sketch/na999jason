aPlutoTeamCompat v100 x86 — No-Training Ally-Opaque Experiment

목적
- 학습 없이 원본 Pluto가 2:2 / 3:3에 "일단 참가"할 수 있는지 확인하는 A/B 실험이다.
- 원본 Pluto의 pluto.dll / pluto_infer.exe / pluto_weights.bin은 그대로 사용한다.
- 원본 Pluto의 inference / 판단 / 전략 / legacy command 생성은 수정하지 않는다.
- 순수 포팅판 v99은 건드리지 않는다. v100은 별도 Team-Compat 실험판이다.

무학습 Team-Compat 규칙
1) SELF: 원본 그대로 관측.
2) ENEMY: 원본의 기존 "other player" 의미 그대로 관측.
3) NEUTRAL: 원본 그대로 관측.
4) ALLY (self가 아닌 동맹):
   - BWAPI GameData unit observation에서 제외.
   - Pluto가 직접 순회하는 legacy CUnit active/hidden/scanner linked list에서도 제외.
   - stable CUnit slot/handle 세대 정보는 보존해 snapshot coherence를 깨지 않는다.
   - 남은 unit의 CUnit pointer가 ally를 가리키면 그 pointer는 null로 redaction.
   - Bullet의 unit pointer가 ally를 가리키면 그 pointer도 null로 redaction.
5) Pluto가 그래도 ally handle을 직접 selection/target하려 하면 해당 packet만 DROP한다.
   - replacement target을 고르지 않는다.
   - 위치 명령/전략을 bridge가 생성하거나 수정하지 않는다.

이게 의미하는 것
- "진짜 팀 AI"가 아니다.
- 원본 1:1 Pluto가 아군을 적군으로 오해하지 않게 아군을 opaque 처리한 상태로,
  자기 운영 + 기존 enemy 상대 전투가 얼마나 유지되는지 보는 실험이다.
- 잘 되면 다음 학습 단계에서 바꿔야 할 범위를 줄일 수 있다.

보존
- v99 coherent CUnit snapshot retry
- v98 bullet retry
- real SCR Game / Players / ActiveTile / visibility
- real SCR team/alliance matrix
- original Pluto inference/decision
- exact legacy command translation
- one-frame delayed game-thread send_command
- same-process multi-match lifecycle

정상 로그
  TEAMCOMPAT_NO_TRAINING=ENABLED
  TEAMCOMPAT_MODE=ALLY_OPAQUE
  TEAMCOMPAT_RELATIONS self=... ally_mask=...
  TEAMCOMPAT owner_mode=ALLY_OPAQUE self_visible=... ally_hidden=... other_visible=... neutral_visible=...
  TEAMCOMPAT_LIST tag=active raw=... kept=... allies_hidden=...

Pluto가 아군을 직접 대상으로 잡으려 한 경우
  TEAMCOMPAT_ALLY_TARGET_BLOCK kind=... legacy=... total=...

중요
- TEAMCOMPAT_ALLY_TARGET_BLOCK은 bridge가 새로운 판단을 하는 것이 아니다.
  "아군 직접 target은 제출하지 않는다"는 안전/호환 경계이며 대체 행동은 만들지 않는다.

권장 첫 테스트
1) StarCraft.exe / pluto_infer.exe 완전 종료.
2) SC:R 32-bit 실행.
3) Hunters 또는 익숙한 맵에서 2:2 먼저 테스트.
4) 내 Pluto 슬롯 + 아군 1 + 적 2로 시작.
5) v100 한 번만 inject.
6) 다음 항목 관찰:
   - 일꾼이 자기 미네랄에서 정상 채취하는가
   - 생산/테크가 정상 진행되는가
   - 아군 미네랄/기지로 이상하게 몰리는 현상이 줄었는가
   - 적군을 찾아가 공격하는가
   - 아군을 공격/직접 타깃하지 않는가
7) 성공하면 3:3 Hunters로 확대.
8) 끝나면 `plutoteamcompat-x86-v100.log`를 보내면 된다.

실패 판정
- 자기 경제/생산도 망가짐
- enemy 공격을 못 함
- TEAMCOMPAT_LIST_* 오류가 반복되어 fail-closed
- 기존 v99의 coherent-state / command-send 안정성이 깨짐

이 경우 ally opaque 접근의 어느 observation path가 필요한지 로그로 좁힌다.
