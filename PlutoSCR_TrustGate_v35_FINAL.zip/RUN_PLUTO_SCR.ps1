﻿$ErrorActionPreference="Stop"
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$log=Join-Path $root "plutoscr-live.log"
"[$(Get-Date -Format o)] PlutoSCR live transport launcher start" | Set-Content $log
function Log($s){$s|Tee-Object -FilePath $log -Append|Out-Null}
function Need($n){$p=Join-Path $root $n;if(-not(Test-Path $p)){Log "[FAIL] missing file: $n";exit 10};Log "[PASS] file=$n bytes=$((Get-Item $p).Length)";return [string]$p}

try{
 $injector=Need "runtime-inject-resident-win.exe";$resident=Need "starcraft-api-resident.dll"
 $hostExe=Need "PlutoHost.exe";$liveBridge=Need "plutoscr-live-bridge.exe"
 $receiver=Need "starcraft-runtime-adapter-proof.exe";$plutoDll=Need "pluto.dll"
 $inferExe=Need "pluto_infer.exe";$null=Need "pluto_weights.bin"

 $sc=Get-Process StarCraft -ErrorAction SilentlyContinue|Select-Object -First 1
 if(-not $sc){Log "[FAIL] StarCraft.exe is not running";exit 20}
 Log "[PASS] StarCraft PID=$($sc.Id)"

 $infer=Get-Process pluto_infer -ErrorAction SilentlyContinue|Select-Object -First 1
 if(-not $infer){$infer=Start-Process -FilePath $inferExe -WorkingDirectory $root -PassThru;Start-Sleep -Milliseconds 700;$infer.Refresh()}
 if($infer.HasExited){Log "[FAIL] pluto_infer exited early code=$($infer.ExitCode)";exit 21}
 Log "[PASS] pluto_infer PID=$($infer.Id)"

 $io=Join-Path $root "injector.stdout.log";$ie=Join-Path $root "injector.stderr.log"
 Remove-Item $io,$ie -Force -ErrorAction SilentlyContinue
 $inj=Start-Process -FilePath $injector -ArgumentList @("--process-id","$($sc.Id)","--adapter","`"$resident`"") -WorkingDirectory $root -PassThru -Wait -RedirectStandardOutput $io -RedirectStandardError $ie
 if(Test-Path $io){Get-Content $io|%{Log "[INJECT-OUT] $_"}}
 if(Test-Path $ie){Get-Content $ie|%{Log "[INJECT-ERR] $_"}}
 Log "[INFO] injector exit=$($inj.ExitCode)"
 if($inj.ExitCode-ne 0){Log "[FAIL] resident injection failed";exit 22}
 Log "[PASS] resident injection request completed"

 $bridge=Join-Path $env:TEMP "starcraft-api-live-bridge"
 Log "[INFO] bridge=$bridge"
 if(Test-Path $bridge){
   Remove-Item (Join-Path $bridge "ready") -Force -ErrorAction SilentlyContinue
   Remove-Item (Join-Path $bridge "commands.log") -Force -ErrorAction SilentlyContinue
 }

 # Run the Windows external proof immediately. This is the authoritative
 # live-memory scanner/validated snapshot producer for v32.
 $ro=Join-Path $root "adapter-proof.stdout.log";$re=Join-Path $root "adapter-proof.stderr.log"
 Remove-Item $ro,$re -Force -ErrorAction SilentlyContinue
 $proofArgs=@("--process-id","$($sc.Id)","--executable","`"$($sc.Path)`"","--bridge","`"$bridge`"",
   "--prove-read-game-state","--prove-read-units","--prove-read-player-data",
   "--active-match-wait-ms","120000","--unit-scan-timeout-ms","30000",
   "--prove-issue-commands","--serve-command-bridge")
 Log "[INFO] Starting Windows live proof/command receiver"
 $rp=Start-Process -FilePath $receiver -ArgumentList $proofArgs -WorkingDirectory $root -PassThru -RedirectStandardOutput $ro -RedirectStandardError $re
 Log "[INFO] adapter-proof PID=$($rp.Id)"
 Log "[INFO] Enter a LOCAL/CUSTOM match now; waiting for validated state+units."

 $ready=Join-Path $bridge "ready"
 $deadline=(Get-Date).AddSeconds(150)
 $active=$false
 while((Get-Date)-lt $deadline){
   $rp.Refresh()
   if($rp.HasExited){break}
   if(Test-Path $ready){
     $r=Get-Content $ready -ErrorAction SilentlyContinue
     $state=($r|Where-Object{$_ -eq "proof.read_game_state=passed"})
     $residentSource=($r|Where-Object{$_ -eq "resident.proof.read_game_state.source=resident"})
     $bwgame=($r|Where-Object{$_ -eq "proof.read_game_state.bwgame_projection=resident-bwgame-projection-v1"})
     if($state -and $residentSource -and $bwgame){$active=$true;break}
   }
   Start-Sleep -Milliseconds 500
 }
 if(-not $active){
   if(Test-Path $ro){Get-Content $ro -Tail 160|%{Log "[PROOF-OUT] $_"}}
   if(Test-Path $re){Get-Content $re -Tail 160|%{Log "[PROOF-ERR] $_"}}
   $rl=Join-Path $bridge "resident-adapter.log"
   if(Test-Path $rl){
     Copy-Item $rl (Join-Path $root "resident-adapter.log") -Force -ErrorAction SilentlyContinue
     Get-Content $rl -Tail 160|%{Log "[RESIDENT] $_"}
   }
   if(Test-Path $ready){
     Copy-Item $ready (Join-Path $root "bridge-ready.txt") -Force -ErrorAction SilentlyContinue
     Get-Content $ready|%{Log "[READY] $_"}
   }
   $rp.Refresh()
   Log "[FAIL] validated live snapshot gate failed; adapter-proof-exited=$($rp.HasExited)"
   exit 23
 }
 Log "[PASS] validated live state+units+active-match gate passed"

 Log "[PASS] V35_RESIDENT_TRUST_GATE=true"
 Log "[INFO] Heuristic map/unit/active-match data is NOT trusted."
 $rl=Join-Path $bridge "resident-adapter.log"
 if(Test-Path $rl){Copy-Item $rl (Join-Path $root "resident-adapter.log") -Force -ErrorAction SilentlyContinue}
 if(Test-Path $ready){Copy-Item $ready (Join-Path $root "bridge-ready.txt") -Force -ErrorAction SilentlyContinue}
 Log "[INFO] PlutoHost intentionally NOT started until verified unit identity/ownership and command path are proven."
 return
 $rp.Refresh()
 if($rp.HasExited){
   if(Test-Path $ro){Get-Content $ro|%{Log "[PROOF-OUT] $_"}}
   if(Test-Path $re){Get-Content $re|%{Log "[PROOF-ERR] $_"}}
   Log "[FAIL] adapter-proof exited before command service code=$($rp.ExitCode)"
   exit 24
 }
 Log "[PASS] command receiver remains active PID=$($rp.Id)"

 $bo=Join-Path $root "live-bridge.stdout.log";$be=Join-Path $root "live-bridge.stderr.log"
 Remove-Item $bo,$be -Force -ErrorAction SilentlyContinue
 $bp=Start-Process -FilePath $liveBridge -ArgumentList @("`"$bridge`"") -WorkingDirectory $root -PassThru -RedirectStandardOutput $bo -RedirectStandardError $be
 Start-Sleep -Seconds 1;$bp.Refresh()
 if($bp.HasExited){Log "[FAIL] live bridge exited early code=$($bp.ExitCode)";exit 25}
 Log "[PASS] live bridge PID=$($bp.Id)"

 $ho=Join-Path $root "PlutoHost.stdout.log";$he=Join-Path $root "PlutoHost.stderr.log"
 Remove-Item $ho,$he -Force -ErrorAction SilentlyContinue
 $hp=Start-Process -FilePath $hostExe -ArgumentList @("`"$plutoDll`"") -WorkingDirectory $root -PassThru -RedirectStandardOutput $ho -RedirectStandardError $he
 Start-Sleep -Seconds 2;$hp.Refresh()
 if($hp.HasExited){
   if(Test-Path $ho){Get-Content $ho|%{Log "[HOST-OUT] $_"}}
   if(Test-Path $he){Get-Content $he|%{Log "[HOST-ERR] $_"}}
   Log "[FAIL] PlutoHost exited early code=$($hp.ExitCode)";exit 26
 }
 Log "[PASS] PlutoHost PID=$($hp.Id)"
 Log "[PASS] LIVE_TRANSPORT_V32_CHAIN_STARTED=true"
 Log "[INFO] Play 30-60 seconds, then send every *.log file plus plutoscr-bridge.log."
}catch{
 Log "[FAIL] launcher exception: $($_.Exception.GetType().FullName): $($_.Exception.Message)"
 Log "[FAIL] at=$($_.InvocationInfo.PositionMessage)";exit 99
}
