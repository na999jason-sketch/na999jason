aPlutoSCR v88 x86 Exact Pluto Bindings + Real SCR State

Purpose
- Run the original Pluto binary on 32-bit StarCraft: Remastered.
- Do not replace Pluto observation, inference, decision, or command generation.
- Flow remains: SC:R real state -> compatibility/legacy ABI -> original Pluto -> original Pluto command output.

Why v88 exists
- v87 was the first build where original Pluto onStart passed and original onFrame returned normally for three consecutive calls while pluto_infer.exe stayed alive.
- The next exception was 0xC000001D (illegal instruction) at Pluto RVA 0x2F9A0.
- v87 still relocated the old BW Game and Players blocks by scanning executable bytes for any 32-bit number inside the legacy address ranges. That can theoretically patch an incidental constant.
- v88 removes that ambiguity: Game and Players operands are patched only when both the exact Pluto RVA and exact original operand value match the pinned public pluto_bindings.h table.

v88 changes
- Uses the verified exact binding table generated for the pinned Pluto cog2026-2578600 binary.
- Game block 0x57F0F0..0x5967EF: exact RVA+expected-value patches only.
- Players[12] block 0x57EEE0..0x57F08F: exact RVA+expected-value patches only; exactly 25 player references are required.
- Any mismatched operand fails closed before Pluto runs.
- Adds a wider exception code window and 16 stack dwords if another deep onFrame fault occurs.
- Keeps v87 real Players, real local-player id, stable 1700 CUnit slots, CUnit internal pointer/sprite/handle conversion, real SCR Game shadow, real ActiveTileArray, and profile bullet shadow.
- Command sink remains disabled/fail-closed. No guessed command packets are sent to SC:R.

Original Pluto runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Expected v88 milestones
  profile_cunit=BOUND_VALIDATED
  reloc88.game_operands=PASS_EXACT_BINDINGS
  legacy_players.select=PROFILE_VALIDATED
  reloc88.players_operands=PASS_EXACT_BINDINGS
  legacy_players=BOUND_REAL_SCR_PLAYERS
  active_tile=BOUND_REAL_SCR
  profile_bullet=BOUND_VALIDATED
  reloc88.start_globals=PASS
  original_pluto.onStart=PASS
  frame[1].after_pluto_onFrame seh=0

If v88 still faults, return plutoscr-x86-v88.log. The extra code-window/stack diagnostics are intended to identify the next exact compatibility boundary without modifying Pluto logic.

The original Pluto model/files are not included and are not modified.
