@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set "INJECTOR=%ROOT%PlutoSCRX86Inject.exe"
set "RESIDENT=%ROOT%PlutoSCRX86V41.dll"
set "PLUTO=%ROOT%pluto.dll"
set "INFER=%ROOT%pluto_infer.exe"
set "WEIGHTS=%ROOT%pluto_weights.bin"
echo [PlutoSCR v41] x86 in-process BWAPI ABI gate
for %%F in ("%INJECTOR%" "%RESIDENT%" "%PLUTO%" "%INFER%" "%WEIGHTS%") do (
  if not exist "%%~F" (
    echo [FAIL] missing: %%~F
    pause
    exit /b 1
  )
)
"%INJECTOR%" "%RESIDENT%"
if errorlevel 1 (
  echo [FAIL] injection failed
  pause
  exit /b 2
)
timeout /t 2 /nobreak >nul
if exist "%ROOT%plutoscr-x86-v41.log" type "%ROOT%plutoscr-x86-v41.log"
pause
