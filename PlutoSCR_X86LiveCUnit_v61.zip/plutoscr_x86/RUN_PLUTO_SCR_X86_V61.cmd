@echo off
setlocal
cd /d "%~dp0"
echo === PlutoSCR v61 x86 runtime ===
if not exist PlutoSCRX86V61.dll (
  echo ERROR: PlutoSCRX86V61.dll missing
  pause
  exit /b 2
)
if not exist PlutoSCRX86Inject.exe (
  echo ERROR: PlutoSCRX86Inject.exe missing
  pause
  exit /b 3
)
if not exist pluto.dll (
  echo ERROR: copy original pluto.dll into this folder
  pause
  exit /b 4
)
if not exist pluto_infer.exe (
  echo ERROR: copy original pluto_infer.exe into this folder
  pause
  exit /b 5
)
if not exist pluto_weights.bin (
  echo ERROR: copy original pluto_weights.bin into this folder
  pause
  exit /b 6
)
del /q plutoscr-x86-v61.log 2>nul
echo Start the 32-bit SC:R StarCraft.exe and enter a local/custom game first.
echo Then press any key to inject PlutoSCRX86V61.dll.
pause >nul
PlutoSCRX86Inject.exe PlutoSCRX86V61.dll
echo.
echo Injector exit code: %ERRORLEVEL%
echo Keep SC:R running for at least 30 seconds.
timeout /t 30 /nobreak >nul
echo.
if exist plutoscr-x86-v61.log (
  echo === RUNTIME LOG ===
  type plutoscr-x86-v61.log
) else (
  echo ERROR: plutoscr-x86-v61.log was not created
)
echo.
pause
