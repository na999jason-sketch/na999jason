#include <BWAPI/Client/GameData.h>
#include <BWAPI/Client/UnitData.h>
#include <BWAPI/Client/PlayerData.h>
#include <BWAPI/Client/ForceData.h>
#include <BWAPI/Client/RegionData.h>
#include <BWAPI/Client/BulletData.h>
#include <BWAPI/Client/Event.h>
#include <BWAPI/Client/Command.h>
#include <BWAPI/Client/UnitCommand.h>
#include <BWAPI/Client/Shape.h>
#include <cstddef>
#include <iostream>

#define SZ(T) std::cout << "sizeof." #T "\t" << sizeof(T) << "\n"
#define OF(T,F) std::cout << "offsetof." #T "." #F "\t" << offsetof(T,F) << "\n"

int main() {
#if defined(_WIN64)
  std::cout << "arch\tx64\n";
#else
  std::cout << "arch\tx86\n";
#endif
  std::cout << "pointer\t" << sizeof(void*) << "\n";

  SZ(BWAPI::GameData); SZ(BWAPI::UnitData); SZ(BWAPI::PlayerData);
  SZ(BWAPI::ForceData); SZ(BWAPI::RegionData); SZ(BWAPI::BulletData);
  SZ(BWAPIC::Event); SZ(BWAPIC::Command); SZ(BWAPIC::UnitCommand); SZ(BWAPIC::Shape);

  OF(BWAPI::GameData, client_version); OF(BWAPI::GameData, revision);
  OF(BWAPI::GameData, isDebug); OF(BWAPI::GameData, forces);
  OF(BWAPI::GameData, players); OF(BWAPI::GameData, units);
  OF(BWAPI::GameData, unitArray); OF(BWAPI::GameData, bullets);
  OF(BWAPI::GameData, frameCount); OF(BWAPI::GameData, averageFPS);
  OF(BWAPI::GameData, mapWidth); OF(BWAPI::GameData, regions);
  OF(BWAPI::GameData, isInGame); OF(BWAPI::GameData, selectedUnits);
  OF(BWAPI::GameData, self); OF(BWAPI::GameData, events);
  OF(BWAPI::GameData, eventStrings); OF(BWAPI::GameData, strings);
  OF(BWAPI::GameData, shapes); OF(BWAPI::GameData, commands);
  OF(BWAPI::GameData, unitCommands); OF(BWAPI::GameData, xUnitSearch);
  OF(BWAPI::GameData, yUnitSearch);

  OF(BWAPI::UnitData, id); OF(BWAPI::UnitData, positionX);
  OF(BWAPI::UnitData, angle); OF(BWAPI::UnitData, hitPoints);
  OF(BWAPI::UnitData, target); OF(BWAPI::UnitData, order);
  OF(BWAPI::UnitData, exists); OF(BWAPI::UnitData, isVisible);
  OF(BWAPI::UnitData, replayID);

  return 0;
}
