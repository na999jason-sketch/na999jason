#pragma once
#include "PlutoSCRShared.h"
#include <BWAPI/Runtime/RuntimeCommandQueue.h>
#include <string>
#include <vector>

namespace PlutoSCR {
struct DrainResult {
  std::vector<BWAPI::Runtime::RuntimeCommandRequest> requests;
  std::vector<std::string> rejected;
};
DrainResult drainBWAPIClientCommands(BWAPI::GameData& data);
}
