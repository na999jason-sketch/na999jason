#include "RuntimeCommandPump.h"
#include <fstream>
namespace PlutoSCR {
static bool hasLine(const std::filesystem::path&p,const std::string& wanted){
 std::ifstream f(p);std::string s;while(std::getline(f,s))if(s==wanted)return true;return false;
}
PumpResult pumpCommandsToValidatedBridge(BWAPI::GameData& data,const std::filesystem::path& bridge){
 PumpResult result; const auto ready=bridge/"ready";
 // Fail closed exactly like upstream submit-command preflight.
 const char* required[]={"mode=validated-runtime-adapter","proof.issue_commands=passed","command.receiver=active","command.sink=runtime-command-queue-v1"};
 for(const char* line:required) if(!hasLine(ready,line)){result.reason=std::string("bridge gate missing: ")+line;return result;}
 auto drained=drainBWAPIClientCommands(data);
 result.rejected+=(int)drained.rejected.size();
 std::ofstream queue(bridge/"commands.log",std::ios::app);
 if(!queue){result.reason="commands.log unavailable";return result;}
 for(const auto& request:drained.requests){
   auto encoded=BWAPI::Runtime::encodeRuntimeCommandRequest(request);
   if(!encoded.encoded){++result.rejected;continue;}
   // Use the upstream receiver's textual queue contract; receiver re-encodes and audits.
   queue<<(request.kind==BWAPI::Runtime::RuntimeCommandKind::GameAction?"game-action":"unit-command")
        <<'\t'<<request.name<<'\t'<<request.targetUnitId;
   for(int a:request.arguments) queue<<'\t'<<a;
   queue<<'\n'; ++result.accepted;
 }
 queue.flush();
 result.reason="ok"; return result;
}
}
