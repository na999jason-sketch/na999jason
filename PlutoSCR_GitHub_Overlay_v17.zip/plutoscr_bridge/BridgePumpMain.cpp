#include "ValidatedSnapshotReader.h"
#include "SCRStateProjection.h"
#include "RuntimeCommandPump.h"
#include <BWAPI/Client/GameData.h>
#include <filesystem>
#include <iostream>
int main(int argc,char**argv){
 if(argc<2){std::cerr<<"usage: plutoscr-bridge-pump <validated-bridge-dir>\n";return 64;}
 const std::filesystem::path bridge=argv[1];
 auto snapshot=PlutoSCR::readValidatedBridgeSnapshot(bridge);
 if(!snapshot.ok){std::cerr<<"snapshot.reject="<<snapshot.reason<<"\n";return 2;}
 BWAPI::GameData data{};
 PlutoSCR::projectValidatedSnapshot(snapshot.frame,data);
 std::cout<<"snapshot.accept=true\nframe="<<data.frameCount<<"\nunits="<<snapshot.frame.units.size()<<"\n";
 // Standalone smoke mode does not fabricate Pluto commands.
 return 0;
}
