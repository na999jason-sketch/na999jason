#pragma once
#include "SCRStateProjection.h"
#include <filesystem>
#include <string>
namespace PlutoSCR {
struct SnapshotReadResult {
  bool ok=false;
  SCRFrameSnapshot frame;
  std::string reason;
};
SnapshotReadResult readValidatedBridgeSnapshot(const std::filesystem::path& bridge);
}
