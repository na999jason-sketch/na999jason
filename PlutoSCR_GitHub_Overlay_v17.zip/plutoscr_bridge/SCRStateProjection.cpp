#include "SCRStateProjection.h"
#include <algorithm>
#include <cstring>
namespace PlutoSCR {
static void copyText(char* dst,size_t n,const std::string& s) {
  if(!n)return; const size_t m=std::min(n-1,s.size()); std::memcpy(dst,s.data(),m); dst[m]=0;
}
void projectValidatedSnapshot(const SCRFrameSnapshot& s,BWAPI::GameData& d) {
  d.frameCount=s.frame; d.isInGame=s.activeMatch; d.isPaused=s.paused; d.isReplay=s.replay;
  d.isMultiplayer=s.multiplayer; d.isBattleNet=s.battleNet;
  d.self=s.self; d.enemy=s.enemy; d.neutral=s.neutral;
  d.mapWidth=s.mapWidth; d.mapHeight=s.mapHeight;
  copyText(d.mapName,sizeof(d.mapName),s.mapName);
  copyText(d.mapFileName,sizeof(d.mapFileName),s.mapFileName);
  copyText(d.mapPathName,sizeof(d.mapPathName),s.mapPathName);

  d.playerCount=0;
  for(const auto& p:s.players) {
    if(p.id<0 || p.id>=12) continue;
    auto& q=d.players[p.id];
    q.race=p.race; q.type=p.type; q.force=p.force; q.minerals=p.minerals; q.gas=p.gas;
    q.isParticipating=p.participating; q.isNeutral=p.neutral;
    d.playerCount=std::max(d.playerCount,p.id+1);
  }

  d.initialUnitCount=0;
  for(const auto& u:s.units) {
    if(u.bwapiId<0 || u.bwapiId>=10000) continue;
    auto& q=d.units[u.bwapiId];
    q.id=u.bwapiId; q.player=u.player; q.type=u.type; q.positionX=u.x; q.positionY=u.y;
    q.hitPoints=u.hp; q.shields=u.shields; q.energy=u.energy; q.order=u.order;
    q.target=u.target; q.targetPositionX=u.targetX; q.targetPositionY=u.targetY;
    q.orderTarget=u.target; q.orderTargetPositionX=u.targetX; q.orderTargetPositionY=u.targetY;
    q.exists=u.exists; q.isCompleted=u.completed;
    for(bool& v:q.isVisible) v=false;
    if(s.self>=0 && s.self<9) q.isVisible[s.self]=u.visible;
    d.initialUnitCount=std::max(d.initialUnitCount,u.bwapiId+1);
  }
}
}
