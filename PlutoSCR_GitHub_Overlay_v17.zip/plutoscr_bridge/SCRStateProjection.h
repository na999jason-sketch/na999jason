#pragma once
#include <BWAPI/Client/GameData.h>
#include <cstdint>
#include <string>
#include <vector>

namespace PlutoSCR {
struct SCRUnitSnapshot {
  int bwapiId=-1, player=-1, type=-1;
  int x=0,y=0,hp=0,shields=0,energy=0,order=0;
  int target=-1,targetX=0,targetY=0;
  bool exists=false,completed=false,visible=false;
};
struct SCRPlayerSnapshot {
  int id=-1,race=-1,type=-1,force=-1;
  int minerals=0,gas=0;
  bool participating=false,neutral=false;
};
struct SCRFrameSnapshot {
  int frame=0;
  bool activeMatch=false,paused=false,replay=false,multiplayer=false,battleNet=false;
  int self=-1,enemy=-1,neutral=-1;
  int mapWidth=0,mapHeight=0;
  std::string mapName,mapFileName,mapPathName;
  std::vector<SCRUnitSnapshot> units;
  std::vector<SCRPlayerSnapshot> players;
};

// Only fields backed by a validated SC:R binding may be set.
// Unknown fields remain zero/false rather than fabricated.
void projectValidatedSnapshot(const SCRFrameSnapshot&, BWAPI::GameData&);
}
