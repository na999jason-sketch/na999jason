PlutoSCR v4 transport

This layer deliberately does NOT create Pluto observations.

x64 runtime:
  validated SC:R snapshot -> SCRStateProjection -> exact BWAPI::GameData shared mapping

x86 PlutoHost:
  BWAPIClient::GameImpl(GameData*) -> original pluto.dll

return path:
  original Pluto -> BWAPIClient UnitCommand/Command records -> BWAPICommandDrain
  -> RuntimeCommandRequest -> upstream RuntimeCommandEncoder -> proven resident sink

Important:
- state-dependent BWAPI commands are rejected until live SC:R state resolves their
  original BWAPI-specific order/selection semantics.
- unknown GameData fields are not fabricated.
- command output arrays are cleared only after x64 has copied them.
- frame state publication is intended to use Control.stateSequence as a seqlock.

Next live gate remains proof.issue_commands=passed on the exact SC:R build.
