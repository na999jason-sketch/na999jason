#include "ValidatedSnapshotReader.h"
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
namespace PlutoSCR {
static std::vector<std::string> tabs(const std::string& s) {
  std::vector<std::string> v; std::size_t a=0;
  for(;;){auto p=s.find('\t',a); if(p==std::string::npos){v.push_back(s.substr(a));break;} v.push_back(s.substr(a,p-a));a=p+1;} return v;
}
static bool readyHas(const std::filesystem::path& p,const std::string& line) {
  std::ifstream f(p); std::string s; while(std::getline(f,s)) if(s==line) return true; return false;
}
static std::string readyValue(const std::filesystem::path& p,const std::string& key) {
  std::ifstream f(p); std::string s, pre=key+"="; while(std::getline(f,s)) if(s.rfind(pre,0)==0) return s.substr(pre.size()); return {};
}
static int iv(const std::string& s,int fallback=0){try{return std::stoi(s,nullptr,0);}catch(...){return fallback;}}
SnapshotReadResult readValidatedBridgeSnapshot(const std::filesystem::path& bridge) {
  SnapshotReadResult r; const auto ready=bridge/"ready";
  if(!std::filesystem::is_regular_file(ready)){r.reason="ready file missing";return r;}
  if(!readyHas(ready,"mode=validated-runtime-adapter")){r.reason="bridge is not validated-runtime-adapter";return r;}
  if(!readyHas(ready,"proof.read_game_state=passed")){r.reason="read_game_state proof missing";return r;}
  if(!readyHas(ready,"proof.read_units=passed")){r.reason="read_units proof missing";return r;}
  if(!readyHas(ready,"proof.active_match_state=passed")){r.reason="active_match proof missing";return r;}

  // Frame identity is proof-backed by the resident active-match context.
  r.frame.activeMatch=true;
  r.frame.frame=iv(readyValue(ready,"resident.proof.active_match.frame"));

  const auto units=bridge/readyValue(ready,"proof.read_units.snapshot");
  std::ifstream uf(units); std::string line;
  if(!uf){r.reason="validated units snapshot missing";return r;}
  std::getline(uf,line);
  if(line!="index\tnode\tsecondary\tsprite\tid\tx\ty\ttarget_x\ttarget_y\torder\tstate\tplayer\ttype_hint\thit_points\tmetadata_source\thit_points_source"){
    r.reason="units snapshot schema mismatch"; return r;
  }
  while(std::getline(uf,line)){
    auto x=tabs(line); if(x.size()!=16) continue;
    SCRUnitSnapshot u;
    u.bwapiId=iv(x[4],-1); u.x=iv(x[5]); u.y=iv(x[6]); u.targetX=iv(x[7]); u.targetY=iv(x[8]);
    u.order=iv(x[9]); u.player=iv(x[11],-1); u.type=iv(x[12],-1);
    u.hp=(x[13]=="unresolved")?0:iv(x[13]); u.exists=true; u.completed=true; u.visible=true;
    r.frame.units.push_back(u);
  }

  const auto players=bridge/"players.snapshot.tsv";
  if(std::filesystem::is_regular_file(players) && readyHas(ready,"proof.read_player_data=passed")){
    std::ifstream pf(players); std::getline(pf,line);
    while(std::getline(pf,line)){
      auto x=tabs(line); if(x.size()!=10) continue;
      SCRPlayerSnapshot p; p.id=iv(x[0],-1); p.race=iv(x[2],-1); p.minerals=iv(x[5]); p.gas=iv(x[6]); p.participating=true;
      r.frame.players.push_back(p);
    }
  }

  const auto map=bridge/"map.snapshot.tsv";
  if(std::filesystem::is_regular_file(map) && readyHas(ready,"proof.read_map_data=passed")){
    std::ifstream mf(map); std::getline(mf,line); if(std::getline(mf,line)){auto x=tabs(line); if(x.size()>=3){r.frame.mapName=x[0];r.frame.mapPathName=x[2];}}
  }

  r.ok=!r.frame.units.empty();
  if(!r.ok) r.reason="validated snapshot contains no units";
  return r;
}
}
