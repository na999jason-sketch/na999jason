#pragma once
#include <cstdint>
#include <BWAPI/Client/GameData.h>

namespace PlutoSCR {
constexpr std::uint32_t Magic = 0x52534350; // PCSR
constexpr std::uint32_t Version = 4;
constexpr wchar_t ControlMapping[] = L"Local\\PlutoSCR_Control_v4";
constexpr wchar_t GameDataMapping[] = L"Local\\PlutoSCR_GameData_v4";

enum class State : std::uint32_t { Empty, RuntimeReady, HostReady, InGame, Stopping, Fault };

#pragma pack(push, 8)
struct Control {
  std::uint32_t magic;
  std::uint32_t version;
  volatile std::int32_t state;

  // Seqlock: odd while x64 runtime writes state; even when stable.
  volatile std::int32_t stateSequence;
  volatile std::int32_t publishedFrame;
  volatile std::int32_t consumedFrame;

  // x86 host increments after Pluto returns from callbacks.
  volatile std::int32_t commandSequence;
  volatile std::int32_t drainedCommandSequence;

  volatile std::int32_t lastCommandCount;
  volatile std::int32_t lastUnitCommandCount;
  volatile std::int32_t rejectedCommands;
  volatile std::int32_t lastError;
};
#pragma pack(pop)

static_assert(sizeof(BWAPIC::Command) == 12, "BWAPIClient Command ABI drift");
static_assert(sizeof(BWAPIC::UnitCommand) == 24, "BWAPIClient UnitCommand ABI drift");
}
