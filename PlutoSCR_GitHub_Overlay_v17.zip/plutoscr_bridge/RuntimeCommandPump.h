#pragma once
#include "BWAPICommandDrain.h"
#include <BWAPI/Runtime/RuntimeCommandEncoder.h>
#include <filesystem>
#include <string>
namespace PlutoSCR {
struct PumpResult { int accepted=0,rejected=0; std::string reason; };
PumpResult pumpCommandsToValidatedBridge(BWAPI::GameData&, const std::filesystem::path& bridge);
}
