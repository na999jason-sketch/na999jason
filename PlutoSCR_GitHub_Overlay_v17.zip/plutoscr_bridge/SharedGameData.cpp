#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include "PlutoSCRShared.h"
#include <cstring>

namespace PlutoSCR {
struct SharedGameData {
  HANDLE controlMap=nullptr, dataMap=nullptr;
  Control* control=nullptr;
  BWAPI::GameData* data=nullptr;

  bool createRuntime() {
    controlMap=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Control),ControlMapping);
    dataMap=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(BWAPI::GameData),GameDataMapping);
    if(!controlMap||!dataMap) return false;
    control=(Control*)MapViewOfFile(controlMap,FILE_MAP_ALL_ACCESS,0,0,sizeof(Control));
    data=(BWAPI::GameData*)MapViewOfFile(dataMap,FILE_MAP_ALL_ACCESS,0,0,sizeof(BWAPI::GameData));
    if(!control||!data) return false;
    std::memset(control,0,sizeof(*control));
    std::memset(data,0,sizeof(*data));
    control->magic=Magic; control->version=Version;
    InterlockedExchange(&control->state,(LONG)State::RuntimeReady);
    return true;
  }

  // Runtime owns state fields. It must never overwrite command output while host is executing.
  void beginStatePublish() {
    LONG s=InterlockedIncrement(&control->stateSequence);
    if((s&1)==0) InterlockedIncrement(&control->stateSequence);
    MemoryBarrier();
  }
  void endStatePublish(int frame) {
    MemoryBarrier();
    InterlockedExchange(&control->publishedFrame,frame);
    LONG s=InterlockedIncrement(&control->stateSequence);
    if((s&1)!=0) InterlockedIncrement(&control->stateSequence);
  }
};
}
