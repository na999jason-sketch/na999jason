#include "BWAPICommandDrain.h"
#include <BWAPI/UnitCommandType.h>
#include <BWAPI/Client/CommandType.h>

namespace PlutoSCR {
using BWAPI::Runtime::RuntimeCommandKind;
using BWAPI::Runtime::RuntimeCommandRequest;

static RuntimeCommandRequest unitReq(const char* name,const BWAPIC::UnitCommand& c) {
  RuntimeCommandRequest r; r.kind=RuntimeCommandKind::UnitCommand; r.name=name; return r;
}
static void target(RuntimeCommandRequest& r,const BWAPIC::UnitCommand& c) {
  r.targetUnitId=c.targetIndex;
}
static void xy(RuntimeCommandRequest& r,const BWAPIC::UnitCommand& c) { r.arguments={c.x,c.y}; }
static void extra(RuntimeCommandRequest& r,const BWAPIC::UnitCommand& c) { r.arguments={c.extra}; }

DrainResult drainBWAPIClientCommands(BWAPI::GameData& d) {
  DrainResult out;
  const int uc = d.unitCommandCount < 0 ? 0 :
                 (d.unitCommandCount > BWAPI::GameData::MAX_UNIT_COMMANDS ? BWAPI::GameData::MAX_UNIT_COMMANDS : d.unitCommandCount);
  for(int i=0;i<uc;++i) {
    const auto& c=d.unitCommands[i];
    RuntimeCommandRequest r;
    switch(c.type.getID()) {
      case BWAPI::UnitCommandTypes::Enum::Attack_Move: r=unitReq("Attack_Move",c); xy(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Attack_Unit: r=unitReq("Attack_Unit",c); target(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Move: r=unitReq("Move",c); xy(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Patrol: r=unitReq("Patrol",c); xy(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Follow: r=unitReq("Follow",c); target(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Right_Click_Position: r=unitReq("Right_Click_Position",c); xy(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Right_Click_Unit: r=unitReq("Right_Click_Unit",c); target(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Set_Rally_Position: r=unitReq("Set_Rally_Position",c); xy(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Set_Rally_Unit: r=unitReq("Set_Rally_Unit",c); target(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Train: r=unitReq("Train",c); extra(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Morph: r=unitReq("Morph",c); extra(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Research: r=unitReq("Research",c); extra(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Upgrade: r=unitReq("Upgrade",c); extra(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Build:
        // Runtime encoder additionally needs resolved build order; do not invent it.
        out.rejected.push_back("Build requires live buildOrder resolution"); continue;
      case BWAPI::UnitCommandTypes::Enum::Use_Tech: r=unitReq("Use_Tech",c); extra(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Use_Tech_Position:
        r=unitReq("Use_Tech_Position",c); r.arguments={c.x,c.y,c.extra}; break;
      case BWAPI::UnitCommandTypes::Enum::Use_Tech_Unit:
        r=unitReq("Use_Tech_Unit",c); target(r,c); r.arguments={c.extra}; break;
      case BWAPI::UnitCommandTypes::Enum::Cancel_Train_Slot:
        r=unitReq("Cancel_Train_Slot",c); extra(r,c); break;
      case BWAPI::UnitCommandTypes::Enum::Cancel_Train: r=unitReq("Cancel_Train",c); break;
      case BWAPI::UnitCommandTypes::Enum::Cancel_Morph: r=unitReq("Cancel_Morph",c); break;
      case BWAPI::UnitCommandTypes::Enum::Unload_All: r=unitReq("Unload_All",c); break;
      case BWAPI::UnitCommandTypes::Enum::Unload_All_Position:
        r=unitReq("Unload_All_Position",c); xy(r,c); break;
      default:
        out.rejected.push_back("unit command id "+std::to_string(c.type.getID())+" needs state-dependent normalization");
        continue;
    }
    out.requests.push_back(std::move(r));
  }

  const int gc = d.commandCount < 0 ? 0 :
                 (d.commandCount > BWAPI::GameData::MAX_COMMANDS ? BWAPI::GameData::MAX_COMMANDS : d.commandCount);
  for(int i=0;i<gc;++i) {
    const auto& c=d.commands[i];
    RuntimeCommandRequest r; r.kind=RuntimeCommandKind::GameAction;
    switch(c.type) {
      case BWAPIC::CommandType::PauseGame: r.name="pauseGame"; break;
      case BWAPIC::CommandType::ResumeGame: r.name="resumeGame"; break;
      case BWAPIC::CommandType::RestartGame: r.name="restartGame"; break;
      case BWAPIC::CommandType::PingMinimap: r.name="pingMinimap"; r.arguments={c.value1,c.value2}; break;
      case BWAPIC::CommandType::SetAllies: r.name="setAlliance"; r.arguments={c.value1}; break;
      case BWAPIC::CommandType::SetVision: r.name="setVision"; r.arguments={c.value1}; break;
      default:
        out.rejected.push_back("game action id "+std::to_string((int)c.type)+" is adapter-local or not turn-buffer encoded");
        continue;
    }
    out.requests.push_back(std::move(r));
  }

  // Ownership handoff: after x64 copied the records, release output slots for next Pluto frame.
  d.commandCount=0;
  d.unitCommandCount=0;
  d.shapeCount=0;
  d.stringCount=0;
  return out;
}
}
