#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <filesystem>
#include <iostream>
#include <string>
int main(int argc,char**argv) {
  DWORD pid=0; std::filesystem::path dll;
  for(int i=1;i<argc;++i) {
    std::string a=argv[i];
    if(a=="--process-id" && i+1<argc) pid=static_cast<DWORD>(std::stoul(argv[++i]));
    else if(a=="--adapter" && i+1<argc) dll=std::filesystem::absolute(argv[++i]);
  }
  if(pid==0 || dll.empty()) { std::cerr<<"usage: --process-id <pid> --adapter <dll>\n"; return 64; }
  const std::wstring path=dll.wstring();
  HANDLE process=OpenProcess(PROCESS_CREATE_THREAD|PROCESS_QUERY_INFORMATION|PROCESS_VM_OPERATION|PROCESS_VM_WRITE|PROCESS_VM_READ,FALSE,pid);
  if(!process) { std::cerr<<"OpenProcess failed error="<<GetLastError()<<"\n"; return 2; }
  const SIZE_T bytes=(path.size()+1)*sizeof(wchar_t);
  void* remote=VirtualAllocEx(process,nullptr,bytes,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
  if(!remote || !WriteProcessMemory(process,remote,path.c_str(),bytes,nullptr)) { std::cerr<<"remote path staging failed error="<<GetLastError()<<"\n"; CloseHandle(process); return 3; }
  auto loadLibrary=reinterpret_cast<LPTHREAD_START_ROUTINE>(GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"LoadLibraryW"));
  HANDLE thread=CreateRemoteThread(process,nullptr,0,loadLibrary,remote,0,nullptr);
  if(!thread) { std::cerr<<"CreateRemoteThread failed error="<<GetLastError()<<"\n"; VirtualFreeEx(process,remote,0,MEM_RELEASE); CloseHandle(process); return 4; }
  DWORD wait=WaitForSingleObject(thread,10000);
  CloseHandle(thread); VirtualFreeEx(process,remote,0,MEM_RELEASE); CloseHandle(process);
  if(wait!=WAIT_OBJECT_0) { std::cerr<<"resident load timed out\n"; return 5; }
  std::cout<<"resident.load_requested=true\n"; return 0;
}
