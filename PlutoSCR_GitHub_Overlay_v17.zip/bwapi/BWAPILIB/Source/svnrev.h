#pragma once
#define SVN_REV 0
#define SVN_REV_STR "PlutoSCR"
#define SVN_REVISION 0
#define SVN_REVISION_STR "PlutoSCR"
