#include <BWAPI/Runtime/RuntimeResidentLoader.h>

#include <filesystem>

namespace BWAPI::Runtime
{
  RuntimeResidentLoadPlan planRuntimeResidentAdapterLoad(
    const RuntimeResidentLoadRequest& request)
  {
    RuntimeResidentLoadPlan plan;
    #if defined(_WIN32)
    plan.loaderMode = "windows-resident-dll";
#else
    plan.loaderMode = "macos-resident-dylib";
#endif

    const RuntimeEnvironment& environment = request.environment;
#if defined(_WIN32)
    if (environment.platform != Platform::Windows)
      plan.errors.push_back("resident adapter DLL loader requires Windows");
#else
    if (environment.platform != Platform::MacOS)
      plan.errors.push_back("resident adapter loader requires macOS");
#endif
    if (environment.product != Product::StarCraftRemastered)
      plan.errors.push_back("resident adapter loader requires StarCraft Remastered");
    if (environment.processId <= 0)
      plan.errors.push_back("resident adapter loader requires a selected runtime process id");
    if (environment.executablePath.empty())
      plan.errors.push_back("resident adapter loader requires a selected runtime executable");
    if (environment.executorBridgePath.empty())
      plan.errors.push_back("resident adapter loader requires an executor bridge path");
    if (request.adapterPath.empty())
    {
      plan.errors.push_back("resident adapter loader requires an adapter dylib path");
    }
    else
    {
      std::error_code error;
      if (!std::filesystem::exists(request.adapterPath, error) || error)
        plan.errors.push_back("resident adapter shared-library path does not exist");
    }

    plan.valid = plan.errors.empty();
    return plan;
  }
}
