@echo off
setlocal
cd /d "%~dp0"
where msbuild >nul 2>nul
if errorlevel 1 (
  echo MSBuild not found. Run this from "Developer Command Prompt for VS 2022".
  pause
  exit /b 2
)
msbuild PlutoHost.vcxproj /m /p:Configuration=Release /p:Platform=Win32 /fl /flp:logfile=PlutoHost.build.log;verbosity=normal
if errorlevel 1 (
  echo BUILD_FAILED - send PlutoHost.build.log
  pause
  exit /b 1
)
echo BUILD_OK
pause
