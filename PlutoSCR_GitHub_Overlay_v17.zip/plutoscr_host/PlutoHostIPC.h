#pragma once
#include <cstdint>
namespace PlutoSCR {
static constexpr wchar_t kMappingName[] = L"Local\\PlutoSCR_BWAPI44_GameData_v1";
static constexpr wchar_t kControlName[] = L"Local\\PlutoSCR_BWAPI44_Control_v1";
static constexpr std::uint32_t kMagic = 0x52534350; // PCSR
static constexpr std::uint32_t kVersion = 1;
enum class HostState : std::uint32_t { Empty=0, RuntimeReady=1, HostReady=2, InGame=3, Stopping=4 };
#pragma pack(push, 1)
struct Control {
  std::uint32_t magic;
  std::uint32_t version;
  volatile std::uint32_t state;
  volatile std::uint32_t runtimeFrameSequence;
  volatile std::uint32_t hostFrameSequence;
  volatile std::uint32_t commandSequence;
  volatile std::uint32_t commandAckSequence;
  volatile std::uint32_t lastError;
  wchar_t plutoDllPath[520];
};
#pragma pack(pop)
}
