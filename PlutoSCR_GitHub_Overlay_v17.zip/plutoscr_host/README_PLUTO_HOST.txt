PlutoSCR x86 BWAPI 4.4 PlutoHost

Purpose:
- load the ORIGINAL 32-bit pluto.dll unchanged
- instantiate upstream BWAPIClient GameImpl (real BWAPI Game vtable)
- call original gameInit(Game*) and newAIModule()
- turn shared GameData events into original AIModule callbacks
- expose Pluto's standard BWAPIClient commands/shapes back to the x64 SC:R runtime

This deliberately avoids hand-reimplementing BWAPI::Game's 108 virtual methods.

Shared mappings:
Local\PlutoSCR_BWAPI44_GameData_v1 : exact BWAPI::GameData
Local\PlutoSCR_BWAPI44_Control_v1  : frame/command synchronization

Remaining x64 side:
populate exact GameData from validated SC:R state bindings, then consume
GameData.commands / unitCommands through RuntimeCommandEncoder + proven
resident command receiver.
