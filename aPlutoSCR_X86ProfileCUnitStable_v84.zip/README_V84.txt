aPlutoSCR v84 x86 Profile CUnit Stable Slots + ActiveTile

Purpose
- Port the original Pluto binary to 32-bit StarCraft: Remastered without replacing Pluto observation, inference, decision, or action generation.
- SC:R real state -> compatibility/legacy view -> original Pluto -> original Pluto command output.

v84 changes
- Stops using process-wide vector-shape scanning to discover CUnits.
- Reads the verified SC:R 1.23.10.13515 x86 profile directly:
  * CUnit pool pointer slot: analyzed VA 0x010436F0
  * CUnit pool length slot: analyzed VA 0x010436F4
  * active head: 0x010436A4
  * hidden head: 0x010436B4
  * scanner-sweep head: 0x010436B8
- Validates pool bounds, 336-byte stride, present units, and head membership before binding.
- Maintains 1700 stable legacy CUnit slots rather than compacting present units every refresh.
- Preserves legacy generation identifiers across reuse of a slot.
- Converts embedded CUnit pointers at offsets 0,4,20,92,104,108,112,124,128,236,240,244,252,284.
- Converts unit-specific union fields 192..216 only when the value is an actual live CUnit pointer.
- Converts SC:R sprites to the legacy 36-byte sprite view.
- Converts loaded-unit handles to legacy 11-bit-index + generation handles.
- Uses the real SC:R active/hidden/scanner heads instead of inferring list semantics.
- Keeps v82 real SCR Game shadow relocation and v83 real ActiveTileArray relocation.
- Existing pluto_infer.exe processes are rejected fail-closed before onStart.
- Command sink remains disabled until the real Pluto-generated command path is verified.

Original Pluto runtime layout
  pluto.dll
  pluto\pluto_infer.exe
  pluto\pluto_weights.bin

Expected v84 log milestones
  profile_cunit=BOUND_VALIDATED
  stable_cunit_slots.present=<live count>
  profile_heads.shadow.visible=<nonzero>
  reloc84.unit_table=PASS
  active_tile=BOUND_REAL_SCR
  original_pluto.onStart=PASS

The original Pluto model/files are not included and are not modified.
