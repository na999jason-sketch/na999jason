PlutoSCR v67 - x86 live CUnit integration runner
Original pluto.dll observation/inference code is unchanged.
This build binds a live legacy-layout CUnit store when present inside SC:R x86, then runs original Pluto lifecycle/frame callbacks.
SC:R command delivery remains fail-closed until a live synchronized command sink is resolved; v67 never writes guessed command addresses.
