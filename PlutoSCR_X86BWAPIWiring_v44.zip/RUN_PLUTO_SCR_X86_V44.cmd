@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set "INJECTOR=%ROOT%PlutoSCRX86Inject.exe"
set "RESIDENT=%ROOT%PlutoSCRX86V44.dll"
for %%F in ("%INJECTOR%" "%RESIDENT%" "%ROOT%pluto.dll" "%ROOT%pluto_infer.exe" "%ROOT%pluto_weights.bin") do (
 if not exist "%%~F" (echo [FAIL] missing: %%~F& pause& exit /b 1)
)
echo [PlutoSCR v44] Original Pluto lifecycle gate in x86 SC:R
"%INJECTOR%" "%RESIDENT%"
if errorlevel 1 (echo [FAIL] injection failed& pause& exit /b 2)
timeout /t 5 /nobreak >nul
if exist "%ROOT%plutoscr-x86-v44.log" type "%ROOT%plutoscr-x86-v44.log"
pause
